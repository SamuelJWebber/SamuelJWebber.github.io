"""Check overlap between raw/modified status partitions on every mixed-status day.
Single-status days are already checked by records == distinct timestamps in fetch_panel.py.
"""
import urllib.request,urllib.parse,json,pathlib,concurrent.futures,collections,time
p=pathlib.Path(__file__).parent
def check(sid):
 groups=collections.defaultdict(set)
 for r in json.loads((p/f'daily_{sid}.json').read_text()):groups[(r['day'],r['flowid'])].add(r['status'])
 dates=sorted({d for (d,f),statuses in groups.items() if len(statuses)>1})
 # Use dates only: fetch exact raw records for all channels on each potentially overlapping status day.
 date_filter=','.join("'"+d+"'" for d in dates)
 params={'$select':'timestamp,flowid,status,counts','$where':f"sensor_id='{sid}' AND date_trunc_ymd(timestamp) in ({date_filter}) AND travelmode='bike'",'$limit':50000}
 u='https://data.cityofnewyork.us/resource/ct66-47at.json?'+urllib.parse.urlencode(params)
 for attempt in range(3):
  try:
   a=json.load(urllib.request.urlopen(u,timeout=90));break
  except Exception:
   if attempt==2:raise
   time.sleep(1)
 (p/f'uniqueness_raw_{sid}.json').write_text(json.dumps(a))
 keys=collections.Counter((r['timestamp'],r['flowid']) for r in a);bad=[{'timestamp':k[0],'flowid':k[1],'multiplicity':v} for k,v in keys.items() if v>1]
 return sid,{'mixedStatusDays':len(dates),'rowsChecked':len(a),'duplicateTimestampFlowPairs':len(bad),'duplicates':bad,'query':u}
with concurrent.futures.ThreadPoolExecutor(3) as ex:results=dict(ex.map(check,['300020904','100062893','100009427']))
(p/'uniqueness-audit.json').write_text(json.dumps(results,indent=2));print(json.dumps({k:{a:b for a,b in v.items() if a!='query'} for k,v in results.items()}))
