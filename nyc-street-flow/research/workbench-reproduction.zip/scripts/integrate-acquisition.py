#!/usr/bin/env python3
"""Integrate verified acquisition ledgers without rerunning earlier study assembly."""
from pathlib import Path
import json, csv, sys

ROOT=Path(__file__).resolve().parent.parent
P=ROOT/'dist/research/global-study'
A=ROOT/'dist/research/acquisition'
S=Path(sys.argv[1]) if len(sys.argv)>1 else Path('/workspace/scratch/11076911f15a/acquisition')
d=json.loads((P/'global.json').read_text())
records=[]
for name in ['europe-ledger.json','us-uk-ledger.json','canada-ledger.json']:
    fragment=json.loads((S/name).read_text())
    records.extend(fragment if isinstance(fragment,list) else fragment['records'])
cases={c['id']:c for c in d['cases']}

def additional(id,city,dataset,status,rows,coverage,use,limit,next_step,case,bundle=None):
    item=dict(id=id,city=city,dataset=dataset,status=status,rows=rows,coverage=coverage,usable_for=use,limitation=limit,next_requirement=next_step,source_url=cases[case]['source_url'])
    if bundle:item['bundle']=bundle
    records.append(item)

additional('manchester-report-tables','Manchester','Oxford Road evaluation tables','downloaded_table','Published table extracts','Before/after dates vary by mode and site','Reconstruct published bicycle, bus and road-time comparisons','Underlying GPS runs, passenger loads and individual survey records have not been acquired; policy includes bus and access changes.','Acquire original observation files and consistent comparator records.','manchester-oxford-road','reproduction.zip')
additional('copenhagen-report-tables','Copenhagen','Nørrebrogade bus and bicycle time tables','downloaded_table','Published table extracts','2008 trial evaluation','Reconstruct reported route-period means','Not individual bus GPS records or passenger counts; one source arithmetic discrepancy is explicitly corrected.','Obtain vehicle run records, passenger loads and aligned control corridors.','copenhagen-norrebrogade-2008','reproduction.zip')
additional('bogota-bluetooth-history','Bogotá','Historical Bluetooth road-speed observations','source_only',0,'2020 intervention period discussed in the paper','Potential road-speed panel','The source and published study were located; underlying historical observations and a complete replication have not been acquired.','Obtain dated link-level observations and treatment mapping.','bogota_2020')
additional('davis-individual-count-time','Davis, California','Fifth Street original count and travel-time observations','not_publicly_found',0,'2014 conversion evaluation','Potential count and road-time replication','Published summaries are available; original observations and a clean comparison group have not been acquired.','Acquire underlying counts, timed runs and occupancy data.','davis_fifth_2014')
additional('sydney-panel-diaries','Sydney','George Street traveler panel diaries','source_only',0,'Published panel study','A design for measuring journeys across modes','Raw diaries have not been acquired; moving-lane conversion eligibility remains unverified.','Verify lane geometry and lawful availability of de-identified panel data.','sydney_george_2014')

records.sort(key=lambda r:(r['city'],r['dataset']))
assert len({r['id'] for r in records})==len(records)
for r in records:
    assert r['status'] in ['downloaded_raw','downloaded_table','source_only','blocked','not_publicly_found'],r
    for k in ['dataset','city','coverage','usable_for','limitation','source_url']: assert r.get(k),(r['id'],k)
    if r.get('bundle'): assert (P/r['bundle']).exists(),r['bundle']
acq=dict(checked_on='2026-11-06',summary='This audit separates actual downloads, published table extracts, sources located and remaining gaps. The new acquisition pass covers eight cities. These are source families and bounded extracts, not a claim that every potentially useful dataset is available or that a causal effect has been estimated.',records=records)
d['acquisition']=acq
d['checked_on']='2026-11-06'
d['summary']='We screened 19 street-reallocation cases in 13 cities and expanded actual data acquisition in eight cities. Downloaded records and published tables are separately labeled below. They improve measurement, but do not yet identify a causal effect on total person flow or complete journey time.'
d['findings'][0]['detail']='19 screened cases, including related designs and explicit exclusions. New acquisition packages cover eight cities; eligibility and causal readiness are separate.'

c=cases['berlin-popup-2020']
c['measurement']='Acquired all 24 monthly motor archives for 2019–2020: 4,532,392 hourly cross-section records. Published daily panel: 190,837 rows; candidate-road hourly extract: 309,085 rows. Bicycle archive: 456,118 counter-hour cells with provider quality flags preserved; 409,245 are unflagged numeric observations. Weather and project geometry also acquired.'
c['limit']+=' Existing bicycle counters are approximately 1.55–1.97 km from the three verified popup geometries; motor and bicycle counts cannot be added as an aligned crossing. Candidate-road matches are not verified treatment assignments. New archives have not yet been used to replicate the published model.'
c=cases['cambridge_mass_2021']
c['measurement']='Original evaluation tables plus raw Miovision intersection counts, selected MBTA AVL event records and historical APC boarding/alighting/onboard-load records acquired. Download includes exact query windows, source metadata and audit notes.'
c['limit']='The intervention combines bus and bike lanes. Miovision source identifiers use UTC timestamps while provisional clock-hour parsing did not; new rush-hour/count comparisons are withheld pending local-time normalization and padded date retrieval. MBTA APC seasonal averages are not matched-day passenger loads. RITIS individual road-time histories and car occupancy remain missing. No new aligned all-mode or complete-journey result is claimed.'
c=cases['london-blackfriars-2016']
c['measurement']='TfL cycling survey source files acquired for 23 waves across 2014–2017 (2,021,712 rows), including private/hire split, bridge/corridor extracts and comparison bridges. DfT estimation flags remain separately audited. Post-opening peak northbound report: cycle track 1,938 people/hour; main carriageway 1,542.'
c['limit']+=' Newly acquired 16-hour survey waves can combine different clock-hour slots observed on different dates, so they are not complete independent daily counts. The raw passenger-occupancy inputs behind the reported +5% throughput claim remain unacquired.'
c=cases['toronto-bloor-2016']
c['measurement']+=' Additional open-data 15-minute intersection turning counts around Bloor, Dupont and Harbord acquired; these queried records are not verified as the original 11-site pilot observations.'
c=cases['vancouver-burrard-2009']
c['measurement']+=' Extended 2009–2012 daily bicycle records and 2008/2011 TransLink screenline/occupancy tables now acquired.'
c['limit']=c['limit'].replace('Vehicles are not people; bus loads and changing car occupancy remain unknown. Other False Creek crossings and transit shifts are not reconstructed.','Vehicles are not people. New 2008/2011 occupancy and passenger tables add context, but road counts span 16 hours and transit counts 9 hours; they cannot be summed into a common-window total. Canada Line opening is a major co-intervention. Aligned other-crossing daily counts are still missing.')+' The extended bicycle source disagrees with the original on 2010-06-29 (40,358 versus 4,420); the discrepancy is preserved and flagged.'
c=cases['calgary-cycle-track-network-2015']
c['measurement']+=' Annual 2012–2019 downtown cordon records and original workbooks also acquired, with person/mode definitions recorded. These cover a wider boundary than the project count sites.'
c['limit']+=' A citywide cordon series is not an untreated comparator or a bike-lane-specific causal estimate.'
for id in ['paris-rivoli-2020','paris-voltaire-2017-2019']:
    c=cases[id]
    c['measurement']+=' Historical 2016–2020 bicycle and road-loop archives now downloaded, with selected Rivoli/Voltaire bicycle rows published and original archive hashes/URLs retained.'
    c['limit']+=' Rivoli bicycle counter location changes between the early and later archives; 2018 has no selected Rivoli observations. Road-loop occupancy is detector occupancy, not car passenger occupancy. Historical archives require quality and geometry alignment before any effect estimate.'
cases['paris-voltaire-2017-2019']['finding']='Treatment staging and historical archives are acquired; a validated aligned outcome panel and causal comparison have not yet been assembled.'
c=cases['seattle_second_2014']
c['measurement']+=' Public Second Avenue and Fremont hourly counters plus selected motor count bins acquired. The Second Avenue retrieved series begins in 2015 and supplies no pre-opening 2014 baseline.'
c=cases['seattle_west_marginal_2023']
c['measurement']='Primary SDOT summary, selected motor count bins and nearby Spokane Street hourly counter records acquired. The Spokane counter is a different measurement boundary; it is not a substitute for West Marginal same-site counts.'

for f in [{'label':'Acquisition ledger','file':'../acquisition/ledger.json'},{'label':'Acquisition notes and gaps','file':'../acquisition/README.txt'}]:
    if not any(x['file']==f['file'] for x in d['downloads']):d['downloads'].append(f)
A.mkdir(parents=True,exist_ok=True)
(A/'ledger.json').write_text(json.dumps(acq,indent=2,ensure_ascii=False)+'\n')
fields=['id','city','dataset','status','rows','coverage','usable_for','limitation','next_requirement','source_url','bundle']
with (A/'ledger.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(records)
(P/'global.json').write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'records':len(records),'statuses':{s:sum(r['status']==s for r in records) for s in sorted({r['status'] for r in records})},'cities':sorted({r['city'] for r in records})}))
