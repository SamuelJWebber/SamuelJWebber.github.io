#!/usr/bin/env python3
"""Refresh hashes and reproduction bundles from final checked source files."""
from pathlib import Path
import hashlib,json,zipfile
R=Path(__file__).resolve().parent.parent
P=R/'dist/research/global-study'
A=R/'dist/research/acquisition'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest={str(p.relative_to(A)):sha(p) for p in sorted(A.rglob('*')) if p.is_file() and p.name!='manifest.json'}
(A/'manifest.json').write_text(json.dumps({'checked_on':'2026-11-06','sha256':manifest},indent=2)+'\n')
files=[p for p in sorted(P.rglob('*')) if p.is_file() and p.suffix!='.zip' and p.name!='manifest.json']
(P/'manifest.json').write_text(json.dumps({'checked_on':'2026-11-06','sha256':{str(p.relative_to(P)):sha(p) for p in files}},indent=2)+'\n')
with zipfile.ZipFile(P/'reproduction.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in files+[P/'manifest.json']:z.write(p,p.relative_to(P))
W=R/'dist/research/workbench-reproduction.zip'
with zipfile.ZipFile(W) as z:names=set(z.namelist())
names.update(['scripts/integrate-acquisition.py','scripts/refresh-research-packages.py','scripts/verify-acquisition.py'])
names.update(str(p.relative_to(R)) for p in A.glob('*') if p.is_file() and p.suffix in ['.json','.csv','.txt'])
names.update(str(p.relative_to(R)) for p in (R/'dist/research/validation').glob('acquisition-*') if p.is_file())
names.discard('dist/research/workbench-manifest.json')
files=[R/n for n in sorted(names) if (R/n).is_file() and (R/n).suffix!='.zip']
manifest=R/'dist/research/workbench-manifest.json'
manifest.write_text(json.dumps({'date':'2026-11-06','note':'Acquisition city data ZIPs are linked separately; not duplicated in this bundle.','sha256':{str(p.relative_to(R)):sha(p) for p in files}},indent=2)+'\n')
with zipfile.ZipFile(W,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in files+[manifest]:z.write(p,p.relative_to(R))
print(json.dumps({'global_files':len(files),'acquisition_files':len(list(A.rglob('*'))),'workbench_bytes':W.stat().st_size}))
