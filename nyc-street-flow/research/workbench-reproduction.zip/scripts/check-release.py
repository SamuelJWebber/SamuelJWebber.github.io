#!/usr/bin/env python3
from pathlib import Path
import subprocess,json,zipfile,re,hashlib
ROOT=Path(__file__).resolve().parent.parent
D=ROOT/'dist'
checks=[]
for p in D.glob('*.mjs'):
 subprocess.run(['node','--check',str(p)],check=True,capture_output=True)
checks.append({'check':'JavaScript syntax','files':len(list(D.glob('*.mjs'))),'passed':True})
for command in [
 ['node','tests/network-time.test.mjs'],
 ['node','tests/global-evidence.test.mjs'],
 ['python','scripts/verify-acquisition.py'],
 ['python','dist/research/global-study/verify.py'],
 ['python','dist/research/causal-design/verify.py'],
 ['node','dist/research/estimate-lab/test.mjs'],
 ['node','dist/research/network-map/verify-map.mjs'],
 ['node','dist/research/validation/independent_math_audit.mjs'],
 ['python','dist/research/validation/independent_data_audit.py']]:
 r=subprocess.run(command,cwd=ROOT,check=True,capture_output=True,text=True)
 checks.append({'check':' '.join(command),'passed':True})
for p in D.rglob('*.zip'):
 with zipfile.ZipFile(p) as z: assert z.testzip() is None,p
checks.append({'check':'All downloadable ZIP integrity','passed':True,'files':len(list(D.rglob('*.zip')))})
for f in ['index.html','workbench.mjs','network-map.mjs','network-time.mjs','estimate-lab.mjs','project-scorecards.mjs','directional-evidence.mjs','causal-design.mjs','global-evidence.mjs']:
 s=(D/f).read_text()
 for v in re.findall(r'(?:src|href)="([^"?#$]+)"',s):
  if ':' not in v and not v.startswith('#') and '${' not in v: assert (D/v).exists(),(f,v)
checks.append({'check':'Literal local asset and download targets','passed':True})
report={'date':'2026-11-06','scope':'Release checks; no inference of causal validity. Browser checks separately documented.','checks':checks,'passed':True}
(D/'research/validation/release-checks.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
