#!/usr/bin/env python3
from pathlib import Path
import json,zipfile,gzip,io,csv
R=Path(__file__).resolve().parent.parent
P=R/'dist/research/global-study'
A=R/'dist/research/acquisition'
ledger=json.loads((A/'ledger.json').read_text())
assert json.loads((P/'global.json').read_text())['acquisition']==ledger
records=ledger['records']
assert len(records)==36 and len({r['id'] for r in records})==36
for r in records:
    assert r['source_url'].startswith('https://')
    if r.get('bundle'): assert (P/r['bundle']).is_file()
zips=sorted(A.glob('*-data.zip'))
assert len(zips)==8
for p in zips:
    with zipfile.ZipFile(p) as z:
        assert z.testzip() is None,p
        assert any('README' in n for n in z.namelist()),p
        if p.name=='vancouver-data.zip':
            assert not any(n.lower().endswith('.pdf') for n in z.namelist())
        if p.name=='cambridge-data.zip':
            assert not any('same_window' in n for n in z.namelist())
        for n in z.namelist():
            if n.endswith('.gz'):
                with gzip.GzipFile(fileobj=io.BytesIO(z.read(n))) as f:
                    while f.read(1024*1024):pass
report={'checked_on':'2026-11-06','passed':True,'ledger_entries':len(records),'city_packages':len(zips),'checks':['Dashboard and downloadable ledger agree','Every bundle target exists','ZIP CRC and gzip integrity','Restricted original TransLink reports excluded','Provisional Cambridge comparisons excluded'],'scope':'Acquisition and presentation checks, not causal validation.'}
(R/'dist/research/validation/acquisition-checks.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
