from pathlib import Path
import json,csv,shutil,hashlib,zipfile,sys
ROOT=Path(__file__).resolve().parent.parent
D=ROOT/'dist/research/global-study';D.mkdir(exist_ok=True)
S=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else D
def read(p):return json.loads((S/p).read_text())
def rows(p):return list(csv.DictReader((S/p).open()))
def join(x):return ' '.join(x) if isinstance(x,list) else x or ''
def case(id,city,project,region,eligibility,status,treatment,timing,measurement,identification,finding,limit,priority,source,outcomes):
 return dict(id=id,city=city,project=project,region=region,eligibility=eligibility,status=status,treatment=treatment,timing=timing,measurement=measurement,identification=identification,finding=finding,limit=limit,priority=priority,source_url=source,outcomes=outcomes)
cases=[]
for c in read('canada/candidates.json'):
 elig='Verified moving-lane reallocation; audit block and time-of-day geometry before pooling.' if c['lane_conversion_verified'] is True else 'Mixed or unverified moving-lane treatment. Keep outside the strict cohort until segment geometry is audited.'
 cases.append(case(c['id'],c['city'],c['project'],'Canada',elig,c['evidence_tier'],c.get('treatment_detail',c['treatment_type']),c['treatment_date']+'; '+c.get('date_precision',''),c.get('data_coverage',c['improvement_over_nyc']),c.get('controls','No verified comparison panel.'),c['observed_result'],join(c['key_limitations']),'Priority acquisition' if c['priority']==1 else 'Screened comparator',c['sources'][0]['url'],['flow','time','cycling']))
for c in read('europe/candidates.json'):
 finding=c['published_findings'] or ('A full 168-hour post-opening week was downloaded, with six vehicle classes and no duplicate record keys. This camera starts after the intervention, so it cannot supply the missing baseline.' if c['id']=='paris-rivoli-2020' else 'Treatment and staged implementation documented; an aligned outcome panel has not yet been acquired.')
 cases.append(case(c['id'],c['city'],c['corridor'],'Europe','Moving-road-space reallocation documented; exact segment dates and geometry require final audit.',c['readiness'],c['treatment_type'],c['treatment_start']+' to '+c['treatment_end']+'. '+c['treatment_date_precision'],join(c['outcomes_available']),('Proposed, not yet run; no aligned panel acquired. ' if c['id']=='paris-voltaire-2017-2019' else '')+c['comparison_design'],finding,join(c['limitations']),c['priority'],c['sources'][0]['url'],['flow','time'] if 'berlin' in c['id'] else ['flow','cycling']))
uk=read('uk/candidates.json')
c=uk[0]
cases.append(case('london-blackfriars-2016','London',c['project'],'UK','Moving-lane replacement documented in official scheme drawings; not a uniform four-to-two conversion.','Person-flow benchmark; causal result unresolved','Protected cycling, junctions, turn bans, signals and bus-stop changes.','Opened May 2016; construction during 2015–2016.','TfL peak northbound counts: cycle track 1,938 people/hour; main carriageway 1,542. DfT raw/manual counts and estimation-quality flags acquired.',c['causal_design'],'At this post-opening point and hour, the cycle track carried more people than the remaining main carriageway. TfL’s +5% initial throughput claim averages two locations; its before/after calculation was not reproducible from retrieved attachments.',join(c['limitations']),'Best person-flow benchmark; missing counterfactual',c['urls'][0],['flow','time','cycling']))
c=uk[1]
cases.append(case('manchester-oxford-road','Manchester',c['project'],'UK','Bundled corridor reallocation with bus gates and changes to a parallel road. Keep separate from bike-only conversion.','Original multimodal evaluation acquired',c['treatment']['moving_lane_conversion'],'Main enforcement September 2017; bus June 2013 vs June 2018, bike March 2015 vs March 2019.','Bus running times, cycle/pedestrian counts, seven years of cycling totals, and GPS times on diversion road versus four radial comparators.',c['causal_design'],'Cycling counts rose at all four main sites. MRI-to-city local buses became 16.2% slower in the AM and 15.2% slower in the PM; reverse-direction changes were small. Estimated through-trip benefits also include removal of an assumed interchange penalty.',join(c['limitations']),'Strong network and bus measurement',c['urls'][0],['flow','time','cycling']))
for c in read('other/candidates.json'):
 region='Latin America' if c['country']=='Colombia' else 'Australia' if c['country']=='Australia' else 'United States'
 elig=('Moving-lane loss documented: '+c['before_general_lanes']+' → '+c['after_general_lanes']+'.') if c['lane_conversion_verified'] else 'Excluded from strict conversion cohort: moving-lane loss unverified.'
 outcomes=['time','cycling']
 if 'bogota' in c['id']:outcomes=['time']
 if 'cambridge' in c['id'] or 'seattle' in c['id']:outcomes=['flow','time','cycling']
 if 'sydney' in c['id']:outcomes=['cycling']
 cases.append(case(c['id'],c['city'],c['corridor'],region,elig,c['tier'].replace('_',' '),c['bike_change']+'; '+c['treatment_class'].replace('_',' '),c['opening']+'. '+c['windows'],c['public_data'],c['identification']+' '+c['controls'],c['findings'], '; '.join(c['main_risks'])+'. '+c['next_step'],'Acquired tables' if 'cambridge' in c['id'] else 'Screened comparator',c['sources'][0]['url'],outcomes))
cases.extend(read('copenhagen/candidates.json'))
# Prominent cases first; retain failed screens so selection is visible.
order=['toronto-bloor-2016','vancouver-burrard-2009','cambridge_mass_2021','berlin-popup-2020','london-blackfriars-2016','manchester-oxford-road','paris-rivoli-2020','copenhagen-norrebrogade-2008','bogota_2020','calgary-cycle-track-network-2015','vancouver-burrard-1996']
cases.sort(key=lambda c: order.index(c['id']) if c['id'] in order else 100)
comparisons=[]
def comp(id,title,unit,rr,note,source,subtitle='',chart=True):
 comparisons.append(dict(id=id,title=title,subtitle=subtitle,unit=unit,rows=rr,note=note,source_url=source,chart=chart))
def row(label,b,a,note=''):return dict(label=label,before=b,after=a,change=round(a-b,6),note=note)
url=read('canada/candidates.json')[0]['sources'][1]['url']
for mode in ['bicycles','motor vehicles']:
 data=rows('canada/bloor-daily-counts.csv'); actualmode=mode if any(r['mode']==mode for r in data) else 'motor_vehicles'
 rr=[]
 for road in ['Bloor','Dupont','Harbord']:
  found={r['wave']:float(r['count']) for r in data if r['corridor']==road and r['mode']==actualmode}
  if not found:continue
  rr.append(row(road,found['2016-06'],found['2017-06'],'Nearby routes can receive diversion; corridor means use different counting locations.'))
 if rr:comp('toronto-'+actualmode,'Toronto: '+mode+' on three corridors','average daily '+mode,rr,'June 2016 versus June 2017, three consecutive weekdays per corridor. These are averages across sites, not aligned unique crossings. Bicycle corridor-mean index increases 4.17%, much less than Bloor’s 48.84%; this is consistent with substantial rerouting but does not identify how many people changed modes.',url)
# Actual daily raw observations, with fragile-window alternatives kept beside main results.
drive=rows('canada/bloor-driving-times.csv'); rr=[]
for road in ['Bloor','Dupont','Harbord']:
 for period,direction in [('AM','EB'),('PM','WB')]:
  f={r['wave']:float(r['seconds']) for r in drive if r['corridor']==road and r['peak']==period and r['direction']==direction}
  rr.append(row(road+' '+period+' '+direction,f['2016-06'],f['2017-06'],'Measured corridor run; nearby roads may receive diverted traffic.'))
comp('toronto-driving','Toronto: peak-direction driving times','seconds',rr,'June 2016 versus June 2017. Three weekdays of GPS runs per corridor. Bloor increased 2 minutes in the AM eastbound and 4 minutes 15 seconds in the PM westbound. These are route components, not full commutes or person-weighted network time.',url)
for mode,title in [('total_bicycles','bicycle'),('total_vehicles','motor-vehicle'),('total_pedestrians','pedestrian')]:
 rr=[]
 for r in rows('canada/burrard-matched-summary.csv'):
  if r['metric']==mode:
   label={'all_modes_14_day_pairs':'14-day offset / 6 complete pairs','bike_vehicle_28_day_pairs':'28-day offset / 11 bike–vehicle pairs','immediate_four_weekdays_sensitivity':'7-day offset / 4 immediate weekday pairs'}[r['window']]
   rr.append(row(label,float(r['before_daily_mean']),float(r['after_daily_mean']),f"{float(r['change_pct']):+.2f}%; alternative windows are not independent studies."))
 comp('vancouver-'+title,'Vancouver: '+title+' counts and window sensitivity','recorded '+title+' passages/day',rr,'Daily bridge counts around July 13, 2009 conversion. Pairs match weekday and exclude missing/event-comment dates; primary window also requires all three modes. Short before period, no weather or comparison-road adjustment. No causal effect or total-person-flow claim.',read('canada/candidates.json')[1]['sources'][0]['url'])
for window in ['2019_to_2022','2021_near_opening']:
 data=[r for r in rows('other/cambridge_road_times.csv') if r['window']==window and r['period'] in ['full_day','16:00-18:00']]
 if data:
  comp('cambridge-road-'+window,'Cambridge: road times '+('2019 → 2022' if window=='2019_to_2022' else 'immediately before → after'),'minutes', [row(r['road']+' '+r['direction']+' '+r['period'],float(r['before']),float(r['after']),r['role']+'; source means rounded to 0.1 min.') for r in data], 'Mass Ave treatment includes bus lanes and signal changes. Broadway is the agency’s nonparallel comparison; verified parallel pre-trends and daily observations are still missing. Different directions cannot simply be paired as exchangeable controls. All-day means do not weight traveler loads.',data[0]['source_url'],subtitle='Tuesday–Thursday observations: '+('April 30–May 9, 2019 versus May 3–12, 2022.' if window=='2019_to_2022' else 'November 2–4 versus December 14–16, 2021.'))
data=rows('other/cambridge_bus_times.csv')
comp('cambridge-bus','Cambridge: bus-link running times','seconds',[row(r['origin']+' → '+r['destination'],float(r['before']),float(r['after']),r['direction']+'; average of time-of-day medians.') for r in data],'May 2019 versus May 2022. Six links from Tables 12/13. Bus lanes are a direct co-intervention; no claim these gains are caused by cycling infrastructure alone. Not complete commutes, and links must not be summed as independent trips.',data[0]['source_url'])
data=rows('uk/manchester_bus_time_calculations.csv');data=[r for r in data if r['measure']=='local observed bus time']
comp('manchester-bus','Manchester: observed local bus times','seconds',[row(r['direction']+' '+r['time_period'],float(r['before_seconds']),float(r['after_seconds']),f"{float(r['calculated_change_percent']):+.1f}%") for r in data],'June 2013 versus June 2018. These observed local segment times are distinct from estimated through-trip benefits that remove an assumed 11-minute interchange. Package changes, not bike-only effects.',data[0]['source'])
mc=read('uk/comparisons.json')[1]
comp('manchester-bikes','Manchester: cycling at four counting sites','cycles counted 06:00–21:00',[row(r['site'],r['before'],r['after'],'One survey day per wave; sites can count the same rider.') for r in mc['sites']],'March 2015 versus March 2019, Table 5.9. Local counts grew strongly, but these sites are not a nonduplicating boundary and have no untreated cycling comparison. Do not add the rows to estimate new trips.',uk[1]['urls'][0])
comparisons.extend(read('copenhagen/comparisons.json'))
# Same-time London comparison is intentionally not dressed as a before/after chart.
comp('london-person-flow','London: post-opening peak person flow','people/hour',[{'label':'Northbound cycle track','before':'No aligned baseline acquired','after':1938,'change':'Not estimated','note':'Observed 08:00–09:00 snapshot.'},{'label':'Northbound main carriageway','before':'No aligned baseline acquired','after':1542,'change':'Not estimated','note':'Includes reported carriageway person estimate; not just cars.'}],'TfL evidence pack, page 17. This establishes observed use per facility at one peak hour, not causal network throughput. The 5× claim is normalized by road space; 1,938 is not five times 1,542. The +18% claim is modelled capacity, not observed flow.',uk[0]['urls'][0],chart=False)
# Registry: conditional published estimates, never labelled newly reproduced.
studies=[]
for p in read('methods/papers.json')['papers']:
 studies.append(dict(id=p['id'],name=p['title']+' ('+str(p['year'])+')',coverage=p['geography']+'. '+p['observed_sample'],outcome=', '.join(p['outcomes']),finding=p['reported_result'],limit=p['moving_lane_conversion']+' '+join(p['limits'])+' '+p['replication_status'],url=p['source_url']))
strategies=[
 ('Separate policy classes before estimating','Build a strict moving-lane conversion cohort, a bike-and-bus redesign cohort, and a mechanism-only group. Verify as-built lanes, opening dates and construction windows by segment. Parking-only projects do not answer the same question.'),
 ('Prioritize three complementary panels','Vancouver for all-bike, pedestrian and vehicle counts at one boundary; Toronto for route diversion; Berlin for high-frequency motor counts and speeds with control sites. Cambridge and Manchester strengthen bus and network-time measurement. No city currently supplies every required outcome.'),
 ('Measure the network, including subway substitution','Use a fixed, nonduplicating boundary across affected routes. Add onboard bus and rail passengers crossing it, observed vehicle occupancy and all-bike/pedestrian counts in the same hours. Station entries and boardings are not onboard boundary loads.'),
 ('Make the counterfactual pass explicit tests','Select untreated roads by pre-treatment demand, capacity and trends; use modern staggered adoption or synthetic-control designs, placebo dates, alternative donors and spillover buffers. Cluster at the corridor/network intervention level. Nearby diversion routes are outcomes, not automatic controls.'),
 ('Keep journey time and access as separate outcomes','Follow fixed origin–destination and time-of-day cohorts across mode changes. Include access, waiting and transfer time; report person-weighted mean and reliability. Report completed trips and access alongside total minutes so suppressed travel cannot masquerade as a benefit.'),
 ('Pool only after measurement and identification pass','No common causal estimate is produced yet. After passing gates, pool compatible within-city effects with uncertainty and leave-one-city-out checks; account for shared datasets and report heterogeneity by transit supply, occupancy, baseline congestion, weather and adaptation. Reweight to NYC only where those conditions overlap.')]
dictdata=dict(checked_on='2026-11-05',title='A wider study pool. A sharper test.',summary='We screened real street reallocations across cities, acquired raw counts and original evaluation tables, and retained unfavorable and inconclusive results. The stronger evidence answers individual parts of the question; it still does not identify one universal effect on all-mode person flow or complete journey time.',findings=[dict(label='Geographic expansion',value=f"{len(set(c['city'] for c in cases))} cities · {len(cases)} cases",detail='A curated screen, including related designs and explicit exclusions. Not every case is eligible or analysis-ready.'),dict(label='Observed outcomes',value='Mixed, by mode',detail='Large treated-route cycling gains can coexist with rerouting, slower driving or faster buses. Keep each outcome visible.'),dict(label='Causal all-mode estimate',value='Not yet identified',detail='Raw data and controlled studies improve the starting point. Passenger loads, comparable boundaries and credible counterfactuals remain gates.')],cases=cases,studies=studies,comparisons=comparisons,strategy=[dict(title=a,detail=b) for a,b in strategies],downloads=[dict(label='Evidence and data package',file='reproduction.zip'),dict(label='Methods and acquisition priorities',file='README.txt'),dict(label='Full case registry',file='global.json'),dict(label='Causal pooling protocol',file='methods/transportability-protocol.txt')])
(D/'global.json').write_text(json.dumps(dictdata,ensure_ascii=False,indent=2)+'\n')
# Preserve small raw files, exact transcriptions and acquisition audit. Bulky original reports stay linked by URL/hash.
for folder in ['canada','europe','uk','other','methods','copenhagen']:
 dest=D/folder;dest.mkdir(exist_ok=True)
 for f in (S/folder).iterdir():
  if not f.is_file() or f.suffix in ['.pdf','.docx','.png','.html','.bin','.zip','.js'] or f.name in ['berlin-study.txt','bhuyan.txt','evaluation-2008.txt']:continue
  if f.resolve()!=(dest/f.name).resolve():shutil.copy2(f,dest/f.name)
if S.resolve()!=D.resolve():shutil.copy2(S/'methods/kraus-koch-zenodo.zip',D/'methods/kraus-koch-zenodo.zip')
print(json.dumps({'cases':len(cases),'cities':len(set(c['city'] for c in cases)),'comparisons':len(comparisons),'studies':len(studies)},indent=2))
