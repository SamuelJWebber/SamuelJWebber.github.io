// In-memory interaction and contract checks; this is not browser/layout QA.
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {renderGlobalEvidence} from '../dist/global-evidence.mjs';

const escape=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
class Element {
  constructor(){this.innerHTML='';this.textContent='';this.value='';this.events={};}
  addEventListener(name,callback){this.events[name]=callback;}
  focus(){}
}
async function mount(data,query=''){
  globalThis.location={href:`https://streetflow.example/?workbench=world&project=ppw${query}#global-evidence`,origin:'https://streetflow.example'};
  globalThis.history={replaceState(_a,_b,u){location.href=String(u);}};
  globalThis.CSS={escape:value=>value};
  globalThis.fetch=async()=>({ok:true,json:async()=>data});
  const elements=new Map(),root=new Element();
  root.classList={add(){}};
  root.querySelector=selector=>{
    if(!elements.has(selector))elements.set(selector,new Element());
    return elements.get(selector);
  };
  await renderGlobalEvidence(root);
  return {root,get:selector=>root.querySelector(selector),params:()=>new URL(location.href).searchParams};
}
const fixture={
  checked_on:'2026-11-05',title:'Test <script>',summary:'Separate outcomes',
  findings:[{label:'Coverage',value:'2 cases',detail:'No pooled effect'}],
  cases:[
    {id:'toronto',city:'Toronto',project:'Bloor',region:'Canada',outcomes:['cycling','time'],eligibility:'Moving lane removed',status:'Observed',treatment:'Two lanes become one',timing:'2016',measurement:'Counts',identification:'No clean control',finding:'More bikes',limit:'Missing transit',priority:'Next study',source_url:'https://www.toronto.ca/test'},
    {id:'london',city:'London',project:'Blackfriars',region:'UK',outcomes:['flow'],eligibility:'Moving lane removed',status:'Reported estimate',treatment:'Bike track',timing:'2016',measurement:'Passenger counts',identification:'Before/after',finding:'Reported throughput',limit:'Raw source unavailable',source_url:'javascript:alert(1)'}
  ],
  comparisons:[
    {id:'counts',title:'Counts',unit:'cycles/day',rows:[{label:'Bikes',before:100,after:125,change:25,note:'Observed'}],note:'Not causal',source_url:'https://example.org/'},
    {id:'strings',title:'Duration strings',unit:'minutes',rows:[{label:'Timing',before:'10:00',after:'11:00',change:'+1 minute'}],note:'No chart'},
    {id:'mixed',title:'Mixed numeric units',unit:'seconds',rows:[{label:'Time',before:60,after:70},{label:'Count',before:200,after:210,unit:'people'}],note:'No chart'}
  ],
  studies:[{id:'a',name:'Paper',coverage:'100 cities',outcome:'Bikes',finding:'Increase',limit:'Not all modes',url:'https://example.org/paper'}],
  strategy:[{title:'Align',detail:'Same outcome'}],downloads:[]
};
const f=await mount(fixture,'&worldCase=london&worldRegion=UK&worldComparison=counts');
assert(f.root.innerHTML.includes('Test &lt;script&gt;'));
assert(!f.root.innerHTML.includes('Test <script>'));
assert.equal(f.get('#world-case-count').textContent,'1 of 2 cases · UK');
assert(f.get('#world-case-detail').innerHTML.includes('Blackfriars'));
assert(!f.get('#world-case-detail').innerHTML.includes('javascript:'));
assert(f.get('#world-comparison-detail').innerHTML.includes('world-bars'));
f.get('#world-region').events.change({target:{value:'Canada'}});
assert(f.get('#world-case-detail').innerHTML.includes('Bloor'));
assert.equal(f.params().get('worldCase'),'toronto');
assert.equal(f.params().get('project'),'ppw');
f.get('#world-outcome').events.change({target:{value:'flow'}});
assert(f.get('#world-case-detail').innerHTML.includes('No cases match'));
assert(!f.params().has('worldCase'));
f.get('#world-region').events.change({target:{value:''}});
assert(f.get('#world-case-detail').innerHTML.includes('Blackfriars'));
for(const id of ['strings','mixed']){
  f.get('#world-comparison').events.change({target:{value:id}});
  assert(!f.get('#world-comparison-detail').innerHTML.includes('world-bars'));
  assert.equal(f.params().get('worldComparison'),id);
}

const actual=JSON.parse(await readFile(new URL('../dist/research/global-study/global.json',import.meta.url),'utf8'));
for(const key of ['cases','comparisons','studies']){
  assert(Array.isArray(actual[key]),`${key} must be an array`);
  assert.equal(new Set(actual[key].map(x=>x.id)).size,actual[key].length,`${key} IDs must be unique`);
}
for(const c of actual.cases){
  for(const field of ['id','city','project','region','eligibility','status','treatment','timing','measurement','identification','finding','limit'])assert.equal(typeof c[field],'string',`${c.id}.${field}`);
  assert(c.outcomes.every(o=>['flow','time','cycling'].includes(o)),c.id);
}
const a=await mount(actual);
assert.equal(a.get('#world-case-count').textContent,`${actual.cases.length} of ${actual.cases.length} cases`);
for(const c of actual.cases){
  a.get('#world-case-list').events.click({target:{closest:()=>({dataset:{worldCase:c.id}})}});
  assert.equal(a.params().get('worldCase'),c.id);
  assert(a.get('#world-case-detail').innerHTML.includes(escape(c.project)),c.id);
  assert(a.get('#world-case-detail').innerHTML.includes(escape(c.limit)),`${c.id}: limitation missing`);
}
for(const region of new Set(actual.cases.map(c=>c.region))){
  a.get('#world-region').events.change({target:{value:region}});
  const expected=actual.cases.filter(c=>c.region===region).length;
  assert.equal(a.get('#world-case-count').textContent,`${expected} of ${actual.cases.length} cases · ${region}`);
}
a.get('#world-region').events.change({target:{value:''}});
for(const c of actual.comparisons){
  a.get('#world-comparison').events.change({target:{value:c.id}});
  assert.equal(a.params().get('worldComparison'),c.id);
  assert(a.get('#world-comparison-detail').innerHTML.includes(escape(c.title)),c.id);
  assert(a.get('#world-comparison-detail').innerHTML.includes(escape(c.note)),`${c.id}: qualification missing`);
  if(c.chart===false)assert(!a.get('#world-comparison-detail').innerHTML.includes('world-bars'),c.id);
}
// Acquisition claims remain inspectable and filter by their actual status.
if(actual.acquisition?.records?.length){
 const records=actual.acquisition.records;
 assert(a.root.innerHTML.includes('Which data have we actually downloaded?'));
 assert.equal(new Set(records.map(r=>r.id)).size,records.length);
 for(const status of new Set(records.map(r=>r.status))){
  a.get('#world-acq-status').events.change({target:{value:status}});
  const html=a.get('#world-acq-records').innerHTML;
  assert.equal((html.match(/<details class="world-acq-record">/g)||[]).length,records.filter(r=>r.status===status).length);
  for(const r of records.filter(r=>r.status===status)){
   assert(html.includes(escape(r.dataset)),r.id);
   assert(html.includes(escape(r.limitation)),r.id+' limitation');
  }
 }
 a.get('#world-acq-status').events.change({target:{value:''}});
 assert.equal((a.get('#world-acq-records').innerHTML.match(/<details class="world-acq-record">/g)||[]).length,records.length);
}
globalThis.fetch=async()=>({ok:false,status:503});
await assert.rejects(()=>renderGlobalEvidence(a.root),/International evidence data: 503/);
console.log(JSON.stringify({passed:true,cases:actual.cases.length,comparisons:actual.comparisons.length,studies:actual.studies.length,checks:['escaping and URL safety','query state and unrelated parameter preservation','region/outcome filters and empty state','all actual case details and limitations','all actual comparison notes','numeric same-unit charts only','fetch error propagation'],limitation:'In-memory UI checks; desktop/mobile rendering must be inspected separately.'}));
