import assert from 'node:assert/strict';
import {journeyPreset,calculateJourneys,validateJourneyState,SWITCH_PAIRS,journeyFrontier,encodeJourneyState,decodeJourneyState} from '../dist/network-time.mjs';
const close=(a,b)=>assert.ok(Math.abs(a-b)<1e-7,`${a} != ${b}`);
let s=journeyPreset('unchanged'),r=calculateJourneys(s);
assert.equal(r.valid,true);close(r.people,1400);close(r.saved,0);close(r.beforeMean,r.afterMean);
assert.equal(r.switchers,0);assert.deepEqual(r.afterCounts,s.counts);
s=journeyPreset();r=calculateJourneys(s);
// Independent row-by-row example: 100 bikes, 350 stay in cars, 200 buses,
// 500 subway, 100 walkers, 50 car-to-bike, and 100 car-to-subway.
const before=100*30+500*30+200*40+500*45+100*20;
const after=100*25+350*32+200*39+500*45+100*20+50*25+100*40;
close(r.beforeTotal,before);close(r.afterTotal,after);close(r.saved,before-after);
close(r.afterCounts.reduce((a,b)=>a+b,0),1400);close(r.switchers,150);
close(r.originAfterMinutes.reduce((a,b)=>a+b,0),after);
close(r.additionalCarMinutesToBreakEven*r.afterCounts[1],r.saved);
const subway=SWITCH_PAIRS.findIndex(([i,j])=>i===1&&j===3);
const frontier=journeyFrontier(s,100),end=frontier.at(-1);
close(end.carToSubway,450);close(end.remainingCarPeople,0);assert.equal(end.additionalCarMinutes,null);
// Mode switching can save time even if car stayers are slower.
s=journeyPreset('unchanged');s.stay[1]=32;s.switches[subway]=200;s.switchTimes[subway]=20;
r=calculateJourneys(s);close(r.saved,2000-300*2);assert.ok(r.saved>0);
// Car occupants entering from another mode are in the break-even denominator.
const busCar=SWITCH_PAIRS.findIndex(([i,j])=>i===2&&j===1);s.switches[busCar]=50;s.switchTimes[busCar]=30;r=calculateJourneys(s);
close(r.afterCounts[1],350);close(r.additionalCarMinutesToBreakEven*r.afterCounts[1],r.saved);
// No car travelers makes a car-delay threshold undefined rather than infinite.
s=journeyPreset('unchanged');s.counts[1]=0;r=calculateJourneys(s);assert.equal(r.additionalCarMinutesToBreakEven,null);
// Weighted fractional observations are valid; active complete journeys need positive time.
s=journeyPreset('unchanged');s.counts=[.5,0,0,0,0];s.before[0]=1;s.stay[0]=2;r=calculateJourneys(s);close(r.saved,-.5);close(r.meanChange,1);
s.before[0]=0;assert.equal(calculateJourneys(s).valid,false);
s=journeyPreset();s.stay[1]=0;assert.equal(calculateJourneys(s).valid,false);
s=journeyPreset();s.switchTimes[subway]=0;assert.equal(calculateJourneys(s).valid,false);
// Inactive zero-time fields are harmless, while impossible uniform car reductions are flagged.
s=journeyPreset('unchanged');s.counts[1]=0;s.before[1]=0;s.stay[1]=0;assert.equal(calculateJourneys(s).valid,true);
s=journeyPreset('unchanged');s.stay[0]=1000;r=calculateJourneys(s);assert.equal(r.uniformCarBreakEvenFeasible,false);
assert.ok(r.additionalCarMinutesToBreakEven < -r.minimumPostCarMinutes);
// Alternatives can populate currently empty groups whose time is zero. Mark
// those alternatives unavailable without breaking a valid current scenario.
s=journeyPreset('unchanged');s.switchTimes[subway]=0;
assert.equal(calculateJourneys(s).valid,true);assert.ok(journeyFrontier(s).some(x=>!x.valid&&x.unavailableReason));
s=journeyPreset('unchanged');s.switches[subway]=s.counts[1];s.stay[1]=0;
assert.equal(calculateJourneys(s).valid,true);assert.ok(journeyFrontier(s).some(x=>!x.valid&&x.unavailableReason));
// Invalid counts, missing fields and over-allocation must never produce estimates.
for(const bad of [null,{version:2}, {...journeyPreset(),counts:[]}, {...journeyPreset(),counts:[0,0,0,0,0]}])assert.equal(calculateJourneys(bad).valid,false);
s=journeyPreset();s.switches[subway]=501;assert.equal(calculateJourneys(s).valid,false);
for(const n of [NaN,Infinity,-1,1441]){s=journeyPreset();s.stay[0]=n;assert.ok(validateJourneyState(s).length);}
// URL state round-trips exactly and rejects malformed / extra data.
s=journeyPreset();assert.deepEqual(decodeJourneyState(encodeJourneyState(s)),s);
assert.equal(decodeJourneyState('not-json'),null);assert.equal(decodeJourneyState('[1,[],[],[],[],[],{}]'),null);
assert.equal(decodeJourneyState(JSON.stringify([1,[0,0,0,0,0],s.before,s.stay,s.switches,s.switchTimes])),null);
// A deterministic full-matrix sweep checks conservation and an independent sum.
let seed=20261105;const random=()=>((seed=(Math.imul(seed,1664525)+1013904223)>>>0)/4294967296);
for(let trial=0;trial<200;trial++){
 s=journeyPreset('unchanged');s.counts=s.counts.map(()=>1+1000*random());s.before=s.before.map(()=>1+100*random());s.stay=s.stay.map(()=>1+100*random());
 s.switchTimes=s.switchTimes.map(()=>1+100*random());
 for(let i=0;i<5;i++){let remaining=s.counts[i];for(let k=0;k<20;k++)if(SWITCH_PAIRS[k][0]===i){s.switches[k]=remaining*random()*.5;remaining-=s.switches[k];}}
 r=calculateJourneys(s);assert.equal(r.valid,true);
 close(r.afterCounts.reduce((a,b)=>a+b,0),s.counts.reduce((a,b)=>a+b,0));
 let independentAfter=0;
 for(let i=0;i<5;i++){let stayers=s.counts[i];for(let k=0;k<20;k++)if(SWITCH_PAIRS[k][0]===i){stayers-=s.switches[k];independentAfter+=s.switches[k]*s.switchTimes[k];}independentAfter+=stayers*s.stay[i];}
 close(r.afterTotal,independentAfter);close(r.beforeMean+r.meanChange,r.afterMean);
 close(r.afterTotal+r.additionalCarMinutesToBreakEven*r.afterCounts[1],r.beforeTotal);
}
console.log('network-time: conservation, weighting, switches, frontier, validation and URL checks passed');
