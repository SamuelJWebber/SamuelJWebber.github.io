MTA subway borough-pair origin–destination panel
Retrieved November5,2026 UTC. Public-data research, not a causal lane-effect estimate.

Requirements: Python3 standard library only. No pip installation required.

REPRODUCE OFFLINE
Unzip this package into one directory.
Run: python subway_od_panel.py
Bundled downloaded aggregates and station registry are used as cache.
This recreates subway-panel.json, subway-panel.mjs and subway-monthly-od.csv.

REFRESH FROM THE OFFICIAL API
Run: python subway_od_panel.py --refresh
This re-fetches the 2021/2022 OD aggregates and observed origin IDs.
Delete stations.json before running if a fresh station registry is also wanted.
API queries can take several minutes. Source APIs may be unavailable or change.
The exact URLs used for aggregated data are in *-query.txt.

DATA
2021 OD dataset https://data.ny.gov/d/rapa-97zv
2022 OD dataset https://data.ny.gov/d/nqnz-e9z9
Station registry https://data.ny.gov/d/39hk-dx4f
OD methodology is bundled as od-overview.pdf and od-overview.txt.
The API tables contain estimated positive/populated station-complex OD cells.
Destinations are inferred from future subway taps/swipes, and unmatched trips
are redistributed/scaled. This is not a direct observation of where a trip ends.

CALCULATION
Filter station pairs to Brooklyn–Manhattan or Queens–Manhattan, both directions.
Map station complex IDs and historical station IDs to boroughs using the
registry; any cross-borough namespace conflict fails an assertion. All424
observed origin complexes in each annual OD dataset map to a borough.
Sum estimated_average_ridership by month,weekday,hour. For AM7–10 or PM16–19,
sum the five weekday × three hour estimates and divide by15. For full-day
average weekday totals, sum all120weekday-hour cells and divide by5.
Missing January2021overnight cells cause daily totals to be withheld (null).
All15AM and15PM cells are present for every month, borough pair and year.
No missing value is converted tozero. Weekend observations are excluded.
Monday–Friday receive equal weight, irrespective of how many times each occurs
in the calendar month. Published monthly means may include holiday effects.

CHECK VALUES (estimated trips per average weekday PM hour, both directions)
June2021 Brooklyn–Manhattan39362.85263333333
June2022 Brooklyn–Manhattan56455.18927333333
June2021 Queens–Manhattan29199.002713333335
June2022 Queens–Manhattan41244.524893333335

INTERPRETATION
This is demand/recovery context. The data do not supply exact trip dates,
actual paths, tunnel/bridge crossings, exit timestamps, door-to-door journey
times, previous mode, or linked travelers across years. Do not add these
estimates to road/bridge counts as a synchronized all-mode total. Increases
cannot be attributed to a bike lane or interpreted as drivers changing modes.
A subway journey may include bus connections and can use routes outside the
intended road-study boundary. The borough pair describes endpoints only.
No causal confidence interval is estimated here. Differences in the inferred
OD model, missing/suppressed records, holiday pattern and rider composition
are not sampling uncertainty supplied by the API.
