#!/usr/bin/env python3
"""Conditional person-flow bounds from auditable source inputs.
Run: python reproduce_bounds.py. Uses Python standard library only.
No input occupancy range, bus transportability condition or counterfactual band is observed data.
"""
import csv, hashlib, itertools, json
from pathlib import Path

ROOT=Path(__file__).resolve().parent

def sign(lo,hi):
    return 'positive under stated restrictions' if lo>0 else 'negative under stated restrictions' if hi<0 else 'both signs possible'

def ppw_change(v0,v1,b0,b1,o0,o1,n0,p0,h=3,walk=0,alignment=0,drift=0):
    # V includes bus vehicles. Bus passenger counts P exclude the driver.
    # Subtract pre-B69 buses from the generic vehicle occupancy multiplier,
    # then add their driver plus passengers. Post B69 at PPW is zero.
    return (o1*v1-o0*(v0-n0)-n0-p0+(b1-b0))/h+walk+alignment-drift

def bounds(v0,v1,b0,b1,occupancy_pairs,nrange,prange,driftrange=(0,0)):
    values=[ppw_change(v0,v1,b0,b1,o0,o1,n,p,drift=g)
            for (o0,o1),n,p,g in itertools.product(occupancy_pairs,nrange,prange,driftrange)]
    lo,hi=min(values),max(values)
    return {'lower_people_per_hour':lo,'upper_people_per_hour':hi,'sign':sign(lo,hi)}

def avg(values):
    return sum(values)/len(values)

def bridge_profiles(data):
    rows=[]
    for window,start,end in [('am',7,9),('pm',16,19)]:
        for year in data['years']:
            for bridge in data['bridges']:
                hours=[r for r in data['hourly'] if r[0]==year and r[1]==bridge and start<=r[3]<end]
                walking=[r for r in data['walking'] if r[0]==year and r[1]==bridge and r[4]==window]
                if len(hours)!=2*(end-start) or not walking:continue
                assert all(r[5] is not None and r[6] is not None for r in hours)
                row={'year':year,'window':window,'bridge':bridge,'hours':end-start,
                     'nonbus_vehicles_per_hour':sum(r[4] for r in hours)/(end-start),
                     'published_nonbus_occupants_per_hour':sum(r[5] for r in hours)/(end-start),
                     'bikes_per_hour':sum(r[6] for r in hours)/(end-start),
                     'pedestrians_per_hour':sum(r[5] for r in walking)/(end-start)}
                row['three_mode_profile_people_per_hour']=row['published_nonbus_occupants_per_hour']+row['bikes_per_hour']+row['pedestrians_per_hour']
                rows.append(row)
    summaries=[]
    for window in ['am','pm']:
        summary={}
        for bridge in data['bridges']:
            s=[r for r in rows if r['window']==window and r['bridge']==bridge]
            pre=avg([r['three_mode_profile_people_per_hour'] for r in s if r['year'] in [2016,2017,2018]])
            post=avg([r['three_mode_profile_people_per_hour'] for r in s if r['year'] in [2022,2023,2024]])
            summary[bridge]={'pre':pre,'post':post,'change':post-pre,'post_pre_ratio':post/pre}
        tr=summary['brooklyn'];ratios=[summary[k]['post_pre_ratio'] for k in ['manhattan','williamsburg']]
        peerbounds=[]
        for bias in [0,.02,.05,.10]:
            # Bias is absolute change in the assumed post/pre counterfactual ratio.
            lo=tr['post']-tr['pre']*(max(ratios)+bias)
            hi=tr['post']-tr['pre']*(min(ratios)-bias)
            peerbounds.append({'allowed_counterfactual_ratio_bias':bias,'lower_people_per_hour':lo,'upper_people_per_hour':hi,'sign':sign(lo,hi)})
        summaries.append({'window':window,'pre_years':[2016,2017,2018],'post_years':[2022,2023,2024],
                          'profiles':summary,'counterfactual_ratio_for_zero_treatment_effect':tr['post']/tr['pre'],
                          'peer_ratio_envelope':[min(ratios),max(ratios)],'conditional_counterfactual_bounds':peerbounds,
                          'interpretation':'Three-mode representative-profile index, not synchronized all-person flow. Peer-envelope bounds require untreated, spillover-free comparison bridges and a transported trend. Those assumptions are not established; earlier bicycle comparisons fail a placebo pre-trend check.'})
    return rows,summaries

def main():
    inputs=json.loads((ROOT/'inputs.json').read_text())
    road=json.loads((ROOT/'road-analysis-input.json').read_text())
    profiles=json.loads((ROOT/'bridge-profiles-input.json').read_text())
    o=inputs['assumptions']['reference_non_b69_occupancy']
    results=[];baseline_rows=[];grid=[]
    for period,r in inputs['ppw']['periods'].items():
        v1=r['vehicle_after'];b0=r['bike_before'];b1=r['bike_after'];nrange=[r['scheduled_b69_before_min'],r['scheduled_b69_before_max']]
        pmax=3*r['historical_route_max_passengers_per_hour']
        v0=r['vehicle_before']['published_average']
        for label,before in r['vehicle_before'].items():
            naive=(o*(v1-before)+b1-b0)/3
            cond=bounds(before,v1,b0,b1,[(o,o)],nrange,[0,pmax])
            baseline_rows.append({'period':period,'before_motor_baseline':label,'before_vehicles':before,'after_vehicles':v1,
                                 'bike_change':b1-b0,'naive_index_change_per_hour_at_1_3':naive,
                                 'bus_corrected_conditional_bounds':cond,
                                 'additional_post_occupancy_drop_that_erases_positive_lower_bound':max(0,cond['lower_people_per_hour']*3/v1),
                                 'counterfactual_growth_per_hour_that_erases_positive_lower_bound':max(0,cond['lower_people_per_hour'])})
        critical_passenger_totals=[o*(v1-v0)+(b1-b0)+(o-1)*n for n in nrange]
        critical_mean_loads=[total/n for total,n in zip(critical_passenger_totals,nrange)]
        out={'period':period,'window':r['window'],'source_counts':r,
             'naive_index_change_per_hour_at_1_3':(o*(v1-v0)+(b1-b0))/3,
             'critical_average_pre_b69_passengers_per_hour_at_stable_1_3':[x/3 for x in critical_passenger_totals],
             'critical_average_pre_b69_passengers_per_scheduled_bus_at_stable_1_3':critical_mean_loads,
             'critical_occupancy_drop_if_no_b69_passengers_no_other_changes':[(o*(v1-v0)+(b1-b0)+(o-1)*n)/v1 for n in nrange],
             'historically_anchored_passenger_total_scenario':[0,pmax],
             'stable_occupancy_conditional_bounds':bounds(v0,v1,b0,b1,[(o,o)],nrange,[0,pmax]),
             'occupancy_box_conditional_bounds':[]}
        for low,high in inputs['assumptions']['occupancy_box_scenarios']:
            box=bounds(v0,v1,b0,b1,list(itertools.product([low,high],repeat=2)),nrange,[0,pmax])
            out['occupancy_box_conditional_bounds'].append({'assumed_non_b69_occupancy_each_period':[low,high],**box})
        for drop in inputs['assumptions']['occupancy_drop_scenarios']:
            for drift in inputs['assumptions']['counterfactual_drift_people_per_hour_scenarios']:
                row={'period':period,'reference_pre_occupancy':o,'assumed_post_occupancy':o-drop,'assumed_counterfactual_drift_bound_per_hour':drift,
                     **bounds(v0,v1,b0,b1,[(o,o-drop)],nrange,[0,pmax],[-drift,drift])}
                grid.append(row)
        results.append(out)
    # Match only clearly published same-direction Brooklyn classification snapshots.
    # These widely separated sample dates do not form a lane-conversion design.
    comparisons=[]
    snapshots={s['snapshot_id']:s for s in road['classification_snapshots']}
    pairs=[('brooklyn-2019-11-20-sb-9014212','brooklyn-2024-02-27-sb-9014212'),
           ('brooklyn-2019-11-20-sb-9014212','brooklyn-2024-04-11-sb-9014212'),
           ('brooklyn-2016-11-02-nb-9014216','brooklyn-2024-04-11-nb-9014216')]
    for before,after in pairs:
        s0,s1=snapshots[before],snapshots[after]
        assert not s0['direction_conflict'] and not s1['direction_conflict']
        v0=s0['windows']['pm']['total_vehicles'];v1=s1['windows']['pm']['total_vehicles']
        comparisons.append({'before_snapshot':before,'after_snapshot':after,'window':'16:00–19:00','before_vehicles':v0,'after_vehicles':v1,
                            'vehicle_change_per_hour':(v1-v0)/3,
                            'post_pre_all_vehicle_mean_occupancy_ratio_needed_to_offset_vehicle_decline':v0/v1,
                            'conditional_motor_occupant_bounds':[{'assumed_all_vehicle_mean_occupancy_each_period':[low,high],
                              'lower_change_per_hour':(v1*low-v0*high)/3,'upper_change_per_hour':(v1*high-v0*low)/3,
                              'sign':sign((v1*low-v0*high)/3,(v1*high-v0*low)/3)} for low,high in [(1,1.5),(1,2)]],
                            'interpretation':'Motor-only occupancy threshold for distinct sample dates. The average includes buses and all other classes; chosen occupancy boxes are assumptions, not measured bounds. No aligned walking, bike, passenger or counterfactual series is supplied.'})
    profile_rows,profile_summary=bridge_profiles(profiles)
    source_hashes={name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in ['inputs.json','road-analysis-input.json','bridge-profiles-input.json']}
    result={'version':'1.0','checked_on':inputs['checked_on'],'scope':'Partial identification and sensitivity, not an estimate of bike-lane causality.',
            'identification_conclusion':{'ppw_all_person_flow_change':'Unidentified from assembled data: walking change, common-date/common-screenline correction, actual occupancy and contemporaneous B69 loads remain unknown. Even the historically anchored stable-occupancy conditional index bounds include zero.',
            'ppw_lane_effect':'Unidentified: additional unrestricted counterfactual trend and concurrent signal/bus changes remain.',
            'brooklyn':'Published representative-profile changes can be computed. Occupancy thresholds for isolated classified dates are conditional motor-only diagnostics; they cannot establish a causal all-mode sign.',
            'pulaski':'No paired classified pre/post conversion panel in assembled extract; 2023 classification is after the 2016 conversion. Nearby ATR coverage has incomplete/low-count cases and cannot be treated as valid aligned person flow. Sign unidentified.'},
            'equations':{'full_screenline_change_per_hour':'[o1*V1 - o0*(V0-N0) - N0 - P0 + (B1-B0)]/H + deltaWalking + alignmentCorrection',
            'definitions':'V includes all motor vehicles; o is mean occupants of vehicles other than relocated B69; N0 pre B69 buses; P0 pre B69 passengers excluding drivers; post B69 at PPW is zero; B is cyclists. H=3 hours. deltaWalking and alignmentCorrection are signed people/hour differences.',
            'causal_effect':'target-screenline observed change minus counterfactual change without the intervention.',
            'restrictions_for_numeric_ppw_bounds':'Set walking/alignment changes to zero; use specified occupancy restrictions; transfer historical route maximum load as an upper bound on all three relevant hours; regular scheduled bus counts stand in for actual runs. These are explicit assumptions, not observations.'},
            'inputs_sha256':source_hashes,'primary_sources':inputs['sources'],'ppw':results,'ppw_before_baseline_sensitivity':baseline_rows,
            'ppw_occupancy_and_counterfactual_grid':grid,'brooklyn_classification_diagnostics':comparisons,
            'brooklyn_profile_comparison_sensitivity':profile_summary,
            'pulaski_coverage':{'classification_years':road['classification_available_years']['Pulaski Bridge'],'atr_years':road['atr_available_years']['Pulaski Bridge'],
             'known_quality_issue':'April13/14,2013 SB records have96intervalrows but only69/9 dailyvehicles. These observations cannot validate complete traffic measurement.'},
            'limitations':['PPW motor counts are southbound at Carroll Street, bikes include both directions near4th Street, and observation dates differ. Numeric results are a published-count index unless an alignment restriction is made.',
            'The B69 route-wide historic maxima are genuine onboard passenger loads, not boardings. Their temporal transportability is unverified; PM maximum occurs3–4PM, outside the4–7PM target but bounds each later hour in that historical source period.',
            'The January2010 timetable is scheduled service, not observed bus counts, passenger capacity or a hard upper limit on service actually operated.',
            'Bus relocation to7th Avenue is not disappearance of those travelers from a wider Park Slope screenline. A corridor-only reduction can coexist with unchanged network travel.',
            'No source-supported finite bounds on all omitted-mode changes or untreated counterfactual trends are available. Numerical scenario bounds must not be reported as unconditional confidence intervals.']}
    (ROOT/'bounds.json').write_text(json.dumps(result,indent=2,allow_nan=False))
    with (ROOT/'ppw-sensitivity.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(grid[0]));writer.writeheader();writer.writerows(grid)
    with (ROOT/'brooklyn-profiles.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(profile_rows[0]));writer.writeheader();writer.writerows(profile_rows)
    print(json.dumps({'ppw':[{k:v for k,v in r.items() if k!='source_counts'} for r in results],'brooklyn_profile_sensitivity':profile_summary},indent=2))

if __name__=='__main__':main()
