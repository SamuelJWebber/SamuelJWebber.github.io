# B 69 relocation: verified evidence and conditional bounds

The B 69 move was effective **June 27, 2010**, independently of the PPW bike-lane treatment. MTA’s September 23, 2011 evaluation confirms the effective date (printed p 2 / PDF p 4) and describes the PPW/8 th Avenue to 7 th Avenue reroute, shorter weekday service, and weekend discontinuation (printed B-18 / PDF p 47). Official PDFs and source hashes are cataloged in `b69_findings.json`.

## Strongest passenger evidence

NYC DOT’s **August 2009** Downtown Brooklyn Surface Transit Circulation Study reports actual onboard loads derived from NYCT on/off counts. It defines load as passengers aboard buses passing a stop during an hour, then takes the largest stop/hour load within each peak period (printed pp 51–52).

| Direction | Historical period | Maximum onboard passengers/hour | Peak location and hour |
|---|---|---:|---|
| Southbound | AM 06:00–10:00 |214|PPW/President Street, 08:00–09:00|
| Southbound | PM 15:00–19:00 |126|Vanderbilt/Fulton, 15:00–16:00|

These are observed historical maxima, **not physical capacities or universal future maxima**. The AM figure directly measures a PPW screenline. The PM maximum can bound PPW load within the same underlying sampled route data, provided stop coverage is complete. The report does not disclose the exact count dates in the located source sections. Applying these to 2010 requires an explicit transportability assumption.

Under that assumption, three-hour baseline passenger-flow sensitivity intervals are **[0,642] for 07:00–10:00** and **[0,378] for 16:00–19:00**. They are not observed 2010 hard bounds.

## Pre-change schedule and driver correction

The actual MTA timetable **effective January 3, 2010**, archived March 30, 2010, is downloaded. Its southbound weekday schedule (PDF p 4) is identical to the April 2009 edition. Regular trips crossing the PPW timepoints:

| Timepoint |07:00–10:00|16:00–19:00|
|---|---:|---:|
|Union Street / PPW|12|10|
|Bartel Pritchard Square|12|11|

The extra PM boundary bus leaves Union 15:55 and reaches Bartel 16:02. Thus the regular schedule implies 10–11 PM runs depending on screenline. The timetable lists supplemental school-day service 14:30–15:30 without times or counts. Delays, bunching, school extras, and actual service deviations prevent treating these schedule counts as observed 2010 bus counts or hard maxima.

Regular southbound service at Union/PPW spans 06:07–01:31 next day, with 51 listed weekday trips. There are at most 6 listed regular departures in a rolling 60-minute window at that timepoint; off-peak headways are generally 30 minutes. Full extracted times are in the JSON. Northbound service on 8 th Avenue should not be added to a PPW screenline north of 15 th Street.

If motor-vehicle counts V already include N B 69 buses, automobile occupancy is o, and P measures bus passengers excluding drivers, corrected baseline motor-person flow is **o(V−N)+P+N**. If B 69 is absent afterward, its correction to the naive before/after change is **−P+(o−1)N**. At o=1 the counted bus already accounts for its driver.

## Figures unsuitable as screenline estimates

DOT Table 18 reports B 69 average routewide ridership 2,302 weekdays, 1,058 Saturdays, 873 Sundays; these are both-direction route totals, not PPW loads. Dividing by service span does not bound a particular hour. MTA’s March 2010 proposal estimated about 1,200 affected weekday customers along PPW and 8 th Avenue combined; that also is not a screenline estimate. MTA’s 91% guideline-capacity figure concerns the combined B 67/B 69 after September 2011 changes and is unsuitable for the pre-change bound. No 2010 fleet-specific physical capacity was verified.

## Primary source URLs

- January 2010 timetable: https://web.archive.org/web/20100330235020id_/http://www.mta.info/nyct/bus/schedule/bkln/b069cur.pdf
- April 2009 timetable: https://web.archive.org/web/20091229043613id_/http://www.mta.info/nyct/bus/schedule/bkln/b069cur.pdf
- March 19, 2010 proposal (printed 48–50): https://web.archive.org/web/20101218020135id_/http://www.mta.info/news/pdf/NYCT_Revised_Service_Changes.pdf
- September 23, 2011 evaluation: https://web.archive.org/web/20241003113136id_/http://web.mta.info/mta/news/books/docs/NYCT_2010_Service_Reduction_Evaluation.pdf
- DOT August 2009 report (printed 49–52, 56): https://www.nyc.gov/html/dot/downloads/pdf/dbstc-existing-future-conditions-report.pdf

Archive PDFs were retrieved directly because the web-search reader could not open them. DOT report search references: `turn5308795search2` (Table 14 definition) and `turn7614616search24` (route profile). The cover dates the DOT report August 2009; later PDF metadata and search crawl dates do not date the observations. `dot_b69_peak_load_table_p52.png` is a rendered verification of the table.
