# Partial-identification audit: person flow after lane conversions

The assembled data do not identify the sign of the causal all-person flow change for Prospect Park West, Brooklyn Bridge or Pulaski Bridge. New official B69 evidence materially narrows an important unknown, but the defensible conclusions remain conditional. This report separates observed facts, assumed restrictions, and mathematical implications.

## What the new B69 sources establish

MTA's September 2011 evaluation dates the bus changes to June 27, 2010 and describes the B69 move from Prospect Park West/8th Avenue to 7th Avenue, shorter weekday hours and elimination of weekend service. That coincides with the PPW redesign period, but the source does not establish the lane as the cause of the bus change. The reroute contaminates 7th and 8th Avenue as untreated travel-time comparisons. DOT also lists signal retiming, loading changes and pedestrian treatments in the redesign package, so even a package effect would not isolate the bicycle lane alone.

The official timetable effective January 3, 2010 lists 12 regular southbound runs during 07:00–10:00 at both bracketing PPW timepoints. During 16:00–19:00 it lists 10 at Union/PPW and 11 at Bartel Pritchard Square; the extra arrival crosses the starting time boundary. These are scheduled regular runs, not actual bus counts or a capacity ceiling. School extras and operational deviations are not fully quantified.

DOT's August 2009 Downtown Brooklyn study, Table 14, reports the maximum southbound AM hourly onboard load as 214 passengers at PPW/President Street, 08:00–09:00. The southbound PM route maximum is 126 passengers at Vanderbilt/Fulton, 15:00–16:00. These are summed onboard passengers passing a stop during an hour, not boardings. The study searched AM 06:00–10:00 and PM 15:00–19:00; the underlying dates are not specified.

Therefore 0–642 AM passengers and 0–378 PM passengers over the three-hour PPW study windows are historically anchored sensitivity ranges **only if the old route maximum remains a ceiling on every relevant hour of the lane-study count days and at the target screenline**. They are not contemporaneous observed bounds. The 214 morning observation is not a three-hour total, and the PM maximum occurs before the 16:00 start of the target window.

## Correct accounting avoids double-counting a bus driver

Let V be the count of all motor vehicles, N the pre-reroute B69 buses, P their passengers excluding drivers, o the mean occupants of other vehicles, and B cyclists. The post-reroute B69 contribution at PPW is zero. The conditional three-hour count index changes by

ΔI = [o₁V₁ − o₀(V₀−N) − N − P + B₁−B₀] / 3.

Equivalently, correct the naive o₁V₁−o₀V₀+B₁−B₀ total by −P+(o₀−1)N before dividing by 3. Adding the full bus load to a vehicle count already multiplied by occupancy would double-count the bus's baseline contribution.

Actual screenline person-flow change additionally contains walking change and a correction for different count dates/locations. A causal effect additionally subtracts the counterfactual change without the intervention. None of those signed terms is bounded by the assembled sources. Accordingly, the data alone provide no finite informative interval or sign for the full causal estimand.

## Conditional PPW bounds

The following sets non-B69 occupancy to 1.3 in both periods, uses scheduled regular bus runs, applies the historically anchored passenger ranges above, and sets walking change, count-alignment error and counterfactual change to zero. These restrictions are assumptions. The outcome is an index combining DOT motor counts at Carroll Street and bicycle counts near 4th Street, observed on different days—not a synchronized physical screenline count.

| Period | Naive index change, people/hour | Bus-adjusted conditional interval | Pre-B69 passenger flow that makes change zero, passengers/hour |
|---|---:|---:|---:|
| AM | 141.2 | -71.6 to 142.4 | 142.4 |
| PM | 85.3 | -39.7 to 86.4 | 86.3–86.4 |

The zero-change thresholds correspond to an average 35.6 passengers per scheduled AM bus or 23.6–25.9 per scheduled PM bus. The historical sources do not establish whether the actual study-day average was above or below those thresholds. Both signs remain possible even after imposing stable occupancy and the historical passenger ceiling.

### Baseline choice matters

DOT's before motor baseline averages April 2009 and May 2010. PM volumes were 2,978 versus 2,636 per three hours, before the lane, while October 2010 is 2,807. The published average is also 2,807. Using the same bicycle endpoints and assumed occupancy gives:

| Motor baseline | Before vehicles | Naive change/hour | Bus-adjusted conditional interval/hour |
|---|---:|---:|---:|
| Published average | 2,807 | 85.3 | -39.7 to 86.4 |
| April 2009 | 2,978 | 11.2 | -113.8 to 12.3 |
| May 2010 | 2,636 | 159.4 | 34.4 to 160.5 |

The May-only PM interval is positive under the stated restrictions, but a post-period occupancy decline of just 0.0368 persons per non-B69 vehicle (from 1.300 to 1.2632) erases its lower bound. A counterfactual growth of 34.4 people/hour does the same. It is therefore conditional sign identification for a particular index and baseline, not robust causal identification of a lane benefit. The code also evaluates independent occupancy boxes [1,1.5] and [1,2], occupancy declines 0/0.05/0.10/0.15, and counterfactual drift bands 0/25/50/100 people/hour. These ranges are labeled assumptions, not confidence intervals.

## Brooklyn Bridge: thresholds, not a new causal estimate

The classified-count extract has mismatched seasonal dates and no June 2021/June 2022 pair. For southbound 16:00–19:00, 7,698 vehicles on November 20, 2019 compare with 4,243 on February 27, 2024 or 3,945 on April 11, 2024. The latter motor-occupant total would decline if the post/pre mean occupancy ratio were below 1.9513; the February threshold is 1.8143. These are algebraic thresholds for distinct dates, not evidence that occupancy satisfied them. They omit aligned bicycle, walking and other passenger changes. The conflicting 2019 northbound direction label is excluded.

The existing representative fall profiles combine published non-bus motor occupants, cyclists and separately observed pedestrians. Their average Brooklyn Bridge three-mode index changes from 8,283.5 to 7,942.7 people/hour in the AM and 8,737.0 to 8,142.2 in the PM, comparing 2016–2018 with 2022–2024.

If the counterfactual Brooklyn post/pre ratio is assumed to lie between the Manhattan and Williamsburg ratios, the implied AM effect is +153.0 to +402.9 people/hour; PM is −424.7 to +201.0. Allowing just two percentage points of counterfactual-ratio deviation widens AM to −12.7 to +568.6, losing its sign. This peer-envelope assumption is not validated: bridges can receive diverted traffic, and the existing bicycle analysis fails its placebo pre-trend check. It is a transparent sensitivity calculation, not a credible untreated control design. These profiles also do not count a synchronized all-mode network boundary.

## Pulaski Bridge remains unbounded for this question

The assembled classified counts are from 2023, after the 2016 conversion. Named-bridge automated records span other years, but nearby pre-period records are incomplete, thin, or have different locations; 2013 southbound examples contain 96 interval rows yet only 69 and 9 daily vehicles. Presence of 96 records cannot establish a usable traffic measurement. The 2019 eight-hour bicycle-share sample is also after the conversion and cannot supply before person flow. No paired all-mode flow panel or defensible occupancy/bus ceiling was recovered, so no numeric causal sign is claimed.

## Reproduction and source audit

Run `python reproduce_bounds.py` with `inputs.json`, `road-analysis-input.json` and `bridge-profiles-input.json` beside it. It regenerates `bounds.json`, `ppw-sensitivity.csv` and `brooklyn-profiles.csv` using standard-library Python only. Linear parameter-box endpoints are enumerated exactly. Source input SHA-256 hashes and explicit conditions appear in the JSON. Input numbers are transcribed from the primary tables listed below; road/profile extracts retain their prior source records.

- [DOT PPW evaluation and raw counts](https://www.nyc.gov/html/dot/downloads/pdf/20110120_ppw_data.pdf), PDF pages 39–40 and 47–48. Motor and bicycle observation dates and sites are stated in the source.
- [MTA January 2010 B69 timetable, archived official PDF](https://web.archive.org/web/20100330235020id_/http://www.mta.info/nyct/bus/schedule/bkln/b069cur.pdf), PDF page 4, map page 10.
- [MTA 2010 Service Reduction Evaluation, archived official PDF](https://web.archive.org/web/20241003113136id_/http://web.mta.info/mta/news/books/docs/NYCT_2010_Service_Reduction_Evaluation.pdf), printed page 2/PDF page 4 and printed B-18/PDF page 47.
- [DOT Downtown Brooklyn existing conditions](https://www.nyc.gov/html/dot/downloads/pdf/dbstc-existing-future-conditions-report.pdf), printed pages 51–52, Table 14 and footnote 11.
- [DOT vehicle classification](https://data.cityofnewyork.us/d/96ay-ea4r), [automated traffic counts](https://data.cityofnewyork.us/d/7ym2-wayt), [pedestrian counts](https://data.cityofnewyork.us/d/cqsj-cfgu), and [NYMTC Hub Bound profiles](https://www.nymtc.org/hub-bound-travel).

The B69 source PDFs, extracted timetable entries and detailed caveats are retained under `b69/`, with `b69_findings.json` and `b69_notes.md`.
