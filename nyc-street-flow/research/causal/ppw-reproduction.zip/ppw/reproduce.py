#!/usr/bin/env python3
"""Extract and audit DOT's public Prospect Park West raw study.

python reproduce.py --refresh
Uses Python standard library and pdftotext (Poppler). No causal identification
or confidence interval is claimed from four survey weekdays.
"""
import argparse
import csv
import datetime as dt
import hashlib
import json
import re
import statistics
import subprocess
import urllib.request
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent
URL = "https://www.nyc.gov/html/dot/downloads/pdf/20110120_ppw_data.pdf"


def seconds(token):
    minutes, sec = token.split('.')
    assert len(sec) == 2 and 0 <= int(sec) < 60, token
    return int(minutes) * 60 + int(sec)


def mean(values):
    return statistics.mean(values)


def dump_csv(name, rows):
    with (ROOT / name).open('w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--refresh', action='store_true')
    args = parser.parse_args()
    pdf = ROOT / 'data2011.pdf'
    if args.refresh or not pdf.exists():
        pdf.write_bytes(urllib.request.urlopen(URL).read())
    subprocess.run(['pdftotext', '-layout', str(pdf), str(ROOT / 'data2011.txt')], check=True)
    pages = (ROOT / 'data2011.txt').read_text().split('\f')
    pattern = re.compile(r'^\s*(PPW|[678] Ave)\s+(South|North)\s+(\d+/\d+/2010)\s+(\d+)\s+(\d+:\d+)\s+(\d+)\s+(\d+\.\d{2})\s+(\d+\.\d{2})\s+(\d+\.\d{2})\s+(\d+\.\d{2})\s*$')
    rows = []
    for page, text in enumerate(pages, start=1):
        for line in text.splitlines():
            m = pattern.match(line)
            if not m:
                continue
            route, direction, date, run, start, hour, t0, t1, t2, t3 = m.groups()
            date_obj = dt.datetime.strptime(date, '%m/%d/%Y').date()
            elapsed = [seconds(s) for s in [t0, t1, t2, t3]]
            assert elapsed[0] == 0 and elapsed == sorted(elapsed), (page, line)
            rows.append(dict(route=route, direction=direction, date=date_obj.isoformat(),
                             weekday=date_obj.strftime('%A'), period='before' if date_obj.month == 5 else 'after',
                             run=int(run), start_time=start, hour=int(hour),
                             start_second=elapsed[0], first_checkpoint_seconds=elapsed[1],
                             second_checkpoint_seconds=elapsed[2], total_seconds=elapsed[3],
                             first_checkpoint='3 St' if direction == 'South' else '9 St',
                             second_checkpoint='9 St' if direction == 'South' else '3 St',
                             start_location='Union St' if direction == 'South' else '15 St',
                             end_location='15 St' if direction == 'South' else 'Union St',
                             source_pdf_page=page, source_url=URL))
    assert len(rows) == 416, len(rows)
    assert len({(r['route'], r['date'], r['run']) for r in rows}) == len(rows)
    weekday = [r for r in rows if r['weekday'] in ('Tuesday', 'Wednesday')]
    assert len(weekday) == 384
    grouped = defaultdict(list)
    for r in weekday:
        grouped[r['route'], r['period']].append(r)
    assert set(grouped) == {(r, p) for r in ['PPW', '6 Ave', '7 Ave', '8 Ave'] for p in ['before', 'after']}
    assert all(len(x) == 48 for x in grouped.values())
    dump_csv('travel-time-runs.csv', rows)

    # Fixed run schedule, not passenger/vehicle-weighted travel times.
    windows = {'daily_07_19': list(range(7, 19)), 'am_07_10': list(range(7, 10)),
               'midday_10_14': list(range(10, 14)), 'pm_16_19': list(range(16, 19))}
    published = {
        'PPW': {'daily_07_19': [174, 167], 'am_07_10': [155, 162], 'midday_10_14': [174, 164], 'pm_16_19': [183, 179]},
        '6 Ave': {'daily_07_19': [260, 258], 'am_07_10': [251, 232], 'midday_10_14': [261, 255], 'pm_16_19': [248, 273]},
        '7 Ave': {'daily_07_19': [325, 353], 'am_07_10': [262, 332], 'midday_10_14': [356, 390], 'pm_16_19': [311, 339]},
        '8 Ave': {'daily_07_19': [255, 237], 'am_07_10': [260, 245], 'midday_10_14': [254, 208], 'pm_16_19': [250, 247]},
    }
    summaries = []
    for route in ['PPW', '6 Ave', '7 Ave', '8 Ave']:
        for window, hours in windows.items():
            selected = {p: [r for r in grouped[route, p] if r['hour'] in hours] for p in ['before', 'after']}
            means = {p: mean(r['total_seconds'] for r in x) for p, x in selected.items()}
            rec = dict(route=route, window=window, before_runs=len(selected['before']), after_runs=len(selected['after']),
                       before_mean_seconds=means['before'], after_mean_seconds=means['after'],
                       change_seconds=means['after'] - means['before'],
                       published_before_seconds=published[route][window][0], published_after_seconds=published[route][window][1],
                       before_error_vs_published_seconds=means['before'] - published[route][window][0],
                       after_error_vs_published_seconds=means['after'] - published[route][window][1])
            summaries.append(rec)
    dump_csv('route-period-summary.csv', summaries)
    date_route_rows = []
    for date in sorted({r['date'] for r in weekday}):
        for route in ['PPW', '6 Ave', '7 Ave', '8 Ave']:
            selected = [r for r in weekday if r['route'] == route and r['date'] == date]
            assert len(selected) == 24
            date_route_rows.append(dict(date=date, weekday=selected[0]['weekday'], period=selected[0]['period'],
                                        route=route, runs=len(selected), mean_seconds=mean(r['total_seconds'] for r in selected)))
    dump_csv('date-route-means.csv', date_route_rows)

    by_window_route = {(r['window'], r['route']): r for r in summaries}
    estimates = []
    for window, hours in windows.items():
        treated = by_window_route[window, 'PPW']
        for label, controls in [('7th_same_direction', ['7 Ave']), ('6th_reverse_direction', ['6 Ave']),
                                ('8th_reverse_direction', ['8 Ave']), ('all_three_equal', ['6 Ave', '7 Ave', '8 Ave']),
                                ('northbound_equal', ['6 Ave', '8 Ave'])]:
            control_change = mean(by_window_route[window, r]['change_seconds'] for r in controls)
            # Match same weekday and departure clock slot, then differ after-before.
            cells = defaultdict(dict)
            for r in weekday:
                if r['hour'] in hours and r['route'] in ['PPW'] + controls:
                    cells[r['weekday'], r['start_time']][r['route'], r['period']] = r['total_seconds']
            values = []
            by_day = defaultdict(list)
            for (day, slot), cell in sorted(cells.items()):
                effect = cell['PPW', 'after'] - cell['PPW', 'before'] - mean(cell[c, 'after'] - cell[c, 'before'] for c in controls)
                values.append(effect)
                by_day[day].append(effect)
            did = treated['change_seconds'] - control_change
            assert abs(mean(values) - did) < 1e-9
            estimates.append(dict(window=window, control=label, control_routes=controls,
                                  treated_change_seconds=treated['change_seconds'], control_change_seconds=control_change,
                                  controlled_change_seconds=did, paired_clock_weekday_cells=len(values),
                                  Tuesday_controlled_change_seconds=mean(by_day['Tuesday']),
                                  Wednesday_controlled_change_seconds=mean(by_day['Wednesday']),
                                  causal_effect_identified=False))
    dump_csv('controlled-travel-time.csv', [{**r, 'control_routes': '|'.join(r['control_routes'])} for r in estimates])

    fixed_mix = []
    for window in windows:
        means = {p: mean(by_window_route[window, r][p + '_mean_seconds'] for r in ['PPW', '6 Ave', '7 Ave', '8 Ave']) for p in ['before', 'after']}
        fixed_mix.append(dict(window=window, drives_per_route=25, total_drives=100,
                              before_vehicle_minutes_per_100_drives=100*means['before']/60,
                              after_vehicle_minutes_per_100_drives=100*means['after']/60,
                              change_vehicle_minutes_per_100_drives=100*(means['after']-means['before'])/60,
                              observed_traffic_or_passenger_weighting=False))
    dump_csv('fixed-four-route-mix.csv', fixed_mix)

    # Published observed mode volumes remain separate; never label bicycles+vehicles people.
    bikes = []
    for daytype, dates, counts in [
        ('weekday', ['2009-06-09','2010-08-17','2010-09-15','2010-10-12','2010-11-09'], [349,1131,1043,1010,863]),
        ('weekend', ['2009-06-27','2010-08-21','2010-09-18','2010-10-09','2010-11-13'], [790,1719,1727,1813,1838])]:
        for date, count in zip(dates, counts):
            bikes.append(dict(date=date, daytype=daytype, period='before' if date.startswith('2009') else 'after',
                              start_hour=7, end_hour=19, count=count, unit='bicycles',
                              location='Prospect Park West between 3rd and 5th Streets (individual sheets refine blocks)',
                              source_pdf_page=5 if daytype=='weekday' else 16))
    dump_csv('bike-count-observations.csv', bikes)
    result = dict(
        title='Prospect Park West 2010: controlled travel-time reanalysis from released run-level data',
        checked_on='2026-11-05', source_url=URL, source_sha256=hashlib.sha256(pdf.read_bytes()).hexdigest(),
        treatment=dict(implemented='June 2010', moving_lanes_before=3, moving_lanes_after=2,
                       package=['two-way protected bicycle path','signal retiming','pedestrian islands','loading changes'],
                       concurrent_bus_change='B69 rerouted from PPW southbound / 8th Avenue northbound to 7th Avenue effective June 27, 2010; separate MTA service change, not isolated bike-lane treatment. B67/B69 weekday frequencies and B69 span were also reduced; net bus-traffic change cannot be inferred from route relocation alone.',
                       bus_change_source='https://web.archive.org/web/20241003113136id_/http://web.mta.info/mta/news/books/docs/NYCT_2010_Service_Reduction_Evaluation.pdf',
                       bus_change_source_pages={'effective_date_pdf_page':4,'effective_date_printed_page':'2','route_change_pdf_page':47,'route_change_printed_page':'B-18'},
                       bus_change_source_status='MTA September 23, 2011 primary evaluation downloaded by companion analyst; pages 4 and 47 independently read locally.'),
        extraction=dict(method='pdftotext -layout, anchored complete-row regular expression; m.ss interpreted as minutes:seconds, never decimal minutes',
                        source_pdf_pages=list(range(52,60)), summary_pdf_page=51, total_runs=len(rows), weekday_runs=len(weekday),
                        Saturday_runs_excluded_from_primary=len(rows)-len(weekday),
                        before_weekdays=['2010-05-11','2010-05-12'], after_weekdays=['2010-10-19','2010-10-20'],
                        all_route_period_panels_complete=True),
        estimator='Difference of before/after travel-time changes, equal weighting of paired weekday × departure-clock slots; equal route weights when controls pooled.',
        outcome='Seconds per instrumented motor-vehicle corridor run between Union St and 15 St; excludes access, parking, traveler counts, bicycle and bus journey times.',
        summaries=summaries, date_route_means=date_route_rows, controlled_changes=estimates,
        exact_date_pairs=[{'weekday':'Tuesday','before':'2010-05-11','after':'2010-10-19','clock_slots':24},
                          {'weekday':'Wednesday','before':'2010-05-12','after':'2010-10-20','clock_slots':24}],
        fixed_four_route_mix=fixed_mix,
        fixed_mix_definition='Illustrative 100 motor-vehicle drives, 25 on each route, same half-hour schedule before/after. Vehicle-minutes, not observed traveler-minutes. Unknown occupants and bus passenger loads preclude person totals. Not a causal effect.',
        uncertainty=dict(confidence_interval=None, reason='Only two survey weekdays before and two after. Half-hour runs are not independent treatment assignments; no defensible cluster-asymptotic causal interval or pretrend test.'),
        causal_limits=[
            'Controls are nearby alternative routes and may be affected by diversion; this can bias treated-minus-control effects.',
            '7th Avenue is the only same-direction control; 6th and 8th run northbound. Their baseline travel times differ.',
            'Concurrent B69 rerouting directly affects the nominal controls: 7th Avenue gained the bus route, while PPW and 8th Avenue lost it. 6th Avenue did not directly gain/lose this route, but still may absorb traffic diversion.',
            'Survey dates are Tuesday/Wednesday in May versus October; shared date shocks are differenced, but corridor-specific seasonal shocks remain.',
            'Only one pre intervention survey wave: parallel trends cannot be evaluated.',
            'Treatment is a street-redesign package, not an isolated bike-lane-only change.',
            'Run times are not vehicle-flow or passenger weighted. Changes do not establish all-person travel-time burden.',
            'Bicycle and motor volume surveys use different dates and locations; their sums are not aligned person counts.',
        ],
        bicycle_count_observations=bikes,
        scope='Useful controlled historical time comparison and counterfactual sensitivity, not resolution of the citywide all-person causal question.')
    (ROOT/'analysis.json').write_text(json.dumps(result, indent=2, allow_nan=False))
    print(json.dumps({'extraction': result['extraction'], 'daily_estimates':[r for r in estimates if r['window']=='daily_07_19'],
                      'max_summary_difference_seconds':max(abs(r[k]) for r in summaries for k in ['before_error_vs_published_seconds','after_error_vs_published_seconds'])}, indent=2))


if __name__ == '__main__':
    main()
