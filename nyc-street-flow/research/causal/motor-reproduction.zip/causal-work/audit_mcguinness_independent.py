"""Independent arithmetic/support audit; does not modify the analysis under review."""
from pathlib import Path
import csv,json,datetime,collections,math,hashlib
import pandas as pd
P=Path(__file__).parent; R=P.parent/'causal-road'
source=R/'nysdot-region11-bidirectional-days.csv'
analysis=json.loads((P/'mcguinness-analysis.json').read_text())
rows=list(csv.DictReader(source.open()))
lookup={(r['station'],r['date']):r for r in rows}
assert len(lookup)==len(rows)
periods={'day':'all_day_vehicles','am':'am_07_10_vehicles','pm':'pm_16_19_vehicles'}
checks=[]; support=[]; largest_error=0
for expected in analysis['comparisons']:
    c=expected['control'];col=periods[expected['period']]
    buckets=collections.defaultdict(list)
    dates={}
    for r in rows:
        if r['station']!='021284':continue
        d=datetime.date.fromisoformat(r['date']);q=lookup.get((c,r['date']))
        if d.weekday()>4 or not q or d.year not in (2014,2015,2016,2017):continue
        if not r[col] or not q[col]:continue
        if float(r[col])<=0 or float(q[col])<=0:continue
        if expected['quality']=='exclude_flagged' and any(z['possible_dropout_flag'].lower() in ('true','1') for z in (r,q)):continue
        key=(d.year,d.month,d.weekday());buckets[key].append((float(r[col]),float(q[col]),r['date']))
    yr=expected['year1'];ms=range(1,9) if yr==2015 else range(5,13)
    k=sorted((m,d) for m in ms for d in range(5) if len(buckets[(2014,m,d)])>=2 and len(buckets[(yr,m,d)])>=2)
    means=lambda year,index:[sum(z[index] for z in buckets[(year,m,d)])/len(buckets[(year,m,d)]) for m,d in k]
    avg=lambda vv:sum(vv)/len(vv)
    t0,t1,c0,c1=avg(means(2014,0)),avg(means(yr,0)),avg(means(2014,1)),avg(means(yr,1))
    calc={'treated_baseline_vehicles':t0,'treated_target_vehicles':t1,'control_baseline_vehicles':c0,'control_target_vehicles':c1,'raw_change_pct':100*(t1/t0-1),'scaled_counterfactual_vehicles':t0*c1/c0,'controlled_change_vehicles':t1-t0*c1/c0,'controlled_change_pct':100*(t1/(t0*c1/c0)-1),'matched_cells':len(k),'baseline_paired_dates':sum(len(buckets[(2014,m,d)]) for m,d in k),'target_paired_dates':sum(len(buckets[(yr,m,d)]) for m,d in k)}
    errors={name:abs(value-expected[name]) for name,value in calc.items()};largest_error=max(largest_error,max(errors.values()));assert max(errors.values())<1e-8
    if expected['period']=='day' and expected['quality']=='exclude_flagged':
        support.append({'control':c,'year1':yr,'retained_cells':len(k),'cells_by_month':dict(collections.Counter(m for m,d in k)),'source_dates_before':calc['baseline_paired_dates'],'source_dates_after':calc['target_paired_dates'],'missing_cells':[(m,d) for m in ms for d in range(5) if (m,d) not in k]})
    checks.append({'period':expected['period'],'control':c,'quality':expected['quality'],'year1':yr,'max_absolute_error':max(errors.values())})
# A fairer control-to-control sensitivity: same source dates and cells across all three stations.
x=pd.read_csv(source,dtype={'station':str},parse_dates=['date'])
x=x[(x.date.dt.dayofweek<5)&~x.possible_dropout_flag&x.station.isin(['021284','010009','010012'])]
common=[]
for period,col in periods.items():
    w=x.pivot(index='date',columns='station',values=col).dropna();w=w[(w>0).all(axis=1)]
    w['year']=w.index.year;w['month']=w.index.month;w['dow']=w.index.dayofweek
    g=w.groupby(['year','month','dow']).agg(T=('021284','mean'),B=('010009','mean'),R=('010012','mean'),n=('021284','size'));g=g[g.n>=2]
    for yr,ms in [(2015,range(1,9)),(2016,range(5,13)),(2017,range(5,13))]:
        a=g.loc[2014];b=g.loc[yr];k=a.index.intersection(b.index);k=k[k.get_level_values('month').isin(ms)];a=a.loc[k];b=b.loc[k]
        for c,station in [('B','010009'),('R','010012')]:
            eff=100*(b['T'].mean()/(a['T'].mean()*b[c].mean()/a[c].mean())-1)
            monthly=[]
            for month in sorted(set(a.index.get_level_values('month'))):
                aa=a.loc[month];bb=b.loc[month];monthly.append(100*(bb['T'].mean()/(aa['T'].mean()*bb[c].mean()/aa[c].mean())-1))
            common.append({'period':period,'control':station,'year1':yr,'matched_cells':len(k),'retained_months':[int(m) for m in sorted(set(k.get_level_values('month')))],'baseline_paired_dates':int(a.n.sum()),'target_paired_dates':int(b.n.sum()),'raw_change_pct':100*(b['T'].mean()/a['T'].mean()-1),'controlled_change_pct':float(eff),'monthly_rmspe_pct':math.sqrt(sum(z*z for z in monthly)/len(monthly))})
result={'checked_on':'2026-11-05','source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'analysis_sha256':hashlib.sha256((P/'mcguinness-analysis.json').read_bytes()).hexdigest(),'checks':checks,'largest_absolute_numeric_error':largest_error,'source_hash_matches_analysis':analysis['source_csv_sha256']==hashlib.sha256(source.read_bytes()).hexdigest(),'pairwise_daily_support':support,'common_three_station_sensitivity':common}
(P/'mcguinness-audit-checks.json').write_text(json.dumps(result,indent=2)+'\n')
print('Verified',len(checks),'comparison rows; maximum arithmetic difference',largest_error)
