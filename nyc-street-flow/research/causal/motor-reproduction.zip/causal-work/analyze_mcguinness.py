"""Pre-period control diagnostics and same-calendar-window motor-count contrasts.
These are approach-traffic diagnostics, not bridge person-flow effects.
Python3,pandas,numpy. Source CSV and metadata in neighboring causal-road/.
"""
from pathlib import Path
import json,hashlib
import pandas as pd,numpy as np
P=Path(__file__).parent; R=P.parent/'causal-road'
x=pd.read_csv(R/'nysdot-region11-bidirectional-days.csv',dtype={'station':str})
x['date']=pd.to_datetime(x.date);x['year']=x.date.dt.year;x['month']=x.date.dt.month;x['dow']=x.date.dt.dayofweek
x['flag']=x.possible_dropout_flag.astype(str).str.lower().isin(['true','1'])
labels={'021284':'McGuinness Boulevard approach','010009':'Boston Road, Bronx','010012':'Broadway, Bronx'}
cols={'day':'all_day_vehicles','am':'am_07_10_vehicles','pm':'pm_16_19_vehicles'}
results=[];monthly=[];datepairs=[]
for period,col in cols.items():
 for c in ['010009','010012']:
  for quality in ['all_complete','exclude_flagged']:
   sub=x[(x.station.isin(['021284',c]))&(x.dow<5)&(x.year.isin([2014,2015,2016,2017]))].copy()
   if quality=='exclude_flagged':sub=sub[~sub.flag]
   wide=sub.pivot(index='date',columns='station',values=col).dropna()
   wide=wide[(wide['021284']>0)&(wide[c]>0)]
   wide['month']=wide.index.month;wide['year']=wide.index.year;wide['dow']=wide.index.dayofweek
   # Use same source dates for target/control. Each month/day-of-week cell must have >=2 paired dates.
   g=wide.groupby(['year','month','dow']).agg(target=('021284','mean'),control=(c,'mean'),days=('021284','size')).reset_index();g=g[g.days>=2]
   for targetyear,months,label in [(2015,list(range(1,9)),'pre_validation_Jan_Aug_2014_to_2015'),(2016,list(range(5,13)),'post_May_Dec_2014_to_2016'),(2017,list(range(5,13)),'later_May_Dec_2014_to_2017')]:
    a=g[(g.year==2014)&g.month.isin(months)].set_index(['month','dow']);b=g[(g.year==targetyear)&g.month.isin(months)].set_index(['month','dow']);k=a.index.intersection(b.index);a=a.loc[k];b=b.loc[k]
    if not len(k):continue
    # Equal month/day-type weights avoid treating sensor availability as travel weights.
    t0=a.target.mean();t1=b.target.mean();c0=a.control.mean();c1=b.control.mean()
    ct=t0*c1/c0;effect=t1-ct;obs=t1/t0-1;eff=t1/ct-1
    # Cell-specific ratios below are diagnostic only. The main estimator is the ratio of equal-cell-weighted means.
    per=(b.target/(a.target*b.control/a.control)-1)
    row={'period':period,'control':c,'control_name':labels[c],'quality':quality,'window':label,'year0':2014,'year1':targetyear,'matched_cells':len(k),'requested_cells':len(months)*5,'baseline_paired_dates':int(a.days.sum()),'target_paired_dates':int(b.days.sum()),'treated_baseline_vehicles':t0,'treated_target_vehicles':t1,'control_baseline_vehicles':c0,'control_target_vehicles':c1,'raw_change_pct':obs*100,'scaled_counterfactual_vehicles':ct,'controlled_change_vehicles':effect,'controlled_change_pct':eff*100,'month_day_type_ratio_rmse_pct':float(np.sqrt(np.mean(per**2))*100),'month_day_type_ratio_median_pct':float(np.median(per)*100)}
    results.append(row)
    for mm in sorted(set(k.get_level_values('month'))):
     aa=a.loc[mm];bb=b.loc[mm];at=aa.target.mean();bt=bb.target.mean();ac=aa.control.mean();bc=bb.control.mean();monthly.append({'period':period,'control':c,'quality':quality,'window':label,'month':int(mm),'cells':len(aa),'target_baseline':at,'target_after':bt,'control_baseline':ac,'control_after':bc,'relative_change_pct':100*(bt/(at*bc/ac)-1)})
# Pre-period diagnostics: requested windows match but available support differs across controls. Do not rank controls on these errors alone.
rank=[]
for period in cols:
 rows=[r for r in results if r['period']==period and r['quality']=='exclude_flagged' and r['window'].startswith('pre_validation')]
 for r in rows:
  mr=[m for m in monthly if m['period']==period and m['control']==r['control'] and m['quality']=='exclude_flagged' and m['window'].startswith('pre_validation')]
  rank.append({'period':period,'control':r['control'],'monthly_pre_rmspe_pct':float(np.sqrt(np.mean([m['relative_change_pct']**2 for m in mr]))),'pre_mean_bias_pct':r['controlled_change_pct'],'months_validated':len(mr),'selection_note':'Descriptive pre-period check. No control deemed validated solely because it has the smaller error.'})
result={'title':'Pulaski approach motor-count counterfactual diagnostics','checked_on':'2026-11-05','source_csv_sha256':hashlib.sha256((R/'nysdot-region11-bidirectional-days.csv').read_bytes()).hexdigest(),'scope':'Both directions on McGuinness Boulevard between I-278/Meeker and Greenpoint Avenue; intervening junctions separate this counter from Pulaski Bridge. Vehicles, not people.','periods':{'day':'00–24h','am':'07–10h','pm':'16–19h'},'design':{'pre_validation':'Same Jan–Aug month×weekday cells,2014 vs2015;2015-09–2016-04excludedasconstruction','primary_post':'Same May–Dec month×weekday cells,2014 vs2016;May–Dec2017sensitivitycanincludeKosciuszkoopening','controls':'Two available non-highway arterial stations with dense2014/2015data, bothinBronx. KentAvebegins2016andcannotvalidatepretrends.','weights':'Equal month×weekday cells;only common source dates across target/control ineachyear;atleast2paired dates/cell','counterfactual':'Baseline targetmean × controltargetmean / controlbaselinemean','selection':'Pre-period errors displayed before post result; no post-based choice. No causalsignificance claim or synthetic precision.'},'control_pre_validation':rank,'comparisons':results,'monthly_comparisons':monthly,'limitations':['Not a bridge screenline; no bicycle/pedestrian/passenger counts at thiscounter.','Only approximate intervention window; permanent motorlaneclosure dateunverified.','Distantcontrols mayhave differentlocaltrends andunverified cointerventions.','Missingday patterns anddetectorchanges mayaffectmeans. Stable stationIDdoesnotprovecalibrationcontinuity.','2017KosciuszkoBridgeopening is a competingnetworkchange;primarypostends2016.','Commoncalendar windowsandprechecksdo notestablishexogenousassignment orparallelposttrends.']}
result.update({'design': {'pre_validation': 'Earlier-period diagnostic: requested January–August 2014 versus 2015. Boston retains 34/40 cells across eight months; Broadway 22/40 across January–June only. These dates are not guaranteed untreated: the December 2014 plan scheduled an April 2015 project start, while a September 2015 release says construction recently began. Exact temporary and permanent lane-closure dates remain unverified. September 2015–April 2016 is excluded by the analysis, not established as the complete construction interval. See the newer directional analysis for January–February sensitivity.', 'primary_post': 'Requested May–December 2014 versus 2016. Boston retains 31/40 cells, no December; Broadway 26/40, no July or August. The 2017 sensitivity may include the Kosciuszko opening.', 'controls': 'Two available non-highway arterial stations with dense 2014/2015 data, both in the Bronx. Kent Avenue begins in 2016 and cannot validate pretrends.', 'weights': 'Equal retained month × weekday cells; at least two exact-date pairs within each year. Equal cells do not imply equal months when support is incomplete.', 'counterfactual': 'Mean baseline target × mean post control / mean baseline control, with the same retained-cell weights within each pair.', 'selection': 'Exploratory diagnostics; no causal significance claim. Different pairwise support prevents fair control ranking. See independent common-three-station audit.'}, 'limitations': ['Approach-road vehicles, not a bridge screenline or all-mode person flow.', 'Exact permanent motor-lane closure date is unverified.', 'Both controls are in the Bronx; local trends and co-interventions can differ.', 'Missing observations and detector changes may affect means; a stable station ID does not establish calibration continuity.', 'Pairwise estimates use different target samples; see common-support audit.', 'The 2017 common sample has only two cells, in May.', 'The 2017 Kosciuszko Bridge opening is a competing network change.', 'Pre-period checks do not establish exogenous assignment or parallel post-treatment trends.'], 'audit_note': 'All 36 estimates independently reconcile within 2.2e-11. Common three-station full-day comparison retains 20/40 post cells: raw change −6.68%, relative change −4.91% vs Boston and −9.76% vs Broadway. See audit files.'})
(P/'mcguinness-analysis.json').write_text(json.dumps(result,indent=2));pd.DataFrame(results).to_csv(P/'mcguinness-comparisons.csv',index=False);pd.DataFrame(monthly).to_csv(P/'mcguinness-monthly-comparisons.csv',index=False)
print(json.dumps(rank,indent=2));print(pd.DataFrame([r for r in results if r['quality']=='exclude_flagged' and r['period']=='day'])[['control_name','window','matched_cells','raw_change_pct','controlled_change_pct']].to_string(index=False))
