#!/usr/bin/env python3
"""Rebuild bridge-entry and nearby continuous-motor coverage from cached sources.

Run python reproduce.py. Add --refresh to download the source archives and repeat
the saved Socrata aggregation queries. Uses only Python standard library.
No causal effect, person count, or imputation is produced.
"""
import argparse, collections, csv, datetime as dt, io, json, pathlib, urllib.request, zipfile

P = pathlib.Path(__file__).resolve().parent
BASE = 'https://www.dot.ny.gov/divisions/engineering/technical-services/highway-data-services/hdsb/repository/'
ARCHIVES = ['CC_VOL_R11_2014.zip','CC_VOL_R11_2015.zip'] + [f'CC_Volume_Data_R11_{y}.zip' for y in (2016,2017,2018,2021)]

def dump(name, data):
    (P/name).write_text(json.dumps(data,indent=2)+'\n')

def csvout(name, rows):
    if not rows:return
    temp=P/(name+'.tmp')
    with temp.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    temp.replace(P/name)

def get(url, path):
    with urllib.request.urlopen(url,timeout=120) as r:path.write_bytes(r.read())

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--refresh',action='store_true');args=parser.parse_args()
    if args.refresh:
        for n in ARCHIVES:get(BASE+n,P/n)
        for stem in ('crz-bridge-hourly-2025-jan-aug','crz-bridge-daily-class-2025-jan-aug'):
            get((P/(stem+'-query.txt')).read_text().strip(),P/(stem+'.json'))
    hourly=json.loads((P/'crz-bridge-hourly-2025-jan-aug.json').read_text())
    classes=json.loads((P/'crz-bridge-daily-class-2025-jan-aug.json').read_text())
    for rows in (hourly,classes):
        for r in rows:
            for k in ('crz_entries','excluded_roadway_entries','source_rows','intervals'):r[k]=int(r[k])
            r['detected_cbd_entries']=r['crz_entries']+r['excluded_roadway_entries']
    csvout('crz-bridge-hourly-2025-jan-aug.csv',hourly)
    csvout('crz-bridge-daily-class-2025-jan-aug.csv',classes)
    bybridge=collections.defaultdict(list)
    for r in hourly:bybridge[r['detection_group']].append(r)
    bridgecoverage=[]
    for bridge,rows in sorted(bybridge.items()):
        expected=[];x=dt.datetime(2025,1,5)
        while x<dt.datetime(2025,9,1):expected.append(x.isoformat());x+=dt.timedelta(hours=1)
        observed={r['toll_hour'][:19] for r in rows}
        missing=sorted(set(expected)-observed)
        assert missing==['2025-03-09T02:00:00'],(bridge,missing)
        assert all(r['source_rows']==36 and r['intervals']==6 for r in rows)
        bridgecoverage.append(dict(bridge=bridge,first_hour=min(observed),last_hour=max(observed),calendar_days=239,hour_rows=len(rows),missing_wall_clock_hours=missing,missing_hour_explanation='US daylight saving spring transition; not a gap in real elapsed hours',crz_entries=sum(r['crz_entries'] for r in rows),excluded_roadway_entries=sum(r['excluded_roadway_entries'] for r in rows)))
    daily=collections.defaultdict(lambda:dict(crz_entries=0,excluded_roadway_entries=0,hour_rows=0))
    for r in hourly:
        a=daily[(r['detection_group'],r['toll_hour'][:10])]
        for k in ('crz_entries','excluded_roadway_entries'):a[k]+=r[k]
        a['hour_rows']+=1
    csvout('crz-bridge-daily-2025-jan-aug.csv',[dict(bridge=b,date=d,**v) for (b,d),v in sorted(daily.items())])
    classdaily=collections.defaultdict(lambda:dict(crz_entries=0,excluded_roadway_entries=0,classes=0))
    for r in classes:
        a=classdaily[(r['detection_group'],r['toll_date'][:10])]
        for k in ('crz_entries','excluded_roadway_entries'):a[k]+=r[k]
        a['classes']+=1
        assert r['intervals']==(138 if r['toll_date'][:10]=='2025-03-09' else 144)
    for key,a in classdaily.items():
        assert a['classes']==6
        assert all(a[k]==daily[key][k] for k in ('crz_entries','excluded_roadway_entries'))
    hourlymc=[];daymc=[];stationcoverage=[];alldays=[]
    for archive in ARCHIVES:
        z=zipfile.ZipFile(P/archive);member=z.namelist()[0]
        rows=[{k.strip():v.strip() for k,v in r.items()} for r in csv.DictReader(io.StringIO(z.read(member).decode('utf-8-sig')))]
        station_groups=collections.defaultdict(list)
        for raw_index,r in enumerate(rows,2):
            station=r.get('RC_STATION') or r.get('Station ID'); station=station.replace('_','')
            date=dt.date(int(r['YEAR']),int(r['MONTH']),int(r['DAY'])).isoformat()
            values=[r.get(f'INTERVAL_{i:02d}',r.get(f'I{i}')) for i in range(1,25)]
            code=r.get('FEDERAL_DIRECTION',r.get('ROAD'))
            # Before 2016, ROAD 99 is primary Begin->End. McGuinness:
            # MEEKER AVE N -> GREENPOINT AVE runs north. Preserve source code.
            direction={'1':'NB','5':'SB','99':'NB','-99':'SB'}.get(code,'unmapped') if station=='021284' else code
            detail=dict(station=station,date=date,direction=direction,direction_source_code=code,nonmissing_hours=sum(v!='' for v in values),sum_observed_vehicles=sum(int(v) for v in values if v!=''),zero_hours=sum(v=='0' for v in values),source_file=archive,source_csv_row=raw_index)
            detail['negative_hours']=sum(v!='' and int(v)<0 for v in values)
            detail['all_24_present_nonnegative']=detail['nonmissing_hours']==24 and detail['negative_hours']==0
            detail['zero_or_missing_flag']=detail['zero_hours']>0 or detail['nonmissing_hours']<24
            # A conservative screening flag, not a sensor-fault adjudication.
            # Real quiet hours remain distinguishable through the original counts.
            detail['possible_dropout_flag']=detail['zero_or_missing_flag'] or detail['negative_hours']>0
            detail['source_lanes_in_direction']=r.get('LANES_IN_DIRECTION','')
            detail['source_dotid']=r.get('DOTID','')
            detail['weekday']=dt.date.fromisoformat(date).weekday()<5
            for period,indices in [('am_07_10',range(7,10)),('pm_16_19',range(16,19))]:
                vv=[values[i] for i in indices]
                detail[period+'_nonmissing_hours']=sum(v!='' for v in vv)
                detail[period+'_vehicles']=sum(int(v) for v in vv) if all(v!='' and int(v)>=0 for v in vv) else ''
            alldays.append(detail)
            station_groups[(station,code)].append(detail)
            if station!='021284':continue
            daymc.append(detail)
            for hour,value in enumerate(values):
                hourlymc.append(dict(station=station,date=date,hour=hour,direction=direction,direction_source_code=code,vehicles=int(value) if value!='' else '',is_missing=value=='',source_file=archive,source_csv_row=raw_index))
        for (station,code),ss in sorted(station_groups.items()):
            stationcoverage.append(dict(station=station,source_file=archive,year=int(ss[0]['date'][:4]),direction_source_code=code,day_rows=len(ss),unique_days=len({x['date'] for x in ss}),first_day=min(x['date'] for x in ss),last_day=max(x['date'] for x in ss),days_with_24_values=sum(x['nonmissing_hours']==24 for x in ss),observed_hours=sum(x['nonmissing_hours'] for x in ss),zero_hours=sum(x['zero_hours'] for x in ss)))
    assert len({(r['date'],r['direction']) for r in daymc})==len(daymc),'Duplicate McGuinness day-direction keys'
    csvout('nysdot-region11-station-coverage.csv',stationcoverage)
    csvout('nysdot-region11-directional-days.csv',sorted(alldays,key=lambda r:(r['station'],r['date'],r['direction_source_code'])))
    csvout('mcguinness-continuous-directional-days.csv',sorted(daymc,key=lambda r:(r['date'],r['direction'])))
    csvout('mcguinness-continuous-hourly.csv',sorted(hourlymc,key=lambda r:(r['date'],r['hour'],r['direction'])))
    monthly=collections.defaultdict(list)
    for r in daymc:
        if r['weekday']:
            for period in ('am_07_10','pm_16_19'):
                if r[period+'_vehicles']!='':monthly[(r['date'][:7],r['direction'],period)].append(r[period+'_vehicles'])
    csvout('mcguinness-monthly-weekday-peaks.csv',[dict(month=m,direction=d,period=p,observed_weekdays=len(v),observed_vehicle_sum=sum(v),mean_vehicles_per_observed_weekday=sum(v)/len(v),minimum=min(v),maximum=max(v))for(m,d,p),v in sorted(monthly.items())])
    # Two-direction station-day panel avoids cross-version direction-code ambiguity.
    both=collections.defaultdict(list)
    for r in alldays:both[(r['station'],r['date'])].append(r)
    panel=[]
    for (station,date),rr in sorted(both.items()):
        row=dict(station=station,date=date,weekday=rr[0]['weekday'],direction_rows=len(rr))
        row['all_day_vehicles']=sum(r['sum_observed_vehicles']for r in rr) if len(rr)==2 and all(r['all_24_present_nonnegative'] for r in rr) else ''
        row['zero_hours']=sum(r['zero_hours']for r in rr)
        row['negative_hours']=sum(r['negative_hours']for r in rr)
        row['possible_dropout_flag']=len(rr)!=2 or any(r['possible_dropout_flag']for r in rr)
        for period in ('am_07_10','pm_16_19'):
            row[period+'_vehicles']=sum(r[period+'_vehicles']for r in rr) if len(rr)==2 and all(r[period+'_vehicles']!=''for r in rr) else ''
        panel.append(row)
    csvout('nysdot-region11-bidirectional-days.csv',panel)
    mcsummary=[r for r in stationcoverage if r['station']=='021284']
    dump('coverage.json',dict(checked_on='2026-11-05',bridge_entries=bridgecoverage,crz_hourly_rows=len(hourly),crz_daily_class_rows=len(classes),mcguinness=mcsummary,mcguinness_hour_rows=len(hourlymc),mcguinness_directional_days=len(daymc),validation=['CRZ hourly and daily-class sums agree on every bridge-day','Every observed CRZ hour has 6 ten-minute blocks and 6 classes','Only absent CRZ local wall-clock hour is 2025-03-09 02:00 (DST)','McGuinness date-direction keys are unique; blanks retained, zeros not imputed'],methods=['CRZ sums are two distinct official fields: entries reaching zone and entries remaining on excluded roadways. Their sum is detected CBD entries, not full two-way bridge traffic.','State CSVs stripped of surrounding spaces; hourly columns unpivoted without interpolation.','2015 ROAD99 primary direction maps north by published Meeker-to-Greenpoint endpoints; -99 maps south. 2016+ federal 1 and 5 are north and south. Original codes retained.','A full set of hourly values establishes availability only, not a guarantee of valid traffic for every hour.','No passenger or occupancy conversion and no causal estimate.']))
    print(json.dumps({'crz_hourly':len(hourly),'crz_daily_class':len(classes),'mcguinness_hour_rows':len(hourlymc),'mcguinness_directional_days':len(daymc),'mcguinness_years':sorted({r['year']for r in mcsummary})}))

if __name__=='__main__':main()
