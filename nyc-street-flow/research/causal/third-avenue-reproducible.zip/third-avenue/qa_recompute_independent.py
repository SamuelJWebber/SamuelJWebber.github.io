"""Independent stdlib QA; does not import or execute the analysis implementation."""
from collections import defaultdict,Counter
from pathlib import Path
from statistics import median,mean,stdev
from math import sqrt
import json,hashlib
P=Path(__file__).resolve().parent
sources=['bus-panel-raw.json','bus-panel-2024h2-raw.json']
raw=sum([json.loads((P/f).read_text()) for f in sources],[])
pre=[f'2023-{m:02d}' for m in range(1,7)];post=[f'2024-{m:02d}' for m in range(1,7)]
months=pre+post
hours={7,8,9,16,17,18};days={'Monday','Tuesday','Wednesday','Thursday','Friday'}
services={('M101','Limited'),('M102','Local'),('M103','Local')}
endpoints={'third_treated':('402688','403777'),'lexington':('403418','403422')}
source=defaultdict(list); base_dist=defaultdict(list); selected=[]
for r in raw:
    route=(r['route_id'],r['route_type']);hour=int(r['hour_of_day']);day=r['day_of_week']
    if route not in services or hour not in hours or day not in days:continue
    pair=(r['timepoint_stop_id'],r['next_timepoint_stop_id'])
    g=next((g for g,pair0 in endpoints.items() if pair==pair0),None)
    if g is None:continue
    m=f"{int(r['year'])}-{int(r['month']):02d}"
    c=route+(day,hour)
    n=float(r['bus_trip_count']);t=float(r['average_travel_time']);d=float(r['road_distance'])
    if min(n,t,d)<=0:continue
    selected.append(r)
    source[g,m,c].append((n,t,d))
    if m in pre:base_dist[g,c].append(d)
cells={g:{c for g0,m,c in source if g0==g and m in months} for g in endpoints}
support={g:{c for c in cells[g] if all((g,m,c) in source for m in months)} for g in endpoints}
paired=support['third_treated']&support['lexington']
ncounts={};times={};pace={}
for k,values in source.items():
    ncounts[k]=sum(x[0] for x in values);times[k]=sum(x[0]*x[1] for x in values)/ncounts[k]
    g,m,c=k
    if (g,c) in base_dist:pace[k]=times[k]/median(base_dist[g,c])
base={c:sum(ncounts['third_treated',m,c] for m in pre) for c in paired}
weights={c:n/sum(base.values()) for c,n in base.items()}
series={g:{m:sum(weights[c]*pace[g,m,c] for c in paired) for m in months} for g in endpoints}
monthly=[(series['third_treated'][b]-series['third_treated'][a])-(series['lexington'][b]-series['lexington'][a]) for a,b in zip(pre,post)]
effect=mean(monthly);scale=1.472*60
rawseries={g:{m:sum(pace[g,m,c]*ncounts[g,m,c] for c in cells[g] if (g,m,c) in pace)/sum(ncounts[g,m,c] for c in cells[g] if (g,m,c) in pace) for m in months} for g in endpoints}
rawdid=(mean(rawseries['third_treated'][m] for m in post)-mean(rawseries['third_treated'][m] for m in pre))-(mean(rawseries['lexington'][m] for m in post)-mean(rawseries['lexington'][m] for m in pre))
pre_gaps=[series['third_treated'][m]-series['lexington'][m] for m in pre]
train_t=mean(series['third_treated'][m] for m in pre[:3]);train_c=mean(series['lexington'][m] for m in pre[:3])
errors=[(series['third_treated'][m]-train_t*series['lexington'][m]/train_c)*scale for m in pre[3:]]
coverage={g:[{'month':m,'matched_cells':len(paired),'available_cells':sum((g,m,c) in source for c in cells[g]),'matched_trips':sum(ncounts[g,m,c] for c in paired),'available_trips':sum(ncounts[g,m,c] for c in cells[g] if (g,m,c) in source)} for m in months] for g in endpoints}
for rows in coverage.values():
 for r in rows:r['share']=r['matched_trips']/r['available_trips']
reported=json.loads((P/'third-avenue-analysis.json').read_text())
e=next(e for e in reported['estimates'] if e['period']=='combined' and e['control']=='lexington')
checks={'combined_effect_seconds':effect*scale,'difference_from_reported_seconds':effect*scale-e['did_seconds_over_treated_segment'],'raw_mix_effect_seconds':rawdid*scale,'t_interval_seconds':[(effect-2.570581835636305*stdev(monthly)/sqrt(6))*scale,(effect+2.570581835636305*stdev(monthly)/sqrt(6))*scale],'pre_placebo_seconds':(mean(pre_gaps[3:])-mean(pre_gaps[:3]))*scale,'heldout_rmspe_seconds':sqrt(mean(x*x for x in errors)),'heldout_mean_error_seconds':mean(errors),'month_pair_seconds':[d*scale for d in monthly]}
summary={g:{'before_minutes_per_mile':mean(series[g][m] for m in pre),'after_minutes_per_mile':mean(series[g][m] for m in post),'directions':sorted({r['direction'] for r in selected if r['timepoint_stop_id']==endpoints[g][0]}),'distances':sorted({round(float(r['road_distance']),8) for r in selected if r['timepoint_stop_id']==endpoints[g][0]}),'stop_orders':sorted({r['stop_order'] for r in selected if r['timepoint_stop_id']==endpoints[g][0]})} for g in endpoints}
weightqa={'cells_per_group':{g:len(cells[g]) for g in cells},'complete_cells_per_group':{g:len(support[g]) for g in support},'paired_complete_cells':len(paired),'theoretical_cells':3*5*6,'sum_weights':sum(weights.values()),'baseline_treated_trip_count':sum(base.values()),'weight_by_route':{r:sum(w for c,w in weights.items() if c[0]==r) for r,_ in services},'weight_by_hour':{h:sum(w for c,w in weights.items() if c[3]==h) for h in sorted(hours)}}
assert abs(checks['difference_from_reported_seconds'])<1e-9
assert len(paired)==90
assert all(abs(r['share']-1)<1e-12 for rows in coverage.values() for r in rows)
sha={f:hashlib.sha256((P/f).read_bytes()).hexdigest() for f in sources}
out={'checked_on':'2026-11-05','reviewer':'independent subagent, standard-library recomputation without running analysis script','status':'arithmetic_pass_with_identification_limits','primary_recomputed':checks,'group_summaries':summary,'weights':weightqa,'coverage':coverage,'raw_file_sha256':sha,'findings':[{'severity':'pass','finding':'Primary paired fixed-weight DID independently matches −27.9516848066 seconds over1.472miles. All90 route/service×weekday×hour cells exist in all12 primary months in both groups; matched share100% of selected source bus trips.'},{'severity':'pass','finding':'Observed GPS-derived timepoint travel times are minutes; distance is miles. Bus-trip-weighted source collapse and fixed baseline treated weights are appropriate for a bus-vehicle estimand. Lexington uses precisely the treated weights. Equal six-month averages and Jan-to-Jan pairing are consistent.'},{'severity':'major_identification_limit','finding':'Pre-period Q1-to-Q2 gap drift is +52.0507sec and held-out RMSPE54.0958sec, larger than the −27.9517sec post contrast. No firm causal effect or isolated bicycle-lane effect is supported; opposite-direction Lexington and intervention/spillover histories remain substantive assumptions.'},{'severity':'inference_caution','finding':'Six-pair t interval includes zero. A two-month circular block percentile interval can exclude zero despite extremely little independent information; it is exploratory variability, not calibrated causal confidence. Existing warning is necessary; do not feature this interval as statistical proof.'},{'severity':'diagnostic_caution','finding':'The held-out check calibrates Q1 levels but retains Jan–June2023 trip weights and full12-month complete-case support. It is not a fully frozen Q1-only forecasting exercise. This is disclosed; no missing primary cells means post-support selection has no numerical effect here.'},{'severity':'robustness','finding':'Analysis relies on raw fetch filters for weekdays and infers direction from exact stop IDs. Both are verified in these raw files. Add explicit assertions if inputs change; current estimates unaffected.'},{'severity':'scope','finding':'Counterfactual and percent fields are conditional arithmetic predictions, not validated counterfactuals. Road-distance normalization makes different-length corridors comparable only under parallel pace trends. Includes bus stop dwell/traffic/signals; no passenger occupancy, private-car speed or door-to-door time.'},{'severity':'scope','finding':'E67→E97 excludes the project E59→E67 section and includes one block beyond E96. Complete support means complete aggregate cells, not complete underlying GPS observations or every actual weekday.'}]}
(P/'qa-independent.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'checks':checks,'weights':weightqa,'groups':summary},indent=2))

# Route/service stratification and a route-matched northern sensitivity, independently from raw rows.
allpairs={**endpoints,'third_north':('401946','402502')}
zz=defaultdict(list);dd=defaultdict(list)
for r in raw:
    service=(r['route_id'],r['route_type']);hour=int(r['hour_of_day']);day=r['day_of_week']
    if service not in services or hour not in hours or day not in days:continue
    pair=(r['timepoint_stop_id'],r['next_timepoint_stop_id'])
    group=next((g for g,v in allpairs.items() if pair==v),None)
    if group is None or (group=='third_north' and service!=('M101','Limited')):continue
    month=f"{int(r['year'])}-{int(r['month']):02d}"
    if month not in months:continue
    cell=service+(day,hour);n=float(r['bus_trip_count']);t=float(r['average_travel_time']);distance=float(r['road_distance'])
    if min(n,t,distance)<=0:continue
    zz[group,month,cell].append((n,t,distance))
    if month in pre:dd[group,cell].append(distance)
cc={k:sum(r[0] for r in v) for k,v in zz.items()}
pp={k:sum(r[0]*r[1] for r in v)/cc[k]/median(dd[k[0],k[2]]) for k,v in zz.items()}
supp=[]
for service,ctrl in [(s,'lexington') for s in sorted(services)]+[(('M101','Limited'),'third_north')]:
    common={k[2] for k in zz if k[0]=='third_treated' and k[2][:2]==service}
    common={c for c in common if all((g,m,c) in zz for g in ['third_treated',ctrl] for m in months)}
    baseline={c:sum(cc['third_treated',m,c] for m in pre) for c in common};tot=sum(baseline.values());ww={c:v/tot for c,v in baseline.items()}
    ss={g:{m:sum(ww[c]*pp[g,m,c] for c in common) for m in months} for g in ['third_treated',ctrl]}
    diff=[(ss['third_treated'][b]-ss['third_treated'][a])-(ss[ctrl][b]-ss[ctrl][a]) for a,b in zip(pre,post)]
    record={'route':service[0],'service':service[1],'control':ctrl,'paired_cells':len(common),'baseline_treated_trips':tot,'weights':'Within-route Jan–June2023 treated bus-trip counts, identical weights in treated/control','treated_change_seconds_over_1_472mi':(mean(ss['third_treated'][m] for m in post)-mean(ss['third_treated'][m] for m in pre))*scale,'control_change_seconds_over_1_472mi':(mean(ss[ctrl][m] for m in post)-mean(ss[ctrl][m] for m in pre))*scale,'did_seconds_over_1_472mi':mean(diff)*scale,'six_pair_t_interval_seconds':[(mean(diff)-2.570581835636305*stdev(diff)/sqrt(6))*scale,(mean(diff)+2.570581835636305*stdev(diff)/sqrt(6))*scale],'month_pair_seconds':[v*scale for v in diff],'counterfactual_warning':'Descriptive controlled sensitivity with one treated corridor; same route does not remove segment differences or spillovers.'}
    supp.append(record)
out['route_service_sensitivity']=supp
out['findings'].append({'severity':'important_sensitivity','finding':'M101-Limited matched northern sensitivity remains positive even after pairing the same30 cells and baseline treated route weights; northern-control sign reversal is not merely different route mix. Its negative control time change can reflect segment-specific changes/spillovers; no clean causal interpretation.'})
(P/'qa-independent.json').write_text(json.dumps(out,indent=2)+'\n')
print('Route sensitivities:',json.dumps(supp,indent=2))
# Also validate that the published weight export uses identical primary weights.
import csv
export=list(csv.DictReader((P/'bus-baseline-cell-weights.csv').open()))
export=[r for r in export if r['period']=='combined' and r['support']=='primary12' and r['group'] in endpoints]
wg={g:{r['cell']:float(r['weight']) for r in export if r['group']==g} for g in endpoints}
assert wg['third_treated']==wg['lexington']
out['weights']['exported_lexington_weights_exactly_equal_treated']=True
out['weights']['exported_weight_sum']=sum(wg['third_treated'].values())
(P/'qa-independent.json').write_text(json.dumps(out,indent=2)+'\n')
