"""Period-specific static SVGs for the interactive Third Avenue evidence view."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parent
d=json.load(open(ROOT/'third-avenue-analysis.json'))
colors={'third_treated':'#264f38','lexington':'#9c593a','first':'#366b8c','madison':'#795992'}
names={'third_treated':'Third Ave · treated','lexington':'Lexington · primary control','first':'First Avenue','madison':'Madison Avenue'}
for period,label in [('am','AM 07:00–09:59'),('pm','PM 16:00–18:59'),('combined','AM + PM peaks')]:
 p=pd.DataFrame(d['monthly_panel']).query('support=="event24" and period==@period').pivot(index='month',columns='group',values='fixed_minutes_per_mile')
 x=np.arange(24)
 fig,axes=plt.subplots(2,1,figsize=(10.5,6.4),sharex=True,gridspec_kw={'height_ratios':[1,1.1]})
 fig.patch.set_facecolor('#fffefa')
 for ax in axes:
  ax.set_facecolor('#fffefa');ax.spines[['top','right']].set_visible(False);ax.grid(axis='y',alpha=.2)
  ax.axvspan(5.5,11.5,color='#dfcb96',alpha=.45);ax.axvspan(11.5,17.5,color='#d9e4d7',alpha=.28);ax.set_xlim(-.25,23.25)
 for gid in ['third_treated','lexington']:
  axes[0].plot(x,p[gid]*1.472,label=names[gid],color=colors[gid],marker='o',ms=3,lw=2)
 axes[0].set_ylabel('Minutes per 1.472 miles\n(fixed 2023 bus weights)',fontsize=9)
 lo,hi=axes[0].get_ylim();axes[0].set_ylim(lo,hi+(hi-lo)*.17)
 axes[0].legend(loc='upper left',bbox_to_anchor=(0,-.025),ncols=2,frameon=False,fontsize=8)
 axes[0].set_title(f'{label} · Actual bus time and control comparisons',loc='left',fontsize=14,pad=20)
 axes[0].text(8.5,.99,'Implementation\nexcluded from estimate',transform=axes[0].get_xaxis_transform(),ha='center',va='top',fontsize=8)
 axes[0].text(14.5,.99,'Primary post window',transform=axes[0].get_xaxis_transform(),ha='center',va='top',fontsize=8)
 for gid in ['lexington','first','madison']:
  gap=(p.third_treated-p[gid])*1.472*60;gap=gap-gap.iloc[:6].mean()
  axes[1].plot(x,gap,color=colors[gid],label=names[gid],marker='o',ms=2.5,lw=1.5)
 axes[1].axhline(0,color='#6e786d',lw=.8)
 axes[1].set_ylabel('Treated − control gap\nseconds from Jan–Jun 2023 mean',fontsize=9)
 axes[1].legend(loc='lower left',ncols=2,frameon=True,facecolor='#fffefa',edgecolor='#fffefa',framealpha=.95,fontsize=8)
 axes[1].set_xticks([0,3,6,9,12,15,18,21,23],['Jan\n2023','Apr','Jul','Oct','Jan\n2024','Apr','Jul','Oct','Dec'])
 fig.text(.09,.024,'Includes bus dwell and traffic. Treatment bundles bus, bike and intersection changes.\nPretrend failures and possible spillovers prevent a firm causal claim. Later 2024 points are descriptive.',fontsize=8.5,color='#455b49')
 fig.subplots_adjust(left=.10,right=.975,top=.89,bottom=.14,hspace=.23)
 fig.savefig(ROOT/f'third-avenue-event-{period}.svg')
 fig.savefig(ROOT/f'third-avenue-event-{period}.png',dpi=150)
 plt.close(fig)
