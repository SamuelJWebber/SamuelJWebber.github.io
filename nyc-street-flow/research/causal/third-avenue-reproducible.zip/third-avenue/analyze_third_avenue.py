"""Fixed-cell Third Avenue bus-time controlled before/after analysis.

Run fetch_bus_panel.py first. Input files are raw MTA endpoint responses retained
with source URLs and checksums. No passenger-weighted or total-time claim is made.
"""
from pathlib import Path
from itertools import product
import json, math
import numpy as np
import pandas as pd
from scipy.stats import t as student_t

ROOT=Path(__file__).resolve().parent
PERIODS={'am':[7,8,9],'pm':[16,17,18],'combined':[7,8,9,16,17,18]}
SERVICES={('M101','Limited'),('M102','Local'),('M103','Local')}
GROUPS={
 'third_treated': {'name':'Third Avenue E67→E97 northbound','start':'402688','end':'403777','services':SERVICES,'role':'treated'},
 'lexington': {'name':'Lexington Avenue E96→E68 southbound','start':'403418','end':'403422','services':SERVICES,'role':'primary_control'},
 'first': {'name':'First Avenue E79→E97 northbound','start':'401712','end':'903275','services':{('M15','Local')},'role':'independent_control'},
 'madison': {'name':'Madison Avenue E57→E95 northbound','start':'400363','end':'404191','services':{('M1','Local'),('M3','Local'),('M4','Local')},'role':'independent_control'},
 'third_south': {'name':'Third Avenue E23→E42 northbound','start':'403855','end':'402679','services':SERVICES,'role':'spatial_control'},
 'third_north': {'name':'Third Avenue E99→E125 northbound','start':'401946','end':'402502','services':{('M101','Limited')},'role':'spatial_control'},
}
MONTHS=[f'{y}-{m:02}' for y in [2023,2024] for m in range(1,13)]
PRE=[f'2023-{m:02}' for m in range(1,7)]
POST=[f'2024-{m:02}' for m in range(1,7)]
PRIMARY_MONTHS=PRE+POST
FIELDS=['route_id','route_type','day_of_week','hour_of_day']
raw=json.load(open(ROOT/'bus-panel-raw.json'))+json.load(open(ROOT/'bus-panel-2024h2-raw.json'))
df=pd.DataFrame(raw)
for k in ['year','month','hour_of_day','road_distance','average_travel_time','bus_trip_count']:
 df[k]=pd.to_numeric(df[k])
df['date']=df['year'].astype(str)+'-'+df['month'].astype(str).str.zfill(2)
df['group']=None
for gid,g in GROUPS.items():
 mask=(df.timepoint_stop_id==g['start'])&(df.next_timepoint_stop_id==g['end'])&df[['route_id','route_type']].apply(tuple,axis=1).isin(g['services'])
 df.loc[mask,'group']=gid
df=df[df.group.notna()&(df.average_travel_time>0)&(df.bus_trip_count>0)&(df.road_distance>0)].copy()
df['cell']=df[FIELDS].astype(str).agg('|'.join,axis=1)
df['weighted_time']=df.average_travel_time*df.bus_trip_count
keys=['group','date','cell']
# Floating-point distance variants are legitimate rows. Count-weighted collapse
# preserves all trips; distance stability is checked separately for each cell.
collapsed=df.groupby(keys).agg(trips=('bus_trip_count','sum'),weighted_time=('weighted_time','sum'),distance_min=('road_distance','min'),distance_max=('road_distance','max'),source_rows=('bus_trip_count','size')).reset_index()
collapsed['minutes']=collapsed.weighted_time/collapsed.trips
stability=collapsed.groupby(['group','cell']).agg(min_distance=('distance_min','min'),max_distance=('distance_max','max'))
stability['relative_range']=(stability.max_distance-stability.min_distance)/stability.min_distance
bad=set(stability[stability.relative_range>.01].index)
collapsed=collapsed[[ (g,c) not in bad for g,c in zip(collapsed.group,collapsed.cell)]].copy()
# One fixed roadway length per exact cell: median pre-period distance, invariant
# to later small GTFS rounding differences. This is not a raw-speed average.
distance=df[df.date.isin(PRE)].groupby(['group','cell']).road_distance.median().to_dict()
collapsed['fixed_distance']= [distance.get((g,c),np.nan) for g,c in zip(collapsed.group,collapsed.cell)]
collapsed['pace']=collapsed.minutes/collapsed.fixed_distance
collapsed=collapsed.dropna(subset=['pace'])
collapsed.to_csv(ROOT/'bus-fixed-cell-input.csv',index=False)

def series_for(period, support_months):
 hours=set(PERIODS[period]); sub=collapsed[collapsed.cell.map(lambda c:int(c.split('|')[-1]) in hours)].copy()
 groups={}; coverage=[]
 for gid,g in GROUPS.items():
  z=sub[sub.group==gid]
  mat=z.pivot(index='cell',columns='date',values='pace').reindex(columns=support_months)
  valid=set(mat.dropna().index)
  groups[gid]={'z':z,'valid':valid}
 # Pair the same route/service class, weekday and hour in both directions.
 paired=groups['third_treated']['valid']&groups['lexington']['valid']
 groups['third_treated']['valid']=paired;groups['lexington']['valid']=paired
 base=groups['third_treated']['z'].query('date in @PRE').groupby('cell').trips.sum()
 rows=[]; weight_rows=[]
 for gid,g in GROUPS.items():
  z=groups[gid]['z']; valid=groups[gid]['valid']
  ownbase=z[z.date.isin(PRE)].groupby('cell').trips.sum()
  b=base if gid in ['third_treated','lexington'] else ownbase
  w=b.reindex(sorted(valid)).dropna();w=w/w.sum()
  for cell,weight in w.items():weight_rows.append({'period':period,'support':'primary12' if len(support_months)==12 else 'event24','group':gid,'cell':cell,'weight':weight,'baseline_trips':float((base if gid=='lexington' else ownbase).get(cell,0))})
  for date in support_months:
   m=z[z.date==date].set_index('cell')
   retained=m.reindex(w.index)
   if len(w)==0 or retained.pace.isna().any():continue
   fixed=float((retained.pace*w).sum())
   raw=float((m.pace*m.trips).sum()/m.trips.sum())
   rows.append({'period':period,'support':'primary12' if len(support_months)==12 else 'event24','group':gid,'month':date,'fixed_minutes_per_mile':fixed,'raw_minutes_per_mile':raw,'fixed_cells':len(w),'matched_bus_trips':float(retained.trips.sum()),'published_bus_trips':float(m.trips.sum()),'matched_share':float(retained.trips.sum()/m.trips.sum())})
 return pd.DataFrame(rows),weight_rows

all_rows=[]; all_weights=[]; estimates=[]; month_diffs=[]; pretrends=[]
for period in PERIODS:
 primary,weights=series_for(period,PRIMARY_MONTHS);event,ew=series_for(period,MONTHS)
 all_rows.extend(primary.to_dict('records')+event.to_dict('records'));all_weights.extend(weights+ew)
 p=primary.pivot(index='month',columns='group',values='fixed_minutes_per_mile')
 r=primary.pivot(index='month',columns='group',values='raw_minutes_per_mile')
 for control in [g for g in GROUPS if g!='third_treated']:
  if control not in p:continue
  tpre=p.loc[PRE,'third_treated'].to_numpy();tpost=p.loc[POST,'third_treated'].to_numpy()
  cpre=p.loc[PRE,control].to_numpy();cpost=p.loc[POST,control].to_numpy()
  pre_gap=tpre-cpre; differences=(tpost-tpre)-(cpost-cpre)
  effect=float(differences.mean());treat_change=float(np.mean(tpost-tpre));control_change=float(np.mean(cpost-cpre))
  # Six paired calendar-month observations, never thousands of independent rows.
  se=float(np.std(differences,ddof=1)/np.sqrt(6));crit=float(student_t.ppf(.975,5))
  blocks=np.array([[differences[i],differences[(i+1)%6]] for i in range(6)])
  bootstrap=np.array([np.concatenate([blocks[i] for i in ix]).mean() for ix in product(range(6),repeat=3)])
  placebo=float(pre_gap[3:].mean()-pre_gap[:3].mean())
  pre_slope=float(np.polyfit(np.arange(6),pre_gap,1)[0])
  counterfactual=float(tpre.mean()+control_change)
  rawdid=float((r.loc[POST,'third_treated'].mean()-r.loc[PRE,'third_treated'].mean())-(r.loc[POST,control].mean()-r.loc[PRE,control].mean()))
  record={'period':period,'control':control,'control_role':GROUPS[control]['role'],'treated_before_min_per_mile':float(tpre.mean()),'treated_after_min_per_mile':float(tpost.mean()),'control_before_min_per_mile':float(cpre.mean()),'control_after_min_per_mile':float(cpost.mean()),'treated_change_min_per_mile':treat_change,'control_change_min_per_mile':control_change,'did_min_per_mile':effect,'did_seconds_over_treated_segment':effect*1.472*60,'counterfactual_after_segment_minutes':counterfactual*1.472,'observed_after_segment_minutes':float(tpost.mean())*1.472,'percent_vs_counterfactual':effect/counterfactual*100,'raw_mix_did_min_per_mile':rawdid,'pre_placebo_min_per_mile':placebo,'pre_placebo_seconds_over_treated_segment':placebo*1.472*60,'pretrend_slope_min_per_mile_per_month':pre_slope,'six_pair_t_interval_min_per_mile':[effect-crit*se,effect+crit*se],'two_month_circular_block_interval_min_per_mile':np.quantile(bootstrap,[.025,.975]).tolist(),'month_pairs':6,'independent_treated_corridors':1,'inference_warning':'Intervals describe variability in six month pairs under assumptions. One treated corridor, serial correlation, pretrend violations and spillover invalidate strong causal significance claims.','negative_month_pairs':int((differences<0).sum()),'leave_one_month_out_range_min_per_mile':[float(np.min([(differences.sum()-v)/5 for v in differences])),float(np.max([(differences.sum()-v)/5 for v in differences]))]}
  estimates.append(record)
  record.update({'q1_only_did_seconds_treated_segment':float(differences[:3].mean()*1.472*60),'q2_only_did_seconds_treated_segment':float(differences[3:].mean()*1.472*60),'exclude_may_did_seconds_treated_segment':float(np.delete(differences,4).mean()*1.472*60),'pre_gap_demeaned_rms_seconds_treated_segment':float(np.sqrt(np.mean((pre_gap-pre_gap.mean())**2))*1.472*60),'pre_gap_range_seconds_treated_segment':float((pre_gap.max()-pre_gap.min())*1.472*60)})
  # Honest pre-only forecast diagnostic: level calibration on Jan–Mar only;
  # April–June is held out. Neither ranking nor calibration uses post outcomes.
  train_t=float(tpre[:3].mean());train_c=float(cpre[:3].mean())
  pred=train_t*cpre/train_c
  errors=(tpre-pred)*1.472*60
  additive_errors=(pre_gap-pre_gap[:3].mean())*1.472*60
  record.update({'control_validation':{'training_months':PRE[:3],'held_out_months':PRE[3:],'prediction':'Jan–Mar treated mean × (monthly control / Jan–Mar control mean); fixed Jan–June 2023 count weights were retained, but no post outcomes used','train_rmspe_seconds_treated_segment':float(np.sqrt(np.mean(errors[:3]**2))),'held_out_rmspe_seconds_treated_segment':float(np.sqrt(np.mean(errors[3:]**2))),'held_out_mean_drift_seconds_treated_segment':float(errors[3:].mean()),'held_out_monthly_errors_seconds_treated_segment':errors[3:].tolist(),'additive_held_out_rmspe_seconds_treated_segment':float(np.sqrt(np.mean(additive_errors[3:]**2))),'control_selection_warning':'Exploratory pre-only diagnostic. Primary Lexington control remains frozen regardless of ranking; three held-out months are too few to establish parallel trends.'}})
  for i in range(6):month_diffs.append({'period':period,'control':control,'calendar_month':i+1,'did_min_per_mile':float(differences[i]),'did_seconds_treated_segment':float(differences[i]*1.472*60),'treated_before_min_per_mile':float(tpre[i]),'treated_after_min_per_mile':float(tpost[i]),'control_before_min_per_mile':float(cpre[i]),'control_after_min_per_mile':float(cpost[i])})
  for i in range(6):pretrends.append({'period':period,'control':control,'month':PRE[i],'treated_control_gap_min_per_mile':float(pre_gap[i]),'gap_relative_january':float(pre_gap[i]-pre_gap[0])})

panel=pd.DataFrame(all_rows);panel.to_csv(ROOT/'bus-monthly-fixed-panel.csv',index=False)
pd.DataFrame(all_weights).to_csv(ROOT/'bus-baseline-cell-weights.csv',index=False)
pd.DataFrame(estimates).to_csv(ROOT/'bus-controlled-comparisons.csv',index=False)
pd.DataFrame(month_diffs).to_csv(ROOT/'bus-paired-month-differences.csv',index=False)
pd.DataFrame(pretrends).to_csv(ROOT/'bus-pretrend-gaps.csv',index=False)
pd.DataFrame([{'period':e['period'],'control':e['control'],'post_did_seconds':e['did_seconds_over_treated_segment'],**{k:v for k,v in e['control_validation'].items() if isinstance(v,(int,float,str))}} for e in estimates]).to_csv(ROOT/'bus-preonly-control-validation.csv',index=False)
def scalar(v):
 if isinstance(v,(np.integer,np.floating)):return v.item()
 if isinstance(v,set):return sorted(v)
 raise TypeError(str(type(v)))
out={'title':'Third Avenue 2023 package: fixed-cell actual bus travel times','design':json.load(open(ROOT/'design-lock.json')),'groups':GROUPS,'qa':{'raw_rows':len(raw),'selected_rows':len(df),'collapsed_rows':len(collapsed),'distance_unstable_cells_excluded':len(bad),'duplicate_source_exact_rows':int(df.astype(str).duplicated().sum()),'available_months':sorted(df.date.unique()),'primary_month_pairs':6,'inference_units_note':'One treated street corridor; rows/trips are not independent policy replications.'},'estimates':estimates,'monthly_panel':all_rows,'pretrend_gaps':pretrends,'month_pair_differences':month_diffs,'sources':[json.load(open(ROOT/'bus-panel-source.json')),json.load(open(ROOT/'bus-panel-2024h2-source.json'))]}
primary=next(e for e in estimates if e['period']=='combined' and e['control']=='lexington')
out['summary']={'causal_identification_status':'Not established: primary pretrend and held-out pre-period validation are poor; control sensitivity includes a sign reversal.','conditional_estimate_seconds':primary['did_seconds_over_treated_segment'],'conditional_estimate_percent':primary['percent_vs_counterfactual'],'observed_treated_before_minutes':primary['treated_before_min_per_mile']*1.472,'observed_treated_after_minutes':primary['treated_after_min_per_mile']*1.472,'held_out_pre_rmspe_seconds':primary['control_validation']['held_out_rmspe_seconds_treated_segment'],'read_this_first':'This is an executed quasi-experimental attempt and a diagnostic failure to establish a clean causal effect. It supports a descriptive improvement and conditional package estimate, not a definitive bicycle-lane or all-traveler time effect.'}
out['source_evidence']=json.load(open(ROOT/'source-evidence.json'))
(ROOT/'third-avenue-analysis.json').write_text(json.dumps(out,indent=2,default=scalar,allow_nan=False))
print(pd.DataFrame(estimates)[['period','control','did_seconds_over_treated_segment','percent_vs_counterfactual','pre_placebo_seconds_over_treated_segment','negative_month_pairs']].to_string(index=False))
print('QA',out['qa'])
