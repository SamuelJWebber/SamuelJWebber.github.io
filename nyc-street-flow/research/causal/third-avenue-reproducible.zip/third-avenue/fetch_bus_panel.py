"""Download a bounded, documented MTA timepoint panel for Third Avenue checks."""
from pathlib import Path
import datetime, hashlib, json, urllib.parse, urllib.request, sys

ROOT = Path(__file__).resolve().parent
BASE = "hour_of_day between 6 and 19 AND day_of_week not in('Saturday','Sunday') AND timepoint_stop_id in(402688,403418,401712,400363,403855,401946)"
for name, dates in [('bus-panel',"year in(2023,2024) AND (year=2023 OR month<=6)"),('bus-panel-2024h2',"year=2024 AND month>=7")]:
 if (ROOT/(name+'-raw.json')).exists() and '--refresh' not in sys.argv:
  print('Using cached',name);continue
 query = {'$where':dates+' AND '+BASE, '$limit':'50000', '$order':'year,month,route_id,direction,route_type,timepoint_stop_id,next_timepoint_stop_id,day_of_week,hour_of_day,road_distance'}
 url = 'https://data.ny.gov/resource/58t6-89vi.json?' + urllib.parse.urlencode(query)
 raw = urllib.request.urlopen(url, timeout=180).read()
 rows = json.loads(raw)
 assert len(rows)<50000, 'Pagination required'
 (ROOT/(name+'-raw.json')).write_bytes(raw)
 (ROOT/(name+'-source.json')).write_text(json.dumps({'url':url,'retrieved_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'rows':len(rows),'sha256':hashlib.sha256(raw).hexdigest()},indent=2))
 print(json.dumps({'rows':len(rows),'bytes':len(raw),'years_months':sorted({(r['year'],r['month']) for r in rows})}))
