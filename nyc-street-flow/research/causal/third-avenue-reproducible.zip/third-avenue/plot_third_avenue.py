from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parent
d=json.load(open(ROOT/'third-avenue-analysis.json'))
p=pd.DataFrame(d['monthly_panel']).query("support=='event24' and period=='combined'").pivot(index='month',columns='group',values='fixed_minutes_per_mile')
x=np.arange(24)
fig,axes=plt.subplots(2,1,figsize=(11,7),sharex=True,gridspec_kw={'height_ratios':[1,1.15]})
fig.patch.set_facecolor('#fffefa')
colors={'third_treated':'#264f38','lexington':'#9c593a','first':'#366b8c','madison':'#795992','third_south':'#8a8860'}
names={'third_treated':'Third Ave · treated','lexington':'Lexington · primary control','first':'First Avenue','madison':'Madison Avenue','third_south':'Third Ave south'}
for ax in axes:
 ax.set_facecolor('#fffefa');ax.spines[['top','right']].set_visible(False);ax.grid(axis='y',alpha=.2)
 ax.axvspan(5.5,11.5,color='#dfcb96',alpha=.45)
 ax.axvspan(11.5,17.5,color='#d9e4d7',alpha=.28)
 ax.set_xlim(-.25,23.25)
for gid in ['third_treated','lexington']:
 axes[0].plot(x,p[gid]*1.472,label=names[gid],color=colors[gid],marker='o',ms=3,lw=2)
axes[0].set_ylabel('Minutes per 1.472 miles\n(fixed 2023 bus weights)',fontsize=10)
axes[0].legend(loc='upper left',bbox_to_anchor=(0,-.025),ncols=2,frameon=False,fontsize=9)
axes[0].set_title('Observed bus time improved slightly; the causal comparison remains uncertain',loc='left',fontsize=15,pad=23)
axes[0].text(8.5,.99,'Implementation\nexcluded from estimate',transform=axes[0].get_xaxis_transform(),ha='center',va='top',fontsize=8)
axes[0].text(14.5,.99,'Primary post window',transform=axes[0].get_xaxis_transform(),ha='center',va='top',fontsize=8)
for gid in ['lexington','first','madison']:
 gap=(p.third_treated-p[gid])*1.472*60
 gap=gap-gap.iloc[:6].mean()
 axes[1].plot(x,gap,color=colors[gid],label=names[gid],marker='o',ms=2.5,lw=1.5)
axes[1].axhline(0,color='#6e786d',lw=.8)
axes[1].set_ylabel('Treated − control gap\nseconds from Jan–Jun 2023 mean',fontsize=10)
axes[1].legend(loc='lower left',ncols=2,frameon=False,fontsize=8)
axes[1].set_xticks([0,3,6,9,12,15,18,21,23],['Jan\n2023','Apr','Jul','Oct','Jan\n2024','Apr','Jul','Oct','Dec'])
fig.text(.075,.025,'Third Ave E67→E97; weekdays 07:00–09:59 and 16:00–18:59. Includes bus dwell and traffic.\nThe package combines bus, bike and intersection changes. Pretrend failures and possible spillovers prevent a firm causal claim.',fontsize=9,color='#455b49')
fig.subplots_adjust(left=.09,right=.975,top=.89,bottom=.13,hspace=.2)
fig.savefig(ROOT/'third-avenue-event-series.png',dpi=170)
fig.savefig(ROOT/'third-avenue-event-series.svg')

fig,ax=plt.subplots(figsize=(9,4.9));fig.patch.set_facecolor('#fffefa');ax.set_facecolor('#fffefa')
rows=[e for e in d['estimates'] if e['period']=='combined']
labels=['Lexington\nprimary','First Ave','Madison','Third Ave\nsouth','Third Ave\nnorth']
xx=np.arange(5);width=.36
ax.bar(xx-width/2,[r['control_validation']['held_out_rmspe_seconds_treated_segment'] for r in rows],width,color='#a3815d',label='Held-out pre-period forecast error (RMS)')
ax.bar(xx+width/2,[r['did_seconds_over_treated_segment'] for r in rows],width,color='#40684d',label='Conditional controlled change after project')
ax.axhline(0,color='#6b7569',lw=.8);ax.set_xticks(xx,labels);ax.set_ylabel('Seconds over the treated 1.472-mile distance')
ax.set_ylim(-40,80)
ax.spines[['top','right']].set_visible(False);ax.grid(axis='y',alpha=.2);ax.set_axisbelow(True)
ax.set_title('Pre-period forecast errors are as large as the estimated savings',loc='left',fontsize=14,pad=17)
ax.legend(frameon=False,fontsize=8,loc='upper left',bbox_to_anchor=(0,1.02))
fig.text(.10,.025,'Pre-only diagnostic: calibrate controls on Jan–Mar 2023, validate on Apr–Jun 2023.\nPost estimate: Jan–Jun 2024 versus the same months in 2023. Negative change means shorter bus time.\nPrimary control stays Lexington; three validation months cannot establish parallel trends.',fontsize=8.5,color='#455b49')
fig.subplots_adjust(left=.10,right=.98,top=.84,bottom=.20)
fig.savefig(ROOT/'third-avenue-pretrend-validation.png',dpi=170)
