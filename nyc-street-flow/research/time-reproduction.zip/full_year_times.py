"""Twelve months before construction vs twelve months after opening.
Usage: python full_year_times.py INPUT_DIR OUTPUT_DIR
Download monthly nestedZIPs for Jun2020-Jun2021 and Sep2021-Sep2022 from CitiBike
annual public archives, then run with expanded_bridge_times.py alongside this file.
Pre Jun21,2020–Jun20,2021. Post Sep15,2021–Sep14,2022. Fixed calendar-month x
ordered dock-pair x time-window support and preperiod weights. This is descriptive,
with no guaranteed untreated comparison and substantial pandemic-era confounding.
"""
import sys,json
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import pandas as pd
from expanded_bridge_times import load_one,calc,finite
RANGES={2021:('2020-06-21','2021-06-20'),2022:('2021-09-15','2022-09-14')}
if __name__=='__main__':
 base,out=map(Path,sys.argv[1:3]);out.mkdir(parents=True,exist_ok=True)
 months=sorted(set(pd.date_range('2020-06-01','2021-06-01',freq='MS').strftime('%Y%m'))|set(pd.date_range('2021-09-01','2022-09-01',freq='MS').strftime('%Y%m')))
 with ThreadPoolExecutor(4) as pool:rides=pd.concat(pool.map(load_one,[(m,base,out) for m in months]),ignore_index=True)
 parts=[]
 for phase,(start,end) in RANGES.items():
  r=rides[rides.date.between(start,end)].copy();r['actual_year']=r.year;r['year']=phase;parts.append(r)
 rides=pd.concat(parts,ignore_index=True);assert not rides.ride_id.duplicated().any()
 def result(radius=750,upper=90,minimum=3,months=list(range(1,13)),drop_shifted=False,save=None):return calc(rides,radius,upper,minimum,months,drop_shifted,save,date_ranges=RANGES)
 results={'source_urls':['https://citibikenyc.com/system-data']+[f'https://s3.amazonaws.com/tripdata/{y}-citibike-tripdata.zip' for y in (2020,2021,2022)],'periods':{'before':RANGES[2021],'after':RANGES[2022]},'primary':result(save=out/'full-year-time-cells.csv'),'monthly':{str(m):result(months=[m]) for m in range(1,13)},'sensitivities':{f'{r}m_{u}min_min{n}':result(r,u,n) for r,u,n in [(500,90,3),(1000,90,3),(750,60,3),(750,120,3),(750,90,1),(750,90,5)]},'excluding_moved_docks':result(drop_shifted=True),'limitations':['Twelve-month windows have different start months and calendar years. Calendar month, dock pair and time-stratum mix are standardized, but weather, rider composition and pandemic changes are not controlled.','Month-specific before/after cells can be one or two years apart; lateJune and September straddlecalendar year cohorts.','No bicycle GPS route or stable rider identity is available. Dock endpoints indicate plausible bridge routes only.','Classic member riders are a selected subset, not all cyclists.','Neighboring ManhattanBridge can be affected by diversion. Relative change is not a causalestimate.','Conditional sampling intervals cluster by date, preserving across-bridge covariance, and hold support/weights fixed. They do not cover serial dependence, repeated riders, route uncertainty, selection or causalidentification.','Within-cell median/p90 averages are not population median/p90.','Elapsed rental times include stops/docking but exclude access/egress walks or waiting for a bicycle.']}
 # Download uses neutral before/after labels despite internal phasecodes 2021 and2022.
 p=out/'full-year-time-cells.csv';s=p.read_text().replace('_2021','_before').replace('_2022','_after');p.write_text(s)
 (out/'full-year-times.json').write_text(json.dumps(finite(results),indent=2,allow_nan=False));print(json.dumps(finite(results['primary']),indent=2,allow_nan=False))
