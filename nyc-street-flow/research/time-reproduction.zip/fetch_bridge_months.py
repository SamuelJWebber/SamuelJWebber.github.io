"""Fetch original CitiBike monthly ZIP members from annual public archives with CRC checks.
python fetch_bridge_months.py CACHE_DIR [YYYYMM ...]
Default downloads months needed for both the six-month and full-year comparisons.
The cache filenames month.csv contain ZIP files, retained for compatibility withthe parsers.
Uses standardPython only. Range downloads avoid downloading irrelevant annual months.
"""
import sys,struct,zlib,time
from pathlib import Path
from urllib.request import Request,urlopen
from zipfile import ZipFile
from concurrent.futures import ThreadPoolExecutor

def request(url,a,b):
 key=f'{a}-{b}'
 for attempt in range(4):
  try:
   with urlopen(Request(url+'?range='+key,headers={'Range':'bytes='+key}),timeout=60) as r:
    if r.status!=206 or not r.headers['Content-Range'].startswith('bytes '+key+'/'):raise ValueError('Wrongrange')
    body=r.read()
    if len(body)!=b-a+1:raise ValueError('Truncatedrange')
    return body
  except Exception:
   if attempt==3:raise
   time.sleep(attempt+1)
def directory(year,base):
 path=base/f'{year}dir.zip';url=f'https://s3.amazonaws.com/tripdata/{year}-citibike-tripdata.zip'
 if not path.exists():
  with urlopen(Request(url+'?manifest=yes',headers={'Range':'bytes=0-1'}),timeout=60) as r:size=int(r.headers['Content-Range'].split('/')[-1])
  tail=request(url,size-65536,size-1);e=tail.rfind(b'PK\x05\x06');length,loc=struct.unpack_from('<II',tail,e+12)
  buf=tail[loc-size+65536:] if loc>=size-65536 else request(url,loc,size-1)
  with path.open('wb') as f:f.seek(loc);f.write(buf)
 return path,url

def download(month,base):
 path,url=directory(month[:4],base)
 with ZipFile(path) as z:a=next(a for a in z.infolist() if '__MACOSX' not in a.filename and month in a.filename)
 folder=base/month;folder.mkdir(exist_ok=True);dest=folder/'month.csv'
 if dest.exists() and dest.stat().st_size==a.file_size:return
 h=request(url,a.header_offset,a.header_offset+1100);n,ex=struct.unpack_from('<HH',h,26);start=a.header_offset+30+n+ex;chunk=6*1024**2
 intervals=[(i,start+x,min(start+a.compress_size-1,start+x+chunk-1)) for i,x in enumerate(range(0,a.compress_size,chunk))]
 def fetch(t):
  i,l,r=t;p=folder/f'{i:03d}.part'
  if not p.exists() or p.stat().st_size!=r-l+1:p.write_bytes(request(url,l,r))
  return p
 with ThreadPoolExecutor(12) as pool:parts=list(pool.map(fetch,intervals))
 dec=zlib.decompressobj(-15);crc=0
 with dest.open('wb') as f:
  for p in parts:
   b=dec.decompress(p.read_bytes());f.write(b);crc=zlib.crc32(b,crc)
  b=dec.flush();f.write(b);crc=zlib.crc32(b,crc)
  assert f.tell()==a.file_size and crc==a.CRC
 print('Verified',month,flush=True)

if __name__=='__main__':
 base=Path(sys.argv[1]);base.mkdir(parents=True,exist_ok=True)
 months=sys.argv[2:] or [f'2020{m:02d}' for m in range(6,13)]+[f'2021{m:02d}' for m in list(range(1,7))+list(range(9,13))]+[f'2022{m:02d}' for m in range(1,10)]
 for year in sorted(set(m[:4] for m in months)):directory(year,base)
 with ThreadPoolExecutor(4) as pool:list(pool.map(lambda m:download(m,base),months))
