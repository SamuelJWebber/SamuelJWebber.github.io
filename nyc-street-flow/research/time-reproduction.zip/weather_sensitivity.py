"""Exploratory linear daily-weather adjustment for fixed-cell full-year time sample.
python weather_sensitivity.py OUTPUT_DIR
Needs full-year-times outputs, filtered rides caches, numpy/pandas/scipy.
Downloads NOAA GHCN-Daily Central Park USW00094728 if not already cached.
Fixed effects for month×OD×time stratum; baseline cell weights fixed, both phases
have equal weight within a cell. Standard errors cluster by actual date.
This is a sensitivity analysis, not validation of a causal effect.
"""
from pathlib import Path
from urllib.request import urlopen
import sys,json,calendar
import numpy as np
import pandas as pd
from scipy.stats import t
from full_year_times import RANGES
from expanded_bridge_times import finite
out=Path(sys.argv[1]);p=out/'USW00094728.dly'
if not p.exists():p.write_bytes(urlopen('https://www.ncei.noaa.gov/pub/data/ghcn/daily/all/USW00094728.dly',timeout=60).read())
rows=[]
for line in p.read_text().splitlines():
 year,month=int(line[11:15]),int(line[15:17]);element=line[17:21]
 if year not in (2020,2021,2022) or element not in ('TMAX','TMIN','PRCP'):continue
 for day in range(1,calendar.monthrange(year,month)[1]+1):
  block=line[21+(day-1)*8:21+day*8];value=int(block[:5]);qflag=block[6]
  if value==-9999 or qflag!=' ':continue
  rows.append({'date':f'{year}-{month:02d}-{day:02d}','element':element,'value':value/10})
weather=pd.DataFrame(rows).pivot(index='date',columns='element',values='value').reset_index();weather['temperature_c']=(weather.TMAX+weather.TMIN)/2;weather=weather.rename(columns={'PRCP':'precipitation_mm'});weather.to_csv(out/'central-park-weather-2020-2022.csv',index=False)
files=sorted(out.glob('rides-*.csv'));rides=pd.concat([pd.read_csv(f,dtype={'start_station_id':str,'end_station_id':str}) for f in files],ignore_index=True)
parts=[]
for phase,(start,end) in RANGES.items():
 r=rides[rides.date.between(start,end)].copy();r['phase']='before' if phase==2021 else 'after';r['post']=int(phase==2022);parts.append(r)
r=pd.concat(parts,ignore_index=True);r=r[r.maxd.le(750)&r.minutes.between(4,90)]
cells=pd.read_csv(out/'full-year-time-cells.csv',dtype={'start_station_id':str,'end_station_id':str});cells['cell']=np.arange(len(cells));keys=['bridge','month','start_station_id','end_station_id','window']
r=r.merge(cells[keys+['cell','weight','n_before','n_after']],on=keys,validate='many_to_one');r['w']=r.weight/np.where(r.post.eq(0),r.n_before,r.n_after)
r=r.merge(weather[['date','temperature_c','precipitation_mm']],on='date',how='left',validate='many_to_one');missing=int(r[['temperature_c','precipitation_mm']].isna().any(axis=1).sum());assert missing==0,'Missing weather, must handle explicitly'
r['post_brooklyn']=r.post*r.bridge.eq('Brooklyn');r['dow']=pd.to_datetime(r.date).dt.dayofweek
for d in range(1,7):r[f'dow_{d}']=r.dow.eq(d).astype(float)

def fit(variables):
 cols=['minutes']+variables
 weighted=r[cols].multiply(r.w,axis=0);weighted['cell']=r.cell
 means=weighted.groupby('cell').sum().divide(r.groupby('cell').w.sum(),axis=0)
 res=r[cols]-means.loc[r.cell].set_axis(r.index)
 X=res[variables].to_numpy(dtype=float);y=res.minutes.to_numpy();w=r.w.to_numpy();bread=np.linalg.pinv(X.T@(w[:,None]*X));beta=bread@(X.T@(w*y));errors=y-X@beta
 score=pd.DataFrame(X*(w*errors)[:,None]);score['date']=r.date.to_numpy();cluster=score.groupby('date').sum().to_numpy();meat=cluster.T@cluster
 # Account for absorbed cell intercepts in finite-sample sandwich correction.
 n=len(r);g=r.date.nunique();k=np.linalg.matrix_rank(X)+r.cell.nunique();cov=(bread@meat@bread)*(g/(g-1))*((n-1)/(n-k));crit=t.ppf(.975,g-1)
 result={}
 for name,l in {'Manhattan':[1,0],'Brooklyn':[1,1],'Brooklyn_minus_Manhattan':[0,1]}.items():
  contrast=np.array(l+[0]*(len(variables)-2));est=float(contrast@beta);se=float(np.sqrt(contrast@cov@contrast))
  result[name]={'change_minutes':est,'cluster95_minutes':[est-crit*se,est+crit*se]}
 return result
report={'source':'https://www.ncei.noaa.gov/pub/data/ghcn/daily/all/USW00094728.dly','station':'Central Park USW00094728','periods':{'before':RANGES[2021],'after':RANGES[2022]},'matched_rides':len(r),'date_clusters':int(r.date.nunique()),'missing_weather_rides':missing,'unadjusted_fixed_cells':fit(['post','post_brooklyn']),'weather_adjusted':fit(['post','post_brooklyn','temperature_c','precipitation_mm']),'weather_and_weekday_adjusted':fit(['post','post_brooklyn','temperature_c','precipitation_mm']+[f'dow_{d}' for d in range(1,7)]),'limitations':['Daily Central Park weather is an imperfect proxy for conditions at each trip time and bridge.','Temperature and precipitation enter linearly with common slopes across bridges.','These models do not control pandemic changes, changing riders or actual route choice.','Date clustering omits cross-date serial dependence and repeated riders.','Conditional intervals are sampling-only; they do not establish causal identification.']}
(out/'weather-sensitivity.json').write_text(json.dumps(finite(report),indent=2,allow_nan=False));print(json.dumps(report,indent=2))
