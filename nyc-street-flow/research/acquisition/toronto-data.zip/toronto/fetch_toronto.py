from pathlib import Path
from urllib.request import urlopen
from urllib.parse import urlencode
import json,csv
P=Path(__file__).resolve().parent;B='https://ckan0.cf.opendata.inter.prod-toronto.ca/api/3/action/'
allrows={};url_log=[]
for road in ['Bloor','Dupont','Harbord']:
 u=B+'datastore_search?'+urlencode({'resource_id':'1364bffa-29a3-4c39-af8a-925d8ca7bf1f','q':json.dumps({'location_name':road}),'limit':32000})
 b=urlopen(u,timeout=90).read();(P/f'toronto-{road.lower()}-summary-query.json').write_bytes(b);url_log.append(u)
 d=json.loads(b)['result'];print(road,len(d['records']),'total',d['total'],flush=True)
 for r in d['records']:
  if '2013-01-01'<=r['count_date']<='2019-12-31' and -79.435<=r['longitude']<=-79.38:allrows[r['count_id']]=r
rs=sorted(allrows.values(),key=lambda x:(x['count_date'],x['count_id']));(P/'toronto-corridor-count-inventory.json').write_text(json.dumps(rs))
with (P/'toronto-corridor-count-inventory.csv').open('w')as f:
 w=csv.DictWriter(f,fieldnames=list(rs[0]));w.writeheader();w.writerows(rs)
u=B+'datastore_search?'+urlencode({'resource_id':'ae400fe2-98ce-4e73-8a94-024b22e29a22','filters':json.dumps({'count_id':list(allrows)}),'limit':32000})
b=urlopen(u,timeout=90).read();(P/'toronto-corridor-15min-response.json').write_bytes(b);url_log.append(u)
d=json.loads(b)['result'];rr=d['records'];print('SELECTED',len(rs),'raw',len(rr),'rawtotal',d['total'],flush=True)
(P/'toronto-corridor-15min-raw.json').write_text(json.dumps(rr))
with(P/'toronto-corridor-15min-raw.csv').open('w')as f:
 w=csv.DictWriter(f,fieldnames=list(rr[0]));w.writeheader();w.writerows(rr)
(P/'toronto-fetch-urls.json').write_text(json.dumps(url_log,indent=2))
