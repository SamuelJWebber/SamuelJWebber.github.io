Calgary acquisition release — 2026-11-06

Eight official annual workbook attachments (2012–2019) are preserved. API CSV exports for 2012–2015 are only location inventories; do not treat their rows as count observations. API CSV files for 2016–2019 contain 123 site-year count records. calgary-16h-published-summary.csv extracts the explicitly labelled 16 Hour Total rows and records source sheet/Excel row.

The 2017 official method states 06:00–22:00 counts over several weeks at 31 locations, one day per site, including car occupants, bus and C-Train passengers, walking and cycling. Therefore this is a synthetic cordon day, not a simultaneous count. The workbook total-occupants column is distinct from vehicle totals and excludes separately listed active modes; no assumed car occupancy is substituted. The sum column is precisely named occupants_plus_pedestrians_plus_bicycles and is not presented as a causal effect or as an audited total of every possible road user. Weather, construction, employment and boundary changes remain unresolved.

City of Calgary open data attribution; source attachment URLs and metadata accompany the files. fetch_data.py also contains the earlier Toronto attempt; use fetch_calgary_attachments.py after refreshing the Calgary metadata for the workbook downloads.
