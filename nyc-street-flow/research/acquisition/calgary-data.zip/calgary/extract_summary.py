"""Reproduce selected published 16-hour summaries from bundled workbooks.
Requires openpyxl. Run from any directory; outputs CSV alongside this script.
These are published annual summary rows, not observations of a causal effect.
"""
from pathlib import Path
import csv,openpyxl
P=Path(__file__).resolve().parent
out=[]
for year in range(2012,2020):
 for sheet in openpyxl.load_workbook(P/f'calgary-{year}-source.xlsx',data_only=True):
  direction=''
  for excel_row,row in enumerate(sheet.values,1):
   label=str(row[0] or '').strip().upper()
   if label in ['INBOUND','OUTBOUND','TOTAL','TOTALS']:direction='BOTH' if label in ['TOTAL','TOTALS'] else label
   if label=='16 HOUR TOTAL':
    assert direction in ['INBOUND','OUTBOUND','BOTH']
    out.append(dict(year=year,sheet=sheet.title,excel_row=excel_row,direction=direction,vehicles=row[4],car_occupants=row[17],calgary_transit_occupants=row[19],other_bus_occupants=row[21],reported_total_occupants=row[22],pedestrians=row[23],bicycles=row[24],occupants_plus_pedestrians_plus_bicycles=sum(row[k] for k in [22,23,24])))
for year in range(2012,2020):
 a={r['direction']:r for r in out if r['year']==year}
 assert set(a)=={'INBOUND','OUTBOUND','BOTH'}
 for k in ['vehicles','car_occupants','calgary_transit_occupants','other_bus_occupants','reported_total_occupants','pedestrians','bicycles']:
  assert a['BOTH'][k]==a['INBOUND'][k]+a['OUTBOUND'][k],(year,k)
with (P/'calgary-16h-published-summary.csv').open('w')as f:
 w=csv.DictWriter(f,fieldnames=list(out[0]));w.writeheader();w.writerows(out)
print(f'Extracted and checked {len(out)} rows')
