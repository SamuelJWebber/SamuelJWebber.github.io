from pathlib import Path
from urllib.request import urlopen
from urllib.parse import urlencode
import json,concurrent.futures,openpyxl
P=Path(__file__).resolve().parent
cal={2012:'n52m-2ku5',2013:'hau8-f2rz',2014:'hxeu-d57b',2015:'5eng-mjuy',2016:'dsje-mu8i',2017:'hzux-dsmm',2018:'44pa-57w4',2019:'ghvn-cts5'}
log=[]
def work(k):
 y,i=k;d=json.loads((P/f'calgary-{y}-metadata.json').read_text())
 for a in d.get('metadata',{}).get('attachments',[]):
  u=f'https://data.calgary.ca/api/views/{i}/files/{a["assetId"]}?'+urlencode({'download':'true','filename':a['filename']});path=P/f'calgary-{y}-source.xlsx'
  path.write_bytes(urlopen(u,timeout=90).read());w=openpyxl.load_workbook(path,data_only=True)
  print(y,[(s.title,s.max_row,s.max_column) for s in w],flush=True)
  out={s.title:list(s.values) for s in w};(P/f'calgary-{y}-workbook.json').write_text(json.dumps(out,default=str));log.append({'year':y,'url':u,'file':path.name})
with concurrent.futures.ThreadPoolExecutor(max_workers=4)as ex:
 for f in concurrent.futures.as_completed([ex.submit(work,k) for k in cal.items()]):
  try:f.result()
  except Exception as e:print('ERROR',repr(e),flush=True)
(P/'calgary-attachment-urls.json').write_text(json.dumps(log,indent=2))
