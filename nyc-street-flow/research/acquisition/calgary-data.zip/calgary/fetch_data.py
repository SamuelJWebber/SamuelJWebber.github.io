from pathlib import Path
from urllib.request import urlopen
from urllib.parse import urlencode
import json,csv,gzip,hashlib,concurrent.futures
P=Path(__file__).resolve().parent
BASE='https://ckan0.cf.opendata.inter.prod-toronto.ca/api/3/action/'
log=[]
def get(name,url):
 path=P/name
 if path.exists():return json.loads(path.read_text())
 b=urlopen(url,timeout=90).read();path.write_bytes(b);log.append({'file':name,'url':url,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()});return json.loads(b)
def sql(name,q):return get(name,BASE+'datastore_search_sql?'+urlencode({'sql':q}))['result']['records']
def savecsv(name,rs):
 if not rs:return
 with (P/name).open('w') as f:
  w=csv.DictWriter(f,fieldnames=list(rs[0]));w.writeheader();w.writerows(rs)
q='''SELECT * FROM "1364bffa-29a3-4c39-af8a-925d8ca7bf1f" WHERE count_date >= '2013-01-01' AND count_date <= '2019-12-31' AND longitude BETWEEN -79.435 AND -79.38 AND (location_name ILIKE '%Bloor%' OR location_name ILIKE '%Dupont%' OR location_name ILIKE '%Harbord%') ORDER BY count_date,count_id'''
try:
 rs=sql('toronto-corridor-count-inventory.json',q);savecsv('toronto-corridor-count-inventory.csv',rs);print('Toronto selected count summaries',len(rs),flush=True)
 ids=','.join(str(r['count_id']) for r in rs)
 rr=sql('toronto-corridor-15min-raw.json','SELECT * FROM "ae400fe2-98ce-4e73-8a94-024b22e29a22" WHERE count_id IN ('+ids+') ORDER BY count_id,start_time');savecsv('toronto-corridor-15min-raw.csv',rr);print('Toronto 15min rows',len(rr),flush=True)
except Exception as e:print('Toronto error',repr(e),flush=True)
cal={2012:'n52m-2ku5',2013:'hau8-f2rz',2014:'hxeu-d57b',2015:'5eng-mjuy',2016:'dsje-mu8i',2017:'hzux-dsmm',2018:'44pa-57w4',2019:'ghvn-cts5'}
def fetchcal(yid):
 y,i=yid
 meta=get(f'calgary-{y}-metadata.json',f'https://data.calgary.ca/api/views/{i}.json')
 rs=get(f'calgary-{y}-raw.json',f'https://data.calgary.ca/resource/{i}.json?$limit=50000')
 (P/f'calgary-{y}-raw.csv').write_bytes(urlopen(f'https://data.calgary.ca/resource/{i}.csv?$limit=50000',timeout=90).read())
 print('Calgary',y,len(rs),'fields',list(rs[0]) if rs else None,'sample',rs[:1],flush=True)
 return y,len(rs)
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:
 for fut in concurrent.futures.as_completed([ex.submit(fetchcal,x) for x in cal.items()]):
  try:fut.result()
  except Exception as e:print('Calgary error',repr(e),flush=True)
(P/'fetch-manifest.json').write_text(json.dumps(log,indent=2))
