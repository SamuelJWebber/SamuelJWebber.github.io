from pathlib import Path
import urllib.request,urllib.parse,csv,json,concurrent.futures
P=Path(__file__).parent
def go(name):
 studies=json.loads((P/f'seattle_{name}_studies_filtered.json').read_text());ids=[r['study_id']for r in studies]
 # Hour table keyed by study/weekday; preserve study-level metrics, no invented individual dates.
 u='https://data.seattle.gov/resource/g32r-fjzp.csv?'+urllib.parse.urlencode({'$where':'study_id in ('+','.join(ids)+')','$limit':50000,'$order':'study_id,weekday'})
 d=urllib.request.urlopen(u,timeout=60).read();(P/f'seattle_{name}_motor_hour_bins.csv').write_bytes(d);rows=list(csv.DictReader(d.decode('utf-8-sig').splitlines()))
 (P/f'seattle_{name}_motor_hour_bins_source.json').write_text(json.dumps({'url':u,'rows':len(rows),'study_ids':ids},indent=2));print(name,len(rows),'weekdays',sorted({r['weekday']for r in rows}),flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as ex:list(ex.map(go,['second','west']))
