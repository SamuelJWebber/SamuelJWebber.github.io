from pathlib import Path
import urllib.request,urllib.parse,json,csv,concurrent.futures
p=Path(__file__).parent
jobs={'second2014_2016':('avwm-i8ym',"date >= '2014-01-01T00:00:00' AND date < '2017-01-01T00:00:00'"),'fremont2013_2016':('65db-xm6k',"date >= '2013-01-01T00:00:00' AND date < '2017-01-01T00:00:00'"),'spokane2021_2024':('upms-nr8w',"date >= '2021-01-01T00:00:00' AND date < '2025-01-01T00:00:00'")}
def go(k,v):
 ds,where=v;u='https://data.seattle.gov/resource/'+ds+'.csv?'+urllib.parse.urlencode({'$where':where,'$order':'date','$limit':100000})
 try:
  target=p/('seattle_'+k+'.csv');d=target.read_bytes() if target.exists() else urllib.request.urlopen(u,timeout=55).read();target.write_bytes(d)
  rows=list(csv.DictReader(d.decode('utf-8-sig').splitlines()))
  print(k,'rows',len(rows),'first',rows[0]if rows else None,'last',rows[-1]if rows else None,flush=True)
  (p/('seattle_'+k+'_source.json')).write_text(json.dumps({'url':u,'rows':len(rows)},indent=2))
 except Exception as e:print(k,type(e).__name__,e,flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=3)as ex:list(ex.map(lambda kv:go(*kv),jobs.items()))
