"""Fetch observed 2014-2017 central and cycleway counts from TfL's public S3 mirror.
Bounded to 23 CSV waves and three metadata files; does not include synthetic COVID waves.
"""
from pathlib import Path
import urllib.request,urllib.parse,xml.etree.ElementTree as E,json,concurrent.futures,time
P=Path(__file__).parent;RAW=P/'raw';RAW.mkdir(exist_ok=True)
BASE='https://s3-eu-west-1.amazonaws.com/cycling.data.tfl.gov.uk/'
listing=BASE+'?'+urllib.parse.urlencode({'list-type':2,'prefix':'ActiveTravelCountsProgramme/','max-keys':1000})
if not (P/'tfl_active_bucket.xml').exists():(P/'tfl_active_bucket.xml').write_bytes(urllib.request.urlopen(listing,timeout=40).read())
r=E.fromstring((P/'tfl_active_bucket.xml').read_bytes());ns={'s':'http://s3.amazonaws.com/doc/2006-03-01/'}
keys=[x.text for x in r.findall('s:Contents/s:Key',ns)]
selected=[k for k in keys if any(y in k for y in ['2014','2015','2016','2017']) and ('Central' in k or 'Cycleways' in k)]
selected += [k for k in keys if any(s in k for s in ['0 Strategic active travel','1 Monitoring locations','2 Availability matrix'])]
def get(k):
 f=RAW/Path(k).name;u=BASE+urllib.parse.quote(k)
 try:
  if not f.exists():f.write_bytes(urllib.request.urlopen(u,timeout=60).read())
  print('OK',f.name,f.stat().st_size,flush=True)
  return {'file':str(f.relative_to(P)),'source_url':u,'public_url':'https://cycling.data.tfl.gov.uk/'+urllib.parse.quote(k),'bytes':f.stat().st_size,'status':'downloaded'}
 except Exception as e:
  print('FAILED',k,str(e),flush=True);return {'source_url':u,'status':'failed','error':str(e)}
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:out=list(ex.map(get,selected))
(P/'tfl_download_manifest.json').write_text(json.dumps(out,indent=2))
