"""Build quality-labelled TfL site/wave counts, preserving rounds and mode categories.
Use wave, NOT individual Date, as analytical period per TfL release note.
Counts from adjacent links cannot be summed as unique trips.
"""
from pathlib import Path
import csv,json,collections,re,statistics
P=Path(__file__).parent
sites={r['Site ID']:r for r in csv.DictReader((P/'raw/1 Monitoring locations.csv').open(encoding='utf-8-sig'))}
agg=collections.defaultdict(lambda:{'count':0,'rows':0,'times':set(),'dates':set(),'weather':set(),'paths':set()})
rows_by_file={};total=0
for f in sorted((P/'raw').glob('20*.csv')):
 n=0;program='central' if '-Central' in f.name else 'cycleways'
 for r in csv.DictReader(f.open(encoding='utf-8-sig')):
  n+=1;total+=1;k=(program,r['SiteID'],r['Wave'],r['Round'],r['Day'],r['Direction'],r['Mode']);a=agg[k];a['count']+=float(r['Count']);a['rows']+=1;a['times'].add(r['Time']);a['dates'].add(r['Date']);a['weather'].add(r['Weather']);a['paths'].add(r['Path'])
 rows_by_file[f.name]=n
out=[]
for k,a in agg.items():
 program,site,wave,round_,day,direction,mode=k;s=sites.get(site,{})
 out.append({'program':program,'site_id':site,'location':s.get('Location description',''),'wave':wave,'round':round_,'day_type':day,'direction':direction,'mode':mode,'count':a['count'],'quarter_hour_bins':len(a['times']),'time_start':min(a['times']),'time_end_bin_start':max(a['times']),'raw_rows':a['rows'],'reference_dates':'|'.join(sorted(a['dates'])),'weather':'|'.join(sorted(a['weather'])),'paths':'|'.join(sorted(a['paths']))})
def writecsv(name,rows):
 with (P/name).open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
writecsv('all_site_wave_direction_mode_totals.csv',out)
# Stable central quarterly sites: include only canonical bike ownership categories, not alternate demographic totals.
rawcycles=collections.defaultdict(lambda:collections.Counter())
for r in out:
 if r['program']=='central' and r['mode'] in ['Private cycles','Cycle hire bikes'] and r['day_type']=='Weekday':
  k=(r['site_id'],r['location'],r['wave'],r['round']);a=rawcycles[k];a[r['mode']]+=r['count'];a['minimum_bins']=min(a.get('minimum_bins',64),r['quarter_hour_bins']);a['direction_mode_groups']+=1
cyc=[]
for k,a in rawcycles.items():
 site,loc,wave,rd=k;totalb=a['Private cycles']+a['Cycle hire bikes'];cyc.append({'site_id':site,'location':loc,'wave':wave,'round':rd,'private_cycles':a['Private cycles'],'hire_cycles':a['Cycle hire bikes'],'all_cycles':totalb,'hire_share_pct':100*a['Cycle hire bikes']/totalb if totalb else None,'minimum_bins_per_direction_mode':a['minimum_bins'],'direction_mode_groups':a['direction_mode_groups'],'period':'06:00-22:00 when64bins','warning':'Wave may combine dates; not unique people; cycle lanes included as site flow but path not separately coded before2022'})
writecsv('central_quarterly_cycle_panel.csv',cyc)
chosen=['ML0003','ML0012','ML0013','ML0014','ML0017','ML0028','ML0030','ML0031','ML0040']
selected=[r for r in cyc if r['site_id'] in chosen];writecsv('bridge_corridor_cycle_panel.csv',selected)
# Matched-quarter descriptive contrasts: construction avoided using2014baseline; no causal label.
comps=[]
for site in chosen:
 for q in ['Q1','Q2','Q3','Q4']:
  def yr(y):return [r for r in selected if r['site_id']==site and r['wave'].startswith(y+' '+q)]
  b,a=yr('2014'),yr('2017')
  if not b or not a:continue
  v0=statistics.mean(r['all_cycles'] for r in b);v1=statistics.mean(r['all_cycles'] for r in a)
  comps.append({'site_id':site,'location':a[0]['location'],'quarter':q,'before_wave':b[0]['wave'],'after_wave':a[0]['wave'],'before_cycles_mean_round':v0,'after_cycles_mean_round':v1,'change_pct':(v1/v0-1)*100,'before_rounds':len(b),'after_rounds':len(a),'causal':False,'caution':'Comparator candidate bridges may receive diversion or their own treatment; no total-person inference'})
writecsv('matched_quarter_descriptive_comparisons.csv',comps)
# Potential additional moving-lane conversion. Preserve ALL mode categories, do not add overlapping demographics.
tav=[r for r in out if r['site_id']=='ML1490'];writecsv('tavistock_wave_direction_mode_totals.csv',tav)
summary={'raw_rows':total,'raw_files':rows_by_file,'locations_metadata_rows':len(sites),'all_site_wave_direction_mode_rows':len(out),'central_cycle_panel_rows':len(cyc),'bridge_panel_rows':len(selected),'matched_quarter_comparisons':len(comps),'tavistock_mode_rows':len(tav)}
(P/'count_processing_summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps({k:v for k,v in summary.items() if k!='raw_files'}))
for r in comps:
 if r['site_id'] in ['ML0030','ML0013','ML0014']:print(r)
