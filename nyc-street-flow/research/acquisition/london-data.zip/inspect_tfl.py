from pathlib import Path
from collections import defaultdict,Counter
import csv,json
P=Path(__file__).parent
sites={r['Site ID']:r for r in csv.DictReader((P/'raw/1 Monitoring locations.csv').open(encoding='utf-8-sig'))}
selected={k:v for k,v in sites.items() if any(s in v['Location description'].lower() for s in ['blackfriar','victoria embank','waterloo bridge','southwark bridge','london bridge','westminster bridge'])}
counts=Counter();modes=defaultdict(set);dates=defaultdict(set);n=0;kept=[]
for f in sorted((P/'raw').glob('20*.csv')):
 for r in csv.DictReader(f.open(encoding='utf-8-sig')):
  n+=1
  if r['SiteID'] in selected:
   r['source_file']=f.name;kept.append(r);key=(r['SiteID'],r['Wave'],f.name);counts[key]+=1;modes[key].add(r['Mode']);dates[key].add(r['Date'])
with (P/'london_corridor_raw.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(kept[0]));w.writeheader();w.writerows(kept)
(P/'london_corridor_sites.json').write_text(json.dumps(selected,indent=2))
out=[{'site':k[0],'wave':k[1],'source_file':k[2],'rows':v,'modes':sorted(modes[k]),'dates':sorted(dates[k])} for k,v in counts.items()]
(P/'london_corridor_coverage.json').write_text(json.dumps(out,indent=2))
print('totalrows',n,'selectedrows',len(kept))
for x in out:
 if x['site'] in ['ML0030','ML0013','ML0014']:print(x)
