Paris acquisition, checked 2026-11-06

Acquired five official annual cycling ZIPs and five official annual road-count ZIPs, 2016–2020.
Large source archives are referenced with URLs, sizes and SHA256, not duplicated in this publication.
The cycling archives contain 2,343,597 total rows; the published road-name subset has 119,870
Rivoli/Voltaire rows. Rivoli is 158 rue de Rivoli (Voie Bus) in 2016–2017; there are no Rivoli
rows in the 2018 archive; the 2019–2020 device is Totem 64 Rue de Rivoli. Do not splice these
as one continuously observed detector. Voltaire has incomplete 2018 coverage. Preserve missing
observations, installation dates and original timestamps. Road-name matching is not treatment assignment.

The road extraction contains 19,488 Rivoli/Voltaire arc-hour rows from two source files:
May 1–8 and June 1–8, 2020 (inspect actual recorded hour-end ranges in the summary).
This bounded sample demonstrates archive accessibility; it is not a continuous road panel.
q denotes vehicles per hour. k is road-detector occupancy, NOT passengers per vehicle.
Serial arcs must not be summed as unique people or trips. Road times denote the hour end.
Lockdown, reopening and changed network access preclude interpreting this two-week contrast causally.

IDFM rail historical catalog metadata was acquired, but individual station validation records were
not downloaded in this pass. Catalog metadata is not passenger data; entries are not onboard loads.

Run fetch_metadata.py, fetch_archives.py and extract_corridors.py to reproduce; the archive fetch
uses more than 1 GB. Source updates should be checked against the included SHA256 manifest.
No causal estimate of total people flow or complete journey time is made by this data package.
