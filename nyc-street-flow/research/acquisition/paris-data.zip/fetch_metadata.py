from pathlib import Path
import urllib.request,json,concurrent.futures
P=Path(__file__).resolve().parent
urls={'bike-history':'https://opendata.paris.fr/api/explore/v2.1/catalog/datasets/comptage-velo-historique-donnees-compteurs','motor-history':'https://opendata.paris.fr/api/explore/v2.1/catalog/datasets/comptages-routiers-permanents-historique','rail-history':'https://data.iledefrance-mobilites.fr/api/explore/v2.1/catalog/datasets/histo-validations-reseau-ferre'}
def f(k,u):
 try:
  b=urllib.request.urlopen(u,timeout=45).read();(P/(k+'-metadata.json')).write_bytes(b);d=json.loads(b);print(k,[(x.get('id'),x.get('filename'),x.get('url')) for x in d.get('attachments',[])]);print('fields',[(x['name'],x.get('label')) for x in d.get('fields',[])])
 except Exception as e:print(k,type(e).__name__,str(e))
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:list(ex.map(lambda x:f(*x),urls.items()))
