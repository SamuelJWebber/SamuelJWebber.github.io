from pathlib import Path
import urllib.request,json,gzip,concurrent.futures,hashlib,shutil,zipfile
P=Path(__file__).resolve().parent;(P/'raw').mkdir(exist_ok=True)
M=[]
def get(name,url):
 f=P/'raw'/name
 if not f.exists():
  with urllib.request.urlopen(url,timeout=90) as r,f.open('wb') as o:shutil.copyfileobj(r,o)
 b=f.read_bytes()
 if b[:2]==b'\x1f\x8b':f.write_bytes(gzip.decompress(b))
 m={'file':'raw/'+name,'url':url,'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()};M.append(m)
 print(name,m['bytes'],flush=True);return f
jobs=[]
for mode,key in [('bike','bike-history'),('motor','motor-history')]:
 d=json.loads((P/(key+'-metadata.json')).read_text())
 for y in [2016,2017,2018,2019,2020]:
  a=next(a for a in d['attachments'] if str(y) in a['id'] and ('_donnees_compteurs' in a['id'] if mode=='bike' else a['id'].startswith('opendata_txt_')))
  jobs.append((f'{mode}-{y}.zip',a['url']))
u='https://data.iledefrance-mobilites.fr/api/explore/v2.1/catalog/datasets/histo-validations-reseau-ferre/records?limit=100'
f=get('rail-history-records.json',u);d=json.loads(f.read_text())
(P/'rail-records.json').write_text(json.dumps(d,ensure_ascii=False,indent=2))
print('RAIL',json.dumps(d,ensure_ascii=False)[:5000],flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:
 fs=list(ex.map(lambda x:get(*x),jobs))
for f in fs:
 with zipfile.ZipFile(f) as z:
  n=next(n for n in z.namelist() if n.endswith(('.csv','.txt')))
  with z.open(n) as src:print(f.name,n,src.read(2000).decode('utf-8',errors='replace')[:600],flush=True)
(P/'download-manifest.json').write_text(json.dumps(M,ensure_ascii=False,indent=2))
