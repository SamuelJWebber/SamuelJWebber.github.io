"""Extract recorded Rivoli/Voltaire cycling observations and two bounded road survey weeks.
Run after fetch_archives.py. Requires only Python standard library.
The road sample is illustrative coverage, not a causal estimate or continuous panel.
"""
from pathlib import Path
import csv,gzip,io,json,zipfile,collections
P=Path(__file__).resolve().parent
summary={'bike':{},'motor':{}}
fields=None
with gzip.open(P/'rivoli-voltaire-bike-hourly-2016-2020.csv.gz','wt',encoding='utf-8',newline='') as out:
 writer=None
 for year in range(2016,2021):
  z=zipfile.ZipFile(P/f'raw/bike-{year}.zip')
  n=next(n for n in z.namelist() if n.endswith('.csv') and not n.startswith('__MACOSX'))
  reader=csv.DictReader(io.TextIOWrapper(z.open(n),encoding='utf-8-sig'),delimiter=';')
  if writer is None:
   fields=reader.fieldnames+['source_archive','source_member'];writer=csv.DictWriter(out,fieldnames=fields);writer.writeheader()
  total=selected=0; dates=[];counters=collections.Counter()
  for r in reader:
   total+=1
   name=(r.get('Nom du compteur','')+' '+r.get('Nom du site de comptage','')).lower()
   if not any(x in name for x in ['rivoli','voltaire']):continue
   selected+=1;dates.append(r['Date et heure de comptage']);counters[r['Nom du compteur']]+=1
   r.update(source_archive=f'bike-{year}.zip',source_member=n);writer.writerow(r)
  summary['bike'][str(year)]={'archive_rows':total,'selected_rows':selected,'first_recorded_timestamp':min(dates) if dates else None,'last_recorded_timestamp':max(dates) if dates else None,'counter_rows':dict(counters)}
with gzip.open(P/'rivoli-voltaire-motor-two-weeks-2020.csv.gz','wt',encoding='utf-8',newline='') as out:
 z=zipfile.ZipFile(P/'raw/motor-2020.zip'); writer=None
 for n in z.namelist():
  if not ('_20200501_20200508.' in n or '_20200601_20200608.' in n):continue
  reader=csv.DictReader(io.TextIOWrapper(z.open(n),encoding='utf-8-sig'),delimiter=';')
  if writer is None:writer=csv.DictWriter(out,fieldnames=reader.fieldnames+['source_archive','source_member']);writer.writeheader()
  total=selected=0;dates=[];arcs=collections.Counter()
  for r in reader:
   total+=1
   if not any(x in r.get('libelle','').lower() for x in ['rivoli','voltaire']):continue
   selected+=1;dates.append(r['t_1h']);arcs[r['iu_ac']]+=1
   r.update(source_archive='motor-2020.zip',source_member=n);writer.writerow(r)
  summary['motor'][n]={'source_rows':total,'selected_rows':selected,'first_hour_end':min(dates) if dates else None,'last_hour_end':max(dates) if dates else None,'arc_rows':dict(arcs)}
summary['interpretation']={'bike':'Raw observations selected by road name; not verified treatment assignment. Empty earlier years mean no selected records in that archive, not zero cycling. Preserve source timestamp strings; earlier archives have naive times.','motor':'Only two sampled weeks from the acquired 2020 archive. q is vehicles per hour, k is detector occupancy, NOT occupants per vehicle. Serial road arcs must not be summed as unique trips. Road timestamps are interval ends. Lockdown, reopening, network changes and unmatched sensors preclude a causal comparison.'}
(P/'corridor-extraction-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
print(json.dumps(summary,ensure_ascii=False,indent=2))
