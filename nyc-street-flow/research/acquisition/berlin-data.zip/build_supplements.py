"""Extract official bicycle data preserving cell quality flags, weather and geometry."""
from pathlib import Path
import openpyxl, pandas as pd, numpy as np
import datetime, json, zipfile, xml.etree.ElementTree as ET, math

ROOT=Path(__file__).resolve().parent
RAW=ROOT/'raw'
w=openpyxl.load_workbook(RAW/'bicycle-hourly-official.xlsx',read_only=True,data_only=True)
site_rows=list(w['Standortdaten'].values)
sites=pd.DataFrame(site_rows[1:],columns=site_rows[0]).dropna(subset=['Zählstelle'])
sites.to_csv(ROOT/'bicycle-station-metadata.csv',index=False)
notes=[]
for sheet in ['Hinweise','Legende']:
    for row in w[sheet].iter_rows():
        for c in row:
            if c.value is not None:
                notes.append({'sheet':sheet,'cell':c.coordinate,'value':str(c.value),'style_id':c._style_id,'fill_id':w._cell_styles[c._style_id].fillId})
(ROOT/'bicycle-provider-notes-and-legend.json').write_text(json.dumps(notes,ensure_ascii=False,indent=2))
rows=[];qc=[]
reconstructed_fill_id=w._cell_styles[w['Legende']['B4']._style_id].fillId
for year in [2019,2020]:
    sheet=w[f'Jahresdatei {year}'];headers=[c.value for c in next(sheet.iter_rows())]
    times=[]
    for excelrow in sheet.iter_rows(min_row=2):
        timestamp=excelrow[0].value
        if not isinstance(timestamp,datetime.datetime):continue
        if timestamp.year!=year:continue
        times.append(timestamp)
        for head,c in zip(headers[1:],excelrow[1:]):
            if not head:continue
            style=getattr(c,'_style_id',0);fill=w._cell_styles[style].fillId
            color=w._fills[fill].fgColor
            val=c.value;numeric=isinstance(val,(int,float))
            if color.type=='rgb' and color.rgb=='FFFFC000':flag='provider_flag_zero_or_implausible'
            elif color.type=='rgb' and color.rgb=='FFFFEB9C':flag='provider_flag_missing'
            elif fill==reconstructed_fill_id:flag='provider_reconstructed'
            elif not numeric:flag='missing_non_numeric'
            elif fill!=0:flag='unclassified_format_review'
            else:flag='unflagged_numeric'
            rows.append({'counter_id':head.split()[0],'timestamp_naive':timestamp.isoformat(),'date':timestamp.strftime('%Y-%m-%d'),'count_raw':val if numeric else None,'quality_flag':flag,'usable_unflagged':numeric and flag=='unflagged_numeric','source_sheet':sheet.title,'source_cell':getattr(c,'coordinate',None),'source_style_id':style,'source_fill_id':fill})
    ix=pd.DatetimeIndex(times);expected=pd.date_range(f'{year}-01-01',f'{year+1}-01-01',freq='h',inclusive='left')
    qc.append({'year':year,'timestamp_rows':len(times),'unique_naive_timestamps':ix.nunique(),'duplicate_naive_timestamps':int(ix.duplicated().sum()),'missing_naive_clock_labels':[str(x) for x in expected.difference(ix)]})
b=pd.DataFrame(rows)
b.to_csv(ROOT/'bicycle-hourly-2019-2020-quality-preserved.csv.gz',index=False)
b['count_valid']=b.count_raw.where(b.usable_unflagged)
daily=b.groupby(['counter_id','date']).agg(source_rows=('timestamp_naive','size'),unflagged_hours=('usable_unflagged','sum'),observed_unflagged_count=('count_valid',lambda s:s.sum(min_count=1)),raw_numeric_hours=('count_raw','count'),raw_numeric_sum=('count_raw',lambda s:s.sum(min_count=1))).reset_index()
daily['complete_24_unflagged_hours']=daily.unflagged_hours.eq(24)
daily.to_csv(ROOT/'bicycle-daily-2019-2020.csv.gz',index=False)
b.groupby(['counter_id','source_sheet','quality_flag']).size().rename('hourly_cells').reset_index().to_csv(ROOT/'bicycle-coverage-by-counter-year.csv',index=False)
summary={'rows':len(b),'counters':b.counter_id.nunique(),'dates':b.date.nunique(),'first_date':b.date.min(),'last_date':b.date.max(),'unflagged_numeric_rows':int(b.usable_unflagged.sum()),'quality_counts':b.quality_flag.value_counts().to_dict(),'timestamp_qc':qc,'daily_rows':len(daily),'clock_warning':'Workbook provides naive clock labels. Do not assume unambiguous UTC; DST labels require audit before exact hourly multimodal joins.'}
(ROOT/'bicycle-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
print('Bicycle',json.dumps(summary),flush=True)

z=zipfile.ZipFile(RAW/'dwd-weather-station00433.zip')
product=[n for n in z.namelist() if n.startswith('produkt_')][0]
weather=pd.read_csv(z.open(product),sep=';');weather.columns=weather.columns.str.strip()
weather=weather[weather.MESS_DATUM.between(20190101,20201231)].copy()
for col in weather.select_dtypes('number').columns:
    if col not in ['STATIONS_ID','MESS_DATUM']:weather[col]=weather[col].replace(-999,np.nan)
weather['date']=pd.to_datetime(weather.MESS_DATUM,format='%Y%m%d').dt.strftime('%Y-%m-%d')
weather['source_member']=product
weather.to_csv(ROOT/'weather-daily-station00433-2019-2020.csv',index=False)
for n in z.namelist():
    if n.endswith('.txt') and any(x in n for x in ['Geographie','Stationsname','Fehlwerte']):(RAW/n).write_bytes(z.read(n))
(ROOT/'weather-summary.json').write_text(json.dumps({'rows':len(weather),'first_date':weather.date.min(),'last_date':weather.date.max(),'missing_by_column':weather.isna().sum().to_dict(),'station':'00433; see official metadata for station-name history','unit_source':'dwd-description.pdf'},indent=2))

projects=json.loads((ROOT/'treatment-related-current-map-kml.json').read_text())
ns={'k':'http://www.opengis.net/kml/2.2'}
features=[]
known={'9040049':('Kantstraße/Neue Kantstraße','2020-06-19'),'9030064':('Danziger Straße','2020-05-12'),'9020091':('Petersburger Straße','2020-04-10')}
for project in projects:
    tree=ET.fromstring(project['kml'])
    ids=[e.text for e in tree.findall('.//k:SimpleData',ns) if e.attrib.get('name')=='ProjektID']
    if not ids:continue
    pid=ids[0]
    coords=[]
    for node in tree.findall('.//k:LineString/k:coordinates',ns):
        line=[[float(y) for y in x.split(',')[:2]] for x in node.text.split()]
        if len(line)>1:coords.append(line)
    if not coords:continue
    props={'project_id':pid,'source_url':'https://www.infravelo.de/karte/','source_endpoint':project['endpoint'],'geometry_vintage':'current map snapshot; not certified historical asbuilt','popup_2020_project_verified':pid in known}
    if pid in known:props.update(road=known[pid][0],date_from_published_2022_paper=known[pid][1],date_source='Schrauth2022Figure2; officialprojectpage gives Q22020 only')
    features.append({'type':'Feature','properties':props,'geometry':{'type':'MultiLineString','coordinates':coords}})
(ROOT/'treatment-related-current-geometries.geojson').write_text(json.dumps({'type':'FeatureCollection','features':features},ensure_ascii=False,indent=2))
verified=[x for x in features if x['properties']['popup_2020_project_verified']]
(ROOT/'three-verified-popup-project-geometries.geojson').write_text(json.dumps({'type':'FeatureCollection','features':verified},ensure_ascii=False,indent=2))

# Local metric projection is sufficient for a proximity audit, not exact street-side assignment.
def xy(lon,lat):return (lon*111320*math.cos(math.radians(52.5)),lat*111320)
def distance(lon,lat,lines):
    point=np.array(xy(lon,lat));best=float('inf')
    for line in lines:
        pp=[np.array(xy(*c)) for c in line]
        for a,c in zip(pp[:-1],pp[1:]):
            v=c-a;den=np.dot(v,v)
            t=max(0,min(1,np.dot(point-a,v)/den)) if den else 0
            best=min(best,float(np.linalg.norm(point-(a+t*v))))
    return best
proximity=[]
study_sites=sites[sites['Zählstelle'].isin(b.counter_id.unique())]
motors=pd.read_csv(ROOT/'motor-station-metadata.csv').drop_duplicates('MQ_KURZNAME')
for feature in verified:
    prop=feature['properties'];lines=feature['geometry']['coordinates']
    for _,s in study_sites.iterrows():proximity.append({'project_id':prop['project_id'],'road':prop['road'],'sensor_type':'bicycle','sensor_id':s['Zählstelle'],'sensor_description':s['Beschreibung - Fahrtrichtung'],'approx_distance_to_line_m':round(distance(s['Längengrad'],s['Breitengrad'],lines),1),'assignment':'proximity only; NOT confirmed treated screenline'})
    for _,s in motors.iterrows():
        if pd.notna(s['LÄNGE (WGS84)']) and pd.notna(s['BREITE (WGS84)']):
            dist=distance(s['LÄNGE (WGS84)'],s['BREITE (WGS84)'],lines)
            if dist<=500:proximity.append({'project_id':prop['project_id'],'road':prop['road'],'sensor_type':'motor','sensor_id':s.MQ_KURZNAME,'sensor_description':s.STRASSE+' '+str(s.POSITION),'approx_distance_to_line_m':round(dist,1),'assignment':'proximity only; NOT confirmed treated screenline'})
proximity=pd.DataFrame(proximity);proximity.to_csv(ROOT/'sensor-project-proximity-audit.csv',index=False)
print('Nearest bicycle counters to verified current popup project lines:',proximity[proximity.sensor_type.eq('bicycle')].sort_values('approx_distance_to_line_m').groupby('project_id').head(2).to_dict('records'),flush=True)
print('Weather records',len(weather),'Geometry projects',len(features),'Verified2020projectIDs',len(verified),flush=True)
