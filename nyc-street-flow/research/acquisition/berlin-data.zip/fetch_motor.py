from pathlib import Path
from urllib.request import urlopen
from concurrent.futures import ThreadPoolExecutor, as_completed
import shutil, hashlib, json, datetime
import pandas as pd
import numpy as np

ROOT=Path(__file__).resolve().parent
RAW=ROOT/'raw'; RAW.mkdir(parents=True,exist_ok=True)
OLD=ROOT.parents[1]/'global-study/europe'
BASE='https://mdhopendata.blob.core.windows.net/verkehrsdetektion/'
manifest=[]
def fetch(y,m):
    name=f'mq_hr_{y}_{m:02}.csv.gz'
    out=RAW/name
    url=BASE+f'{y}/alte_qualitaetssicherung/Messquerschnitte/'+name
    if not out.exists():
        if (OLD/name).exists():shutil.copy2(OLD/name,out)
        else:out.write_bytes(urlopen(url,timeout=90).read())
    return {'file':str(out.relative_to(ROOT)),'source_url':url,'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest()}
with ThreadPoolExecutor(max_workers=4) as pool:
    futures=[pool.submit(fetch,y,m) for y in [2019,2020] for m in range(1,13)]
    for f in as_completed(futures):
        item=f.result(); manifest.append(item);print('Downloaded',item['file'],flush=True)
for name,url in [('station-metadata.xlsx',BASE+'Stammdaten_Verkehrsdetektion_2022_07_20.xlsx'),('README-provider.txt',BASE+'ReadMe.txt')]:
    out=RAW/name
    if not out.exists():out.write_bytes(urlopen(url,timeout=90).read())
    manifest.append({'file':str(out.relative_to(ROOT)),'source_url':url,'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest()})
(ROOT/'motor-source-manifest.json').write_text(json.dumps(manifest,indent=2))
metadata=pd.read_excel(RAW/'station-metadata.xlsx')
metadata.to_csv(ROOT/'motor-station-metadata.csv',index=False)
pattern='Kant|Hallesche|Zossener|Gitschiner|Lichtenberger|Petersburger|Kottbusser|Schöneberger Ufer|Tempelhofer Ufer|Danziger|Frankfurter Allee|Adlergestell|Blaschko'
candidates=metadata[metadata.STRASSE.str.contains(pattern,case=False,na=False)]
candidates.to_csv(ROOT/'candidate-road-detectors.csv',index=False)
daily=[];hours=[];coverage=[];checks=[]
for f in sorted(RAW.glob('mq_hr*.csv.gz')):
    d=pd.read_csv(f,sep=';');d['source_file']=f.name
    d['date']=pd.to_datetime(d.tag,format='%d.%m.%Y').dt.strftime('%Y-%m-%d')
    dup=int(d.duplicated(['mq_name','tag','stunde']).sum())
    checks.append({'source_file':f.name,'rows':len(d),'stations':d.mq_name.nunique(),'first_date':d.date.min(),'last_date':d.date.max(),'duplicate_local_station_date_hour_keys':dup,'null_motor_counts':int(d.q_kfz_mq_hr.isna().sum()),'negative_motor_counts':int(d.q_kfz_mq_hr.lt(0).sum())})
    for speed,count in [('v_kfz_mq_hr','q_kfz_mq_hr'),('v_pkw_mq_hr','q_pkw_mq_hr'),('v_lkw_mq_hr','q_lkw_mq_hr')]:d[speed+'_weighted_numerator']=d[speed]*d[count]
    agg=d.groupby(['mq_name','date'],sort=False).agg(observed_rows=('stunde','size'),unique_local_hour_labels=('stunde','nunique'),q_kfz_observed=('q_kfz_mq_hr','sum'),q_pkw_observed=('q_pkw_mq_hr','sum'),q_lkw_observed=('q_lkw_mq_hr','sum'),mean_hourly_motor_speed=('v_kfz_mq_hr','mean'),speed_weighted_numerator=('v_kfz_mq_hr_weighted_numerator','sum'),quality_min=('qualitaet','min')).reset_index()
    agg['vehicle_weighted_point_speed']=agg.speed_weighted_numerator/agg.q_kfz_observed.replace(0,np.nan)
    agg['source_file']=f.name
    # Expected hours handles DST using actual Europe/Berlin local calendar days.
    dates=pd.to_datetime(agg.date)
    agg['expected_clock_hours']=[int((pd.Timestamp(x+pd.Timedelta(days=1)).tz_localize('Europe/Berlin')-pd.Timestamp(x).tz_localize('Europe/Berlin')).total_seconds()/3600) for x in dates]
    agg['row_coverage_fraction']=agg.observed_rows/agg.expected_clock_hours
    daily.append(agg)
    selected=d[d.mq_name.isin(candidates.MQ_KURZNAME)].drop(columns=[x for x in d if x.endswith('_weighted_numerator')])
    hours.append(selected)
    coverage.append(d.groupby('mq_name').agg(rows=('stunde','size'),days=('date','nunique'),first_date=('date','min'),last_date=('date','max')).reset_index().assign(source_file=f.name))
    print('Processed',f.name,len(d),'rows',flush=True)
pd.concat(daily).to_csv(ROOT/'motor-daily-all-cross-sections-2019-2020.csv.gz',index=False)
pd.concat(hours).to_csv(ROOT/'motor-hourly-candidate-roads-2019-2020.csv.gz',index=False)
pd.concat(coverage).to_csv(ROOT/'motor-monthly-coverage.csv',index=False)
pd.DataFrame(checks).to_csv(ROOT/'motor-file-qc.csv',index=False)
summary={'raw_files':len(checks),'raw_hourly_rows':sum(x['rows'] for x in checks),'daily_rows':sum(len(x) for x in daily),'candidate_hourly_rows':sum(len(x) for x in hours),'cross_sections':int(pd.concat(daily).mq_name.nunique()),'first_date':min(x['first_date'] for x in checks),'last_date':max(x['last_date'] for x in checks),'duplicate_local_keys':sum(x['duplicate_local_station_date_hour_keys'] for x in checks),'causal_gate':'No finalized spatial treatment assignment; no causal estimate. Road-name candidates may include untreated sections. Motor totals are vehicles, not occupants.'}
(ROOT/'motor-summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary),flush=True)
