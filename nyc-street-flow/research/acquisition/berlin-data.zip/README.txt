Berlin data acquisition, checked 2026-11-06

Official motor archive: Digitale Plattform Stadtverkehr Berlin / Verkehrsdetektion Berlin.
24 monthly archives (2019–2020), 4,532,392 hourly cross-section records at 267 sections.
Included derived daily panel: 190,837 section-days; candidate-road hourly panel: 309,085 rows.
Motor totals are vehicles, not passengers. Candidate roads are text matches, not verified treated segments.
Vehicle-weighted point speed is not complete-trip duration. Two source-wide missing dates are
2019-06-03 and 2019-09-10. Missing data have not been zero-filled.

Official cycling workbook: 456,118 cells; 409,245 unflagged numeric cells, 46,793 provider-flagged
zero/implausible cells, 80 other missing cells. Provider quality styles are preserved in extraction.
Naive timestamps and daylight-saving labels require review before exact hourly multimodal joins.
26 counters do not provide same-screenline matches to the three verified pop-up project geometries:
nearest bicycle counters are roughly 1.55–1.97 km away. Never add these totals as a treated corridor.
Current infrastructure geometries are supporting spatial evidence, not a historical as-built lane inventory.
Weather: DWD station 00433, 731 daily records; rainfall missing on 2 dates.

Raw archives are referenced by source URL, file size and SHA256 rather than duplicated in this download.
Run fetch_manifest_sources.py to restore the provider inputs (network required), then fetch_motor.py
and build_supplements.py to regenerate extracts (pandas, numpy, openpyxl required).
Source URLs can change; hash mismatch requires source version review rather than silently replacing data.
No causal estimate of total people flow or complete journey time is made by this data package.
