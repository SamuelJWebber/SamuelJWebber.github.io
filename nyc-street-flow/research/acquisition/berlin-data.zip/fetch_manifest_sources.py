"""Restore original provider inputs from included manifests, validating SHA256."""
from pathlib import Path
from urllib.request import urlopen
import json,hashlib,shutil
P=Path(__file__).resolve().parent
for manifest in ["motor-source-manifest.json","supplement-source-manifest.json","treatment-source-manifest.json"]:
 for row in json.loads((P/manifest).read_text()):
  dest=P/row["file"];dest.parent.mkdir(parents=True,exist_ok=True)
  if not dest.exists():
   with urlopen(row["source_url"],timeout=120) as inp,dest.open("wb") as out:shutil.copyfileobj(inp,out)
  assert hashlib.sha256(dest.read_bytes()).hexdigest()==row["sha256"],str(dest)+" source version changed; retain original hash and investigate"
