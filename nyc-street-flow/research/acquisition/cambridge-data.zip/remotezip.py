import io,urllib.request,json,zipfile,concurrent.futures
from pathlib import Path
P=Path(__file__).parent
class RangeFile(io.RawIOBase):
 def __init__(self,url,size):self.url,self.size,self.pos=url,size,0
 def seekable(self):return True
 def readable(self):return True
 def tell(self):return self.pos
 def seek(self,offset,whence=0):
  self.pos=(offset if whence==0 else self.pos+offset if whence==1 else self.size+offset);return self.pos
 def read(self,n=-1):
  if n<0:n=self.size-self.pos
  if n==0:return b''
  start=self.pos;end=min(self.size-1,start+n-1)
  req=urllib.request.Request(self.url,headers={'Range':f'bytes={start}-{end}'})
  with urllib.request.urlopen(req,timeout=60)as r:
   d=r.read()
   if r.status!=206:raise RuntimeError('Range not honored: '+str(r.status))
  self.pos+=len(d);return d
ids={'apc':'8daf4a33925a4df59183f860826d29ee','avl2022':'ef464a75666349f481353f16514c06d0','avl2021':'2d415555f63b431597721151a7e07a3e'}
def index(k,id):
 u='https://www.arcgis.com/sharing/rest/content/items/'+id+'/data'
 with urllib.request.urlopen(urllib.request.Request(u,method='HEAD'),timeout=45)as r:size=int(r.headers['content-length'])
 z=zipfile.ZipFile(RangeFile(u,size));rows=[{'name':i.filename,'size':i.file_size,'compressed':i.compress_size,'offset':i.header_offset}for i in z.infolist()]
 (P/('mbta_'+k+'_archive_index.json')).write_text(json.dumps({'url':u,'size':size,'members':rows},indent=2));print(k,rows,flush=True)
if __name__=='__main__':
 with concurrent.futures.ThreadPoolExecutor(max_workers=3)as ex:list(ex.map(lambda kv:index(*kv),ids.items()))
