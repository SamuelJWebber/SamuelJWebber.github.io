from pathlib import Path
import urllib.request,urllib.parse,csv,json,concurrent.futures
P=Path(__file__).parent
sites=['Massachusetts Avenue and Alewife Brook Parkway','Galileo Galilei Way and Broadway','Garden Street and Huron Avenue']
win=[('202105','2021-05-01','2021-05-15'),('202111','2021-11-02','2021-11-05'),('202112','2021-12-14','2021-12-17'),('202205','2022-05-01','2022-05-15')]
def go(k,a,b):
 where="timebin >= '"+a+"T00:00:00' AND timebin < '"+b+"T00:00:00' AND intersection in ("+','.join("'"+s+"'"for s in sites)+')'
 params={'$where':where,'$order':'timebin,intersection,class,entrance,exit','$limit':200000}
 u='https://data.cambridgema.gov/resource/jwtp-n65u.csv?'+urllib.parse.urlencode(params)
 try:
  d=urllib.request.urlopen(u,timeout=70).read();(P/f'cambridge_miovision_{k}.csv').write_bytes(d);rows=list(csv.DictReader(d.decode('utf-8-sig').splitlines()))
  assert len(rows)<200000,'possibletruncation'
  (P/f'cambridge_miovision_{k}_source.json').write_text(json.dumps({'url':u,'rows':len(rows),'date_from':a,'date_to_exclusive':b,'sites':sites},indent=2))
  print(k,len(rows),'classes',sorted({r['class']for r in rows}),flush=True)
 except Exception as e:print(k,type(e).__name__,e,flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=4)as ex:list(ex.map(lambda v:go(*v),win))
