from pathlib import Path
import urllib.request,zipfile,io,json,csv,struct,zlib,concurrent.futures,time
P=Path(__file__).parent
# Public ZIP byte-range extraction; member offsets/lengths from saved central directory.
def fetch(archive,needle,outname):
 j=json.loads((P/f'mbta_{archive}_archive_index.json').read_text());m=next(x for x in j['members']if needle in x['name'] and x['name'].endswith('.csv'))
 # Request local header+compressed member. Header has variable filename/extra lengths.
 start=m['offset'];end=start+30+len(m['name'].encode())+4096+m['compressed']
 req=urllib.request.Request(j['url'],headers={'Range':f'bytes={start}-{min(end,j["size"]-1)}'})
 with urllib.request.urlopen(req,timeout=90)as r:
  if r.status!=206:raise RuntimeError('Range ignored')
  data=r.read()
 name_len,extra_len=struct.unpack_from('<HH',data,26);beg=30+name_len+extra_len
 # Persist source compressed member with enough provenance to reproduce extraction.
 c=data[beg:beg+m['compressed']];(P/(outname+'.deflate')).write_bytes(c)
 raw=zlib.decompress(c,-15)
 assert len(raw)==m['size']
 rows=csv.DictReader(io.StringIO(raw.decode('utf-8-sig')))
 keys=rows.fieldnames;keep=[];total=0
 for row in rows:
  total+=1
  rid=row.get('route_id',row.get('route','')).lstrip('0')
  if rid in {'77','1','71','73','74','75','78'}:keep.append(row)
 with (P/(outname+'.csv')).open('w',newline='')as f:
  w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(keep)
 src={'archive_url':j['url'],'member':m,'source_rows':total,'selected_rows':len(keep),'routes':['77','1','71','73','74','75','78'],'fields':keys}
 (P/(outname+'_source.json')).write_text(json.dumps(src,indent=2));print(outname,'source_rows',total,'kept',len(keep),'fields',keys,'first',keep[:1],flush=True)
J=[('apc','Fall_2019','mbta_apc_fall2019_selected_routes'),('apc','Fall_2022','mbta_apc_fall2022_selected_routes'),('avl2021','2021-11.csv','mbta_avl_202111_selected_routes'),('avl2021','2021-12.csv','mbta_avl_202112_selected_routes'),('avl2022','2022-05.csv','mbta_avl_202205_selected_routes')]
if __name__=='__main__':
 with concurrent.futures.ThreadPoolExecutor(max_workers=3)as ex:
  futures=[ex.submit(fetch,*j) for j in J]
  for f in futures:f.result()
