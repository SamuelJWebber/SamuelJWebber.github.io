Vancouver acquisition release — 2026-11-06

City open-data files are observed counts or explicitly labelled location inventories. The 1,005-day extended bike panel contains one inconsistent overlapping Burrard record (2010-06-29: 40,358 versus 4,420). Both are retained and flagged. The original 579-day panel was already acquired in the previous release.

TransLink files are derived factual table extracts, not original microdata. Full PDF reports and full text are intentionally not redistributed. Official source URLs and page references are in the manifests and findings. Shared nine-hour definitions do not establish matched dates/weather; 16-hour motor and nine-hour transit counts cannot be summed. Canada Line opening is a major cointervention. Location inventories are not counts. No causal estimate is calculated from these files.
