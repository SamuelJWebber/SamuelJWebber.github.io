# TransLink acquisition: useful passenger evidence acquired

Downloaded the official 417-page 2008 screenline report and 2011 report plus station appendices (approximately 67 MB total). This is **downloaded published table evidence**, not the underlying dated raw survey database. `fetch_extract.py` downloads and reproduces the selected machine-readable CSVs. Ninety-six 2008 bridge/hour/direction rows were extracted, with bike and pedestrian sums validated against the published nine-hour summary tables.

| Bridge | 2008 → 2011 nine-hour bikes | Nine-hour pedestrians | Nine-hour transit passengers | 16-hour auto occupancy |
|---|---:|---:|---:|---:|
| Burrard | 2,346 → 1,934 | 1,440 → 1,403 | 10,261 → approximately 10,500 | 1.27 → 1.25 |
| Granville | 286 → 126 | 987 → 624 | 44,040 → approximately 18,000 | 1.27 → 1.24 |
| Cambie | 477 → 1,075 | 905 → 1,320 | 5,320 → approximately 1,850 | 1.31 → 1.26 |

The shared nine-hour period is 06:00–09:00, 11:00–13:00 and 15:00–19:00. These are **period-definition aligned**, not matched days or weather. Each year's manual survey used one weekday per site: September 15–November 28, 2008, versus mid-September–mid-December 2011. Exact station dates are absent from these reports. The 2011 transit numbers are rounded published table cells, not digitized graphs; the report's changes calculated from unrounded data can therefore differ from subtraction of displayed cells.

This adds actual occupancy and bus passengers to our evidence. It also demonstrates why the broad counterfactual is hard: the 2011 False Creek screenline includes approximately **42,000 Canada Line passengers in those nine hours**, and total transit crossings of approximately 73,000, versus 59,621 in 2008. The new rapid-transit route, bus restructuring, the end of Cambie construction and differing weather preclude attributing changes to the 2009 bike conversion. Burrard's lower single-day bicycle count in 2011 is another warning against equating one before/after count with a treatment effect.

The 2008 table's “total person trips” is explicitly **motorised modes only** (Appendix G p89); it must not be relabeled all-mode person flow. Its auto occupancy excludes taxis, limousines and buses. Vehicle occupants of three or more are coded as 3.25; trucks and motorcycles assume one person and taxis two (Appendix I pp98–99). Offpeak motor classification/occupancy rows are interpolated/extrapolated; bicycle, pedestrian and transit counts at peak sites are not extrapolated. There are no complete journey times here.

Still not acquired: original 2008 station database (described on p19), dated 2009 bus running times/passenger loads, and the original TransLink before/after Burrard analysis. The City report quotes a favorable bus-time conclusion but does not expose its observations. This bounded search did not find public downloads; that is not evidence the agency lacks them.

For public use, link the original reports rather than hosting their full PDFs: TransLink's research landing page states that the information cannot be redistributed without permission. No request, email, registration or login was sent.

Source provenance and file hashes are in `acquisitions.json` and `manifest.json`. Exact 2008 report pages: occupancy70, bikes84, pedestrians87, transit91, hourly tables120/122/124. Exact 2011 report pages: vehicles18, occupancy26, bikes40, pedestrians42, transit45.
