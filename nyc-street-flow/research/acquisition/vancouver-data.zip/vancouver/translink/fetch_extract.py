#!/usr/bin/env python3
"""Download official reports if missing; extract exact published 2008 bridge tables.
Requires pdftotext; no table cell is a new causal estimate.
"""
from pathlib import Path
import urllib.request, subprocess, csv, re, json, hashlib
P=Path(__file__).resolve().parent
BASE='https://www.translink.ca/-/media/translink/documents/about-translink/customer-service/trip-diary/'
FILES={'screenline-2008-report.pdf':'2008-regional-screenline-survey-report.pdf',
 '2011-screenline-survey-report.pdf':'2011-screenline-survey-report.pdf',
 '2011-screenline-survey-appendix-a.pdf':'2011-screenline-survey-appendix-a.pdf',
 '2011-screenline-survey-appendix-c.pdf':'2011-screenline-survey-appendix-c.pdf'}
for local,remote in FILES.items():
    if not (P/local).exists():
        (P/local).write_bytes(urllib.request.urlopen(BASE+remote,timeout=60).read())
    subprocess.run(['pdftotext','-layout',str(P/local),str(P/local.replace('.pdf','.txt'))],check=True)

def write(name,rows):
    with (P/name).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

text=(P/'screenline-2008-report.txt').read_text()
hourly=[]
for i,page in enumerate(text.split('\f')):
    if 'Hourly Vehicle Volumes, Classification and Occupancy' not in page:continue
    bridge=re.search(r'(Burrard|Granville|Cambie) Bridge \(3-',page)
    if not bridge:continue
    matches=[m for line in page.splitlines() if (m:=re.match(r'^\s*(\d\d:\d\d)\s+(.+)$',line))]
    assert len(matches)==38
    # Each direction: sixteen hourly observations, then three peak-hour summaries.
    for direction,subset in [('northbound',matches[:16]),('southbound',matches[19:35])]:
        for m in subset:
            tokens=re.sub(r'\([^)]*\)','',m[2]).split()
            assert len(tokens)==13
            fields=['total_motor_vehicles','passenger_vehicles_1_person','passenger_vehicles_2_people','passenger_vehicles_3plus_people','light_trucks','heavy_trucks','transit_buses','mean_auto_occupancy','bicycles_on_road','bicycles_on_bus','pedestrians','vehicles_including_road_bikes','bike_pct']
            row={'bridge':bridge[1],'direction':direction,'hour_begin':m[1],'survey_year':2008,'report_page':{135:120,137:122,139:124}[i+1],'pdf_page':i+1,'offpeak_motor_values_interpolated':m[1][:2] in ['09','10','13','14','19','20','21']}
            for k,v in zip(fields,tokens):
                v=v.replace(',','').replace('%','');row[k]=None if v=='-' else float(v) if '.' in v else int(v)
            hourly.append(row)
assert len(hourly)==96
write('bridge-hourly-classification-occupancy-2008.csv',hourly)

# Table18, report p70. Occupancy excludes taxis/limousines/buses; 3+ auto occupants coded3.25.
occupancy=[]
for bridge,vals in [('Burrard',[1.17,1.26,1.29,1.26,1.27,1.27,1.28]),('Granville',[1.20,1.26,1.26,1.26,1.21,1.27,1.23]),('Cambie',[1.22,1.25,1.37,1.29,1.22,1.31,1.24])]:
    occupancy.append(dict(bridge=bridge,am_peak_2008=vals[0],midday_peak_2008=vals[1],pm_peak_2008=vals[2],nine_hour_2008=vals[3],nine_hour_2004=vals[4],sixteen_hour_2008=vals[5],sixteen_hour_2004=vals[6],report_page=70))
write('bridge-auto-occupancy-2008.csv',occupancy)

# Table24, report p91. 'Total person trips' means MOTORISED modes, not all modes.
transit=[]
for bridge,vals in [('False Creek screenline',[9566,3894,9703,25799,16610,28537,59621,32.0]),('Burrard',[2352,540,1623,9046,5831,9417,10261,16.7]),('Granville',[6299,3174,7452,12980,8352,15342,44040,45.4]),('Cambie',[915,180,628,3773,2426,3779,5320,19.2])]:
    row=dict(bridge=bridge,survey_year=2008,report_page=91)
    row.update(zip(['am_peak_transit_passengers','midday_peak_transit_passengers','pm_peak_transit_passengers','am_peak_motorised_people','midday_peak_motorised_people','pm_peak_motorised_people','nine_hour_transit_passengers','nine_hour_transit_share_motorised_pct'],vals));transit.append(row)
write('bridge-transit-person-tables-2008.csv',transit)

active=[]
for bridge,bikes,peds in [('Burrard',2346,1440),('Granville',286,987),('Cambie',477,905)]:
    h=[r for r in hourly if r['bridge']==bridge]
    assert sum(r['bicycles_on_road'] or 0 for r in h)==bikes
    assert sum(r['pedestrians'] or 0 for r in h)==peds
    active.append(dict(bridge=bridge,survey_year=2008,nine_hour_bicycles=bikes,nine_hour_pedestrians=peds,hours='06:00-09:00;11:00-13:00;15:00-19:00',report_pages='84;87'))
write('bridge-active-2008.csv',active)

# Exact reported 2011 summary cells; Table10 transit uses a rounding scheme.
# 2011 single-day surveys are not matched to 2008 days/weather.
later=[]
for bridge,occ,bikes,peds,transit9,vehicles24 in [
    ('Burrard',1.25,1934,1403,10500,57000),
    ('Granville',1.24,126,624,18000,57000),
    ('Cambie',1.26,1075,1320,1850,52000),
]:
    later.append(dict(bridge=bridge,survey_year=2011,auto_occupancy_16h=occ,bicycles_9h=bikes,pedestrians_9h=peds,transit_passengers_9h_rounded=transit9,motor_vehicles_24h_rounded=vehicles24,source_report_pages='18;26;40;42;45',manual_coverage='one weekday between mid-September and mid-December 2011'))
write('bridge-selected-tables-2011.csv',later)
write('false-creek-transit-context-2011.csv',[
    dict(location='False Creek screenline including Canada Line',survey_year=2011,transit_passengers_9h_rounded=73000,report_page=45),
    dict(location='Canada Line across False Creek',survey_year=2011,transit_passengers_9h_rounded=42000,report_page=45),
])

aligned=[]
for row in later:
    b=row['bridge'];early=next(x for x in active if x['bridge']==b);occ=next(x for x in occupancy if x['bridge']==b);t=next(x for x in transit if x['bridge']==b)
    for metric,before,after,unit,page0,page1 in [
        ('bicycles',early['nine_hour_bicycles'],row['bicycles_9h'],'crossings in 9 observed hours',84,40),
        ('pedestrians',early['nine_hour_pedestrians'],row['pedestrians_9h'],'crossings in 9 observed hours',87,42),
        ('auto_occupancy',occ['sixteen_hour_2008'],row['auto_occupancy_16h'],'people per passenger vehicle over 16 hours; some 2008 offpeak interpolation',70,26),
        ('transit_passengers',t['nine_hour_transit_passengers'],row['transit_passengers_9h_rounded'],'passengers in 9 observed hours; 2011 rounded',91,45),
    ]:
        aligned.append(dict(bridge=b,metric=metric,before_year=2008,after_year=2011,before=before,after=after,change=after-before,change_pct=(after/before-1)*100,unit=unit,before_report_page=page0,after_report_page=page1,before_survey_dates='single weekday 2008-09-15 to 2008-11-28; exact station day not public in report',after_survey_dates='single weekday mid-September to mid-December 2011; exact station day not public in report',interpretation='period-definition aligned, not day/weather matched; descriptive; NOT lane causal effect'))
write('bridge-comparison-2008-2011.csv',aligned)

boundary=[]
for metric,before,after,unit,p0,p1,limit in [
    ('published_cyclist_counts',sum(x['nine_hour_bicycles'] for x in active),sum(x['bicycles_9h'] for x in later),'crossings in nine hours',84,40,'Sum of separate site survey days; sidewalk inclusion in on-road column not explicit; weather not matched'),
    ('pedestrians',sum(x['nine_hour_pedestrians'] for x in active),sum(x['pedestrians_9h'] for x in later),'crossings in nine hours',87,42,'Sum of separate site survey days; weather not matched'),
    ('transit_passengers',59621,73000,'passengers in nine hours; 2011 rounded',91,45,'2011 includes new Canada Line; rounded screenline aggregate differs from sum of rounded components'),
    ('motor_vehicles',170388,166000,'vehicles per24h average weekday; 2011 rounded',62,18,'Different window from9h rows; not occupants; Cambie construction confounds2008'),
]:
    boundary.append(dict(boundary='False Creek: Burrard/Granville/Cambie bridges plus Canada Line when present',metric=metric,before_year=2008,after_year=2011,before=before,after=after,change=after-before,change_pct=(after/before-1)*100,unit=unit,before_report_page=p0,after_report_page=p1,limitation=limit))
write('false-creek-separate-mode-window-comparison.csv',boundary)
comparison={'id':'false-creek-2008-2011-separated-modes','status':'downloaded_table','title':'False Creek crossing counts before/after, with a new rapid-transit route','causal':False,'all_person_flow_estimated':False,'metrics':boundary,'cannot_sum_reason':'Published motorised-person totals exist only for 2008 selected peak hours, not aligned9h totals in bothyears; 2011 appendix reports roundedvehicleclassification shares andbusvehiclecounts, not9hpassengerloads for everyhour. 24hvehicles cannotbeaddedto9hpassengers.','coverage':'Manual sites: onefallweekdayperyear, notsamecalendar dates; nine-hourperiod definitionsmatch.','source_urls':[BASE+FILES['screenline-2008-report.pdf'],BASE+FILES['2011-screenline-survey-report.pdf']],'limitations':['Canada Line andendofCambieconstruction aremajorcointerventions.','2011transit isroundedbythepublisher.','2008tables label bicycles onroad versusonbus; sidewalkinclusionnotexplicitlydocumentedinretrievedprotocol.','No completejourneytimeoutcome.']}
(P/'comparison.json').write_text(json.dumps(comparison,indent=2)+'\n')

manifest=[]
for local,remote in FILES.items():
    b=(P/local).read_bytes();manifest.append(dict(file=local,url=BASE+remote,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
(P/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'hourly_rows':len(hourly),'occupancy_rows':len(occupancy),'transit_rows':len(transit),'active_rows':len(active)}))
