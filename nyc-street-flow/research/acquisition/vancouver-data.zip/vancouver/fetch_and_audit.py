#!/usr/bin/env python3
"""Download public Vancouver exports and audit schema/overlap; no credentials needed.

Usage: python fetch_and_audit.py [--refresh]
Existing files are used by default; --refresh fetches from the listed original URLs.
The 2008 TransLink report is handled by translink/fetch_and_extract.py separately.
"""
import argparse,csv,datetime as dt,hashlib,json,pathlib,urllib.request

P=pathlib.Path(__file__).resolve().parent
REFRESH=argparse.ArgumentParser();REFRESH.add_argument('--refresh',action='store_true');refresh=REFRESH.parse_args().refresh
BASE='https://opendata.vancouver.ca/api/explore/v2.1/catalog/datasets/'
DATASETS=[
 'bike-lane-statistics-for-burrard-bridge-2009-2010',
 'bike-lane-statistics-for-hornby-dunsmuir-and-burrard-2009-2012',
 'directional-traffic-count-locations',
 'intersection-traffic-movement-counts',
]
manifest=[]
def fetch(filename,url):
    p=P/filename
    if refresh or not p.exists():
        with urllib.request.urlopen(url,timeout=45) as response:
            p.write_bytes(response.read())
    data=p.read_bytes()
    manifest.append({'file':filename,'source_url':url,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
    return json.loads(data)
def savecsv(filename,rows):
    if not rows:return
    with (P/filename).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
all_data={}
for dataset in DATASETS:
    all_data[dataset]=fetch(dataset+'.json',BASE+dataset+'/exports/json')
    print(dataset,len(all_data[dataset]))
old=all_data[DATASETS[0]];new=all_data[DATASETS[1]]
assert len(old)==579 and len(new)==1005, 'Source changed; inspect new coverage before proceeding.'
for dataset in DATASETS[:2]:
    rows=all_data[dataset];rows.sort(key=lambda r:r['date']);savecsv(dataset+'.csv',rows)
coverage=[]
for dataset in DATASETS[:2]:
    rows=all_data[dataset]
    for field in rows[0]:
        if field in ('date','comments'):continue
        valid=[r for r in rows if r[field] is not None]
        coverage.append({'dataset':dataset,'field':field,'valid_rows':len(valid),'missing_rows':len(rows)-len(valid),'first_valid':min(r['date'] for r in valid),'last_valid':max(r['date'] for r in valid)})
savecsv('daily-panel-coverage.csv',coverage)
lookup={r['date']:r['total_bicycles'] for r in old}
overlap=[]
for r in new:
    if r['date'] in lookup and lookup[r['date']] is not None and r['burrard_bridge'] is not None:
        overlap.append({'date':r['date'],'original_2009_2010_total_bicycles':lookup[r['date']],'extended_2009_2012_burrard_bridge':r['burrard_bridge'],'difference':r['burrard_bridge']-lookup[r['date']]})
savecsv('burrard-overlap-all.csv',overlap)
savecsv('burrard-overlap-discrepancies.csv',[r for r in overlap if r['difference']])
locations=[]
for r in all_data['directional-traffic-count-locations']:
    if r['location'] in ('BURRARD BRIDGE','GRANVILLE BRIDGE','CAMBIE BRIDGE') or 'ONTARIO' in r['location']:
        locations.append({'dataset':'directional inventory','location':r['location'],'longitude':r['geo_point_2d']['lon'],'latitude':r['geo_point_2d']['lat'],'data_url':'','actual_counts_present':False})
for r in all_data['intersection-traffic-movement-counts']:
    if any(s in r['intersection'] for s in ('BURRARD','GRANVILLE','CAMBIE','ONTARIO')):
        coords=r['geom']['geometry']['coordinates']
        locations.append({'dataset':'intersection inventory','location':r['intersection'],'longitude':coords[0],'latitude':coords[1],'data_url':r['url'],'actual_counts_present':False})
savecsv('target-location-inventory.csv',locations)
(P/'download-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(P/'audit-summary.json').write_text(json.dumps({'daily_rows_original':len(old),'daily_rows_extended':len(new),'overlapping_nonnull_burrard_dates':len(overlap),'discrepant_dates':sum(bool(r['difference']) for r in overlap),'target_inventory_rows':len(locations),'important':'Location inventories are not observations. No Ontario, Granville or Cambie count series is present in these exports. No effect estimate is computed from incompatible or incomplete records.'},indent=2)+'\n')
print('overlap',len(overlap),'discrepancies',sum(bool(r['difference']) for r in overlap))
