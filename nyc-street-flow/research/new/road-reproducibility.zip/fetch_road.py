"""Auditable road count discovery; exact named bridges, no inferred nearby paths."""
import json,urllib.request,urllib.parse,time,pathlib,csv
from concurrent.futures import ThreadPoolExecutor
P=pathlib.Path(__file__).parent
jobs={
 'classification_bridges':('96ay-ea4r',{'$where':"upper(roadway_name) like '%BROOKLYN%BRIDGE%' OR upper(roadway_name) like '%PULASKI%'",'$limit':50000,'$order':'roadway_name,date,direction,veh_class_type'}),
 'atr_bridges':('7ym2-wayt',{'$select':'street,yr,m,d,fromst,tost,direction,count(*) as intervals,sum(vol) as total','$where':"upper(street) like '%BROOKLYN%BRIDGE%' OR upper(street) like '%PULASKI%'",'$group':'street,yr,m,d,fromst,tost,direction','$order':'street,yr,m,d,direction','$limit':50000}),
 'classification_names':('96ay-ea4r',{'$select':'roadway_name,count(*) as n,min(date) as first,max(date) as last','$where':"upper(roadway_name) like '%PROSPECT%PARK%WEST%' OR upper(roadway_name) like '%AMSTERDAM%' OR upper(roadway_name) like '%THIRD%' OR upper(roadway_name) like '%3 AVENUE%' OR upper(roadway_name) like '%3RD%'",'$group':'roadway_name','$limit':1000}),
}
def fetch(item):
 name,(api,params)=item;url='https://data.cityofnewyork.us/resource/'+api+'.json?'+urllib.parse.urlencode(params);(P/(name+'-query.txt')).write_text(url)
 dest=P/(name+'.json')
 if not dest.exists():
  for attempt in range(4):
   try:
    with urllib.request.urlopen(url,timeout=90) as r:payload=r.read()
    obj=json.loads(payload)
    if not isinstance(obj,list):raise ValueError(str(obj))
    dest.write_bytes(payload);break
   except Exception as e:
    if attempt==3:raise
    time.sleep(1+attempt)
 rows=json.loads(dest.read_text());print(name,len(rows),flush=True);return name,rows
with ThreadPoolExecutor(max_workers=3) as pool:out=dict(pool.map(fetch,jobs.items()))
cl=out['classification_bridges']
groups={}
for r in cl:
 key=tuple(r.get(k,'') for k in ['roadway_name','segmentid','from','to','date','direction'])
 groups.setdefault(key,[]).append(r['veh_class_type'])
for k,v in groups.items():print(k,v)
print('ATR day/direction records',len(out['atr_bridges']))
print('Avenue names',out['classification_names'])
