"""Reproduce bridge vehicle-class snapshots and ATR coverage from saved official extracts.

Run fetch_road.py first to obtain source JSON if absent. This script does not refresh
cached inputs or infer passenger counts. All directions remain as published.
"""
from pathlib import Path
from collections import defaultdict, Counter
import csv, datetime as dt, hashlib, json, re

P=Path(__file__).resolve().parent
classification=json.loads((P/'classification_bridges.json').read_text())
atr=json.loads((P/'atr_bridges.json').read_text())
CLASS_URL='https://data.cityofnewyork.us/Transportation/Vehicle-Classification-Counts/96ay-ea4r'
ATR_URL='https://data.cityofnewyork.us/Transportation/Automated-Traffic-Volume-Counts/7ym2-wayt'
HOURS=['_12_00_1_00_am','_1_00_2_00am','_2_00_3_00am','_3_00_4_00am',
 '_4_00_5_00am','_5_00_6_00am','_6_00_7_00am','_7_00_8_00am',
 '_8_00_9_00am','_9_00_10_00am','_10_00_11_00am','_11_00_12_00pm',
 '_12_00_1_00pm','_1_00_2_00pm','_2_00_3_00pm','_3_00_4_00pm',
 '_4_00_5_00pm','_5_00_6_00pm','_6_00_7_00pm','_7_00_8_00pm',
 '_8_00_9_00pm','_9_00_10_00pm','_10_00_11_00pm','_11_00_12_00am']
CLASSES={'Auto':'Auto','Autos':'Auto','Commercial':'Commercial','Commercial Vehicle':'Commercial',
 'Taxis':'Taxi','Taxi':'Taxi','Heavy Truck':'Heavy Truck','Medium Truck':'Medium Truck',
 'Other Bus':'Other Bus','School Bus':'School Bus'}
WINDOWS={'day':('00:00','24:00',list(range(24))),
 'am':('07:00','09:00',[7,8]),'pm':('16:00','19:00',[16,17,18])}
keys=['roadway_name','segmentid','from','to','date','direction']
grouped=defaultdict(list)
for rownum,r in enumerate(classification,1):grouped[tuple(r[k] for k in keys)].append((rownum,r))
assert len(grouped)==12
snapshots=[];classrows=[];hourrows=[];checks=[]
for key,rows in sorted(grouped.items()):
 road,segment,fromst,tost,date,direction=key
 date=date[:10];bridge='Brooklyn Bridge' if 'BROOKLYN' in road.upper() else 'Pulaski Bridge'
 sid=f'{bridge.split()[0].lower()}-{date}-{direction.lower()}-{segment}'
 label_match=re.search(r'\b(NB|SB|EB|WB)\b$',road.upper())
 conflict=bool(label_match and label_match.group(1)!=direction)
 base=dict(snapshot_id=sid,bridge=bridge,roadway_name=road,segmentid=segment,from_street=fromst,
     to_street=tost,date=date,weekday=dt.date.fromisoformat(date).strftime('%A'),
     direction_published=direction,name_direction=label_match.group(1) if label_match else None,
     direction_conflict=conflict)
 assert len(rows)==7 and len({CLASSES[r['veh_class_type']] for _,r in rows})==7
 hourly={}
 for rownum,r in rows:
  cls=CLASSES[r['veh_class_type']]
  values=[int(r[h]) if r.get(h) is not None and r[h]!='' else None for h in HOURS]
  assert all(v is not None and v>=0 for v in values),(sid,cls)
  hourly[cls]=values
  for hour,value in enumerate(values):
   hourrows.append({**base,'hour_start_local':hour,'vehicle_class':cls,'source_class_label':r['veh_class_type'],
       'vehicles':value,'source_row_number':rownum,'source_field':HOURS[hour],'source_url':CLASS_URL})
 window_results={}
 for window,(start,end,hours) in WINDOWS.items():
  counts={c:sum(v[h] for h in hours) for c,v in hourly.items()};total=sum(counts.values())
  shares={c:n/total if total else None for c,n in counts.items()}
  window_results[window]=dict(start_local=start,end_local=end,duration_hours=len(hours),
      total_vehicles=total,vehicles_per_hour=total/len(hours),class_counts=counts,class_shares=shares)
  for rownum,r in rows:
   cls=CLASSES[r['veh_class_type']]
   classrows.append({**base,'window':window,'start_local':start,'end_local':end,
       'duration_hours':len(hours),'vehicle_class':cls,'source_class_label':r['veh_class_type'],
       'vehicles':counts[cls],'all_class_vehicles':total,'class_share':shares[cls],
       'source_row_number':rownum,'source_url':CLASS_URL})
  checks.append(dict(check='class_share_sum',snapshot_id=sid,window=window,
       passed=abs(sum(shares.values())-1)<1e-12 if total else True))
 snapshots.append({**base,'source_class_rows':len(rows),'hours_per_class':24,
   'source_url':CLASS_URL,'windows':window_results,
   'flags':['roadway_name_SB_conflicts_with_direction_NB_and_segment_9014216; retain source label; verify before directional use'] if conflict else []})

# Exact road-name whitelist includes only explicitly named bridge records; exclude ramps.
WHITELIST={
 'BROOKLYN BRIDGE':'Brooklyn Bridge','E/B BROOKLYN BRIDGE':'Brooklyn Bridge',
 'W/B BROOKLYN BRIDGE':'Brooklyn Bridge','PULASKI BR':'Pulaski Bridge',
 'PULASKI BRIDGE':'Pulaski Bridge','N/B PULASKI BRIDGE @ EAGLE ST - 49 AVE':'Pulaski Bridge',
 'S/B PULASKI BRIDGE @ 49 AVE - EAGLE ST':'Pulaski Bridge'}
days=[];excluded=[]
for rownum,r in enumerate(atr,1):
 name=r['street'].upper()
 if name not in WHITELIST:excluded.append({'source_row_number':rownum,**r});continue
 date=dt.date(int(r['yr']),int(r['m']),int(r['d'])).isoformat()
 intervals=int(r['intervals']);volume=int(r['total']);flags=[]
 if intervals!=96:flags.append('interval_count_not_96')
 if volume<100:flags.append('very_low_total_under_100_requires_review')
 if volume==0:flags.append('zero_reported_total')
 if date in ['2013-04-13','2013-04-14'] and r['direction']=='SB' and 'PULASKI' in name:
    flags.append('96_intervals_with_69_or_9_vehicles_not_a_validity_certificate')
 days.append(dict(bridge=WHITELIST[name],street_published=r['street'],date=date,year=int(r['yr']),
    month=int(r['m']),weekday=dt.date.fromisoformat(date).strftime('%A'),direction_published=r['direction'],
    from_street=r.get('fromst',''),to_street=r.get('tost',''),interval_records=intervals,
    has_96_interval_records=intervals==96,reported_vehicle_sum=volume,
    day_validity='not_established_from_aggregated_extract',flags=flags,
    source_row_number=rownum,source_url=ATR_URL))
assert len(days)==250 and len(excluded)==1
dup=Counter((r['bridge'],r['date'],r['direction_published']) for r in days)
assert max(dup.values())==1
coverage=[]
for bridge,year in sorted({(r['bridge'],r['year']) for r in days}):
 rows=[r for r in days if r['bridge']==bridge and r['year']==year]
 coverage.append(dict(bridge=bridge,year=year,dates=sorted({r['date'] for r in rows}),
    first_date=min(r['date'] for r in rows),last_date=max(r['date'] for r in rows),
    months=sorted({r['month'] for r in rows}),distinct_dates=len({r['date'] for r in rows}),
    directional_day_records=len(rows),directions=sorted({r['direction_published'] for r in rows}),
    directional_days_by_direction=dict(Counter(r['direction_published'] for r in rows)),
    records_with_96_intervals=sum(r['has_96_interval_records'] for r in rows),
    records_with_other_interval_counts=sum(not r['has_96_interval_records'] for r in rows),
    low_total_review_records=sum(r['reported_vehicle_sum']<100 for r in rows),
    from_to_pairs=sorted({(r['from_street'],r['to_street']) for r in rows})))

def csvwrite(name,rows):
 with (P/name).open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader()
  for r in rows:w.writerow({k:json.dumps(v) if isinstance(v,(dict,list,tuple)) else v for k,v in r.items()})
csvwrite('bridge-class-mixes.csv',classrows)
csvwrite('bridge-class-hours.csv',hourrows)
csvwrite('bridge-atr-directional-days.csv',days)
csvwrite('bridge-atr-year-coverage.csv',coverage)
illustration=next(s for s in snapshots if s['bridge']=='Brooklyn Bridge' and s['date']=='2024-04-11' and s['direction_published']=='NB')
out=dict(schema_version=1,checked_on='2026-11-05',units='motor vehicles, not people',
 source_files={n:dict(sha256=hashlib.sha256((P/n).read_bytes()).hexdigest(),rows=len(classification) if n.startswith('classification') else len(atr)) for n in ['classification_bridges.json','atr_bridges.json']},
 source_urls={'classification':CLASS_URL,'atr':ATR_URL},
 saved_queries={n:(P/n).read_text().strip() for n in ['classification_bridges-query.txt','atr_bridges-query.txt']},
 methods=[
  'Classification snapshot key: roadway_name, segmentid, from, to, date and published direction. Sum seven mutually named source classes within 24 hourly columns.',
  'Normalize only class-label spelling: Auto/Autos, Commercial/Commercial Vehicle, Taxi/Taxis. Preserve source labels in CSV.',
  'AM window is 07:00–09:00; PM is 16:00–19:00; day is 00:00–24:00. Class shares divide class vehicles by all seven classes in the same day/direction/window.',
  'ATR input is already grouped by street/year/month/day/from/to/direction, with count(*) and sum(vol). Select exact named bridge records; exclude Brooklyn Bridge Exit Ramp.',
  'Coverage counts presence of source records. A count of96 intervals does not verify distinct quarter-hours, completeness, sensor validity, or representative traffic.',
  'Values under100 vehicles/day are flagged for review as a transparent screening rule, not automatically repaired or declared sensor failures.',
  'No seasonal adjustment, occupancy conversion, passenger inference, causal before/after comparison, or cross-date volume averaging is performed.'],
 counts=dict(classification_source_rows=len(classification),day_direction_snapshots=len(snapshots),
    class_window_rows=len(classrows),hour_class_rows=len(hourrows),atr_source_aggregate_rows=len(atr),
    atr_nonramp_directional_days=len(days),atr_excluded_rows=len(excluded)),
 classification_available_years={b:sorted({int(s['date'][:4]) for s in snapshots if s['bridge']==b}) for b in ['Brooklyn Bridge','Pulaski Bridge']},
 classification_snapshots=snapshots,atr_available_years={b:sorted({r['year'] for r in days if r['bridge']==b}) for b in ['Brooklyn Bridge','Pulaski Bridge']},
 atr_coverage=coverage,atr_directional_days=days,excluded_atr_records=excluded,
 quality_flags=[dict(snapshot_id=s['snapshot_id'],issue=s['flags'][0]) for s in snapshots if s['flags']]+[
   dict(bridge=r['bridge'],date=r['date'],direction=r['direction_published'],interval_records=r['interval_records'],reported_vehicle_sum=r['reported_vehicle_sum'],flags=r['flags']) for r in days if r['reported_vehicle_sum']<100],
 alignment=dict(brooklyn_classification_june_2021_present=False,brooklyn_classification_june_2022_present=False,
    brooklyn_atr_2021_present=False,brooklyn_atr_2022_dates=sorted({r['date'] for r in days if r['bridge']=='Brooklyn Bridge' and r['year']==2022}),
    note='In this explicit-name extract, Brooklyn classification dates are November2016/November2019 and February/April2024. None align with June2021/June2022. Brooklyn2022 ATR is October25–27 southbound only; it does not repair the missing classification or June alignment.'),
 illustrative_snapshot=illustration,
 caveats=[
  'Roadway name Brooklyn Bridge SB on2019-11-26 conflicts with published NB direction and segment9014216. Preserve and flag; do not silently flip directions.',
  'Pulaski southbound2013-04-13/14 have96 interval records but totals69/9. Record-count completeness alone cannot establish a valid traffic day.',
  'Different dates, seasons, years and street naming/segment conventions prevent treating the snapshots as a matched lane-conversion experiment.',
  'The explicit bridge-name search is not an exhaustive spatial search of every possible approach or alias. Missing matches mean absence from this extract, not proof no agency counts exist.',
  'Class counts measure vehicles. Bus counts do not reveal riders; auto/taxi counts do not reveal occupancy.'],
 verification=dict(class_sets_seven_per_snapshot=True,hour_values_present_nonnegative=True,
    duplicate_atr_bridge_date_direction_records=0,share_sum_checks=checks))
(P/'road-analysis.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(dict(counts=out['counts'],class_years=out['classification_available_years'],atr_years=out['atr_available_years'],illustration=illustration),indent=2))
