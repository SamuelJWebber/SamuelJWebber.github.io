# CMS 2024 independent methods audit

Checked 2026-11-05 against [official 2024 user guide](https://www.nyc.gov/html/dot/downloads/pdf/2024-cms-user-guide.pdf), [trip table wgnh-qwsg](https://data.cityofnewyork.us/d/wgnh-qwsg), [day table naav-ygga](https://data.cityofnewyork.us/d/naav-ygga), and the [official attached data dictionary](https://data.cityofnewyork.us/api/views/wgnh-qwsg/files/c2e15726-bbd7-4057-ade3-cb3712a2ee17?download=true). Page numbers below are printed page numbers. Web reference for guide: turn4194173view0. Files are retained in the audit/ subdirectory.

## Source-prescribed interpretation

- Guide §§2–3, pp 2–4: adult NYC resident personal travel, during May–June 2024 fielding; smartphone diaries span seven days, online/call diaries one. Citywide and zonal weights are different estimators. Use trip_weight_citywide for citywide trip counts/shares and day_weight_citywide for the adult-person-day denominator. Use the zonal counterparts for within-zone analysis.
- Guide §4.6 pp 18–19 and §4.7 p 20: the resident travel universe includes trips outside NYC. It excludes nonresident visitors/commuters, children, commercial travel including delivery bicycling, group quarters outside the sampling frame, and seasonal/holiday travel outside fielding. An additional city-boundary filter changes the estimand and must be stated.
- Guide §4.7 pp 20–21 recommends complete travel days and appropriate unit weights. The day denominator must come from the DAY table, including zero-trip days. Household/person/day weights must not be summed after duplication across trip rows.
- Guide §3.3 pp 11–12: online/call trip-rate adjustment is already incorporated. Home-based purpose categories receive factor 2 and non-home-based factor 1; smartphone factor 1. Do not reapply those factors. The guide does not specify a procedure for choosing one weight after collapsing linked legs.
- Guide §4.5 pp 17–18 permits imputed attributes on incomplete trip questionnaires. A day can be complete even when some trip_survey_complete values are 0; therefore do not equate the latter to valid-trip inclusion.
- Guide §4.7 pp 21–22: transit legs were split using a Google route match. Synthetic access/egress rows deliberately have missing duration/distance and copied adjacent timestamps. These timestamps do not establish zero-duration access/egress.
- Guide §4.7 p 22: mode_type is the broad main-mode estimate; higher valid values have priority. Code 995 means missing and must never win a max operation. This is a row-level definition; applying it across linked legs is an explicit analyst extension. Detailed transit codes have no documented numerical priority order.
- Guide §4.3 pp 15–16: continuous missing values are blank; categorical 995 is missing. flag_speed, flag_distance, flag_duration mark single-mode outliers using a modified-z cutoff 4. The guide advises attention to outliers, not automatic exclusion. flag_mode can identify corrected original mode input; it is not automatically an exclusion rule.

## Independent full-file integrity results

The supplied export contains 115,920 rows and 80,081 linked_trip_id groups. trip_id is unique. Every linked group has exactly the stated n_legs, a complete leg_num sequence 1…n, one person, and exactly one anchor row where trip_id==linked_trip_id. No anchor is synthetic(flag 1/2).53 linked groups span day_id values, so grouping by day fragments journeys. Preserve groups globally before eligibility filters.

Forty linked groups have varying supplied weights, including a handful of cross-midnight synthetic rows with zero weight. Three groups have disagreement even among nonsynthetic legs because a home-origin access leg carries 2×day weight while transit/egress carry 1×. The source provides no explicit linked-weight resolution. A transparent anchor-weight convention plus an exclusion-of-inconsistent-weights sensitivity is preferable to silently taking max/mean. All finite observed trip/day weight ratios are exactly 1 or 2.

Complete-day positive-weight rows include 1,170 trip_survey_complete=0 rows and 9,774 code 995 rows. Filtering those flags before reconstruction discards legitimate or synthetic stages. Full-day eligibility should be anchored on the original trip's day. In the overall group audit,74,974 groups have complete trip-day flags and some positive weight; one additional incomplete group has a small positive synthetic weight.

All 10,256 missing-duration rows are synthetic access/egress; they affect 7,781 full-file linked groups. Every nonmissing duration_seconds exactly equals its leg arrival minus departure timestamp. Use seconds/60, avoiding per-leg rounded duration_minutes.

Among 74,974 complete positive-weight groups,3,819 have elapsed journey time greater than the sum of observed leg durations;3,803 are transit.2,994 gaps exceed 5 minutes;28 exceed 60 minutes. No negative elapsed-minus-sum gaps were found. Elapsed time captures between-leg gaps but does not recover synthetic missing endpoints.7,395 of 13,190 broad-transit journeys contain synthetic missing time. Complete-case deletion would strongly select the transit sample.

Recommended time labels: observed journey elapsed minutes, with unmeasured access/egress excluded; and observed leg minutes as a sensitivity. Full door-to-door minutes require extra imputation assumptions. Keep missing-time coverage visible by mode. Person-minutes equal journey weight times the chosen observed minutes, without multiplying by party size; these are sampled respondent-person journeys. For daily time per adult divide by unique complete-day weight, retaining zero-trip days.

## Mode-definition cautions

Use supplied mode_type for broad classes rather than reconstructing AppendixD blindly: data and AppendixD differ. Observed code 26 shuttle and 27 paratransit map to type 13 transit;41 Amtrak maps 13;78 ferry,175 Staten Island Ferry,176 NYC Ferry,200 Water Taxi map 12 ferry;79 vehicle ferry maps 7 other. The guide omits or classifies some differently.15,808 rows have mode_priority 995 but type 1 walk, and 104 have 995 but type 2 bike, consistent with recoded component modes.

Type 8 car includes household and other motorcycles/mopeds, so do not call it private automobile only. Type 2 bike and type 4 scooter categories also need their codebook labels, not assumptions. For subway involvement use detailed NYC subway code 30. A journey can also involve bus; involvement shares overlap. The maximum numerical detailed code is not a valid bus/subway ranking. A mutually exclusive detailed main-mode split needs a disclosed analyst rule.

## Implementation guardrails (analyst recommendations)

1. Assert unique trip_id; group by linked_trip_id or person_id+linked_trip_id, keeping all legs.
2. Select the unique trip_id==linked_trip_id row as original-trip anchor for weight and eligibility; this agrees with first nonsynthetic leg in every group; sensitivity-test 40 inconsistent groups.
3. Retain valid broad mode values only when computing max; keep all-missing groups as unknown rather than silently shrinking the denominator.
4. Join day by unique day_id and person by unique person_id with many-to-one validation. Never sum day/person weights in the trip-joined file. Vehicle join is one-to-many and needs prior aggregation.
5. Compute mode shares with one chosen trip weight per linked journey. For geography filters use first-leg origin and last-leg destination, documenting treatment of missing endpoint geography.
6. Report elapsed/summed observed time, missing access/egress coverage, and optional outlier-flag sensitivity. These are descriptive weighted survey estimates, not street throughput or causal lane-conversion effects.

## Final anchor/day reconciliation

All 53 cross-day linked groups have nonsynthetic legs on one day; only synthetic endpoint rows cross the day boundary. The original anchor agrees with the day-table completion flag in all 80,081 groups. Original-anchor weights equal first-nonsynthetic weights in every group. The complete positive-day denominator contains 18,970 days from 3,512 respondents, matching the official report overview; complete-but-zero-weight records should not add respondents to this analytic universe. The sum of supplied complete-day citywide weights is 6,423,515.430787874.

## Official headline reconciliation attempt

The [official 2024 report](https://www.nyc.gov/html/dot/downloads/pdf/2024-cms-report.pdf), printed p 9, reports Walk 37.6%, Transit 20.7%, Bike/Micromobility 2.9%, Car 38.5%, Other 0.2%, for trips beginning AND ending in NYC. Web reference: turn1287458view0, lines 104–113. The report does not publish an exact linked-journey recoding or flag-filter recipe on that page. Its overview p 6 has 3,512 participants,18,970 days,109,465 trips. Those counts reconcile to positive-weight participants/days and positive-weight STAGE rows, respectively.

Transparent reconstruction: collapse global linked_trip_id; select the unique original anchor's citywide weight; require anchor complete day and positive weight; main mode=max valid supplied mode_type; first-leg origin and last-leg destination in_region=1; exclude all-missing modes from this particular known-mode denominator. Mapping: Walk 1; Bike/Micro 2,4; Car 5,6,8,9; Transit 10,11,12,13; Other 7,14. Results on 65,132 journeys:

| Mode | Independent reconstruction | DOT headline |
|---|---:|---:|
| Walk |40.9570%|37.6%|
| Transit |19.2838%|20.7%|
| Bike/Micro |2.8079%|2.9%|
| Car |36.4020%|38.5%|
| Other |0.5492%|0.2%|

Including unknown as its own category instead yields Walk 40.3600%, Transit 19.0028%, Bike/Micro 2.7670%, Car 35.8714%, Other 0.5412%, Unknown 1.4576% on 66,102 journeys. Using CMS-zone rather than in_region endpoint filters, zonal weights, stage rows, anchor-only modes, and complete-trip questionnaire filters did not reproduce the headline. Requiring anchor trip_survey_complete=1 barely changes the known-mode results (Walk 40.9716%, Transit 19.2662%, Bike/Micro 2.8090%, Car 36.4038%, Other 0.5494%). Removing speed/distance/duration flags individually also did not reproduce it; removing all num_flags excludes many synthetic transit records and is clearly unsuitable.

Exploratory duration/distance cutoffs can move numbers closer but are not source-prescribed and still do not reproduce all headline values. They must not be selected to force agreement. Preserve the independent estimator, document the unresolved discrepancy, and avoid claiming exact DOT replication. The stage/linked choice alone is material: complete positive raw stages with both endpoints in-region and known mode give Walk 42.8625%, Transit 30.1924%, Bike/Micro 1.9987%, Car 24.5261%, Other 0.4202%.

Machine-readable variant results are in audit/report-reconciliation-variants.json and audit/report-reconciliation-filter-variants.json. These record exploratory checks, not endorsed alternative estimators.
