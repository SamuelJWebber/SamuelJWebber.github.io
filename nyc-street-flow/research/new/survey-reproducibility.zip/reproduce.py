#!/usr/bin/env python3
"""Reproduce descriptive NYC CMS 2024 linked-journey analysis. Python3, pandas, numpy.
Run: python reproduce.py [--refresh]. Downloads public CSVs if absent.
No causal interpretation or official-replication claim. All outputs beside this file.
"""
import argparse, hashlib, json, time, urllib.request
from pathlib import Path
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parent
CHECKED="2026-11-05"
SOURCES={
 "trips.csv":"https://data.cityofnewyork.us/api/views/wgnh-qwsg/rows.csv?accessType=DOWNLOAD",
 "persons.csv":"https://data.cityofnewyork.us/api/views/i2im-iqtt/rows.csv?accessType=DOWNLOAD",
 "households.csv":"https://data.cityofnewyork.us/api/views/5mb3-padx/rows.csv?accessType=DOWNLOAD",
 "audit/cms2024_day_full.csv":"https://data.cityofnewyork.us/api/views/naav-ygga/rows.csv?accessType=DOWNLOAD",
 "guide.pdf":"https://www.nyc.gov/html/dot/downloads/pdf/2024-cms-user-guide.pdf",
 "audit/cms2024_report.pdf":"https://www.nyc.gov/html/dot/downloads/pdf/2024-cms-report.pdf",
 "audit/cms2024_collections.xlsx":"https://data.cityofnewyork.us/api/views/wgnh-qwsg/files/c2e15726-bbd7-4057-ade3-cb3712a2ee17?download=true",
}
LABELS={1:"Walk / wheelchair",2:"Bicycle / e-bike",4:"Shared scooter",5:"Taxi",6:"App ride-hail",7:"Other",8:"Car (survey group)",9:"Car share",10:"School bus",11:"Shuttle / vanpool",12:"Ferry",13:"Transit",14:"Long-distance passenger",995:"Unknown main mode"}
ZONES={1:"Northern Bronx",2:"Southern Bronx",3:"Inner Brooklyn",4:"Outer Brooklyn",5:"Inner Queens",6:"Middle Queens",7:"Outer Queens",8:"Manhattan Core",9:"Upper Manhattan",10:"Staten Island",11:"JFK",12:"LGA",13:"Outside study region"}
PURPOSES={1:"Home",2:"Work",3:"Work related",4:"School",5:"School related",6:"Escort",7:"Shopping",8:"Meal",9:"Social/recreation",10:"Errand",11:"Change mode",12:"Overnight",13:"Other"}

def download(refresh=False):
 for name,url in SOURCES.items():
  p=ROOT/name
  if p.exists() and not refresh:continue
  p.parent.mkdir(parents=True,exist_ok=True)
  for attempt in range(3):
   try:
    body=urllib.request.urlopen(url,timeout=120).read();p.write_bytes(body);break
   except Exception:
    if attempt==2:raise
    time.sleep(2*(attempt+1))

def number(x):
 return None if pd.isna(x) or not np.isfinite(x) else float(x)

def weighted_median(values,weights):
 order=np.argsort(np.asarray(values),kind="stable")
 v=np.asarray(values)[order];w=np.asarray(weights)[order]
 return number(v[np.searchsorted(np.cumsum(w),w.sum()/2,side="left")]) if len(v) else None

def mean_col(d,c):
 ok=np.isfinite(d[c]) & (d.weight>0)
 return number(np.average(d.loc[ok,c],weights=d.loc[ok,"weight"])) if ok.any() else None

def mode_summary(d):
 totalw=d.weight.sum();obstotal=(d.weight*d.observed_elapsed_minutes).sum()
 summedtotal=(d.weight*d.known_leg_minutes).sum()
 complete=d[d.complete_duration]
 completetotal=(complete.weight*complete.observed_elapsed_minutes).sum()
 bounded=d[d.observed_elapsed_minutes.between(0,240,inclusive="right")]
 boundedtotal=(bounded.weight*bounded.observed_elapsed_minutes).sum()
 rows=[]
 for code,x in d.groupby("mode_code",sort=True):
  full=x[x.complete_duration];bounded_x=x[x.observed_elapsed_minutes.between(0,240,inclusive="right")]
  unflag=x[x.duration_flag==0]
  w=x.weight.sum();om=(x.weight*x.observed_elapsed_minutes).sum();km=(x.weight*x.known_leg_minutes).sum()
  rows.append({
   "mode_code":int(code),"mode":LABELS.get(int(code),"Unknown"),"sample_journeys":len(x),"sample_people":x.person_id.nunique(),
   "weighted_daily_journeys":number(w),"trip_share_pct":number(100*w/totalw),
   "observed_mean_minutes":mean_col(x,"observed_elapsed_minutes"),"observed_median_minutes":weighted_median(x.observed_elapsed_minutes,x.weight),
   "weighted_observed_person_minutes":number(om),"share_observed_person_minutes_pct":number(100*om/obstotal),
   "mean_sum_known_leg_minutes":mean_col(x,"known_leg_minutes"),"share_sum_known_leg_minutes_pct":number(100*km/summedtotal),
   "synthetic_missing_time_journeys":int(x.synthetic_missing_time.sum()),"weighted_missing_time_journeys":number(x.loc[x.synthetic_missing_time,"weight"].sum()),
   "missing_time_weight_share_pct":number(100*x.loc[x.synthetic_missing_time,"weight"].sum()/w),
   "complete_leg_duration_journeys":len(full),"complete_leg_duration_weight_share_pct":number(100*full.weight.sum()/w),
   "complete_leg_duration_mean_minutes":mean_col(full,"observed_elapsed_minutes"),"complete_leg_duration_median_minutes":weighted_median(full.observed_elapsed_minutes,full.weight),
   "share_complete_case_person_minutes_pct":number(100*(full.weight*full.observed_elapsed_minutes).sum()/completetotal),
   "observed_0_to_240min_journeys":len(bounded_x),"observed_0_to_240min_weight_share_pct":number(100*bounded_x.weight.sum()/w),
   "observed_0_to_240min_mean_minutes":mean_col(bounded_x,"observed_elapsed_minutes"),"observed_0_to_240min_median_minutes":weighted_median(bounded_x.observed_elapsed_minutes,bounded_x.weight),
   "share_observed_0_to_240min_person_minutes_pct":number(100*(bounded_x.weight*bounded_x.observed_elapsed_minutes).sum()/boundedtotal),
   "duration_flag_clear_mean_minutes":mean_col(unflag,"observed_elapsed_minutes"),"duration_flag_clear_weight_share_pct":number(100*unflag.weight.sum()/w),
   "stated_subway_journeys":int(x.stated_subway.sum()),"stated_subway_weighted_journeys":number(x.loc[x.stated_subway,"weight"].sum()),
  })
 return rows

def snapshot(d):
 return {"sample_journeys":len(d),"sample_people":int(d.person_id.nunique()),"weighted_daily_journeys":number(d.weight.sum()),"mode_summary":mode_summary(d)}

def standardize(d,pair):
 # Both actual route distance and actual origin/destination purposes affect mode choice;
 # this is a descriptive overlap check, not a counterfactual or causal adjustment.
 base=d[d.mode_code.isin(pair)&d.complete_duration&d.complete_distance&d.observed_elapsed_minutes.between(0,240,inclusive="right")&(d.duration_flag==0)&(d.distance_flag==0)&d.o_zone.between(1,12)].copy()
 base["distance_bin"]=pd.cut(base.distance_miles,[0,.5,1,2,3,5,10,20,np.inf],right=False).astype(str)
 # For homebound trips, use the activity being left; otherwise destination activity.
 base["activity_purpose"]=np.where(base.d_purpose==1,base.o_purpose,base.d_purpose)
 base=base[base.activity_purpose.between(1,13)]
 keys=["distance_bin","activity_purpose","o_zone"]
 stats=base.groupby(keys+["mode_code"],observed=True).agg(n=("weight","size"),people=("person_id","nunique"),w=("weight","sum"),wm=("weighted_minutes","sum"))
 nwide=stats.n.unstack("mode_code",fill_value=0)
 if any(k not in nwide.columns for k in pair):return {"modes":list(pair),"status":"No overlap"}
 pwide=stats.people.unstack("mode_code",fill_value=0)
 common=nwide.index[(nwide[pair[0]]>=5)&(nwide[pair[1]]>=5)&(pwide[pair[0]]>=3)&(pwide[pair[1]]>=3)]
 details=[]
 for key in common:
  a=stats.loc[tuple(key)+(pair[0],)];b=stats.loc[tuple(key)+(pair[1],)]
  details.append({"cell":list(key),"target_weight":number(a.w+b.w),"a_mean":number(a.wm/a.w),"b_mean":number(b.wm/b.w),"a_n":int(a.n),"b_n":int(b.n),"a_people":int(a.people),"b_people":int(b.people),"a_weight":number(a.w),"b_weight":number(b.w)})
 total=sum(x["target_weight"] for x in details)
 result={"modes":[LABELS[c] for c in pair],"method":"Exact shared cells of actual distance bins, activity purpose and origin CMS zone; at least 5 sampled journeys and 3 distinct diarists per mode per cell; standardize to pooled weighted distribution over those cells. Complete measured legs, positive elapsed <=240 minutes, no DOT duration/distance flag.","shared_cells":len(details),"eligible_sample_journeys":len(base),"eligible_weight":number(base.weight.sum()),"comparison_is_causal":False,"cells":details}
 for code,prefix in zip(pair,["a","b"]):
  x=base[base.mode_code==code];matched=sum(z[prefix+"_weight"] for z in details)
  result[LABELS[code]]={"eligible_sample":len(x),"eligible_people":int(x.person_id.nunique()),"matched_sample":sum(z[prefix+"_n"] for z in details),"eligible_observed_mean_minutes":mean_col(x,"observed_elapsed_minutes"),"matched_weight_coverage_pct":number(100*matched/x.weight.sum()) if len(x) else None,"standardized_mean_minutes":number(sum(z["target_weight"]*z[prefix+"_mean"] for z in details)/total) if total else None}
 return result

def main():
 args=argparse.ArgumentParser();args.add_argument("--refresh",action="store_true");opt=args.parse_args();download(opt.refresh)
 t=pd.read_csv(ROOT/"trips.csv",low_memory=False);p=pd.read_csv(ROOT/"persons.csv",low_memory=False);h=pd.read_csv(ROOT/"households.csv",low_memory=False);day=pd.read_csv(ROOT/"audit/cms2024_day_full.csv",low_memory=False)
 assert not t.trip_id.duplicated().any();assert not p.duplicated(["hh_id","person_id"]).any();assert not h.hh_id.duplicated().any();assert not day.day_id.duplicated().any()
 for prefix,seconds in [("depart","depart_seconds"),("arrive","arrive_second")]:
  t[prefix+"_ts"]=pd.to_datetime(t[prefix+"_date"],format="%m/%d/%Y",errors="coerce")+pd.to_timedelta(t[prefix+"_hour"],unit="h")+pd.to_timedelta(t[prefix+"_minute"],unit="m")+pd.to_timedelta(t[seconds],unit="s")
 t=t.sort_values(["person_id","linked_trip_id","leg_num"])
 t["valid_mode"]=t.mode_type.where(t.mode_type.between(1,14))
 t["synthetic"]=t.transit_quality_flag.isin([1,2])
 t["stated_subway"]=(t[["mode_priority"]+["mode_"+str(i) for i in range(1,10)]]==30).any(axis=1)
 g=t.groupby(["person_id","linked_trip_id"],sort=False)
 a=g.agg(hh_id=("hh_id","first"),legs=("trip_id","size"),declared_legs=("n_legs","first"),unique_leg_numbers=("leg_num","nunique"),all_days_complete=("day_is_complete","min"),weight_nunique=("trip_weight_citywide","nunique"),weight=("trip_weight_citywide","first"),min_weight=("trip_weight_citywide","min"),max_weight=("trip_weight_citywide","max"),mode_code=("valid_mode","max"),duration_count=("duration_seconds","count"),known_seconds=("duration_seconds","sum"),depart=("depart_ts","first"),arrive=("arrive_ts","last"),synthetic_missing_time=("synthetic","max"),synthetic_legs=("synthetic","sum"),distance_count=("distance_miles","count"),distance_miles=("distance_miles","sum"),duration_flag=("flag_duration","max"),distance_flag=("flag_distance","max"),speed_flag=("flag_speed","max"),o_zone=("o_cms_zone","first"),d_zone=("d_cms_zone","last"),o_purpose=("o_purpose_category","first"),d_purpose=("d_purpose_category","last"),stated_subway=("stated_subway","max"),n_days=("day_id","nunique"))
 assert (a.legs==a.declared_legs).all();assert (a.unique_leg_numbers==a.legs).all()
 anchor=t[t.trip_id==t.linked_trip_id][["person_id","linked_trip_id","day_id","trip_weight_citywide","day_is_complete"]].rename(columns={"trip_weight_citywide":"anchor_weight","day_is_complete":"anchor_trip_day_complete"})
 assert len(anchor)==len(a);assert not anchor.duplicated(["person_id","linked_trip_id"]).any()
 a=a.reset_index().merge(anchor,on=["person_id","linked_trip_id"],validate="one_to_one")
 a=a.merge(day[["day_id","is_complete","day_weight_citywide"]].rename(columns={"is_complete":"anchor_day_complete"}),on="day_id",how="left",validate="many_to_one")
 a=a.merge(h[["hh_id","home_cms_zone","diary_platform"]],on="hh_id",how="left",validate="many_to_one")
 a=a.merge(p[["hh_id","person_id","age","is_participant"]],on=["hh_id","person_id"],how="left",validate="many_to_one")
 a["mode_code"]=a.mode_code.fillna(995).astype(int)
 a["observed_elapsed_minutes"]=(a.arrive-a.depart).dt.total_seconds()/60
 a["known_leg_minutes"]=a.known_seconds/60
 a["between_leg_minutes"]=a.observed_elapsed_minutes-a.known_leg_minutes
 a["complete_duration"]=(a.duration_count==a.legs)&np.isfinite(a.observed_elapsed_minutes)&(a.observed_elapsed_minutes>0)
 a["complete_distance"]=(a.distance_count==a.legs)&(a.distance_miles>0)
 a["home_work_commute"]=((a.o_purpose==1)&(a.d_purpose==2))|((a.o_purpose==2)&(a.d_purpose==1))
 a["within_nyc"]=a.o_zone.between(1,12)&a.d_zone.between(1,12)
 a["manhattan_origin"]=a.o_zone.isin([8,9])
 # All sampled households live in the ten residential NYC survey zones. Person age
 # is categorical: 4..11 are 18+. Do not apply resident restriction to trip endpoints.
 adult=a.age.between(4,11)&a.home_cms_zone.between(1,10)&(a.is_participant==1)
 complete=(a.anchor_day_complete==1)&(a.anchor_trip_day_complete==1)
 same=(a.weight_nunique==1)
 positive=np.isfinite(a.weight)&(a.weight>0)
 b=a[adult&complete&same&positive].copy()
 assert np.isfinite(b.observed_elapsed_minutes).all() and (b.observed_elapsed_minutes>0).all()
 b["weighted_minutes"]=b.weight*b.observed_elapsed_minutes
 base_summary=mode_summary(b)
 eligible_day=day[(day.is_complete==1)&np.isfinite(day.day_weight_citywide)&(day.day_weight_citywide>0)]
 dayden=eligible_day.day_weight_citywide.sum()
 allamb=a[adult&complete&(~same)].copy()
 filters={"raw_trip_leg_rows":len(t),"positive_weight_trip_leg_rows":int((t.trip_weight_citywide>0).sum()),"raw_person_rows":len(p),"raw_households":len(h),"raw_day_rows":len(day),"missing_household_join_journeys":int(a.home_cms_zone.isna().sum()),"missing_household_join_positive_weight_journeys":int((a.home_cms_zone.isna()&(a.max_weight>0)).sum()),"sequential_attrition":[{"stage":"All reconstructed journeys","n":len(a)},{"stage":"Original-anchor day complete in both Trip and Day tables","n":int(complete.sum())},{"stage":"Adult participant with NYC household record","n":int((complete&adult).sum())},{"stage":"Identical positive finite citywide weight on all legs","n":len(b)}],"raw_linked_journeys":len(a),"cross_day_linked_journeys":int((a.n_days>1).sum()),"anchor_day_not_in_day_table":int(a.anchor_day_complete.isna().sum()),"incomplete_anchor_day_journeys":int((~complete).sum()),"nonadult_or_nonparticipant_or_nonresident_journeys":int((~adult).sum()),"complete_adult_consistent_weight_nonpositive_journeys":int((adult&complete&same&(~positive)).sum()),"complete_adult_inconsistent_weight_journeys":len(allamb),"all_inconsistent_weight_journeys":int((~same).sum()),"baseline_journeys":len(b),"baseline_people":int(b.person_id.nunique()),"baseline_weight":number(b.weight.sum()),"excluded_inconsistent_max_weight":number(allamb.max_weight.sum()),"baseline_weight_coverage_vs_max_ambiguous_weight_pct":number(100*b.weight.sum()/(b.weight.sum()+allamb.max_weight.sum())),"baseline_weighted_missing_time_pct":number(100*b.loc[b.synthetic_missing_time,"weight"].sum()/b.weight.sum()),"raw_missing_duration_rows":int(t.duration_seconds.isna().sum()),"missing_duration_rows_all_synthetic":bool(t.loc[t.duration_seconds.isna(),"synthetic"].all()),"positive_complete_day_rows_trip_survey_incomplete":int(((t.day_is_complete==1)&(t.trip_weight_citywide>0)&(t.trip_survey_complete==0)).sum()),"baseline_between_leg_positive_journeys":int((b.between_leg_minutes>1e-6).sum()),"baseline_between_leg_over_5min_journeys":int((b.between_leg_minutes>5).sum())}
 subsets={"all_resident_journeys":snapshot(b),"both_endpoints_nyc":snapshot(b[b.within_nyc]),"manhattan_origin":snapshot(b[b.manhattan_origin]),"home_work_commute":snapshot(b[b.home_work_commute]),"other_purposes":snapshot(b[~b.home_work_commute])}
 weightsensitivity={}
 for label,col in [("original_trip_anchor_weight","anchor_weight"),("first_leg_weight","weight"),("maximum_leg_weight","max_weight")]:
  s=a[adult&complete&np.isfinite(a[col])&(a[col]>0)].copy();s["weight"]=s[col];weightsensitivity[label]=snapshot(s)
 scenarios=[]
 for extra in [0,5,10,15]:
  scen=b.copy();affected=(scen.mode_code==13)&scen.synthetic_missing_time
  scen["observed_elapsed_minutes"]+=extra*affected
  scenarios.append({"extra_minutes_per_affected_transit_journey":extra,"affected_journeys":int(affected.sum()),"affected_weighted_journeys":number(scen.loc[affected,"weight"].sum()),"additional_weighted_person_minutes":number(extra*scen.loc[affected,"weight"].sum()),"mode_summary":mode_summary(scen)})
 # Subway indicator is overlapping; never add it to mutually exclusive mode shares.
 subway={"definition":"At least one public stage states code30 Subway in mode_1..mode_9 or mode_priority; overlaps main Transit. PATH/SIR/rail not counted as subway in this indicator.","sample_journeys":int(b.stated_subway.sum()),"weighted_daily_journeys":number(b.loc[b.stated_subway,"weight"].sum()),"share_of_all_journeys_pct":number(100*b.loc[b.stated_subway,"weight"].sum()/b.weight.sum()),"share_of_transit_journeys_pct":number(100*b.loc[b.stated_subway&(b.mode_code==13),"weight"].sum()/b.loc[b.mode_code==13,"weight"].sum())}
 result={"title":"NYC CMS 2024: weighted all-purpose linked journeys and observed travel time","analysis_version":"1.2","checked_on":CHECKED,"universe":"Personal travel by NYC resident adults18+ in address-based sampled households, including trips outside NYC. Excludes nonresidents/visitors, children, commercial/delivery travel, group quarters outside sampling frame; field-period estimates, not full-year or all street users.","official_estimate":False,"data_dates":{"earliest_departure":str(t.depart_ts.min().date()),"latest_departure":str(t.depart_ts.max().date()),"baseline_earliest_departure":str(b.depart.min().date()),"baseline_latest_departure":str(b.depart.max().date())},"main_mode_rule":"Within each linked ID, highest valid supplied mode_type1..14 across stages. Guide hierarchy applies to individual rows; extending it to linked journeys is an analyst rule. Unknown995 retained in denominator. Do not multiply weights by party size.","duration_rule":"Last-arrival minus first-departure timestamp; includes observed between-stage intervals. Synthetic access/egress timestamps copy neighboring stage boundaries, so their unmeasured time is absent. Survey timestamps include RSG departure-time imputation. These are recorded/reconstructed journey minutes, not fully measured door-to-door time. Sum-of-known-leg and complete-leg cases are separate sensitivity universes.","weight_rule":"One trip_weight_citywide per reconstructed linked journey; baseline requires identical positive finite weights on every stage and complete original-anchor day.39 complete-day inconsistent-weight journeys omitted; original anchor, first-stage, maximum-stage alternatives provided.","sources":[{"local":name,"url":url,"sha256":hashlib.sha256((ROOT/name).read_bytes()).hexdigest()} for name,url in SOURCES.items()],"guide_sections":{"3.3":"Online/call-center home-based trip weights adjusted2x; other rates1x; use supplied weights.","4.6":"Survey universe, citywide versus zonal weights, limitations.","4.7":"Join keys, table weights, zero-trip days, transit unlinking and synthetic missing duration, main-mode hierarchy."},"filters":filters,"weighted_day_denominator":{"sample_complete_positive_days":len(eligible_day),"sample_zero_trip_days":int((eligible_day.num_trips==0).sum()),"sample_people":int(eligible_day.person_id.nunique()),"weighted_average_day_adults":number(dayden),"weighted_zero_trip_day_share_pct":number(100*eligible_day.loc[eligible_day.num_trips==0,"day_weight_citywide"].sum()/dayden),"linked_journeys_per_resident_per_day":number(b.weight.sum()/dayden)},"subsets":subsets,"subway_indicator":subway,"weight_sensitivity":weightsensitivity,"missing_transit_time_scenarios":{"warning":"Illustrative missing-access/egress allowance per affected linked transit journey, not data-imputed actual duration; zero allowance is observed elapsed, not zero true missing time.","scenarios":scenarios},"matched_descriptive_checks":[standardize(b,(2,8)),standardize(b,(2,13)),standardize(b,(8,13))],"zone_labels":ZONES,"purpose_labels":PURPOSES,"cautions":["Trip-share denominator includes journeys whose true full duration is not observed; observed-minute shares are shares of captured minutes only, not shares of total travel time.","Complete-leg estimates select a different transit sample and must not be treated as a correction for missing time.","Durations include very large outliers. Uncapped estimates,0<duration<=240minute estimates and DOT-duration-flag-clear estimates are all supplied.","Trip distances are observed path distance, not straight-line or a common origin-destination distance. Matching remains descriptive and can select little overlap.","No replicate weights/design-based confidence intervals are produced; repeated journeys by each diarist are correlated.","Shared streets person-throughput and lane-conversion causal effects require corridor exposure, controls and before/after counts; these survey results establish resident travel mix and time context only.","Manhattan-origin estimates use citywide weights for a domain estimate of resident trips; they do not cover visitors or suburban inbound commuters.","DOT report headline uses start-and-end-within-NYC geography and broader mode groups; this analyst reconstruction is not represented as an exact replication."]}
 # This diagnostic is computed afresh; only published DOT figures below are
 # transcribed constants, bound to the archived report's SHA-256 and check date.
 endpoint_geo=t.groupby(["person_id","linked_trip_id"],sort=False).agg(diag_o_in_region=("o_in_region","first"),diag_d_in_region=("d_in_region","last")).reset_index()
 diagnostic=a.merge(endpoint_geo,on=["person_id","linked_trip_id"],validate="one_to_one")
 report_groups={1:"Walk",2:"Bike/Micromobility",4:"Bike/Micromobility",5:"Car",6:"Car",8:"Car",9:"Car",10:"Transit",11:"Transit",12:"Transit",13:"Transit",7:"Other",14:"Other"}
 diagnostic=diagnostic[(diagnostic.anchor_day_complete==1)&(diagnostic.anchor_trip_day_complete==1)&np.isfinite(diagnostic.anchor_weight)&(diagnostic.anchor_weight>0)&(diagnostic.diag_o_in_region==1)&(diagnostic.diag_d_in_region==1)&diagnostic.mode_code.isin(report_groups)].copy()
 diagnostic["report_group"]=diagnostic.mode_code.map(report_groups)
 report_weights=diagnostic.groupby("report_group").anchor_weight.sum()
 diagnostic_shares={name:number(100*report_weights.get(name,0)/report_weights.sum()) for name in ["Walk","Transit","Bike/Micromobility","Car","Other"]}
 result["raw_input_hashes"]={source["local"]:source["sha256"] for source in result["sources"] if source["local"].endswith(".csv")}
 result["official_headline_reconciliation"]={
  "status":"Not exactly reproduced; independent estimator, not official DOT headline.",
  "url":"https://www.nyc.gov/html/dot/downloads/pdf/2024-cms-report.pdf#page=9",
  "official_page":9,
  "official_universe":"Trips starting and ending in NYC",
  "official_values_transcribed_on":CHECKED,
  "official_pdf_sha256":hashlib.sha256((ROOT/"audit/cms2024_report.pdf").read_bytes()).hexdigest(),
  "official_share_pct":{"Walk":37.6,"Transit":20.7,"Bike/Micromobility":2.9,"Car":38.5,"Other":0.2},
  "independent_reconstruction_computation":"Recomputed from the current raw inputs on every run; not a frozen audit result.",
  "independent_known_mode_anchor_reconstruction_share_pct":diagnostic_shares,
  "independent_reconstruction_sample":len(diagnostic),
  "independent_reconstruction_weight":number(diagnostic.anchor_weight.sum()),
  "diagnostic_raw_input_hashes":result["raw_input_hashes"],
  "mode_group_mapping":report_groups,
  "reconstruction_recipe":"Linked person+trip IDs; original-trip anchor citywide weights; complete anchor day in Trip and Day tables; first origin and last destination in_region=1; known-mode denominator; broader grouped modes. This is a separate diagnostic from the conservative baseline and includes consistent or inconsistent positive anchor weights.",
  "remaining_gap":"Public report provides no exact recoding/filter recipe. Historical exploratory geography, weighting, completion and outlier variants did not resolve the discrepancy; those variant files are not recomputed by this script. No tuning to match headline."
 }
 (ROOT/"input-manifest.json").write_text(json.dumps({"checked_on":CHECKED,"sources":result["sources"]},indent=2))
 pd.DataFrame(base_summary).to_csv(ROOT/"mode-summary.csv",index=False)
 pd.DataFrame([dict(subset=key,**row) for key,value in subsets.items() for row in value["mode_summary"]]).to_csv(ROOT/"subset-mode-summary.csv",index=False)
 # De-identified public IDs retained solely for reproducibility/integrity, no precise locations.
 b.drop(columns=["weighted_minutes"]).to_csv(ROOT/"linked-journeys.csv",index=False)
 (ROOT/"survey-analysis.json").write_text(json.dumps(result,indent=2,allow_nan=False))
 print(json.dumps({"filters":filters,"day_denominator":result["weighted_day_denominator"],"headline":[{k:r[k] for k in ["mode","sample_journeys","trip_share_pct","observed_mean_minutes","observed_0_to_240min_mean_minutes","missing_time_weight_share_pct"]} for r in base_summary]},indent=2))

if __name__=="__main__":main()
