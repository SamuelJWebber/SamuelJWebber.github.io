#!/usr/bin/env python3
"""Reproduce MTA customer journey metrics supplement with Python standard library.

Default: use cached raw.json/metadata.json when present; --refresh re-downloads.
All selected lines use the same fully observed calendar months across all years.
No Site files are read or written.
"""
import argparse, collections, csv, datetime as dt, hashlib, json, math, pathlib, urllib.request

DATASET='r7qk-6tcy'
DATA_URL='https://data.ny.gov/resource/r7qk-6tcy.json?$limit=50000&$order=month,line,period'
META_URL='https://data.ny.gov/api/views/r7qk-6tcy.json'
OVERVIEW_URL='https://data.ny.gov/api/views/r7qk-6tcy/files/6df4aa7f-70eb-4e44-b1ce-bc4a1ad3379a?download=true&filename=MTA_SubwayCustomerJourneyFocusedMetrics_Overview.pdf'
DICTIONARY_URL='https://data.ny.gov/api/views/r7qk-6tcy/files/b916d86e-edb6-4c4c-90a2-d392ce54236b?download=true&filename=MTA_SubwayCustomerJourneyFocusedMetrics_DataDictionary.pdf'
YEARS=[2019,2021,2022,2024,2026]
LINES=['2','3','4','5','A','B','C','D','F','G','JZ','L','N','Q','R']
PERIODS=['peak','offpeak']
NUMERIC=['num_passengers','additional_platform_time','additional_train_time','total_apt','total_att','over_five_mins','over_five_mins_perc','customer_journey_time']

def download(url,path):
    with urllib.request.urlopen(url,timeout=90) as r: b=r.read()
    path.write_bytes(b)
    return b

def pct_delta(value,base):
    return (value/base-1)*100 if base else None

def dump_csv(path,rows):
    with path.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def round_json(obj):
    if isinstance(obj,float): return round(obj,6) if math.isfinite(obj) else None
    if isinstance(obj,list): return [round_json(x) for x in obj]
    if isinstance(obj,dict): return {k:round_json(v) for k,v in obj.items()}
    return obj

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--refresh',action='store_true');ap.add_argument('--out',default=str(pathlib.Path(__file__).parent));a=ap.parse_args()
    p=pathlib.Path(a.out);p.mkdir(parents=True,exist_ok=True)
    for file,url in [('raw.json',DATA_URL),('metadata.json',META_URL)]:
        if a.refresh or not (p/file).exists():download(url,p/file)
    raw=json.loads((p/'raw.json').read_text());meta=json.loads((p/'metadata.json').read_text())
    assert len(raw)<50000,'API limit hit: paginate before analysis'
    rows=[]
    for x in raw:
        if int(x['month'][:4]) not in YEARS or x['line'] not in LINES:continue
        y=dict(year=int(x['month'][:4]),month=int(x['month'][5:7]),line=x['line'],period=x['period'])
        for k in NUMERIC:y[k]=float(x[k])
        y['net_extra_passenger_minutes']=y['total_apt']+y['total_att']
        y['net_extra_minutes_per_leg']=y['additional_platform_time']+y['additional_train_time']
        rows.append(y)
    keyed={(x['year'],x['month'],x['line'],x['period']):x for x in rows}
    assert len(keyed)==len(rows),'Duplicate month/line/period keys'
    assert all(x['num_passengers']>0 for x in rows),'Nonpositive weight'
    shared_months=[m for m in range(1,13) if all((y,m,l,t) in keyed for y in YEARS for l in LINES for t in PERIODS)]
    assert shared_months,'No fully comparable months'
    assert 6 in shared_months,'June not complete'
    latest=max(x['month'] for x in rows if x['year']==max(YEARS))
    residuals={}
    for mean,total in [('additional_platform_time','total_apt'),('additional_train_time','total_att')]:
        err=[abs(x[mean]*x['num_passengers']-x[total]) for x in rows]
        residuals[total+'_max_abs_minutes']=max(err)
        assert max(err)<1e-4,'Published total does not equal mean times modeled legs'
    windows={'shared_months':shared_months,'june':[6]}
    summary=[]
    for window,months in windows.items():
        for line in ['ALL_SELECTED']+LINES:
            ls=LINES if line=='ALL_SELECTED' else [line]
            for period in ['all','peak','offpeak']:
                ts=PERIODS if period=='all' else [period]
                cells=[(m,l,t) for m in months for l in ls for t in ts]
                base=[keyed[(2019,*c)] for c in cells]
                base_weight=sum(x['num_passengers'] for x in base)
                base_apt=sum(x['total_apt'] for x in base)/base_weight
                base_att=sum(x['total_att'] for x in base)/base_weight
                base_net=base_apt+base_att
                base_total=sum(x['net_extra_passenger_minutes'] for x in base)
                for year in YEARS:
                    z=[keyed[(year,*c)] for c in cells]
                    n=sum(x['num_passengers'] for x in z)
                    apt=sum(x['total_apt'] for x in z);att=sum(x['total_att'] for x in z)
                    fix_apt=sum(b['num_passengers']*c['additional_platform_time'] for b,c in zip(base,z))/base_weight
                    fix_att=sum(b['num_passengers']*c['additional_train_time'] for b,c in zip(base,z))/base_weight
                    net=(apt+att)/n;fix_net=fix_apt+fix_att
                    summary.append(dict(window=window,line=line,period=period,year=year,months=len(months),matched_cells=len(cells),matched_passenger_share=1.0,represented_unlinked_legs=n,total_extra_platform_passenger_minutes=apt,total_extra_train_passenger_minutes=att,net_extra_passenger_minutes=apt+att,current_mix_platform_minutes_per_leg=apt/n,current_mix_train_minutes_per_leg=att/n,current_mix_net_minutes_per_leg=net,fixed_2019_platform_minutes_per_leg=fix_apt,fixed_2019_train_minutes_per_leg=fix_att,fixed_2019_net_minutes_per_leg=fix_net,fixed_2019_net_delta_minutes=fix_net-base_net,fixed_2019_net_delta_percent=pct_delta(fix_net,base_net),current_mix_net_delta_minutes=net-base_net,net_total_delta_percent=pct_delta(apt+att,base_total),represented_legs_delta_percent=pct_delta(n,base_weight),mix_gap_minutes=net-fix_net,journeys_within_five_minutes_pct=100*(1-sum(x['over_five_mins'] for x in z)/n)))
    coverage=[]
    for year in YEARS:
        present={(x['month'],x['line'],x['period']) for x in rows if x['year']==year}
        expected={(m,l,t) for m in shared_months for l in LINES for t in PERIODS}
        coverage.append(dict(year=year,published_selected_rows=len(present),published_months=sorted(set(m for m,l,t in present)),expected_shared_cells=len(expected),available_shared_cells=len(expected&present),missing_shared_cells=[list(x) for x in sorted(expected-present)]))
    limitations=[
      'These are model-derived time differences from scheduled service for unlinked train legs, not directly observed individual journey durations or door-to-door travel time.',
      'The selection contains whole lines that serve Brooklyn. It does not isolate riders, trips or time spent in Brooklyn, and it is not every Brooklyn-serving line.',
      'A person transferring between selected lines contributes multiple legs. Aggregate minutes are the modeled extra time on those legs; represented legs are not unique people or complete linked journeys.',
      'total_apt and total_att already contain passenger weighting. Do not multiply them by passenger counts again or add this layer to runtime/OD-derived minutes.',
      'Coverage is weekdays 06:00–23:00 only. Peak combines 07:00–10:00 and 16:00–19:00; offpeak is the remaining covered weekday hours. These windows differ from the end-to-end runtime dataset.',
      'Additional times can be negative; retain signed totals. They measure net time relative to the contemporary timetable, not gross delay, total travel time, or a constant 2019 schedule.',
      'Faster or slower scheduled service can change the metric. Fixed 2019 weights hold the line/month/period passenger mix constant but do not hold OD, schedule, train assignment or measurement technology constant.',
      'In September 2024 MTA introduced a revised pipeline, including data-source and schedule fixes; scheduled-hold handling alone increased ATT about two seconds in MTA assessment. Pre/post values are not perfectly methodologically identical.',
      'In November 2023 MTA lengthened fare-card trip matching; prior customer metrics were not revised. Fare-evasion scaling, representative OD models and data-exclusion rules also affect represented volumes.',
      'Monthly totals vary with modeled demand and number of weekdays as well as service. Same calendar months reduce seasonality but do not equalize weekday counts, holidays, disruptions or other confounders.',
      'No causal lane-conversion effect, mode switching, or corridor-specific net benefit can be identified from these comparisons.'
    ]
    payload=dict(metadata=dict(title='Modeled subway extra passenger-time context',dataset_id=DATASET,publisher='MTA New York City Transit',retrieved_on=dt.datetime.now(dt.timezone.utc).isoformat(),data_updated_at=dt.datetime.fromtimestamp(meta['rowsUpdatedAt'],dt.timezone.utc).isoformat(),source_url='https://data.ny.gov/d/'+DATASET,api_url=DATA_URL,overview_url=OVERVIEW_URL,dictionary_url=DICTIONARY_URL,raw_sha256=hashlib.sha256((p/'raw.json').read_bytes()).hexdigest(),raw_rows=len(raw),selected_lines=LINES,years=YEARS,latest_published_selected_month=f'2026-{latest:02}',windows={k:dict(months=v,label=('Jan–Sep' if v==list(range(1,10)) else ', '.join(map(str,v)))) for k,v in windows.items()},unit='Net additional passenger-minutes and additional minutes per modeled unlinked leg',current_mix_method='Sum published total_apt and total_att over disjoint month/line/period rows, divided by summed num_passengers for the average.',fixed_mix_method='Within the same line/month/period cells present in every selected year, weight each year’s APT and ATT means by the corresponding 2019 num_passengers, and divide by total 2019 weights.',baseline=2019,line_selector=['ALL_SELECTED']+LINES,period_selector=['all','peak','offpeak'],limitations=limitations),validation=dict(duplicate_keys=0,full_shared_cell_coverage=True,negative_att_rows=sum(x['additional_train_time']<0 for x in rows),negative_apt_rows=sum(x['additional_platform_time']<0 for x in rows),negative_net_rows=sum(x['net_extra_minutes_per_leg']<0 for x in rows),**residuals),coverage=coverage,comparisons=summary)
    (p/'passenger-time-supplement.json').write_text(json.dumps(round_json(payload),separators=(',',':'),ensure_ascii=False))
    dump_csv(p/'passenger-time-monthly.csv',rows)
    dump_csv(p/'passenger-time-comparisons.csv',summary)
    (p/'passenger-time-methods.txt').write_text('MTA passenger-time supplement\n\n'+payload['metadata']['current_mix_method']+'\n'+payload['metadata']['fixed_mix_method']+'\n\n'+'\n\n'.join(limitations)+'\n\nSource: '+payload['metadata']['source_url']+'\nOverview: '+OVERVIEW_URL+'\nDictionary: '+DICTIONARY_URL+'\n')
    print(json.dumps(dict(coverage=coverage,validation=payload['validation'],all_selected=[x for x in summary if x['line']=='ALL_SELECTED' and x['period']=='all']),indent=2))

if __name__=='__main__':main()
