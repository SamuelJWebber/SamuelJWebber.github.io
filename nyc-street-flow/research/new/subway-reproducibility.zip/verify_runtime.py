import urllib.request,urllib.parse,json,pathlib,math,datetime,hashlib
P=pathlib.Path(__file__).parent
params={'$where':"line='L' AND schedule_day_type='Weekday' AND time_period in ('AM peak','PM peak') AND month in ('2021-06-01T00:00:00','2022-06-01T00:00:00')",'$order':'month,direction,time_period,stop_path_id','$limit':1000}
u='https://data.ny.gov/resource/sp9g-mzjh.json?'+urllib.parse.urlencode(params)
with urllib.request.urlopen(u,timeout=60) as res:b=res.read()
a=json.loads(b);by={y:{} for y in [2021,2022]}
for r in a:by[int(r['month'][:4])][(r['direction'],r['time_period'],r['stop_path_id'])]=r
common=by[2021].keys()&by[2022].keys();n=sum(int(by[2021][k]['actual_trains']) for k in common)
b0=sum(int(by[2021][k]['actual_trains'])*float(by[2021][k]['average_actual_runtime']) for k in common)/n
t0=sum(int(by[2021][k]['actual_trains'])*float(by[2022][k]['average_actual_runtime']) for k in common)/n
d=json.load(open(P/'runtime-analysis.json'));x=next(r for r in d['pairwise_comparisons'] if r['line']=='L' and r['period']=='peak_combined' and r['window']=='june' and r['baseline_year']==2021)
assert abs(x['fixed_baseline_minutes']-b0)<1e-7 and abs(x['fixed_target_minutes']-t0)<1e-7
assert len(common)==x['matched_cells']==6
for r in d['pairwise_comparisons']:
 assert 0<=r['baseline_matched_share']<=1 and 0<=r['target_matched_share']<=1
 if r['matched_cells']==0:assert r['fixed_target_minutes'] is None and r['fixed_change_minutes'] is None
for r in d['balanced_series']:
 if r['year']==2019 and r['fixed_actual_minutes'] is not None:assert r['change_minutes']==0
out={'verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'independent_query_url':u,'query_response_sha256':hashlib.sha256(b).hexdigest(),'query_rows':len(a),'matched_cells':len(common),'baseline_weight_trains':n,'independent_baseline_minutes':b0,'independent_target_minutes':t0,'independent_change_minutes':t0-b0,'matches_runtime_analysis_json':True,'coverage_bounds_and_null_support_checks_passed':True,'zero_baseline_change_check_passed':True}
(P/'runtime-independent-check.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
