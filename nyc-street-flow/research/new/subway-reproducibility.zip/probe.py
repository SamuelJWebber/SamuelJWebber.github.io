import urllib.request,urllib.parse,json,pathlib,concurrent.futures
P=pathlib.Path(__file__).parent
queries={
'runtime_coverage':('sp9g-mzjh',{'$select':'month,schedule_day_type,count(*) as rows,sum(actual_trains) as trains','$group':'month,schedule_day_type','$order':'month,schedule_day_type','$limit':1000}),
'runtime_sample':('sp9g-mzjh',{'$where':"month >= '2026-01-01T00:00:00'",'$limit':10}),
'path_sample':('tdmq-asac',{'$limit':10}),
'stations':('39hk-dx4f',{'$limit':1000}),
'path_count':('tdmq-asac',{'$select':'count(*) as rows,count(distinct stop_path_id) as paths'})}
def get(x):
 n,(d,q)=x;u='https://data.ny.gov/resource/'+d+'.json?'+urllib.parse.urlencode(q)
 with urllib.request.urlopen(u,timeout=60) as r:t=r.read()
 (P/(n+'.json')).write_bytes(t);(P/(n+'-query.txt')).write_text(u);print(n,len(t),t[:500],flush=True)
with concurrent.futures.ThreadPoolExecutor(5) as ex:list(ex.map(get,queries.items()))
