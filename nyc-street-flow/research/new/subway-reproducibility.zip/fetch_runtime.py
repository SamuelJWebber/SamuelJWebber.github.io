import urllib.request,urllib.parse,json,pathlib,concurrent.futures,hashlib,datetime,time
P=pathlib.Path(__file__).parent
where="schedule_day_type='Weekday' AND date_extract_y(month) in (2019,2021,2022,2024,2026)"
qs={
 'runtime_raw':('sp9g-mzjh',{'$where':where,'$order':'month,line,direction,time_period,stop_path_id','$limit':100000}),
 'paths_raw':('tdmq-asac',{'$select':'stop_path_id,stop_order,station_id','$order':'stop_path_id,stop_order','$limit':200000}),
 'runtime_count':('sp9g-mzjh',{'$where':where,'$select':'count(*) as rows'}),
 'runtime_metadata':('sp9g-mzjh',None),
 'paths_metadata':('tdmq-asac',None)}
def get(item):
 n,(id,q)=item;f=P/(n+'.json')
 u=('https://data.ny.gov/resource/'+id+'.json?'+urllib.parse.urlencode(q)) if q else ('https://data.ny.gov/api/views/'+id+'.json')
 for tries in range(3):
  try:
   with urllib.request.urlopen(u,timeout=180) as r:b=r.read()
   d=json.loads(b);f.write_bytes(b)
   m={'retrieved_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'url':u,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'records':len(d) if isinstance(d,list) else None}
   (P/(n+'-manifest.json')).write_text(json.dumps(m,indent=2))
   print(n,m['records'],m['bytes'],flush=True);return
  except Exception as e:
   print(n,'attempt',tries+1,str(e),flush=True)
   if tries==2:raise
   time.sleep(1)
with concurrent.futures.ThreadPoolExecutor(5) as ex:list(ex.map(get,qs.items()))
