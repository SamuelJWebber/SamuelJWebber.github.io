import json,pathlib,collections
P=pathlib.Path(__file__).parent
r=json.load(open(P/'runtime_raw.json'));s=json.load(open(P/'stations.json'));paths=json.load(open(P/'paths_raw.json'))
st={x['gtfs_stop_id']:x for x in s};pb=collections.defaultdict(set)
for p in paths:pb[p['stop_path_id']].add(st.get(p['station_id'],{}).get('borough','unknown'))
print('missing paths',len({x['stop_path_id'] for x in r}-pb.keys()),'unknown stations',sorted({p['station_id'] for p in paths if p['station_id'] not in st})[:100])
print('lines',sorted({x['line'] for x in r}));print('periods',sorted({x['time_period'] for x in r}))
lookup={};dupes=[]
for x in r:
 y=int(x['month'][:4]);m=int(x['month'][5:7]);k=(y,m,x['line'],x['direction'],x['time_period'],x['stop_path_id'])
 if k in lookup:dupes.append(k)
 lookup[k]=x
print('duplicate keys',len(dupes))
for line in ['2','3','4','5','A','B','C','D','F','G','J','L','N','Q','R']:
 ds=[x for x in r if x['line']==line and int(x['month'][5:7])<=9 and x['time_period'] in ['AM peak','PM peak']]
 keys=collections.defaultdict(set)
 for x in ds:keys[int(x['month'][:4])].add((int(x['month'][5:7]),x['direction'],x['time_period'],x['stop_path_id']))
 common=set.intersection(*keys.values())
 vals=[]
 for y in [2019,2021,2022,2024,2026]:
  allrows=[x for x in ds if int(x['month'][:4])==y];ma=[x for x in allrows if (int(x['month'][5:7]),x['direction'],x['time_period'],x['stop_path_id']) in common]
  n=sum(float(x['actual_trains']) for x in allrows);nm=sum(float(x['actual_trains']) for x in ma)
  vals.append(round(nm/n*100,1) if n else None)
 print(line,len(common),vals)
print('TOPL2019AM')
for x in sorted([x for x in r if x['line']=='L' and x['month'].startswith('2019-06') and x['time_period']=='AM peak'],key=lambda x:-float(x['actual_trains']))[:12]:print(x['stop_path_id'],x['origin_station_name'],x['destination_station_name'],x['actual_trains'],pb[x['stop_path_id']])
