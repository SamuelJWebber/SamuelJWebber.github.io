"""Extract NYU Appendix C published counts; never infer missing Citi Bike categories.
Run with the primary Python runtime (pypdf installed). Local PDF cached on first run.
"""
from pathlib import Path
import csv, hashlib, json, re, urllib.request
from collections import defaultdict
from pypdf import PdfReader

P=Path(__file__).resolve().parent
URL='https://c2smart.engineering.nyu.edu/wp-content/uploads/2026/04/25-38-NYC-Delivery-Worker-Data-Collection-and-Research-Report.pdf'
pdf=P/'report.pdf'
if not pdf.exists(): pdf.write_bytes(urllib.request.urlopen(URL,timeout=90).read())
reader=PdfReader(pdf)
names={
 2:('ashland-nbsb',1,'Ashland Place and DeKalb Avenue','Brooklyn','NB/SB'),
 3:('ashland-wb',1,'Ashland Place and DeKalb Avenue','Brooklyn','WB'),
 4:('sixth-nb',2,'6th Avenue and 38th Street','Manhattan','NB'),
 5:('sixth-eb',2,'6th Avenue and 38th Street','Manhattan','EB'),
 6:('eighth-nb',3,'8th Avenue and 50th Street','Manhattan','NB'),
 7:('eleventh-nb',4,'11th Street and 44th Drive','Queens','NB'),
 8:('eleventh-sb',4,'11th Street and 44th Drive','Queens','SB'),
 9:('queensboro-ebwb',5,'Queensboro Bridge','Manhattan approach','EB/WB'),
}
cats=['Personal E-bike','Rental E-bike','Moped','Pedal bike','Other bike','Scooter']
columns=[(day,status,period,start,end) for day in ['2024-10-24','2024-10-25']
 for status in ['Delivery Workers','Others']
 for period,start,end in [('lunch','12:00','14:00'),('dinner','17:30','19:30')]]
counts=[]; totals={}; vectors={}; raw={}
for pageidx in [83,84,85]:
    text=reader.pages[pageidx].extract_text()
    (P/f'pdf-page-{pageidx+1}-extracted.txt').write_text(text)
    current=None
    for line in text.splitlines():
        m=re.match(r'Table C-(\d+)\.',line)
        if m: current=int(m[1]);vectors[current]={};raw[current]={'page':pageidx+1,'rows':{}}
        m=re.match(r'^(Personal E-bike|Rental E-bike|Moped|Pedal bike|Other bike|Scooter|Total)\s+([\d, ]+)\s*$',line)
        if not m:continue
        category=m[1]; values=[int(v.replace(',','')) for v in m[2].split()]
        assert len(values)==8,(pageidx,current,line)
        vectors[current][category]=values;raw[current]['rows'][category]=line.strip()
        if category=='Total':totals[current]=values;continue
        sid,site,location,borough,direction=names[current]
        for col,(day,status,period,start,end) in enumerate(columns):
            counts.append(dict(screenline_id=sid,site_id=site,location=location,borough=borough,
                direction=direction,date=day,period=period,start_local=start,end_local=end,
                duration_hours=2,delivery_status=status,device_category=category,count=values[col],
                source_pdf_page=pageidx+1,source_printed_page=f'C-{pageidx-81}',source_table=f'C-{current}',
                source_column=col+1,source_url=URL,citi_extractable=False))
assert sorted(vectors)==list(range(2,10))
assert len(counts)==384
assert all(set(v)==set(cats+['Total']) for v in vectors.values())

# Table C-1 rows are extracted in report order, not copied from detail sums.
summarytext=reader.pages[82].extract_text()
(P/'pdf-page-83-extracted.txt').write_text(summarytext)
summaryvectors=[]
for line in summarytext.splitlines():
    m=re.search(r'((?:[\d,]+\s+){7}[\d,]+)\s*$',line)
    if m:
        v=[int(t.replace(',','')) for t in m[1].split()]
        if len(v)==8:summaryvectors.append(v)
assert len(summaryvectors)==8,summaryvectors
groups=[(2,),(3,),(4,),(5,),(6,),(7,8),(9,)]
checks=[]
for t,v in vectors.items():
 for col in range(8):
    actual=sum(v[c][col] for c in cats); printed=v['Total'][col]
    checks.append(dict(check='category_sum_equals_printed_table_total',table=f'C-{t}',column=col+1,
        computed=actual,published=printed,delta=actual-printed,passed=actual==printed))
for i,group in enumerate(groups):
 for col in range(8):
    actual=sum(totals[t][col] for t in group);printed=summaryvectors[i][col]
    checks.append(dict(check='detail_total_equals_C1_screenline',tables=[f'C-{t}' for t in group],column=col+1,
        computed=actual,published=printed,delta=actual-printed,passed=actual==printed))
for col in range(8):
    actual=sum(v[col] for v in summaryvectors[:-1]);printed=summaryvectors[-1][col]
    checks.append(dict(check='C1_screenlines_equal_grand_total',column=col+1,
        computed=actual,published=printed,delta=actual-printed,passed=actual==printed))

local=[]
for t,v in vectors.items():
 sid,site,location,borough,direction=names[t]
 for dayidx,day in enumerate(['2024-10-24','2024-10-25']):
  for periodidx,(period,start,end) in enumerate([('lunch','12:00','14:00'),('dinner','17:30','19:30')]):
   cols=[dayidx*4+periodidx,dayidx*4+periodidx+2]
   devices={cat:sum(v[cat][c] for c in cols) for cat in cats}
   bike=sum(devices[c] for c in ['Personal E-bike','Rental E-bike','Pedal bike','Other bike'])
   allmicro=sum(devices.values())
   local.append(dict(screenline_id=sid,site_id=site,location=location,borough=borough,direction=direction,
        date=day,period=period,start_local=start,end_local=end,duration_hours=2,
        published_bicycle_labeled_count=bike,all_micromobility_count=allmicro,
        other_bike_count=devices['Other bike'],moped_count=devices['Moped'],scooter_count=devices['Scooter'],
        bicycle_labeled_fraction=bike/allmicro,citi_numerator=None,citi_share_bicycle=None,
        citi_share_all_micromobility=None,citi_extractable=False,source_table=f'C-{t}',
        source_pdf_page=raw[t]['page']))

def csvwrite(name,rows):
 with (P/name).open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
csvwrite('nyu-device-counts.csv',counts)
csvwrite('nyu-local-denominators.csv',local)
(P/'nyu-extracted-source-rows.json').write_text(json.dumps(raw,indent=2)+'\n')
out=dict(source_url=URL,source_sha256=hashlib.sha256(pdf.read_bytes()).hexdigest(),
    extracted_on='2026-11-05',citi_extractable=False,citi_numerator=None,citi_share=None,
    critical_finding='The methods and Figure 3 distinguish Citi Bike electric/pedal, but the released Appendix C tables publish only six categories and no explicit Citi Bike count. Other bike cannot be assumed to mean Citi Bike.',
    methods_pages={'method_pdf_page':20,'figure_3_pdf_page':23,'appendix_intro_pdf_page':83,
        'table_pdf_pages':{'C-1':83,'C-2':84,'C-3':84,'C-4':84,'C-5':85,'C-6':85,'C-7':85,'C-8':86,'C-9':86}},
    extraction='pypdf text extraction; strict eight-integer device-row parsing; table/location metadata and column order verified from rendered PDF pages. No numeric transcription or category relabeling.',
    denominator_definition='Published bicycle-labeled count = Personal E-bike + Rental E-bike + Pedal bike + Other bike. All micromobility adds Moped and Scooter. This denominator is computable; Citi Bike numerator is unpublished in these tables.',
    delivery_status_note='Others includes uncertain delivery-worker status; do not label it exclusively non-delivery.',
    screenline_note='Five sites yield eight detailed directional tables. C-1 combines 11th/44th NB and SB; detailed C-7 and C-8 keep them separate. No sum across these sites is a citywide traffic estimate.',
    counts=dict(device_cells=len(counts),local_windows=len(local),checks=len(checks),failed_checks=sum(not x['passed'] for x in checks)),
    checks=checks,local_windows=local,
    snapshot_device_totals_for_audit_only={cat:sum(r['count'] for r in counts if r['device_category']==cat) for cat in cats},
    local_bicycle_labeled_fraction_range=[min(r['bicycle_labeled_fraction'] for r in local),max(r['bicycle_labeled_fraction'] for r in local)],
    limitations=['Two October weekdays at selected delivery-peak windows; no annual/current citywide calibration.',
        'Rider status and device type visually classified; methods acknowledge potential confusion.',
        'Collected 15-minute intervals are not exposed individually in the released two-hour tables.',
        'No defensible Citi Bike share or multiplier can be computed from the released categories.'])
(P/'nyu-audit.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:out[k] for k in ['counts','snapshot_device_totals_for_audit_only','local_bicycle_labeled_fraction_range']},indent=2))
print('Failures:',[x for x in checks if not x['passed']])
