#!/usr/bin/env python3
"""Reproduce the local calibration audit from retained official DCP JSON.

Usage: python reproduce.py [--refresh]
Python standard library only. Refresh downloads raw DCP rows and metadata.
NYU's separate extraction script is retained in nyu/; its result is attached when
available, but no unpublished Citi Bike category mapping is inferred here.
"""
import argparse
import csv
import hashlib
import json
import urllib.request
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
RAW = ROOT / 'raw'
URLS = {
    'dcp_onstreet.json': 'https://data.cityofnewyork.us/resource/qfs9-xn8t.json?$limit=5000',
    'dcp_offstreet.json': 'https://data.cityofnewyork.us/resource/mfmf-gtvc.json?$limit=5000',
    'dcp_onstreet_metadata.json': 'https://data.cityofnewyork.us/api/views/qfs9-xn8t.json',
    'dcp_offstreet_metadata.json': 'https://data.cityofnewyork.us/api/views/mfmf-gtvc.json',
}
SOURCES = {
    'dcp_onstreet': {
        'name': 'DCP Manhattan Bike Counts – On Street Weekday',
        'url': 'https://data.cityofnewyork.us/Transportation/NYCDCP-Manhattan-Bike-Counts-On-Street-Weekday/qfs9-xn8t',
        'api_url': URLS['dcp_onstreet.json'],
        'dataset_id': 'qfs9-xn8t', 'denominator_field': 'cyclistvolume',
        'all_users_field': 'totalusers', 'other_users_field': 'noncyc_otheruser',
    },
    'dcp_offstreet': {
        'name': 'DCP Manhattan Bike Counts – Off Street',
        'url': 'https://data.cityofnewyork.us/Transportation/NYCDCP-Manhattan-Bike-Counts-Off-Street/mfmf-gtvc',
        'api_url': URLS['dcp_offstreet.json'],
        'dataset_id': 'mfmf-gtvc', 'denominator_field': 'cyclists_all',
        'all_users_field': 'alluservolume',
    },
}
DICTIONARY_URL = 'https://data.cityofnewyork.us/api/views/qfs9-xn8t/files/2ba06c49-0f97-4120-a71a-760730887123'
NYU_URL = 'https://c2smart.engineering.nyu.edu/wp-content/uploads/2026/04/25-38-NYC-Delivery-Worker-Data-Collection-and-Research-Report.pdf'

def number(row, key):
    val = row.get(key)
    return None if val is None or val == '' else float(val)

def write_csv(filename, rows):
    if not rows:
        return
    with (ROOT / filename).open('w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)

def reference_samples():
    """Manually entered published counts; each record identifies its source."""
    p = 'https://www.bike.nyc/wp-content/uploads/2019/12/Pulaski-Bridge-count-write-up.pdf'
    b = 'https://pmc.ncbi.nlm.nih.gov/articles/PMC9900529/'
    h = 'https://s29068.pcdn.co/wp-content/uploads/hunter.cuny.edu-riding-behavior-cyclists-hunter-college-1.pdf'
    rows = []
    for id, label, n, d, window in [
        ('pulaski_all', 'Pulaski Bridge, all sampled hours', 205, 960, 'Six peak and two off-peak hours, November 2019'),
        ('pulaski_peak', 'Pulaski Bridge, peak hours', 189, 853, 'Six sampled peak hours, November 2019'),
        ('pulaski_offpeak', 'Pulaski Bridge, off-peak hours', 16, 107, 'Two sampled off-peak hours, November 2019'),
    ]:
        rows.append(dict(id=id,label=label,citi_count=n,denominator_count=d,
            denominator='Bicycles as classified in this study',share=n/d,
            share_precision='Calculated from published integer counts',period=window,
            source_url=p,source_locator='December 2019 report, summary tables and full count sheet',
            limits='One bridge and selected weekdays; throttle e-bikes with non-pedaling riders were classified among motorized path traffic rather than bicycles.',
            use_for_current_citywide_multiplier=False))
    rows.append(dict(id='hunter_2019',label='Hunter College central Manhattan sample',citi_count=None,
        denominator_count=4325,denominator='Observed cyclists aged 14 or older',share=.271,
        share_precision='Reported to one decimal percent; exact Citi Bike numerator not published in inspected passage',
        period='April 8–May 1, 2019; 46 locations, two one-hour visits per site, 07:00–19:00 sampling range',
        source_url=h,source_locator='PDF pages 3–5 (printed 2–4)',
        limits='Stratified locations with observer exclusions and missed riders while recording; not a complete traffic census. No exact numerator reconstructed from the rounded percentage.',
        use_for_current_citywide_multiplier=False))
    for id,label,d,den in [
        ('basch_bicycles','Basch et al. Manhattan protected lanes, bicycles',922,'Citi Bike electric 17 + Citi Bike regular 301 + private electric 315 + private regular 289'),
        ('basch_all_micromobility','Basch et al. Manhattan protected lanes, all micromobility',988,'All eight Table 1 vehicle categories, including mopeds, scooters, skateboards and motorcycle/dirt bikes'),
    ]:
        rows.append(dict(id=id,label=label,citi_count=318,denominator_count=d,denominator=den,share=318/d,
            share_precision='Calculated from Table 1 integer counts',
            period='Published February 2023; observation dates not reported in inspected methods',
            source_url=b,source_locator='Table 1; Methods and Results',
            limits='About 100 observations per zone across ten zones; geography is not weighted by actual traffic. Different denominator choices answer different questions. Article prose contains 998/988 inconsistencies; device table sums to 988.',
            use_for_current_citywide_multiplier=False))
    return rows

def main(refresh=False):
    RAW.mkdir(exist_ok=True,parents=True)
    for filename,url in URLS.items():
        p=RAW/filename
        if refresh or not p.exists():
            p.write_bytes(urllib.request.urlopen(url,timeout=90).read())
    rows=[]
    issues=[]
    source_stats=[]
    for source,meta in SOURCES.items():
        data=json.loads((RAW/(source+'.json')).read_text())
        source_stats.append({'source':source,'raw_rows':len(data),'year_min':min(int(r['year']) for r in data),'year_max':max(int(r['year']) for r in data)})
        for raw_index,r in enumerate(data):
            year=int(r['year'])
            if not 2013 <= year <= 2015:
                continue
            c=number(r,'citibike_all')
            non=number(r,'non_citibikecyc')
            total=number(r,meta['denominator_field'])
            allusers=number(r,meta['all_users_field'])
            if source=='dcp_onstreet':
                other=number(r,'noncyc_otheruser')
            else:
                other=sum(number(r,k) or 0 for k in ['rllrbld_scootr','jogger','walker'])
            assert c is not None and non is not None and total is not None and total > 0
            assert 0 <= c <= total and non >= 0
            rid=f"{source}-{r['locationid']}-{year}-{r['typeoftime'].lower()}"
            reconciliation=c+non-total
            alluser_reconciliation=total+other-allusers
            gender_check=None
            if source=='dcp_onstreet':
                male,female=number(r,'citibike_male'),number(r,'citibike_female')
                if male is not None and female is not None:
                    gender_check=male+female-c
            flags=[]
            if reconciliation != 0:
                flags.append('Citi plus non-Citi does not equal reported cyclists')
                issues.append({'id':rid,'check':'citi_plus_non_minus_reported_cyclists','difference':reconciliation,'action':'Retain reported cyclist denominator and flag; do not silently repair.'})
            if alluser_reconciliation != 0:
                flags.append('Cyclists plus other users does not equal all users')
                issues.append({'id':rid,'check':'cyclists_plus_others_minus_allusers','difference':alluser_reconciliation,'action':'Retain published values; all users is not used as bicycle-share denominator.'})
            if gender_check not in [None,0]:
                flags.append('Male plus female Citi count mismatch')
                issues.append({'id':rid,'check':'citi_gender_sum_minus_citi_all','difference':gender_check,'action':'Use published Citi all numerator and retain flag.'})
            rows.append({
                'id':rid,'source':source,'dataset_id':meta['dataset_id'],'location_id':r['locationid'],
                'location':r['location'],'location_type':r['locationtype'],'year':year,'season':'Fall',
                'day_type':r['typeoftime'],'observation_date':None,'window_start_local':None,
                'window_end_local':None,'window_hours':None,'direction':'Not separately reported in source row; NB+SB only where stated in location name',
                'latitude':number(r,'location_lat'),'longitude':number(r,'location_long'),
                'citi_bikes':c,'non_citi_bicycles':non,'all_bicycles':total,'all_users':allusers,
                'citi_share_bicycles':c/total,'inverse_share_bicycles_per_citi':total/c if c>0 else None,
                'citi_plus_non_minus_all_bicycles':reconciliation,
                'cyclists_plus_others_minus_all_users':alluser_reconciliation,
                'citi_gender_reconciliation':gender_check,
                'share_using_component_sum':c/(c+non) if c+non>0 else None,
                'zero_status':'Recorded zero Citi Bike count with positive bicycle denominator' if c==0 else 'Positive observed Citi Bike count',
                'zero_means_missing':False,'data_quality_flags':'; '.join(flags),
                'source_url':meta['url'],'source_raw_file':'raw/'+source+'.json',
                'source_raw_index_zero_based':raw_index,
                'numerator_field':'citibike_all','denominator_field':meta['denominator_field'],
                'use_for_current_citywide_multiplier':False,
            })
    rows.sort(key=lambda r:(r['source'],int(r['location_id']),r['day_type'],r['year']))
    assert len(rows)==57
    assert len({r['id'] for r in rows})==57
    assert sum(r['citi_bikes']==0 for r in rows)==6
    # Summaries describe the range of local records; they are not pooled shares.
    group=defaultdict(list)
    for r in rows:
        group[(r['source'],r['year'],r['day_type'])].append(r)
    ranges=[]
    for (source,year,day),rr in sorted(group.items()):
        lo=min(rr,key=lambda r:r['citi_share_bicycles'])
        hi=max(rr,key=lambda r:r['citi_share_bicycles'])
        ranges.append({'source':source,'year':year,'day_type':day,'local_records':len(rr),
            'zero_records':sum(r['citi_bikes']==0 for r in rr),
            'min_share':lo['citi_share_bicycles'],'min_record':lo['id'],
            'max_share':hi['citi_share_bicycles'],'max_record':hi['id'],
            'summary_type':'Range of local observations; not a citywide estimate or confidence interval'})
    bystratum=defaultdict(dict)
    for r in rows:
        bystratum[(r['source'],r['location_id'],r['day_type'])][r['year']]=r
    changes=[]
    for key,years in sorted(bystratum.items()):
        for before,after in [(2013,2014),(2014,2015),(2013,2015)]:
            if before in years and after in years:
                a,b=years[before],years[after]
                changes.append({'location':a['location'],'source':a['source'],'location_id':a['location_id'],
                    'day_type':a['day_type'],'before_id':a['id'],'after_id':b['id'],
                    'before_year':before,'after_year':after,'before_share':a['citi_share_bicycles'],
                    'after_share':b['citi_share_bicycles'],
                    'change_percentage_points':100*(b['citi_share_bicycles']-a['citi_share_bicycles']),
                    'interpretation':'Same location/day type; exact survey dates/windows unavailable. Descriptive change, not a lane-project effect.'})
    sources=[]
    for filename,url in URLS.items():
        p=RAW/filename
        sources.append({'file':'raw/'+filename,'url':url,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size})
    output={
        'schema_version':1,'checked_on':'2026-11-05',
        'title':'Local Citi Bike share calibration: published observations and denominator audit',
        'headline':'Local shares vary by place, year and day type. No current citywide multiplier is estimated.',
        'methods':{
            'dcp_filter':'Keep 2013–2015 records with a positive reported bicycle denominator; retain all six recorded zero Citi Bike counts.',
            'dcp_fraction':'citibike_all / cyclistvolume (on-street), or citibike_all / cyclists_all (off-street). Never divide by all-user volume.',
            'dcp_window':'Official dictionary states annual fall counts. Tables/dictionary do not expose exact observation dates or within-day start/end times; those fields remain null.',
            'zero_handling':'Recorded Citi Bike zero is preserved as zero, not missing. It does not prove the probability of a Citi Bike crossing was exactly zero and cannot produce a finite inverse-share calibration.',
            'non_integer_counts':'Preserve fractional source values. Do not coerce the 1802.5 bicycle count to an integer or invent an averaging explanation.',
            'aggregation':'No pooled citywide share or average of different windows. Range summaries describe observed local records only.',
            'uncertainty':'No binomial confidence intervals: sampling windows/design and dependence are insufficiently documented; these records are not a probability sample of NYC trips.',
            'dictionary_url':DICTIONARY_URL,
        },
        'dcp':{'raw_source_stats':source_stats,'records':rows,'ranges':ranges,'same_location_changes':changes,
            'audit':{'selected_rows':len(rows),'locations':len({r['location_id'] for r in rows}),
                'site_day_type_strata':len(bystratum),'recorded_zero_citi_rows':6,
                'numerator_denominator_reconciliation_mismatches':sum(r['citi_plus_non_minus_all_bicycles']!=0 for r in rows),
                'all_user_reconciliation_mismatches':sum(r['cyclists_plus_others_minus_all_users']!=0 for r in rows),
                'issues':issues}},
        'nyu':{
            'source_url':NYU_URL,'observation_dates':['2024-10-24','2024-10-25'],
            'periods':['12:00–14:00','17:30–19:30'],'citi_share_extractable':False,
            'citi_numerator':None,'citi_share':None,
            'reason':'Methods mention separate electric/pedal Citi Bike observations, but published Appendix C device tables do not expose those separate categories or define a mapping from Other bike to Citi Bike.',
            'method_locator':'Figure 3, PDF page 23 (printed page 12); Appendix C introduction, PDF page 83 (printed C-1)',
            'table_locator':'PDF pages 84–86 (printed C-2–C-4), Tables C-2–C-9',
            'published_device_categories':['Personal E-bike','Rental E-bike','Moped','Pedal bike','Other bike','Scooter'],
            'allowed_use':'Use published classified micromobility volumes with explicit bicycle/all-micromobility denominators; do not call Other bike a Citi Bike count.',
            'missing_data_needed':'Underlying categorized observations or explicit author-confirmed mapping for the collapsed published categories.',
        },
        'reference_samples':reference_samples(),
        'ui_recommendations':[
            'Offer DCP location, year and weekday/weekend selectors; show numerator, bicycle denominator, period and quality flag alongside the share.',
            'Do not preselect a citywide multiplier from DCP or NYU. Label the historical records as local reference observations.',
            'For a zero Citi Bike count, show the observed fraction and disable inverse scaling rather than dividing by zero.',
            'Keep bicycle and all-micromobility denominators visibly separate for Basch and NYU.',
            'Existing Pulaski and Basch counts are reproducible reference samples, not newly collected data. Hunter2019 is a rounded published proportion.',
        ],
        'provenance':sources,
    }
    nyu_meta=ROOT/'nyu'/'nyu-audit.json'
    if nyu_meta.exists():
        output['nyu']['extraction_audit']=json.loads(nyu_meta.read_text())
    (ROOT/'calibration.json').write_text(json.dumps(output,indent=2,allow_nan=False)+'\n')
    write_csv('dcp-local-shares.csv',rows)
    write_csv('dcp-same-location-changes.csv',changes)
    write_csv('reference-samples.csv',output['reference_samples'])
    (ROOT/'audit.json').write_text(json.dumps(output['dcp']['audit'],indent=2)+'\n')
    print(json.dumps({'records':len(rows),'zero_citi_rows':6,'audit_issues':issues},indent=2))

if __name__=='__main__':
    args=argparse.ArgumentParser(description=__doc__)
    args.add_argument('--refresh',action='store_true')
    main(args.parse_args().refresh)
