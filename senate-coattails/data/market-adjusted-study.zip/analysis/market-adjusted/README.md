# Market-adjusted donor support

Samuel Webber · November 6, 2026

This release executes the proposed test: measure disclosed individual support above what a candidate's lagged electoral prospects and race context predict. It uses historical PredictIt prices under the explicit assumption that they represent calibrated probabilities, together with official FEC contribution records. The result is conditional donor support, not a proven charisma scale.

The main sample is eventual Democratic and Republican Senate nominees in covered regular elections. Donation weeks fall within August 1–September 28; only paired, complete weeks with strictly preceding odds no more than seven days old are retained. The first cycle is cross-fitted by whole race; later cycles use earlier cycles only. These are retrospective receipt-date reconstructions, not historically available filing snapshots.

## Read the evidence

- `model/PROTOCOL.md`: specifications fixed before calculating the new results.
- `model/results/dashboard.json`: exact figures and explanations used by the website.
- `model/results/donation_metrics.csv`: out-of-fold and later-cycle fundraising prediction errors.
- `model/results/vote_metrics.csv`: exploratory own-Senate vote prediction, with paired errors and uncertainty.
- `model/results/candidate_scores.csv`: actual support, arithmetic expected support, ratios, measurement windows and training years.
- `model/results/weekly_predictions.csv`: row-level aggregate predictions for independent checking.
- `odds/`: dated prices, market definitions, raw market archives, acquisition code and checksums.
- `donations/`: public candidate-week aggregates, FEC acquisition and processing code, and source audits. No donor identities are distributed.
- `causal-coverage/`: the completed intersection with the existing close-primary cohort.
- `verification/`: independent numerical and timing checks, when present.

Fundraising prediction, independent candidate-appeal validation and causal coattails are separate questions. The exploratory vote target concerns a candidate's own election, not teammate lift. No measure is selected because it generates a desirable down-ballot effect.

The primary-coverage audit is not a newly estimated effect. Only two exact party-market matches precede the existing donor cutoffs; both higher-donor contenders lost, and neither cumulative donation window is fully covered by market history. A common seat-level adjustment also cannot change a same-party donor ranking when it applies the same positive divisor to both contenders.

## Reproduce from frozen aggregates

Keep the archive's `analysis/` directory structure intact and run from the extraction root. The small prior-study files used for nominee identity, population, returns and the primary cohort are included at their original relative paths.

```sh
python -m pip install -r analysis/market-adjusted/requirements.txt
python analysis/market-adjusted/odds/qa_odds.py
python analysis/market-adjusted/causal-coverage/build_coverage.py
python analysis/market-adjusted/reproduce.py
```

`reproduce.py` reads the four frozen aggregate panels, executes the main model and its predetermined specification checks, and copies the main dashboard data into `dist/data/`. A result is not a live donation or market feed.

For acquisition from source, follow `odds/README.txt` and `donations/README.md`. Full FEC archives total about 14 GB compressed and must remain outside any public output directory. FEC may update its archives; recorded hashes identify this release's retrieved vintage. Frozen aggregates allow reproducing the published analysis without distributing personal donor records or repeating the bulk download.

## Interpretation

The default donor measure counts approximate disclosed identities first observed in that election cycle during the measurement window. It is not every donor, every new supporter, or the campaign's lifetime donor count. Separate specifications use in-state identities, positive individual receipt rows and gross recorded positive dollars. Ratios compare observed with arithmetic model expectations; the log score uses a one-unit offset to handle zeros. Neither quantity is a percentage-point coattail effect.

Current odds can already reflect candidate quality and past fundraising. Conditioning on them can remove a channel through which candidate quality matters. Residual support also reflects donor networks, ideology, opponent dislike, publicity and campaign effort. Selective market coverage and limited election cycles restrict generalization. Additional candidate-appeal data and a credible nomination assignment would be needed to interpret this as a causal talent effect.

`RELEASE_MANIFEST.json` records the exact included file hashes. `package_release.py` rebuilds the downloadable bundle from the source checkout.
