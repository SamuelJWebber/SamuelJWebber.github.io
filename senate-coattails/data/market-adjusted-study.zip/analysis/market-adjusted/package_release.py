"""Package frozen aggregate inputs, code and results without donor-level records."""
from pathlib import Path
import hashlib
import json
import zipfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
DEPENDENCIES = [
    'analysis/stage3/score/core.py',
    'analysis/stage3/fundraising/nominee_fec_mapping.csv',
    'analysis/stage3/population/prior_census_population.csv',
    'analysis/stage3/population/provenance.json',
    'analysis/stage3/inputs/mit_senate_nominee_returns.csv',
    'analysis/stage3/SOURCES.json',
    'analysis/donor-primary/donors/candidate_donor_counts.csv',
    'analysis/donor-primary/analysis/results/treatment_ledger.csv',
    'analysis/donor-primary/donors/DONOR_METHODS.md',
    'dist/market-adjusted.html',
    'dist/market-adjusted.css',
    'dist/market-adjusted.js',
    'dist/data/market-adjusted.json',
]

def files():
    candidates = list(HERE.rglob('*')) + [ROOT / p for p in DEPENDENCIES]
    answer = []
    for p in candidates:
        if not p.is_file() or '__pycache__' in p.parts or p.suffix in {'.pyc', '.log'}:
            continue
        if p.name == 'RELEASE_MANIFEST.json':
            continue
        if p.suffix in {'.partial', '.sqlite', '.db'}:
            raise ValueError(f'Private or incomplete input in release: {p.name}')
        answer.append(p)
    return sorted(set(answer))

def main():
    for name in DEPENDENCIES:
        assert (ROOT / name).is_file(), name
    selected = files()
    manifest = {'description': 'Aggregate-only market-adjusted donor study; full FEC individual archives remain excluded.',
                'files': [{'path': str(p.relative_to(ROOT)), 'bytes': p.stat().st_size,
                           'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in selected]}
    mp = HERE / 'RELEASE_MANIFEST.json'
    mp.write_text(json.dumps(manifest, indent=2) + '\n')
    selected.append(mp)
    dest = ROOT / 'dist/data/market-adjusted-study.zip'
    with zipfile.ZipFile(dest, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for p in selected:
            info = zipfile.ZipInfo(str(p.relative_to(ROOT)), date_time=(2026, 11, 6, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            z.writestr(info, p.read_bytes())
    with zipfile.ZipFile(dest) as z:
        assert z.testzip() is None
        assert len(z.namelist()) == len(selected)
    print(json.dumps({'path': str(dest), 'files': len(selected), 'bytes': dest.stat().st_size,
                      'sha256': hashlib.sha256(dest.read_bytes()).hexdigest()}))

if __name__ == '__main__':
    main()
