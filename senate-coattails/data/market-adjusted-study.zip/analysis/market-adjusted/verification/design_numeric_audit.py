#!/usr/bin/env python3
"""Independent numerical audit of the market-adjusted donor analysis.

Re-fits ridge predictions using NumPy's closed-form solution rather than the
production sklearn pipeline; recomputes exported metrics from prediction rows.
No source model or output is mutated. This is not external scientific validation.
"""
from pathlib import Path
import argparse
import hashlib
import json
import numpy as np
import pandas as pd
from sklearn.model_selection import GroupKFold

HERE = Path(__file__).resolve().parent
BASE = ['log_population', 'democrat', 'incumbent', 'party_prior_lean', 'weeks_until_election', 'cycle_trend']
MARKET = BASE + ['p', 'p2', 'p3']
VOTE_BASE = ['prior_pres_lean', 'incumbency_difference', 'mean_probability', 'logit_probability']


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def ridge_numpy(train, test, features, target):
    X = train[features].to_numpy(float)
    Z = test[features].to_numpy(float)
    med = np.nanmedian(X, axis=0)
    assert np.isfinite(med).all(), 'Entirely missing feature needs explicit audit treatment'
    X = np.where(np.isnan(X), med, X)
    Z = np.where(np.isnan(Z), med, Z)
    mu, scale = X.mean(axis=0), X.std(axis=0)
    scale = np.where(scale == 0, 1., scale)
    X, Z = (X-mu)/scale, (Z-mu)/scale
    y = np.asarray(target, float)
    intercept = y.mean()
    beta = np.linalg.solve(X.T@X + np.eye(X.shape[1])*10., X.T@(y-intercept))
    return Z@beta + intercept, X@beta + intercept


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--results', type=Path, default=HERE.parent/'model'/'results')
    parser.add_argument('--output', type=Path, default=HERE)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    r = args.results
    panel = pd.read_csv(r/'model_panel.csv')
    pred = pd.read_csv(r/'weekly_predictions.csv')
    scores = pd.read_csv(r/'candidate_scores.csv')
    dm = pd.read_csv(r/'donation_metrics.csv')
    manifest = json.loads((r/'run_manifest.json').read_text())
    checkout = HERE.parents[2]
    checks = []

    def check(name, condition, detail):
        checks.append({'check': name, 'passed': bool(condition), 'detail': detail})

    week = pd.to_datetime(panel.week_start, utc=True)
    quote = pd.to_datetime(panel.observed_at, utc=True)
    check('odds_strictly_before_donation_week', (quote < week).all(), f'{len(panel)} candidate-week rows')
    check('odds_age_at_most_seven_days', ((week-quote).dt.total_seconds() <= 7*86400).all(), 'No future interpolation or stale beyond seven days')
    check('both_nominees_same_weeks', panel.groupby(['race_id','week_start']).party.apply(lambda x:set(x)=={'D','R'}).all(), 'Exactly two major-party nominees per retained week')
    check('no_duplicate_candidate_week', not panel.duplicated(['candidate_key','week_start']).any(), 'Panel rows unique before measure/model expansion')
    check('complete_seven_day_windows', ((pd.to_datetime(panel.week_end)-pd.to_datetime(panel.week_start)).dt.days==6).all(), 'No truncated donor weeks')
    start_ok = pd.to_datetime(panel.week_start) >= pd.to_datetime(panel.year.astype(str)+'-08-01')
    end_ok = pd.to_datetime(panel.week_end) <= pd.to_datetime(panel.year.astype(str)+'-09-28')
    check('fixed_august_september_window', (start_ok & end_ok).all(), 'No donation weeks after September 28')
    check('minimum_four_paired_weeks', (panel.groupby('race_id').week_start.nunique()>=4).all(), 'Race coverage threshold')
    check('new_national_donors_not_repeated_weekly_total', (panel.national_new_donors<=panel.national_donors).all(), 'First-cycle-observed count never exceeds active unique donors in that week')
    check('new_in_state_donors_subset_definition', (panel.in_state_new_donors<=panel.in_state_donors).all(), 'First in-state observation, potentially after an earlier out-of-state observation')
    check('support_nonnegative', (panel[['national_new_donors','in_state_new_donors','transactions','dollars']]>=0).all().all(), 'Gross positive receipts and nonnegative donor counts')
    check('donor_prediction_features_exclude_current_outcomes', not {'dshare','actual','winner','senate_share'}.intersection(MARKET), 'Fixed features contain no current election outcome')
    donor_inputs = manifest['input_donations']
    if isinstance(donor_inputs, str): donor_inputs = [donor_inputs]
    source_donors = pd.concat([pd.read_csv(checkout/p if not Path(p).is_absolute() else p) for p in donor_inputs],ignore_index=True)
    source_keys = ['candidate_id','year','week_start']
    source_fields = ['national_new_donors','in_state_new_donors','transactions','dollars']
    joined=panel[source_keys+source_fields].merge(source_donors[source_keys+source_fields],on=source_keys,validate='one_to_one',suffixes=('','_source'))
    check('model_support_matches_exported_donor_aggregates', len(joined)==len(panel) and all(np.allclose(joined[f],joined[f+'_source']) for f in source_fields), 'All four support fields match candidate-week FEC aggregates')
    op=Path(manifest['input_odds']); op=op if op.is_absolute() else checkout/op
    source_odds=pd.read_csv(op,low_memory=False);source_odds['obs']=pd.to_datetime(source_odds.observed_at,utc=True)
    source_odds['party_short']=source_odds.party.replace({'DEM':'D','REP':'R'})
    metadata=pd.read_csv(op.parent/'market_metadata.csv')
    market_identity=panel[['race_id','year','state_abbrev','market_id']].drop_duplicates().merge(
        metadata[['market_id','year','state','seat','market_title']],on='market_id',how='left',suffixes=('','_market'),validate='many_to_one')
    check('market_identity_matches_regular_nominee_race',
          (market_identity.seat.eq('regular')&market_identity.state_abbrev.eq(market_identity.state)&market_identity.year.eq(market_identity.year_market)).all(),
          'Independent market-ID lookup verifies state, election year and regular-vs-special seat; prevents MN2018 special-market/regular-nominee mismatch')
    source_odds=source_odds[source_odds.seat.eq('regular')]
    matched=True
    for row in panel.itertuples():
        o=source_odds[(source_odds.year==row.year)&source_odds.state.eq(row.state_abbrev)&source_odds.party_short.eq(row.party)]
        o=o[o.obs<pd.Timestamp(row.week_start,tz='UTC')].sort_values('obs')
        if not len(o): matched=False;continue
        last=o.iloc[-1]
        probability=last.normalized_probability if manifest.get('normalized_odds') else last.probability
        matched &= pd.Timestamp(row.observed_at)==last.obs and abs(row.p-probability)<1e-12
    check('matched_quotes_are_latest_eligible_source_observations', matched, 'Independently recomputed latest strictly preceding quote from source odds file')
    # A named-incumbent market must concern one of the two actual nominees in
    # the retained state-election, not merely any politician from that state.
    import re
    aliases={'BOB':'ROBERT','BILL':'WILLIAM','TED':'RAFAEL','JOE':'JOSEPH','DEBBIE':'DEBORAH','JON':'JONATHAN'}
    def nameset(s):
        return {aliases.get(w,w) for w in re.sub('[^A-Z ]',' ',str(s).upper()).split() if w not in {'JR','SR','II','III','DR'}}
    named_ok=True
    for row in market_identity.itertuples():
        named=metadata.loc[metadata.market_id.eq(row.market_id),'named_candidate'].iloc[0]
        if pd.isna(named):continue
        people=panel.loc[panel.race_id.eq(row.race_id),'benchmark_candidate'].drop_duplicates()
        named_tokens=nameset(named)
        named_ok &= any(named_tokens.issubset(nameset(person)) for person in people)
    check('named_candidate_contract_matches_an_actual_nominee', named_ok, 'Name-token and common-short-name audit of named incumbent markets against the paired nominee roster')
    max_log_error, max_count_rel_error = 0., 0.
    fold_records=[]
    for (year, measure, model, kind, fold), g in pred.groupby(['year','measure','model','validation','fold']):
        valid_panel = panel[panel.year.eq(year)].copy()
        if kind == 'out_of_time':
            train = panel[panel.year.lt(year)].copy()
            fold_valid = valid_panel
        elif kind == 'race_crossfit':
            splits = list(GroupKFold(min(5, valid_panel.race_id.nunique())).split(valid_panel, groups=valid_panel.race_id))
            ia, ib = splits[int(fold)]
            train, fold_valid = valid_panel.iloc[ia], valid_panel.iloc[ib]
        else:
            raise ValueError(f'Unknown validation {kind}')
        keys = ['candidate_key','week_start']
        assert set(map(tuple,g[keys].to_numpy())) == set(map(tuple,fold_valid[keys].to_numpy()))
        assert not set(train.race_id) & set(g.race_id)
        declared = set(str(g.training_years.iloc[0]).split(','))
        actual_years = set(str(x) for x in sorted(train.year.unique()))
        assert declared == actual_years
        if kind == 'out_of_time':
            assert train.year.max() < year
        features = BASE if model=='context' else MARKET
        y = np.log1p(train[measure].to_numpy(float))
        z, fit = ridge_numpy(train,g,features,y)
        smear = float(np.exp(y-fit).mean())
        expected = np.maximum(np.exp(np.clip(z,-20,25))*smear-1,0)
        max_log_error=max(max_log_error,float(np.abs(z-g.expected_log1p).max()))
        max_count_rel_error=max(max_count_rel_error,float((np.abs(expected-g.expected)/np.maximum(1,abs(g.expected))).max()))
        assert np.allclose(g.actual,g[measure])
        assert np.allclose(g.smearing_factor,smear)
        fold_records.append({'year':int(year),'measure':measure,'model':model,'validation':kind,'fold':int(fold),
                             'train_years':','.join(sorted(actual_years)),'train_races':train.race_id.nunique(),
                             'test_races':g.race_id.nunique(),'race_overlap':0})
    check('whole_race_folds_and_past_only_training', True, f'{len(fold_records)} independently reconstructed model fits')
    check('ridge_log_predictions_recomputed', max_log_error<1e-8, f'Maximum absolute difference {max_log_error:.3g}')
    check('training_only_smearing_recomputed', max_count_rel_error<1e-8, f'Maximum relative arithmetic expectation difference {max_count_rel_error:.3g}')
    pd.DataFrame(fold_records).to_csv(args.output/'reconstructed_folds.csv',index=False)

    metric_errors=[]
    for row in dm.itertuples():
        g=pred[pred.year.eq(row.year)&pred.measure.eq(row.measure)&pred.model.eq(row.model)&pred.validation.eq(row.validation)]
        e=np.log1p(g.actual)-g.expected_log1p
        quantities={'log_mae':abs(e).mean(),'log_rmse':np.sqrt((e**2).mean()),
                    'aggregate_absolute_error_ratio':abs(g.actual-g.expected).sum()/max(g.actual.sum(),1),
                    'actual_sum':g.actual.sum(),'expected_sum':g.expected.sum(),
                    'candidate_weeks':len(g),'races':g.race_id.nunique()}
        for field,value in quantities.items():
            metric_errors.append(abs(float(getattr(row,field))-float(value))/max(1,abs(float(value))))
    check('donation_metrics_recomputed', max(metric_errors,default=0)<1e-10, f'{len(dm)} metric rows; candidate-week error unit, race count separately disclosed')

    score_errors=[]
    for row in scores.itertuples():
        g=pred[pred.candidate_key.eq(row.candidate_key)&pred.measure.eq(row.measure)&pred.model.eq(row.model)]
        actual,expected=g.actual.sum(),g.expected.sum()
        quantities={'actual':actual,'expected':expected,'score':np.log1p(actual)-np.log1p(expected),'ratio':actual/expected if expected else np.nan}
        for field,value in quantities.items():
            if np.isfinite(value):score_errors.append(abs(float(getattr(row,field))-float(value))/max(1,abs(float(value))))
    check('candidate_totals_ratios_and_scores_recomputed', max(score_errors,default=0)<1e-10, 'Displayed ratio = observed/expected; log score = log((observed+1)/(expected+1)); these differ for sparse counts')

    vote_max_error=None;vote_metric_error=None
    if (r/'vote_predictions.csv').exists() and (r/'vote_metrics.csv').exists():
        vp=pd.read_csv(r/'vote_predictions.csv'); vm=pd.read_csv(r/'vote_metrics.csv'); v=pd.read_csv(r/'vote_validation_panel.csv')
        vote_probability='cutoff_probability' if 'cutoff_probability' in v else 'mean_probability'
        vote_features=['prior_pres_lean','incumbency_difference',vote_probability,'logit_probability']
        check('own_vote_benchmark_uses_protocol_cutoff_odds', vote_probability=='cutoff_probability', 'Cutoff odds, rather than window-average odds, honor the written main specification')
        if 'forecast_odds_observed_at' in panel:
            cutoff=pd.to_datetime(panel.year.astype(str)+'-09-29',utc=True)
            obs=pd.to_datetime(panel.forecast_odds_observed_at,utc=True)
            eligible=obs.notna()
            check('own_vote_odds_strictly_before_cutoff', ((obs[eligible]<cutoff[eligible])&((cutoff[eligible]-obs[eligible]).dt.total_seconds()<=7*86400)).all(), 'Latest available quote strictly before September 29 00:00 UTC; at most seven days old')
        pred_errors=[];metric_errors=[]
        for (year,measure,model),g in vp.groupby(['year','measure','model']):
            train=v[v.year.lt(year)&v.measure.eq(measure)]
            assert train.year.max()<year
            assert not set(train.race_id)&set(g.race_id)
            extra={'baseline':[],'raw_support':['raw_difference'],'context_adjusted':['context_difference'],'market_adjusted':['market_difference']}[model]
            z,_=ridge_numpy(train,g,vote_features+extra,train.dshare.to_numpy(float))
            z=np.clip(z,0,1)
            pred_errors.extend(np.abs(z-g.prediction).tolist())
        base=vp[vp.model.eq('baseline')][['race_id','measure','prediction']].rename(columns={'prediction':'baseline_prediction'})
        vp=vp.merge(base,on=['race_id','measure'],validate='many_to_one')
        raw=vp[vp.model.eq('raw_support')][['race_id','measure','prediction']].rename(columns={'prediction':'raw_support_prediction'})
        vp=vp.merge(raw,on=['race_id','measure'],validate='many_to_one')
        rng=np.random.default_rng(20261106)
        for (year,measure,model),g in vp.groupby(['year','measure','model']):
            e=100*(g.prediction-g.dshare);eb=100*(g.baseline_prediction-g.dshare)
            gains=abs(eb)-abs(e)
            draws=rng.choice(gains.to_numpy(),size=(2000,len(gains)),replace=True).mean(axis=1)
            row=vm[vm.year.eq(year)&vm.measure.eq(measure)&vm.model.eq(model)].iloc[0]
            quantities={'mae_pp':abs(e).mean(),'rmse_pp':np.sqrt((e**2).mean()),'baseline_mae_pp':abs(eb).mean(),
                        'mae_gain_pp':gains.mean(),'gain_low95':np.quantile(draws,.025),'gain_high95':np.quantile(draws,.975),'races':len(g)}
            if 'gain_vs_raw_pp' in vm:
                eraw=100*(g.raw_support_prediction-g.dshare)
                raw_gains=abs(eraw)-abs(e)
                raw_draws=rng.choice(raw_gains.to_numpy(),size=(2000,len(raw_gains)),replace=True).mean(axis=1)
                quantities.update({'raw_support_mae_pp':abs(eraw).mean(),'gain_vs_raw_pp':raw_gains.mean(),
                                   'gain_vs_raw_low95':np.quantile(raw_draws,.025),'gain_vs_raw_high95':np.quantile(raw_draws,.975)})
            for field,value in quantities.items():metric_errors.append(abs(float(row[field])-float(value)))
        vote_max_error=max(pred_errors,default=0);vote_metric_error=max(metric_errors,default=0)
        check('own_vote_models_past_only_and_recomputed', vote_max_error<1e-8, f'Maximum absolute probability difference {vote_max_error:.3g}')
        check('own_vote_metrics_and_paired_bootstrap_recomputed', vote_metric_error<1e-8, f'Maximum difference {vote_metric_error:.3g}; one state-election per observation')
        check('own_vote_test_not_called_causal_or_charisma_validation', True, 'Protocol identifies this as exploratory own-race prediction; independent personal-appeal target remains absent')
    else:
        check('own_vote_metrics_not_yet_available', True, 'No own-vote result exists in this run; cannot verify uncomputed later-cycle results')

    pd.DataFrame(checks).to_csv(args.output/'design_numeric_checks.csv',index=False)
    result={'passed':all(x['passed'] for x in checks),'checks':checks,'audit_type':'Independent code review and numerical reproduction; not independent data collection or scientific identification',
            'years':sorted(map(int,panel.year.unique())),'candidate_weeks':len(panel),'races':int(panel.race_id.nunique()),
            'max_ridge_log_prediction_error':max_log_error,'max_smearing_expectation_relative_error':max_count_rel_error,
            'max_own_vote_prediction_error':vote_max_error,'max_own_vote_metric_error':vote_metric_error,
            'limitations':['Retrospective FEC vintage; later amendments/itemization can reveal earlier donations.',
                           'First observed disclosed identities are not a census of all donors or newly persuaded supporters.',
                           'Eventual-nominee selection does not provide losing-primary contenders or causal assignment.',
                           'Independent candidate-appeal validation is absent; own-vote prediction is exploratory.',
                           'Displayed O/E ratio and +1-smoothed log score are different quantities.'],
            'input_sha256':{p.name:sha(p) for p in [r/'model_panel.csv',r/'weekly_predictions.csv',r/'candidate_scores.csv',r/'donation_metrics.csv',r.parent/'analyze.py',r.parent/'PROTOCOL.md']},
            'script_sha256':sha(__file__)}
    (args.output/'design_numeric_audit.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'passed':result['passed'],'years':result['years'],'races':result['races'],
                      'checks':len(checks),'max_log_error':max_log_error,'max_count_relative_error':max_count_rel_error,
                      'max_own_vote_prediction_error':vote_max_error,'max_own_vote_metric_error':vote_metric_error},indent=2))
    if not result['passed']:raise SystemExit(1)


if __name__=='__main__':main()
