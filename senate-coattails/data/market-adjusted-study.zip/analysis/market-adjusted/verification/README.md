# Independent numerical and design audit

`design_numeric_audit.py` reconstructs the model's arithmetic without importing its estimator or fitting code. Ridge coefficients are solved directly with NumPy, using training-only imputation, scaling and residual smearing. The production model uses a scikit-learn pipeline.

The audit verifies:

- Every market observation precedes its donation week and is no more than seven days old; the selected observation is independently matched back to the source odds file.
- Market IDs map to the correct state, election year and regular Senate seat; named-incumbent contracts refer to an actual candidate in the paired nominee roster.
- Donation values match the exported FEC candidate-week aggregates; first-observed donors are distinguished from repeated weekly active-donor totals.
- Both party nominees share the same complete weeks, within the fixed August–September window, with at least four paired weeks per race.
- Cross-validation holds an entire state-election together. Later-cycle predictions use only earlier election cycles, with no training/test race overlap.
- Recomputed log predictions, arithmetic expected counts, training-only smearing, candidate totals, support ratios and log scores match published values.
- The exploratory own-Senate vote predictions, MAE, RMSE, gains versus baseline/raw support, and paired bootstrap intervals reproduce from exported rows.

`design_numeric_audit.json` contains the current pass status, scope, maximum discrepancies and file hashes. `design_numeric_checks.csv` contains one row per check; `reconstructed_folds.csv` records the independently reconstructed training/test design.

## Corrections made during review

Review found and flagged an initial repository-relative input path error, which the model owner corrected before the full run. It also clarified that the displayed ratio is `observed / expected`, while the modeling score is `log((observed + 1) / (expected + 1))`; these differ for small counts. In-state first-observed donors refer to first observation within the in-state subset and can include someone previously observed out of state.

The initial own-vote implementation used window-average odds despite the written protocol specifying cutoff odds. The model owner corrected the principal own-vote benchmark to honor the original cutoff specification. This does not change the weekly donation model or donor rankings. See the model's protocol and output fields for the exact cutoff; historical source timing is handled conservatively.

Review also caught a material race-identity error: the initial state-year join attached Minnesota's 2018 special-election market to its regular-election nominees. The model owner added explicit regular-seat filtering. This removes the mismatched race and changes fitted expectations and results. The audit now verifies market metadata independently, rather than relying only on arithmetic consistency and timestamps.

## Reproduce

```bash
python analysis/market-adjusted/verification/design_numeric_audit.py
```

The script's default target is the principal `model/results` directory and the alpha-10 specification. It is not intended to validate alpha-1 or alpha-100 sensitivity fits without adapting the fixed coefficient.

## Limits

Arithmetic reproduction does not establish causality, validate charisma, certify the completeness of public donor disclosures, or convert retrospective FEC bulk snapshots into information observable in real time. The audit did not collect an independent donor census or independent personal-appeal survey. It confirms that the published calculations follow the disclosed model and timing rules, subject to the documented data limitations.
