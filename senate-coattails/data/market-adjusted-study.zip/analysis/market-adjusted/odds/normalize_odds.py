"""Normalize archived, dated PredictIt prices. Standard library only; no live credentials.
Sources are pinned in raw/download_manifest.json. No settled prices are used.
"""
import csv,io,json,re,zipfile,tarfile,collections,datetime,pathlib
from zoneinfo import ZoneInfo
B=pathlib.Path(__file__).parent
NY=ZoneInfo('America/New_York');UTC=datetime.timezone.utc
NAMES='Alabama|Alaska|Arizona|Arkansas|California|Colorado|Connecticut|Delaware|Florida|Georgia|Hawaii|Idaho|Illinois|Indiana|Iowa|Kansas|Kentucky|Louisiana|Maine|Maryland|Massachusetts|Michigan|Minnesota|Mississippi|Missouri|Montana|Nebraska|Nevada|New Hampshire|New Jersey|New Mexico|New York|North Carolina|North Dakota|Ohio|Oklahoma|Oregon|Pennsylvania|Rhode Island|South Carolina|South Dakota|Tennessee|Texas|Utah|Vermont|Virginia|Washington|West Virginia|Wisconsin|Wyoming'.split('|')
ABBR='AL AK AZ AR CA CO CT DE FL GA HI ID IL IN IA KS KY LA ME MD MA MI MN MS MO MT NE NV NH NJ NM NY NC ND OH OK OR PA RI SC SD TN TX UT VT VA WA WV WI WY'.split()
STATES=dict(zip(NAMES,ABBR));ELECTION={2016:'2016-11-08',2018:'2018-11-06',2020:'2020-11-03',2022:'2022-11-08'}
NAMED={'Elizabeth Warren':'DEM','Ted Cruz':'REP','Bernie Sanders':'IND','Joe Manchin':'DEM','Joe Donnelly':'DEM','Bill Nelson':'DEM','Heidi Heitkamp':'DEM','Jon Tester':'DEM','Claire McCaskill':'DEM','Tammy Baldwin':'DEM','Debbie Stabenow':'DEM','Sherrod Brown':'DEM','Bob Menendez':'DEM','Martin Heinrich':'DEM','Angus King':'IND','Jeff Flake':'REP','Dean Heller':'REP','Dianne Feinstein':'DEM','Deb Fischer':'REP','Bob Casey':'DEM','Tina Smith':'DEM'}
PARTY={'Democratic':'DEM','Democratic or DFL':'DEM','Republican':'REP','Independent':'IND','Libertarian':'LIB','Other':'OTH'}
meta={}
def title_meta(mid,title,year=None,state=None,seat=None):
 if year is None:
  yr=re.findall(r'20(?:16|18|20|22)',title)
  if not yr:return None
  year=int(yr[-1])
 if state is None:
  state=next((v for k,v in sorted(STATES.items(),key=lambda kv:-len(kv[0])) if k in title),None)
 if not state:return None
 seat=seat or ('special' if 'special' in title.lower() else 'regular')
 named=next((n for n in NAMED if n in title),'')
 typ='candidate_unconditional_win' if named else 'party_unconditional_win'
 eligible=True;reason=''
 if (year,state) in [(2016,'CA'),(2018,'CA')]:eligible=False;reason='same_party_general_election'
 if state=='LA':eligible=False;reason='jungle_primary_multiple_candidates'
 if year==2018 and state in ['VT','ME']:eligible=False;reason='independent_incumbent_three_way_race'
 if year==2018 and state=='AZ' and named=='Jeff Flake':eligible=False;reason='candidate_did_not_run'
 if year==2018 and state=='MS':eligible=False;reason='jungle_special_election'
 if year==2020 and state=='GA' and seat=='special':eligible=False;reason='jungle_special_election'
 if year==2020 and state in ['AK','AR']:eligible=False;reason='nonstandard_party_candidate_mapping'
 if year==2022 and state=='UT':eligible=False;reason='independent_challenger_no_democratic_nominee'
 out=dict(market_id=str(mid),market_title=title,year=year,state=state,seat=seat,named_candidate=named,contract_type=typ,eligible_main=eligible,exclusion_reason=reason)
 meta[str(mid)]=out;return out
rows=[]
# Primary-supplied historical daily OHLCV exports.
for year in [2016,2018]:
 z=zipfile.ZipFile(B/f'raw/k5cents/{year}/data/DailyMarketData.zip')
 for r in csv.DictReader(io.StringIO(z.read('DailyMarketData.csv').decode('utf-16')),delimiter='|'):
  if 'senate' not in r['MarketName'].lower():continue
  m=title_meta(r['MarketId'],r['MarketName'],year)
  if not m:continue
  rows.append(dict(**m,date=r['Date'],observed_at=r['Date']+'T23:59:59-05:00',contract_name=r['ContractName'],raw_price=float(r['ClosePrice']),volume=float(r['Volume']),source='k5cents_primary_daily_export',priority=3))
# 2020 original hourly capture. Daily final observation by New York date; retain real observation timestamp.
t=tarfile.open(B/'raw/k5cents/2020/data/2020.tar.xz')
hourly={}
hourly_meta={r['mid']:r for r in csv.DictReader(io.TextIOWrapper(t.extractfile('data/senate_markets.csv')))}
for n in t.getnames():
 if '/races/' not in n or '-S' not in n or not n.endswith('.csv'):continue
 code=n.rsplit('/',1)[-1][:-4];state=code[:2];seat='special' if code in ['GA-S3','AZ-S3'] else 'regular'
 for r in csv.DictReader(io.TextIOWrapper(t.extractfile(n))):
  if r['contract'] not in PARTY or r['close']=='NA':continue
  stamp=datetime.datetime.fromisoformat(r['time'].replace('Z','+00:00'));date=stamp.astimezone(NY).date().isoformat()
  m=title_meta(r['mid'],hourly_meta[r['mid']]['market'],2020,state,seat)
  key=(r['mid'],date,r['contract']);rec=dict(**m,date=date,observed_at=(stamp+datetime.timedelta(hours=1)).isoformat(),contract_name=r['contract'],raw_price=float(r['close']),volume=float(r['volume']) if r['volume']!='NA' else 0,source='k5cents_original_hourly_capture',priority=3)
  if key not in hourly or rec['observed_at']>hourly[key]['observed_at']:hourly[key]=rec
rows+=list(hourly.values())
# Independent researcher archive of PredictIt last-90-day exports, supplement uncovered days/cycles.
for r in csv.DictReader((B/'raw/slchism/raw_data/polls/market_urls.csv').open()):
 if 'senate' in r['Market Title'].lower():
  m=title_meta(r['Market ID'],r['Market Title'])
  # original 2020 special IDs absent from table; retained above.
for r in csv.DictReader((B/'raw/slchism/R Data Analysis/market_timeseries_data.csv').open()):
 m=meta.get(r['market_id'])
 if not m:continue
 rows.append(dict(**m,date=r['date'],observed_at=r['date']+'T23:59:59-05:00',contract_name=r['contract_name'],raw_price=float(r['closeSharePrice']),volume=float(r['tradeVolume']),source='chism_gunlogson_predictit_export',priority=1))
# Remove prices on or after general election; retain only cycle calendar year.
rows=[r for r in rows if str(r['year'])+'-01-01'<=r['date']<ELECTION[r['year']] and 0<=r['raw_price']<=1]
# Select one complete source snapshot per market/date. Do not mix archive sources within a normalization group.
groups=collections.defaultdict(list)
for r in rows:groups[(r['market_id'],r['date'],r['source'])].append(r)
chosen={}
for (mid,date,source),rr in groups.items():
 key=(mid,date)
 if key not in chosen or rr[0]['priority']>chosen[key][0]['priority']:chosen[key]=rr
out=[]
for (mid,date),rr in chosen.items():
 m=meta[mid]; named=m['named_candidate']
 if named:
  r=rr[0];p=r['raw_price'];party=NAMED[named]
  for pr,prob,orient in [(party,p,'yes'),('REP' if party=='DEM' else 'DEM',1-p,'no_complement')]:
   x={**r,'party':pr,'probability':prob,'price_sum':1.0,'orientation':orient}
   x['contract_name']=named if orient=='yes' else 'Not '+named
   out.append(x)
 elif any(r['contract_name'] in ['Kamala Harris','Loretta Sanchez'] for r in rr):
  total=sum(r['raw_price'] for r in rr)
  for r in rr:
   if total>0:out.append({**r,'party':'DEM','probability':r['raw_price']/total,'price_sum':total,'orientation':'named_two_candidate','named_candidate':r['contract_name']})
 else:
  rr=[r for r in rr if r['contract_name'] in PARTY]
  if len(set(r['contract_name'] for r in rr))<2:continue
  total=sum(r['raw_price'] for r in rr)
  if total<=0:continue
  for r in rr:out.append({**r,'party':PARTY[r['contract_name']],'probability':r['raw_price']/total,'price_sum':total,'orientation':'normalized_all_listed_outcomes'})
# PA2018 duplicate named vs party market: select party market, explicitly retain duplicate audit records only.
for r in out:
 if r['year']==2018 and r['state']=='PA' and r['market_id']=='4232':r['eligible_main']=False;r['exclusion_reason']='duplicate_race_prefer_party_market_4177'
 if r['year']==2018 and r['state']=='MN' and r['market_id']=='4233':r['eligible_main']=False;r['exclusion_reason']='duplicate_race_prefer_party_market_3949'
 # All Minnesota rows in these archives are special Senate seat.
 if r['year']==2018 and r['state']=='MN':r['seat']='special'
 r['normalized_probability']=r['probability']
 r['probability']=r['raw_price'] if r['orientation']!='no_complement' else 1-r['raw_price']
 r.pop('priority',None)
 r['observed_at']=datetime.datetime.fromisoformat(r['observed_at']).astimezone(UTC).isoformat().replace('+00:00','Z')
out.sort(key=lambda r:(r['year'],r['state'],r['seat'],r['date'],r['party'],r['market_id']))
def save(name,data):
 if not data:return
 with (B/name).open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(data[0]));w.writeheader();w.writerows(data)
save('odds_all.csv',out)
main=[r for r in out if r['eligible_main'] and r['party'] in ['DEM','REP']];save('odds_main.csv',main)
roster=[]
for key,rr in __import__('itertools').groupby(main,key=lambda r:(r['year'],r['state'],r['seat'])):
 rr=list(rr);roster.append(dict(year=key[0],state=key[1],seat=key[2],first_date=min(r['date'] for r in rr),last_date=max(r['date'] for r in rr),rows=len(rr),market_ids=';'.join(sorted(set(r['market_id'] for r in rr))),contract_types=';'.join(sorted(set(r['contract_type'] for r in rr)))))
save('covered_races.csv',roster);save('market_metadata.csv',list(meta.values()))
summary=dict(main_rows=len(main),main_races=len(roster),coverage_by_year={str(y):[r for r in roster if r['year']==y] for y in ELECTION},all_rows=len(out),notes=['Prices are closing transaction prices, not midquote spreads.','probability retains raw observed close price; named NO uses 1-YES. normalized_probability separately normalizes multi-outcome prices across all listed outcomes, including Other/Independent.','Named incumbent markets retain YES and NO-complement; NO is not exactly opposing-party chance.','Before nomination, named contracts are unconditional on nomination; party contracts describe party, not individual contender.','Daily export date lacks intraday timestamp, so available_at is conservatively next-day 04:59:59 UTC.','2020 hourly data uses last observation each New York day plus one hour as conservative availability.','No election-day or later settled price enters outputs.','No pre-election data-vintage guarantee for retrospectively downloaded exports; source observations are dated historical prices.'])
(B/'coverage.json').write_text(json.dumps(summary,indent=2));print(json.dumps({k:v for k,v in summary.items() if k!='coverage_by_year'},indent=2));print({y:len(v) for y,v in summary['coverage_by_year'].items()})
