import csv,pathlib,collections,json,datetime,hashlib
B=pathlib.Path(__file__).parent
r=list(csv.DictReader((B/'odds_main.csv').open()));allr=list(csv.DictReader((B/'odds_all.csv').open()))
keys=[(x['year'],x['state'],x['seat'],x['date'],x['party']) for x in r]
assert len(keys)==len(set(keys)), 'duplicate race-party-day'
assert all(0<=float(x['probability'])<=1 for x in r)
election={'2016':'2016-11-08','2018':'2018-11-06','2020':'2020-11-03','2022':'2022-11-08'}
assert all(x['date']<election[x['year']] for x in r)
assert all(datetime.datetime.fromisoformat(x['observed_at'].replace('Z','+00:00')).date().isoformat()>=x['date'] for x in r)
assert all(x['market_id']=='6651' for x in r if x['state']=='GA' and x['year']=='2020')
assert all(x['seat']=='special' for x in r if x['state']=='AZ' and x['year']=='2020')
assert all(x['seat']=='special' for x in r if x['state']=='MN' and x['year']=='2018')
files=[]
for p in (B/'raw').rglob('*'):
 if p.is_file():files.append({'path':str(p.relative_to(B)), 'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(B/'source_checksums.json').write_text(json.dumps(files,indent=2))
summary={'checks':'PASS','main_rows':len(r),'main_races':len(set((x['year'],x['state'],x['seat']) for x in r)), 'main_rows_by_cycle':dict(collections.Counter(x['year'] for x in r)), 'contract_type_rows':dict(collections.Counter(x['contract_type'] for x in r)), 'excluded_rows_by_reason':dict(collections.Counter(x['exclusion_reason'] for x in allr if x['eligible_main']=='False')),'ga_regular2020_market':'6651','ga_special2020_market_excluded':'6567','primary_party_before_nomination_is_not_individual_conditional_electability':True}
(B/'qa_summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
