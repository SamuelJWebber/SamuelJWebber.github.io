Historical Senate market odds for market-adjusted donor appeal
Acquired 2026-11-06. Prepared for Samuel Webber's Senate Coattails project.

DELIVERABLE
odds_main.csv: 27,692 dated candidate-party observations, 78 Senate race-cycles.
2016: 12 races; 2018: 20; 2020: 31; 2022: 15.
This is an odds input panel, not a causal estimate or a validated charisma score.
covered_races.csv lists exact dates, state, seat and market IDs. odds_all.csv retains
excluded markets for audit. market_metadata.csv records market definitions.

PROVENANCE
1. k5cents/predelect, commit cc973d5878daeeedd4f6e3b15912f11277817252
   https://github.com/k5cents/predelect
   2016/data/DailyMarketData.zip, 2018/data/DailyMarketData.zip:
   original PredictIt daily OHLCV exports furnished to the archive author under an
   academic research agreement, according to the archive README.
   2020/data/2020.tar.xz: original hourly price captures. The archive README says
   daily collection occurred after 11pm ET; within-file timestamps are UTC.
2. Sawyer Chism and Daniel Gunlogson, Prediction Markets vs. Polls: Which Forecasts
   Elections Better?, replication repository, commit
   7f4a907e64ab3f5f0e1e7c8a4d7e44f0b838fc28
   https://github.com/slchism/Do-Prediction-Markets-Predict-Elections-Better-Than-Polling-
   R Data Analysis/market_timeseries_data.csv and raw_data/polls/market_urls.csv.
   These are archived PredictIt dated daily observations, typically the last90days.
   The analysis imports historical closeSharePrice, not the archive paper's model
   of vote share. Its outcome/actual-vote columns are not used here.
   The archive warns its live API collector no longer works. We download committed
   data only, and do not copy or use that collector's expired cookie.

All actual input files are retained under raw/, with original source bytes and
SHA256 checksums in source_checksums.json. download_manifest.json pins source URLs.
fetch_sources.py downloads data with Python standard library; normalize_odds.py
rebuilds both outputs, then qa_odds.py verifies keys/ranges/timing/seat distinctions.
Run python fetch_sources.py; python normalize_odds.py; python qa_odds.py.
No external Python packages, private credentials, or paid access are required.

PROBABILITY AND TIMING
probability = raw observed closing transaction price for the relevant outcome.
For a named-incumbent YES contract, the modeled opposite outcome is 1-YES and
orientation=no_complement; raw_price still retains the original YES price.
normalized_probability separately divides multi-outcome prices by their sum over
all listed outcomes (including Other or Independent). The main probability column
is deliberately NOT silently normalized. Use normalized_probability as robustness.
price_sum allows inspecting the price overround. These are close transaction prices,
not bid-ask midpoint quotes. Calibration is an explicit project assumption, not a
claim that these archives were empirically perfectly calibrated.

For 2016/2018, prefer primary supplied daily exports. For 2020, prefer original
hourly captures where available, then supplement with the independent daily archive.
For 2022, use the independent daily archive. We do not blend sources within a given
market/day. We restrict all input days to January1 through the day before the general
election, and never use election-day or postelection settled prices. We do not
impute prices outside the observed date range.

Daily exports only report dates. observed_at conservatively treats the close as
available at 23:59:59 fixed UTC-5 on that date (nextday04:59:59UTC). For hourly data,
select the final observed hour within each New York local day and add one hour as a
conservative availability bound. An analysis must join ONLY observations with
observed_at strictly before its donation window. A day-to-week join should also
cap price staleness. Historic transaction prices are dated, but this archive does
not establish every historical download or reporting vintage.

CONTRACT DEFINITIONS
party_unconditional_win describes a PARTY winning the seat, not each contender's
chance of winning conditional on nomination. candidate_unconditional_win describes
a named candidate winning, including nomination risk before the primary. It is not
conditional general-election electability. These distinctions are essential for
any pre-primary causal design. Complement of a named incumbent's YES is not exactly
the opposite party's chance: retirement, primary defeat and third parties can matter.
The corresponding columns must be retained in any analysis or publication.

GEORGIA / SPECIAL SEATS
The actual 2020 source senate_markets.csv identifies:
6651: "Which party wins regular GA Senate race?", source race code GA-S2.
6567: "Which party will win GA Senate special?", source race code GA-S3.
Only 6651 is included in main: Ossoff versus Perdue, July11 through September28.
6567 is excluded because multiple candidates per party contested the special.
5809 is the Arizona2020 special election; Minnesota2018 covered markets refer to
the special seat. No Romney2018 market was found in these archives.
Georgia election-win markets can include subsequent runoff resolution; their
probabilities must not be called probabilities of winning a November vote plurality.
Live old-market pages did not expose readable rule text during this retrieval.

EXCLUSIONS FROM MAIN
Same-party California2016/2018; all Louisiana jungle contests; Vermont/Maine2018
independent incumbents; Jeff Flake2018 (did not run); Mississippi2018 special jungle;
Georgia2020 special jungle; Alaska/Arkansas2020 nonstandard party-candidate mappings;
Utah2022 independent challenger. Duplicated Pennsylvania2018 and Minnesota2018 named
markets are retained in odds_all but the party market is preferred in main.
These exclusions trade coverage for defensible candidate-party assignment. They
are not evidence that omitted candidates have low or high donor appeal.

LIMITS
The panel is not a random sample of Senate races. Listing and archival selection
favor salient or competitive contests. Calendar windows differ across cycles.
2016/2018 contain early-year observations; 2020 starts in July; 2022 in August.
An OOT test must compare common-support windows and hold whole races together.
The large number of daily rows is NOT the number of independent elections.
For causal nomination tests, the usable pre-primary sample is much smaller.
