import urllib.request,json,pathlib,concurrent.futures
base=pathlib.Path(__file__).parent; raw=base/'raw';raw.mkdir(exist_ok=True)
repos=[('k5cents/predelect','cc973d5878daeeedd4f6e3b15912f11277817252'),('slchism/Do-Prediction-Markets-Predict-Elections-Better-Than-Polling-','7f4a907e64ab3f5f0e1e7c8a4d7e44f0b838fc28')]
tasks=[]
for repo,branch in repos:
 d=json.load(urllib.request.urlopen(f'https://api.github.com/repos/{repo}/git/trees/{branch}?recursive=1',timeout=60)); (raw/(repo.split('/')[0]+'_tree.json')).write_text(json.dumps(d))
 print(repo,'commit',d['sha'],flush=True)
 for x in d['tree']:
  p=x['path']
  if x['type']!='blob': continue
  if repo.startswith('k5') or (p.endswith('.csv') and ('market_timeseries_data' in p or 'master_with_actuals' in p or 'market_urls' in p)):
   print(p,x.get('size'),flush=True)
   if p.endswith(('.csv','.zip','.md','.json','.R','.xz')):
    url=f'https://raw.githubusercontent.com/{repo}/{d["sha"]}/{urllib.parse.quote(p)}';dest=raw/repo.split('/')[0]/p;tasks.append((url,dest))
def get(t):
 u,d=t;d.parent.mkdir(parents=True,exist_ok=True)
 try: d.write_bytes(urllib.request.urlopen(u,timeout=90).read());return str(d),d.stat().st_size
 except Exception as e:return str(d),str(e)
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as e:
 for z in e.map(get,tasks):print(z,flush=True)
(raw/'download_manifest.json').write_text(json.dumps([{'url':u,'path':str(d.relative_to(base))} for u,d in tasks],indent=2))
