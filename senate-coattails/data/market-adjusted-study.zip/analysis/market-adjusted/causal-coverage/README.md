# Does the market-adjusted measure support a new causal coattails estimate?

**Not from the recovered close-primary intersection. We executed the join: only two of the 65 existing nomination comparisons have an exact party-win market quote strictly before the donor cutoff. In both, the contender with more disclosed donors lost the primary. There is no treated comparison.**

This is a coverage result, not evidence that coattails are zero or that the proposed donation measure fails.

## Executed coverage

| Category | Primary pairs |
|---|---:|
| Existing frozen donor cohort | 65 |
| Both candidates have observed donor counts | 65 |
| Election years included in retrieved market archives | 14 |
| Exact party-win quote before cutoff, no more than 7 days old | 2 |
| Additional named-opponent re-election proxies before cutoff | 4 |
| Party-win histories begin only after cutoff | 7 |
| No matching market in an otherwise covered year | 1 |
| Earlier election cycles outside the retrieved archives | 51 |

The 14 market-era comparisons comprise five 2018 primaries, two 2020 primaries and seven 2022 primaries. The existing cohort contains no 2016 comparisons.

| Exact match | Broader disclosed-donor contender | Other contender | Donors | Broader-donor result | Primary margin |
|---|---|---|---:|---|---:|
| New Hampshire Republican, 2020 | Don Bolduc | Corky Messner | 558 vs. 242 | Lost | 8.60 pp |
| New Hampshire Republican, 2022 | Chuck Morse | Don Bolduc | 667 vs. 446 | Lost | 1.64 pp |

The main existing five-point window contains only the 2022 New Hampshire comparison. The ten-point window contains both. Neither has observations on both sides of the treatment assignment. We therefore do not fit a new coattails coefficient or manufacture an interval.

Four 2018 comparisons—Michigan, Montana, Wisconsin and West Virginia—have earlier named Democratic-incumbent re-election contracts. The complementary probability is not exactly the probability of a Republican victory before nomination: it can also include a different Democrat winning after a nomination defeat or withdrawal. They are shown separately as an approximate sensitivity category, not relabeled as exact party markets. All four have primary margins above five percentage points.

## What this does and does not adjust

The existing donor data count people over January 1 of the preceding year through 30 days before the primary. A market quote just before that cutoff cannot adjust each earlier donation for the electoral prospects at the time it was made. Neither exact match has odds covering the entire donor window, and the existing paired-candidate cohort provides cumulative counts, not weekly flows for both contenders. These are eligible historical snapshots, not completed weekly market-adjusted primary scores.

Moreover, applying the same positive expected-donation divisor to both same-party contenders does not change their ordering:

`donors_A / expected_race_donors > donors_B / expected_race_donors` if and only if `donors_A > donors_B`.

The same is true when subtracting one common expected log-donation level from both candidates. This correction can improve comparisons across races while leaving the existing within-primary treatment orientation unchanged. Candidate-specific controls or differently timed weekly donor flows can alter rankings; that requires the corresponding data and is not asserted here.

The original broader-donor nomination analysis remains available with its original timing, balance and statistical limitations. It cannot be renamed a validated charisma or all-star causal estimate simply because a shared market adjustment is added.

## Timing and integrity

- Quotes must have a date strictly earlier than the donor cutoff and a conservative `observed_at` timestamp earlier than cutoff-date midnight UTC. The freshest quote must be at most seven days old. This is intentionally conservative about daily closing-price availability.
- Source `probability` values and their original quote/orientation fields are retained. Settled outcomes and future prices are not substituted.
- Historical donor filing availability remains unverified for this cohort. These are retrospective receipt-date donor counts, not a claimed live score available to observers at the time.
- All 65 comparisons, including exclusions, appear in `pair_coverage.csv`. `market_era_pairs.csv` is the 14-row subset; `selected_historical_quotes.csv` preserves matched quote provenance; `causal_window_coverage.csv` reports assignment-arm counts at two-, five- and ten-point windows.
- Input SHA-256 hashes and timing policy are in `summary.json`. The script checks pair identities, pre-cutoff timestamps and the algebraic cancellation property.

## Reproduce

Run from any directory:

```bash
python analysis/market-adjusted/causal-coverage/build_coverage.py \
  --odds analysis/market-adjusted/odds/odds_all.csv
```

The script reads the existing donor and treatment ledgers relative to its own location. Override `--donors`, `--treatment-ledger` or `--output` if the package layout differs. Requires Python, pandas and NumPy.

The odds acquisition provenance is documented in the sibling odds package. This audit uses the exact recovered archive coverage; it does not claim that no additional historical odds exist elsewhere.
