#!/usr/bin/env python3
"""Audit historical-odds overlap with the frozen close-primary donor cohort.

This does not fit a charisma or coattails effect. It distinguishes exact party
contracts from named-candidate contract complements and refuses future quotes.
"""
from pathlib import Path
import argparse
import hashlib
import json
import math
import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def native(obj):
    if isinstance(obj, dict):
        return {str(k): native(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [native(x) for x in obj]
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.floating,)):
        return None if not math.isfinite(float(obj)) else float(obj)
    if isinstance(obj, (np.bool_,)):
        return bool(obj)
    return obj


def boolean(series):
    return series.astype(str).str.lower().eq('true')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--odds', type=Path, default=HERE.parent / 'odds' / 'odds_all.csv')
    parser.add_argument('--donors', type=Path, default=HERE.parents[1] / 'donor-primary' / 'donors' / 'candidate_donor_counts.csv')
    parser.add_argument('--treatment-ledger', type=Path, default=HERE.parents[1] / 'donor-primary' / 'analysis' / 'results' / 'treatment_ledger.csv')
    parser.add_argument('--output', type=Path, default=HERE)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    donors = pd.read_csv(args.donors)
    treatment = pd.read_csv(args.treatment_ledger)
    treatment = treatment[treatment.measure.eq('national_donors')].set_index('pair_id')
    odds = pd.read_csv(args.odds, low_memory=False)
    odds['observed_ts'] = pd.to_datetime(odds.observed_at, utc=True)
    odds['quote_date'] = pd.to_datetime(odds.date)
    rows, quote_rows = [], []
    years = sorted(odds.year.unique().tolist())
    for pair_id, group in donors.groupby('pair_id', sort=True):
        group = group.sort_values('slot')
        assert len(group) == 2 and group.slot.tolist() == [0, 1]
        a, b = group.iloc[0], group.iloc[1]
        assert group[['year', 'state', 'party', 'cutoff_date', 'window_start']].nunique().eq(1).all()
        cutoff = pd.Timestamp(a.cutoff_date, tz='UTC')
        start = pd.Timestamp(a.window_start, tz='UTC')
        q = odds[(odds.year == a.year) & odds.state.eq(a.state)
                 & odds.seat.eq('regular') & odds.party.eq(a.party.upper())].copy()
        exact = q[q.contract_type.eq('party_unconditional_win')].copy()
        approximate = q[q.contract_type.eq('candidate_unconditional_win')].copy()
        valid_time = lambda z: z[(z.observed_ts < cutoff) & (z.observed_ts >= start)
                                 & (z.quote_date < pd.Timestamp(a.cutoff_date))]
        before = valid_time(exact)
        before_approx = valid_time(approximate)
        fresh = before[before.observed_ts >= cutoff - pd.Timedelta(days=7)]
        fresh_approx = before_approx[before_approx.observed_ts >= cutoff - pd.Timedelta(days=7)]
        count_ok = bool(boolean(group.count_observed).all() and boolean(group.source_complete).all()
                        and group.national_donors.notna().all())
        tr = treatment.loc[pair_id]
        r = {
            'pair_id': int(pair_id), 'year': int(a.year), 'state': a.state,
            'party': a.party.upper(), 'name0': str(a['name']).strip(), 'name1': str(b['name']).strip(),
            'candidate_id0': a.candidate_id, 'candidate_id1': b.candidate_id,
            'donors0': int(a.national_donors), 'donors1': int(b.national_donors),
            'both_donor_counts_observed': count_ok,
            'donor_window_start': a.window_start, 'donor_cutoff_date': a.cutoff_date,
            'primary_date': a.primary_date,
            'abs_primary_margin_pp': float(abs(tr.margin_pp)),
            'higher_donor_slot': int(tr.higher_donor_slot),
            'higher_donor_won': bool(tr.treatment),
            'official_primary_verified': bool(tr.official_primary_verified),
            'filing_asof_verified': bool(boolean(group.filing_asof_verified).all()),
            'has_any_market_for_race': bool(len(q)),
            'has_exact_party_contract': bool(len(exact)),
            'has_exact_precutoff_quote': bool(len(before)),
            'has_fresh_exact_precutoff_quote': bool(len(fresh)),
            'has_named_candidate_precutoff_proxy': bool(len(before_approx)),
            'has_fresh_named_candidate_precutoff_proxy': bool(len(fresh_approx)),
            'exact_precutoff_quote_days': int(before.date.nunique()),
            'named_proxy_precutoff_quote_days': int(before_approx.date.nunique()),
            'exact_market_first_observed_at': exact.observed_at.min() if len(exact) else '',
            'named_market_first_observed_at': approximate.observed_at.min() if len(approximate) else '',
            'exact_full_donor_window_covered': bool(len(before) and before.observed_ts.min() <= start + pd.Timedelta(days=1)),
            'paired_weekly_donor_flows_in_existing_cohort': False,
            'exact_pair_coverage': bool(len(fresh) and count_ok),
        }
        if len(fresh):
            category = 'exact_party_quote_before_cutoff'
            selected = fresh.sort_values(['observed_ts', 'market_id']).iloc[-1]
        elif len(before):
            category = 'exact_party_quote_stale_over_7_days'
            selected = before.sort_values(['observed_ts', 'market_id']).iloc[-1]
        elif len(fresh_approx):
            category = 'named_opponent_proxy_only'
            selected = fresh_approx.sort_values(['observed_ts', 'market_id']).iloc[-1]
        elif len(before_approx):
            category = 'named_opponent_proxy_stale_over_7_days'
            selected = before_approx.sort_values(['observed_ts', 'market_id']).iloc[-1]
        elif len(exact):
            category = 'party_market_only_after_cutoff'
            selected = None
        elif len(q):
            category = 'named_market_only_after_cutoff'
            selected = None
        elif a.year not in years:
            category = 'cycle_outside_available_market_archives'
            selected = None
        else:
            category = 'no_matched_market_in_available_archive'
            selected = None
        r['coverage_status'] = category
        if selected is not None:
            for column in ['market_id', 'market_title', 'contract_type', 'named_candidate',
                           'date', 'observed_at', 'raw_price', 'probability', 'volume', 'orientation', 'source']:
                r['selected_' + column] = selected[column]
            r['selected_quote_age_days'] = (cutoff - selected.observed_ts).total_seconds() / 86400
            quote_rows.append({'pair_id': int(pair_id), 'cutoff_date': a.cutoff_date,
                               **selected.drop(['observed_ts', 'quote_date']).to_dict()})
        rows.append(r)
    ledger = pd.DataFrame(rows)
    quotes = pd.DataFrame(quote_rows)
    ledger.to_csv(args.output / 'pair_coverage.csv', index=False)
    ledger[ledger.year.isin(years)].to_csv(args.output / 'market_era_pairs.csv', index=False)
    quotes.to_csv(args.output / 'selected_historical_quotes.csv', index=False)
    exact = ledger[ledger.exact_pair_coverage]
    broad = ledger[ledger.exact_pair_coverage | ledger.has_fresh_named_candidate_precutoff_proxy]
    windows = []
    for label, subset in [('exact_party_contracts', exact), ('including_named_opponent_proxies', broad)]:
        for width in [2, 5, 10]:
            s = subset[subset.abs_primary_margin_pp < width]
            treated = int(s.higher_donor_won.sum())
            windows.append({'contract_sample': label, 'bandwidth_pp': width, 'pairs': len(s),
                            'higher_donor_wins': treated, 'higher_donor_losses': len(s) - treated,
                            'states': int(s.state.nunique()), 'both_assignment_arms': bool(treated and len(s) > treated),
                            'causal_estimate': None,
                            'reason_no_new_causal_estimate': 'No treated observations' if not treated else
                            'No control observations' if treated == len(s) else
                            'Named-candidate complements are approximate party odds; few races, full donation-window odds and paired weekly flows unavailable'})
    pd.DataFrame(windows).to_csv(args.output / 'causal_window_coverage.csv', index=False)
    summary = {
        'analysis': 'Frozen donor-primary cohort historical-market coverage, not a new causal estimate',
        'cohort_pairs': len(ledger), 'candidate_rows': len(donors), 'market_archive_years': years,
        'pairs_in_market_archive_years': int(ledger.year.isin(years).sum()),
        'all_pair_counts_observed': bool(ledger.both_donor_counts_observed.all()),
        'coverage_status_counts': ledger.coverage_status.value_counts().to_dict(),
        'exact_party_quote_and_two_donor_counts': len(exact),
        'exact_matched_pair_ids': exact.pair_id.tolist(),
        'exact_matched_states': sorted(exact.state.unique().tolist()),
        'exact_high_donor_wins': int(exact.higher_donor_won.sum()),
        'exact_high_donor_losses': int((~exact.higher_donor_won).sum()),
        'additional_named_opponent_proxy_pairs': int(ledger.has_fresh_named_candidate_precutoff_proxy.sum()),
        'exact_full_donor_window_covered_pairs': int(ledger.exact_full_donor_window_covered.sum()),
        'strict_historical_filing_asof_verified_pairs': int(ledger.filing_asof_verified.sum()),
        'cutoff_policy': 'Quote date strictly earlier than donor cutoff date, and conservative observed_at strictly earlier than cutoff date 00:00 UTC; freshest quote must be at most 7 days old.',
        'snapshot_not_flow_adjustment': 'A quote before a cumulative-donor cutoff does not adjust every prior donation for its contemporaneous odds. The two exact matches have only partial odds histories and the existing cohort contains cumulative counts, not paired weekly flows.',
        'within_pair_cancellation': 'For a common positive expected-donation divisor E_r shared by both same-party contenders, D_A/E_r > D_B/E_r iff D_A > D_B. Common subtraction from log counts likewise cannot change orientation. Weekly weight changes or candidate-specific controls can change rankings and need their own data.',
        'causal_result': 'No market-covered causal nomination estimate: both exact-contract matches are higher-donor losses, so there is no treated comparison.',
        'reusable_prior_analysis': 'The existing broader-donor nomination estimates may be reused only under their original label and caveats. Common market adjustment does not make them a newly validated all-star or charisma effect.',
        'windows': windows,
        'input_sha256': {'odds_all.csv': digest(args.odds), 'candidate_donor_counts.csv': digest(args.donors),
                         'treatment_ledger.csv': digest(args.treatment_ledger)},
        'script_sha256': digest(__file__),
    }
    (args.output / 'summary.json').write_text(json.dumps(native(summary), indent=2) + '\n')
    assert ledger.pair_id.nunique() == 65
    assert ledger.both_donor_counts_observed.all()
    assert all(pd.Timestamp(r['selected_observed_at']) < pd.Timestamp(r['donor_cutoff_date'], tz='UTC')
               for r in rows if 'selected_observed_at' in r)
    # Verify the stated cancellation property over every pair and arbitrary positive common divisors.
    divisors = np.array([0.1, 1.0, 4.0, 10000.0])
    for r in rows:
        assert np.all((r['donors0'] / divisors > r['donors1'] / divisors)
                      == (r['donors0'] > r['donors1']))
    print(json.dumps(native({k: summary[k] for k in ['cohort_pairs', 'pairs_in_market_archive_years',
          'coverage_status_counts', 'exact_matched_pair_ids', 'exact_high_donor_wins', 'exact_high_donor_losses']}), indent=2))


if __name__ == '__main__':
    main()
