# Market-adjusted donor appeal: analysis plan

This plan was written before computing the new market-adjusted results. It is an analysis plan, not an externally registered protocol.

## Estimand and scope

Measure individual donor support above the level predicted by electoral prospects and predetermined context. The score is **conditional donor appeal**, not a causal estimate of charisma or coattails. The available cohort consists of eventual major-party US Senate nominees; it cannot retrospectively label losing primary contenders.

Historical prediction-market probabilities are accepted as the user-specified measure of perceived competitiveness. We do not test market calibration here. Donation data are retrospective FEC bulk extracts indexed by receipt date, not historical disclosure snapshots. Therefore later-cycle evaluation is out-of-time by election cohort, but not a vintage-safe real-time backtest.

## Sample and timing

Use complete seven-day donation weeks within August 1 through September 28 of each available even-year election cycle. This common cutoff precedes the general election and avoids extending beyond the recovered 2020 market archive. Match each week to the latest eligible market observation strictly before its beginning; discard prices older than seven days. Use the intersection of observed weeks for both major-party nominees in each regular state-election. Require at least four matched weeks. Special, multi-candidate, and ambiguous nominee markets remain excluded from the primary paired analysis and are reported in the coverage ledger.

The proposed donation measures are (1) approximate distinct disclosed donors first observed in the current election cycle, nationally, (2) first observed in the in-state subset, (3) positive individual transactions, and (4) positive itemized individual dollars. A person is not known to be new to politics or new to the campaign merely because they are first observed in the two-year file. Unique identities approximate normalized name plus ZIP. Counts omit unitemized people and inherit disclosure/amendment limitations. Publish aggregates only.

## Expected donation model

Fit fixed ridge regressions (alpha=10) to log(1 + weekly measure). Base covariates: log prior-census population, party, incumbent status, prior presidential state lean relative to the national result, weeks until election, and linear cycle trend. The market model adds probability, probability squared and probability cubed. Probability terms are candidate-oriented. Standardization and missing-value imputation are fitted only on training observations; no candidate fixed effects are used. Convert to arithmetic expected values using a training-only residual smearing factor. No final odds, election result, or same-election teammate outcome enters this model.

The first available election cohort receives five-fold whole-state-election cross-fitted expectations. Every subsequent cohort receives predictions fitted solely on earlier cycles. Both nominees and all their weeks remain in the same fold. Donation forecast comparisons report out-of-fold/out-of-time log mean absolute error and aggregate absolute error relative to actual volume. Election-year results are reported individually; no post-hoc model selection.

## Scores and validation

The market-adjusted score is log((sum observed + 1)/(sum expected + 1)) over a candidate's matched weeks. Display the unregularized observed/expected ratio with the denominator and coverage. This displayed ratio differs from the +1-smoothed log score used in regressions, especially for sparse cells. Also retain raw support per population and the adjustment without market odds. Do not combine donor measures based on downstream election results.

Score stability compares first and second halves of the same observed window. This is reliability evidence, not evidence of personal charisma.

The independent appeal target originally desired—paired same-opponent polling, candidate favorability or comparable personal-appeal measures—is not available in the recovered panel. A secondary exploratory criterion predicts a held-out election's Democratic two-party Senate vote share from predetermined lean, incumbency and cutoff odds, then adds the paired donor-score difference. Such a test mixes candidate appeal, opponent characteristics and common political conditions; it is not independent charisma validation. Only report genuinely later-cycle predictions; do not use this outcome to choose the donation specification.

## Causality

No claim of causal coattails follows from these regressions. A future close-primary design requires the score frozen for both primary contenders before their contest, including candidates who lose. Post-primary nominees' fundraising cannot supply that treatment label. Do not condition a future total-coattails outcome regression on post-nomination odds, turnout or spending without a separate causal rationale.

## Bounded sensitivity checks

Before the full multi-cycle result run, add normalized contract probabilities and fixed ridge alpha 1 and 100 as sensitivity checks. The primary remains raw reported prices and alpha 10. These variants are reported, never used to select a winner. Only 2016 cross-fit output had been inspected when this sensitivity plan was added.
