# Market-adjusted donation analysis

The primary result reconstructs weekly individual receipts for **71 regular Senate races, 142 eventual major-party nominees, and 1,048 candidate-weeks** across 2016, 2018, 2020 and 2022. It uses complete Monday–Sunday weeks within August 1–September 28 and requires at least four weeks observed for both nominees. Prices must precede the donation week and be no more than seven days old.

## Reproduce

From the repository root (or the released bundle's matching root):

```bash
python analysis/market-adjusted/model/analyze.py \
  --donations analysis/market-adjusted/donations/weekly_donations_2016.csv \
    analysis/market-adjusted/donations/weekly_donations_2018.csv \
    analysis/market-adjusted/donations/weekly_donations_2020.csv \
    analysis/market-adjusted/donations/weekly_donations_2022.csv \
  --odds analysis/market-adjusted/odds/odds_main.csv
```

Dependencies: Python 3, NumPy, pandas, SciPy and scikit-learn. The source-data acquisition code and manifests are in the sibling `donations/` and `odds/` directories. No identity-level donor records are published.

Repeat the command with these fixed sensitivity flags, keeping the same inputs:

```text
--normalized-odds --results-dir analysis/market-adjusted/model/sensitivity/normalized
--alpha 1 --results-dir analysis/market-adjusted/model/sensitivity/alpha1
--alpha 100 --results-dir analysis/market-adjusted/model/sensitivity/alpha100
```

Then run `python analysis/market-adjusted/model/summarize_sensitivity.py` to merge the fixed robustness checks into `results/dashboard.json`. No sensitivity result is used to choose a winning specification.

## What the scores mean

The primary breadth measure counts approximate disclosed identities first observed in the current two-year election cycle. The in-state counterpart counts the first appearance in the in-state subset; a mover can already have appeared out of state. Neither measure is a complete census of donors or a count of first-ever supporters. Transaction counts and dollar sums are retained positive individual receipt rows and gross recorded dollars, not net fundraising.

Expected values come from log(1 + weekly measure) ridge regression, including population, prior presidential state lean, party, incumbency, time, cycle trend, and a cubic in lagged candidate-oriented market probability. Training residual smearing converts predictions to arithmetic expectations. Earliest-cycle expectations are whole-race cross-fitted; later cycles use only earlier cycles. The displayed ratio is observed / expected. Regressions use the separate +1-smoothed log ratio.

## Results and interpretation

- Adding odds lowers national first-observed donor-flow log MAE by **14.72% in 2020** and **40.03% in 2022**, versus context alone on identical rows.
- Market-adjusted support does **not** beat raw support in the primary own-vote checks: 2020 MAE is **2.711 vs 2.657 percentage points**; 2022 is **2.074 vs 1.894**. The paired error differences are imprecise. This is a secondary predictive check, not an independent candidate-appeal measurement.
- Jon Ossoff's August 3–September 27, 2020 national first-observed disclosed donor count is **9,686**, against **2,742.38 expected** (**3.532×**). His in-state count is **934**, against **1,236.16 expected** (**0.756×**). These are conditional donor-support ratios, not votes added or charisma effects.
- Fixed price-normalization and shrinkage sensitivities preserve the donor-flow prediction improvement. They do not establish a robust own-vote advantage for adjustment.
- The score is not causal: it can reflect networks, ideology, opponent dislike and campaign effort. Current bulk data incorporate retrospective amendments and itemization, so the temporal evaluation is **not a historical-vintage real-time backtest**.

`PROTOCOL.md` records the pre-result specification and the timing of the bounded sensitivity addition. `IMPLEMENTATION_AUDIT.md` records two corrected implementation errors caught before publication: using mean rather than cutoff odds in the secondary vote criterion, and joining a Minnesota special-election contract to regular-election nominees. Published rows explicitly assert regular-seat provenance, named-candidate identity and pre-window market timing.

## Output inventory

- `model_panel.csv`: exact matched candidate-week input, including source market title, seat, timestamps, baseline covariates and support amounts.
- `weekly_predictions.csv`: cross-fitted and out-of-time predictions, training cycles and smearing factors.
- `candidate_scores.csv`: observed/expected support and ratios, raw and context-only comparators, matched windows.
- `donation_metrics.csv`: fixed-row fundraising forecast errors.
- `vote_validation_panel.csv`, `vote_predictions.csv`, `vote_metrics.csv`: secondary own-vote criterion and paired bootstrap intervals.
- `candidate_fundamentals.csv`, `named_market_audit.csv`, `coverage.csv`: mapping and coverage checks.
- `score_stability.csv`: first-half/second-half rank correlations; reliability, not causal validity.
- `sensitivity_summary.csv`, `ossoff_sensitivity.csv`: all fixed robustness comparisons.
- `run_manifest.json`: exact input hashes, probability convention, ridge penalty and sample size.

All numerical results are conditional on this limited market-covered sample. The coattail identification audit is a separate sibling directory and does not report an estimated causal effect for this score.
