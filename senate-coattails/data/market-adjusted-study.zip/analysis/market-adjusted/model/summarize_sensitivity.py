#!/usr/bin/env python3
"""Combine fixed, unselected robustness runs into the public result payload."""
from pathlib import Path
import json
import pandas as pd

B=Path(__file__).resolve().parent
variants={'main_raw_alpha10':B/'results','normalized_prices_alpha10':B/'sensitivity/normalized','raw_alpha1':B/'sensitivity/alpha1','raw_alpha100':B/'sensitivity/alpha100'}
rows=[];rank=[]
for name,p in variants.items():
    d=pd.read_csv(p/'donation_metrics.csv');v=pd.read_csv(p/'vote_metrics.csv');s=pd.read_csv(p/'candidate_scores.csv')
    for year in [2020,2022]:
        a=d[(d.measure=='national_new_donors')&(d.year==year)].set_index('model')
        b=v[(v.measure=='national_new_donors')&(v.year==year)].set_index('model')
        rows.append({'variant':name,'year':year,'context_log_mae':a.loc['context','log_mae'],'market_log_mae':a.loc['market','log_mae'],'donation_error_improvement_pct':100*(a.loc['context','log_mae']-a.loc['market','log_mae'])/a.loc['context','log_mae'],'raw_vote_mae_pp':b.loc['raw_support','mae_pp'],'adjusted_vote_mae_pp':b.loc['market_adjusted','mae_pp'],'adjusted_vs_raw_gain_pp':b.loc['market_adjusted','gain_vs_raw_pp']})
    for measure in ['national_new_donors','in_state_new_donors']:
        x=s[(s.benchmark_candidate=='JON OSSOFF')&(s.year==2020)&(s.model=='market')&(s.measure==measure)].iloc[0]
        rank.append({'variant':name,'candidate':'Jon Ossoff','year':2020,'measure':measure,'actual':x.actual,'expected':x.expected,'ratio':x.ratio})
frame=pd.DataFrame(rows);frame.to_csv(B/'results/sensitivity_summary.csv',index=False)
pd.DataFrame(rank).to_csv(B/'results/ossoff_sensitivity.csv',index=False)
out={'variants':rows,'ossoff':rank,'selection':'No variant selected on these results. Raw prices and alpha10 remain primary.','note':'Contract normalization and ridge alpha1/100 are fixed sensitivity checks. Alpha changes both donation and own-vote model shrinkage. The main result is not an estimate of causal charisma.'}
(B/'results/sensitivity_summary.json').write_text(json.dumps(out,indent=2)+'\n')
obj=json.loads((B/'results/dashboard.json').read_text())
obj['sensitivity']=out
national=[r['ratio'] for r in rank if r['measure']=='national_new_donors']
local=[r['ratio'] for r in rank if r['measure']=='in_state_new_donors']
sentence=f"Fixed sensitivity checks preserve better national donor-flow prediction with odds in both test cycles. Ossoff’s national observed/expected ratio ranges from {min(national):.2f}× to {max(national):.2f}×, while his in-state ratio ranges from {min(local):.2f}× to {max(local):.2f}×. The own-vote ranking is not robust evidence of an advantage for adjustment."
obj['limitations'].append(sentence)
obj['tests']['fundraising']+=' Normalizing contract prices and using fixed ridge penalties of 1 or 100 preserve the direction in both test cycles.'
obj['tests']['appeal']+=' Fixed normalization and shrinkage checks do not establish a robust predictive advantage for the adjusted measure.'
(B/'results/dashboard.json').write_text(json.dumps(obj,indent=2)+'\n')
print(json.dumps(out,indent=2))
