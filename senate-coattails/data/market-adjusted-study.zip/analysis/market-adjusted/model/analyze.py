#!/usr/bin/env python3
"""Reproduce market-adjusted donation scores; no causal coattail estimand is fitted."""
from pathlib import Path
import argparse, json, hashlib, math, warnings
import numpy as np
import pandas as pd
from sklearn.linear_model import Ridge
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.model_selection import GroupKFold

HERE=Path(__file__).resolve().parent
REPO=HERE.parents[1]  # analysis directory; all inputs remain repository-relative
RESULTS=HERE/'results'
ALPHA=10.
BASE_FEATURES=['log_population','democrat','incumbent','party_prior_lean','weeks_until_election','cycle_trend']
MARKET_FEATURES=BASE_FEATURES+['p','p2','p3']
MEASURES={'national_new_donors':'National first-observed disclosed donors','in_state_new_donors':'First observed in-state disclosed donors','transactions':'Positive individual receipt rows','dollars':'Gross positive itemized individual dollars'}

def clean_json(x):
    if isinstance(x,dict):return {str(k):clean_json(v) for k,v in x.items()}
    if isinstance(x,list):return [clean_json(v) for v in x]
    if isinstance(x,(np.integer,)):return int(x)
    if isinstance(x,(np.floating,float)):return float(x) if np.isfinite(x) else None
    if isinstance(x,(np.bool_,)):return bool(x)
    return x

def write_json(path,data):path.write_text(json.dumps(clean_json(data),indent=2)+'\n')

def normalize_name(name):
    import re
    words=re.sub('[^A-Z ]',' ',str(name).upper()).split()
    words=[w for w in words if w not in {'JR','SR','II','III','IV','DR'}]
    return ' '.join(words)

def candidate_key(name,state):
    import sys
    sys.path.insert(0,str(REPO/'stage3/score'))
    from core import candidate_key as ck
    return ck(name,state)

def fundamentals():
    mapping=pd.read_csv(REPO/'stage3/fundraising/nominee_fec_mapping.csv')
    mapping=mapping[mapping.year.isin([2016,2018,2020,2022])].copy()
    sen=pd.read_csv(HERE/'inputs/mit_senate.tsv',sep='\t')
    pres=pd.read_csv(HERE/'inputs/mit_president.csv')
    pres=pres[pres.party_simplified.isin(['DEMOCRAT','REPUBLICAN'])]
    pp=pres.groupby(['state_po','year','party_simplified']).candidatevotes.sum().unstack()
    pp['share']=pp.DEMOCRAT/(pp.DEMOCRAT+pp.REPUBLICAN)
    national=pp.groupby('year')[['DEMOCRAT','REPUBLICAN']].sum()
    national['national']=national.DEMOCRAT/(national.DEMOCRAT+national.REPUBLICAN)
    pp=pp.join(national.national,on='year');pp['prior_pres_lean']=pp['share']-pp.national
    pp=pp.reset_index()[['state_po','year','prior_pres_lean']].rename(columns={'state_po':'state_abbrev','year':'pres_year'})
    mapping['pres_year']=mapping.year.map(lambda y:y-1-(y-1)%4)
    mapping=mapping.merge(pp,on=['state_abbrev','pres_year'],how='left',validate='many_to_one')
    pop=pd.read_csv(REPO/'stage3/population/prior_census_population.csv')
    mapping=mapping.merge(pop,on=['state_abbrev','year'],how='left',validate='many_to_one')
    # Eligibility: the existing audited one-nominee-per-major-party regular-race spine.
    ret=pd.read_csv(REPO/'stage3/inputs/mit_senate_nominee_returns.csv')
    mapping=mapping.merge(ret[['state_abbrev','year','dshare']],on=['state_abbrev','year'],how='inner',validate='many_to_one')
    # Known electoral history, never current-race outcomes: candidate won a Senate
    # contest in the preceding six years. Special elections are included here.
    old=sen.dropna(subset=['candidate']).copy()
    old['person']=[candidate_key(n,s) for n,s in zip(old.candidate,old.state_po)]
    old['stage_rank']=old.stage.astype(str).str.lower().map({'pre':0,'gen':1,'runoff':2}).fillna(1)
    vot=old.groupby(['state_po','year','special','stage_rank','person'],as_index=False).candidatevotes.sum()
    winner=vot.sort_values(['stage_rank','candidatevotes']).groupby(['state_po','year','special']).tail(1)
    incumb=[]
    for r in mapping.itertuples():
        key=candidate_key(r.benchmark_candidate,r.state_abbrev)
        match=winner[(winner.state_po==r.state_abbrev)&(winner.year<r.year)&(winner.year>=r.year-6)&(winner.person==key)]
        incumb.append(int(len(match)>0))
    mapping['incumbent']=incumb
    mapping['incumbency_source']='earlier Senate winner identity within six years; includes special elections'
    mapping['incumbent_history_inferred']=incumb
    # Named appointment exception fixed before seeing market-adjusted results.
    padilla=(mapping.year==2022)&(mapping.state_abbrev=='CA')&(mapping.party=='D')
    mapping.loc[padilla,'incumbent']=1
    mapping.loc[padilla,'incumbency_source']='appointed January 2021; https://www.senate.gov/senators/senators-contact.htm'
    cn=[]
    for year in [2016,2018,2020,2022]:
        p=REPO/f'market-adjusted/donations/candidate_roster_{year}.csv'
        if p.exists():
            r=pd.read_csv(p);r=r[r.election_year.eq(year)].copy();r['year']=year
            cn.append(r[['candidate_id','year','incumbent_status']])
    if cn:
        mapping=mapping.merge(pd.concat(cn),on=['candidate_id','year'],how='left',validate='one_to_one')
        valid=mapping.incumbent_status.isin(['I','C','O'])
        mapping.loc[valid,'incumbent']=mapping.loc[valid,'incumbent_status'].eq('I').astype(int)
        mapping.loc[valid,'incumbency_source']='Official FEC cycle-specific CN; CAND_ELECTION_YR equals election cycle'
        mapping['incumbency_disagrees_history']=mapping.incumbent.ne(mapping.incumbent_history_inferred)
    mapping['race_id']=mapping.state_abbrev+'-'+mapping.year.astype(str)
    mapping.to_csv(RESULTS/'candidate_fundamentals.csv',index=False)
    return mapping

def load_panel(donation_path,odds_path,normalized=False):
    d=pd.concat([pd.read_csv(p) for p in donation_path],ignore_index=True)
    odds=pd.read_csv(odds_path)
    # The nominee spine contains regular seats only. A same-state special-seat
    # contract is a different election and must never be joined by state alone.
    odds=odds[odds.seat.eq('regular')].copy()
    if 'candidate_name' in d:d=d.rename(columns={'candidate_name':'fec_name'})
    d['week_start']=pd.to_datetime(d.week_start)
    d['week_end']=pd.to_datetime(d.week_end)
    f=fundamentals()
    named_audit=[]
    for r in odds[['year','state','market_id','named_candidate']].dropna(subset=['named_candidate']).drop_duplicates().itertuples():
        names=f[(f.year==r.year)&(f.state_abbrev==r.state)]
        matches=any(candidate_key(r.named_candidate,r.state)==candidate_key(n,r.state) for n in names.benchmark_candidate)
        named_audit.append({'year':r.year,'state':r.state,'market_id':r.market_id,'named_candidate':r.named_candidate,'matches_regular_nominee':matches,'regular_nominee_names':' | '.join(names.benchmark_candidate)})
        if len(names) and not matches:raise ValueError(f'Named market does not describe the regular nominee: {r.market_id}')
    pd.DataFrame(named_audit).to_csv(RESULTS/'named_market_audit.csv',index=False)
    # Retain only the precise FEC ID associated with the audited eventual nominee.
    keep=['candidate_id','year','state_abbrev','party','benchmark_candidate','prior_pres_lean','prior_census_population','incumbent','dshare','race_id']
    d=d.drop(columns=[c for c in keep if c in d and c not in ['candidate_id','year']],errors='ignore').merge(f[keep],on=['candidate_id','year'],how='inner',validate='many_to_one')
    d['candidate_key']=d.candidate_id+'-'+d.year.astype(str)
    complete=(d.week_end-d.week_start).dt.days.eq(6)
    if 'window_start' in d:complete &= pd.to_datetime(d.window_start).eq(d.week_start)
    if 'window_end' in d:complete &= pd.to_datetime(d.window_end).eq(d.week_end)
    win=(d.week_start>=pd.to_datetime(d.year.astype(str)+'-08-01'))&(d.week_end<=pd.to_datetime(d.year.astype(str)+'-09-28'))
    d=d[complete&win].copy()
    odds['party']=odds.party.replace({'DEM':'D','REP':'R'})
    odds=odds[odds.party.isin(['D','R'])].copy()
    odds['observed_at']=pd.to_datetime(odds.observed_at,utc=True)
    if normalized:odds['probability']=odds.normalized_probability
    rows=[]
    for (state,year,party),g in d.groupby(['state_abbrev','year','party']):
        o=odds[(odds.state==state)&(odds.year==year)&(odds.party==party)].sort_values('observed_at')
        if len(o)==0:continue
        if o.observed_at.duplicated().any():raise ValueError(f'Duplicate odds {state} {year} {party}')
        g=g.sort_values('week_start').copy()
        # US candidate receipt dates lack time-of-day: lag strictly before UTC
        # start of the first date, a conservative restriction across US zones.
        g['week_available_at']=g.week_start.dt.tz_localize('UTC')
        joined=pd.merge_asof(g,o[['observed_at','probability','market_id','contract_type','orientation','source','seat','market_title','named_candidate']],left_on='week_available_at',right_on='observed_at',direction='backward',allow_exact_matches=False,tolerance=pd.Timedelta(days=7))
        cutoff=pd.Timestamp(f'{year}-09-29',tz='UTC')
        forecast_odds=o[(o.observed_at<cutoff)&(o.observed_at>=cutoff-pd.Timedelta(days=7))]
        joined['forecast_probability']=forecast_odds.probability.iloc[-1] if len(forecast_odds) else np.nan
        joined['forecast_odds_observed_at']=forecast_odds.observed_at.iloc[-1] if len(forecast_odds) else pd.NaT
        rows.append(joined)
    d=pd.concat(rows,ignore_index=True)
    coverage=d.groupby(['race_id','year','state_abbrev'],as_index=False).agg(candidate_weeks=('candidate_key','size'),observed_prices=('probability','count'))
    d=d.dropna(subset=['probability'])
    # Every included week must be observable for both nominees, preserving
    # identical measurement windows in the paired outcome comparison.
    pair=d.groupby(['race_id','week_start']).party.nunique()
    keys=pair[pair.eq(2)].reset_index()[['race_id','week_start']]
    d=d.merge(keys,on=['race_id','week_start'],validate='many_to_one')
    size=d.groupby('race_id').week_start.nunique()
    allowed=size[size>=4].index
    d=d[d.race_id.isin(allowed)].copy()
    coverage=coverage.merge(size.rename('matched_weeks'),on='race_id',how='left')
    coverage['included']=coverage.race_id.isin(allowed)
    coverage.to_csv(RESULTS/'coverage.csv',index=False)
    d['p']=d.probability.astype(float);d['p2']=d.p**2;d['p3']=d.p**3
    d['log_population']=np.log(d.prior_census_population)
    d['democrat']=d.party.eq('D').astype(int)
    d['party_prior_lean']=d.prior_pres_lean*np.where(d.party.eq('D'),1,-1)
    def election(y):
        dt=pd.Timestamp(f'{y}-11-01');return dt+pd.Timedelta(days=(7-dt.weekday())%7+1)
    d['weeks_until_election']=[(election(y)-w).days/7 for y,w in zip(d.year,d.week_start)]
    d['cycle_trend']=(d.year-2016)/2
    assert (d.observed_at<d.week_available_at).all()
    assert d.seat.eq('regular').all()
    assert d.groupby(['race_id','week_start']).size().eq(2).all()
    assert not d.duplicated(['candidate_key','week_start']).any()
    d.to_csv(RESULTS/'model_panel.csv',index=False)
    return d

def fit_predict(train,test,target,features):
    y=np.log1p(train[target].astype(float).to_numpy())
    model=make_pipeline(SimpleImputer(strategy='median'),StandardScaler(),Ridge(alpha=ALPHA))
    model.fit(train[features],y)
    z=model.predict(test[features]);fit=model.predict(train[features])
    # Duan smearing factor fitted exclusively to the training sample.
    smear=float(np.exp(y-fit).mean())
    expected=np.maximum(np.exp(np.clip(z,-20,25))*smear-1,0)
    return z,expected,smear

def donation_predictions(d):
    out=[]
    for year in sorted(d.year.unique()):
        test=d[d.year==year].copy();old=d[d.year<year]
        if len(old):folds=[(old,test,'out_of_time')]
        else:
            k=min(5,test.race_id.nunique())
            if k<2:continue
            folds=[(test.iloc[a],test.iloc[b],'race_crossfit') for a,b in GroupKFold(k).split(test,groups=test.race_id)]
        for fold,(train,valid,kind) in enumerate(folds):
            for target in MEASURES:
                for name,features in [('context',BASE_FEATURES),('market',MARKET_FEATURES)]:
                    z,expected,smear=fit_predict(train,valid,target,features)
                    r=valid.copy();r['measure']=target;r['model']=name;r['expected_log1p']=z;r['expected']=expected;r['actual']=valid[target].astype(float).to_numpy()
                    r['training_years']=','.join(str(v) for v in sorted(train.year.unique()));r['training_races']=train.race_id.nunique();r['validation']=kind;r['fold']=fold;r['smearing_factor']=smear
                    out.append(r)
    pred=pd.concat(out,ignore_index=True)
    pred.to_csv(RESULTS/'weekly_predictions.csv',index=False)
    metrics=[]
    for (year,measure,model,kind),g in pred.groupby(['year','measure','model','validation']):
        e=np.log1p(g.actual)-g.expected_log1p
        metrics.append({'test':'Donation forecast','year':year,'measure':measure,'model':model,'validation':kind,'candidate_weeks':len(g),'races':g.race_id.nunique(),'log_mae':abs(e).mean(),'log_rmse':np.sqrt(np.mean(e**2)),'aggregate_absolute_error_ratio':abs(g.actual-g.expected).sum()/max(g.actual.sum(),1),'actual_sum':g.actual.sum(),'expected_sum':g.expected.sum()})
    pd.DataFrame(metrics).to_csv(RESULTS/'donation_metrics.csv',index=False)
    return pred,pd.DataFrame(metrics)

def scores(pred):
    keys=['year','state_abbrev','race_id','candidate_id','candidate_key','benchmark_candidate','party','measure','model','validation','training_years']
    pred=pred.sort_values(['candidate_key','week_start'])
    s=pred.groupby(keys,as_index=False).agg(actual=('actual','sum'),expected=('expected','sum'),weeks=('week_start','nunique'),window_start=('week_start','min'),window_end=('week_end','max'),mean_probability=('p','mean'),min_probability=('p','min'),max_probability=('p','max'),last_week_probability=('p','last'),cutoff_probability=('forecast_probability','first'),population=('prior_census_population','first'),prior_pres_lean=('prior_pres_lean','first'),incumbent=('incumbent','first'),dshare=('dshare','first'))
    s['ratio']=s.actual/s.expected.replace(0,np.nan)
    s['score']=np.log1p(s.actual)-np.log1p(s.expected)
    s['raw_log_per100k']=np.log1p(s.actual/s.population*1e5)
    s.to_csv(RESULTS/'candidate_scores.csv',index=False)
    stability=[]
    for (year,measure,model),g in pred.groupby(['year','measure','model']):
        halves=[]
        for key,x in g.groupby('candidate_key'):
            x=x.sort_values('week_start');mid=len(x)//2
            vals=[]
            for half in [x.iloc[:mid],x.iloc[mid:]]:vals.append(float(np.log1p(half.actual.sum())-np.log1p(half.expected.sum())))
            halves.append(vals)
        h=pd.DataFrame(halves,columns=['first','last'])
        stability.append({'year':year,'measure':measure,'model':model,'candidates':len(h),'spearman_first_second_half':h.corr(method='spearman').iloc[0,1]})
    stab=pd.DataFrame(stability);stab.to_csv(RESULTS/'score_stability.csv',index=False)
    return s,stab

def vote_validation(s):
    market=s[s.model=='market'];context=s[s.model=='context']
    v=market.merge(context[['candidate_key','measure','score']],on=['candidate_key','measure'],suffixes=('','_context'),validate='one_to_one')
    rows=[]
    for (race,measure),g in v.groupby(['race_id','measure']):
        if set(g.party)!= {'D','R'}:continue
        D=g[g.party=='D'].iloc[0];R=g[g.party=='R'].iloc[0]
        if not np.isfinite(D.cutoff_probability):continue
        rows.append({'race_id':race,'state_abbrev':D.state_abbrev,'year':D.year,'measure':measure,'dshare':D.dshare,'prior_pres_lean':D.prior_pres_lean,'incumbency_difference':D.incumbent-R.incumbent,'cutoff_probability':D.cutoff_probability,'logit_probability':np.log(np.clip(D.cutoff_probability,.01,.99)/(1-np.clip(D.cutoff_probability,.01,.99))),'raw_difference':D.raw_log_per100k-R.raw_log_per100k,'context_difference':D.score_context-R.score_context,'market_difference':D.score-R.score})
    v=pd.DataFrame(rows);v.to_csv(RESULTS/'vote_validation_panel.csv',index=False)
    features=['prior_pres_lean','incumbency_difference','cutoff_probability','logit_probability']
    out=[]
    for (year,measure),test in v.groupby(['year','measure']):
        train=v[(v.year<year)&(v.measure==measure)]
        if train.race_id.nunique()<10:continue
        for name,extra in [('baseline',[]),('raw_support',['raw_difference']),('context_adjusted',['context_difference']),('market_adjusted',['market_difference'])]:
            fs=features+extra
            model=make_pipeline(SimpleImputer(strategy='median'),StandardScaler(),Ridge(alpha=ALPHA))
            model.fit(train[fs],train.dshare)
            r=test.copy();r['prediction']=np.clip(model.predict(test[fs]),0,1);r['model']=name;r['training_years']=','.join(map(str,sorted(train.year.unique())));r['training_races']=train.race_id.nunique();out.append(r)
    if not out:return pd.DataFrame(),pd.DataFrame()
    out=pd.concat(out,ignore_index=True);out.to_csv(RESULTS/'vote_predictions.csv',index=False)
    base=out[out.model=='baseline'][['race_id','measure','prediction']].rename(columns={'prediction':'baseline_prediction'})
    out=out.merge(base,on=['race_id','measure'],validate='many_to_one')
    raw=out[out.model=='raw_support'][['race_id','measure','prediction']].rename(columns={'prediction':'raw_support_prediction'})
    out=out.merge(raw,on=['race_id','measure'],validate='many_to_one')
    metrics=[];rng=np.random.default_rng(20261106)
    for (year,measure,model),g in out.groupby(['year','measure','model']):
        e=100*(g.prediction-g.dshare);eb=100*(g.baseline_prediction-g.dshare)
        gains=np.abs(eb)-np.abs(e)
        draws=rng.choice(gains.to_numpy(),size=(2000,len(gains)),replace=True).mean(axis=1)
        eraw=100*(g.raw_support_prediction-g.dshare)
        raw_gains=np.abs(eraw)-np.abs(e)
        raw_draws=rng.choice(raw_gains.to_numpy(),size=(2000,len(raw_gains)),replace=True).mean(axis=1)
        metrics.append({'test':'Exploratory own-vote prediction','year':year,'measure':measure,'model':model,'races':len(g),'mae_pp':np.abs(e).mean(),'rmse_pp':np.sqrt(np.mean(e**2)),'baseline_mae_pp':np.abs(eb).mean(),'mae_gain_pp':gains.mean(),'gain_low95':np.quantile(draws,.025),'gain_high95':np.quantile(draws,.975),'raw_support_mae_pp':np.abs(eraw).mean(),'gain_vs_raw_pp':raw_gains.mean(),'gain_vs_raw_low95':np.quantile(raw_draws,.025),'gain_vs_raw_high95':np.quantile(raw_draws,.975),'training_years':g.training_years.iloc[0]})
    m=pd.DataFrame(metrics);m.to_csv(RESULTS/'vote_metrics.csv',index=False)
    return out,m

def make_dashboard(d,pred,s,dm,st,vm):
    rows=[]
    context=s[s.model=='context'].set_index(['candidate_key','measure'])
    for r in s[s.model=='market'].sort_values(['year','measure','ratio'],ascending=[False,True,False]).itertuples():
        rows.append({'name':r.benchmark_candidate.title(),'state':r.state_abbrev,'year':r.year,'party':r.party,'measure':r.measure,'actual':r.actual,'expected':r.expected,'ratio':r.ratio,'score':r.score,'coverage':f'{r.weeks} matched complete weeks','window':f'{r.window_start:%b %d}–{r.window_end:%b %d, %Y}','window_start':r.window_start.date().isoformat(),'window_end':r.window_end.date().isoformat(),'matched_weeks':r.weeks,'mean_lagged_probability':r.mean_probability,'note':'First observed means first recorded in this two-year election-cycle extract; disclosed identities only.' if 'donor' in r.measure else 'Positive receipt rows and gross itemized dollars; not net fundraising.','expectation_note':f'Expected values use {r.training_years}; {r.validation.replace("_"," ")}. FEC vintage is retrospective.'})
        rows[-1].update({'baseline_ratio':context.loc[(r.candidate_key,r.measure),'ratio'],'training_cycles':r.training_years,'min_lagged_probability':r.min_probability,'max_lagged_probability':r.max_probability})
    metrics=[]
    for r in dm.itertuples():metrics.append({'test':r.test,'measure':r.measure,'model':r.model,'holdout':str(r.year)+(' · race cross-fit' if r.validation=='race_crossfit' else ' · later cycle'),'n':r.candidate_weeks,'metric':'Mean absolute log(1 + amount) error','value':r.log_mae})
    for r in vm.itertuples():metrics.append({'test':r.test,'measure':r.measure,'model':r.model,'holdout':str(r.year),'n':r.races,'metric':'Senate two-party vote-share MAE (pp)','value':r.mae_pp})
    obj={'summary':{'status':'Measured; causality not identified','period':'2016–2022','heading':'Donor support after accounting for election odds','verdict':'The market-adjusted donor measure is now calculated and tested on later elections. It remains a conditional fundraising measure, not a validated charisma scale or a causal coattail estimate.','subtitle':'Actual disclosed support compared with what earlier-cycle models predict from lagged market odds and race context.','scope_note':'Retrospective receipt-date reconstruction for eventual major-party Senate nominees; all prices precede their donation weeks.','candidate_races':d.candidate_key.nunique(),'races':d.race_id.nunique(),'cycles':d.year.nunique(),'weeks':d.groupby(['race_id','week_start']).ngroups,'metrics':[{'value':d.candidate_key.nunique(),'label':'Candidate elections'},{'value':d.race_id.nunique(),'label':'Matched Senate races'},{'value':d.year.nunique(),'label':'Election cycles'},{'value':len(d),'label':'Candidate weeks'}]},'measure_labels':MEASURES,'rankings':rows,'ranking_note':'Each ratio compares observed with arithmetic expected support over the same complete weeks. Ratios are descriptive and do not measure votes caused. Both nominees share each race’s observed weeks.','expectation_note':'Fixed ridge models of log(1 + weekly support), training-only smearing correction; no candidate fixed effects or current election outcomes. Earliest-cycle expectations are whole-race cross-fitted; later cycles use earlier cycles only.','tests':{'fundraising':'The table compares whether lagged market probabilities improve later-cycle fundraising prediction over context alone. Smaller error is better. This does not by itself validate charisma.','appeal':'An exploratory held-out own-Senate vote-share benchmark compares raw, context-adjusted and market-adjusted support. No independent paired candidate-appeal survey is available, so this is not independent charisma validation.','causal':'Not identified. These are eventual general-election nominees. They cannot supply scores for losing primary contenders; no close-primary causal coattail estimate is asserted.'},'model_metrics':metrics,'model_note':'All specifications and alpha=10 were fixed before new results. 2018 is development; 2020 and 2022 are later-cycle tests under a predetermined expanding training window. No model is selected on teammate outcomes.','stability':st.to_dict('records'),'vote_metrics':vm.to_dict('records'),'donation_metrics':dm.to_dict('records'),'limitations':['The scores reflect donor appeal conditional on odds, which can include networks, ideology, opposition to the opponent and campaign effort.','Odds are themselves affected by candidate quality and past fundraising. Lagging establishes order but does not remove endogeneity.','FEC bulk extracts are retrospective and incorporate amendments and later itemization. This is not a vintage-safe real-time backtest.','Unique donors approximate normalized name plus ZIP and omit unitemized individuals. First observed means first seen in this two-year cycle, not a genuinely new supporter.','Only eventual major-party nominees and covered markets with at least four paired complete weeks are included. Market coverage is selective.','Gross receipt dollars and positive receipt rows are not net fundraising and can be sensitive to reporting/amendment conventions.','Own-vote prediction is a secondary criterion, not an independent charisma target. No downstream causal lift is estimated.'],'sources':[{'title':'FEC bulk data','url':'https://www.fec.gov/data/browse-data/?tab=bulk-data','note':'Official individual receipts, candidate and committee metadata; aggregate-only public outputs.'},{'title':'PredictIt daily and hourly archive (k5cents/predelect)','url':'https://github.com/k5cents/predelect','note':'Archived market data; source-specific capture and time handling in the download bundle.'},{'title':'Historical PredictIt election archive','url':'https://github.com/slchism/Do-Prediction-Markets-Predict-Elections-Better-Than-Polling-','note':'Dated market records; these are archival data, not current settled prices.'},{'title':'MIT Election Lab Senate and presidential returns','url':'https://electionlab.mit.edu/data','note':'Prior presidential lean and held-out own-race validation outcomes.'}]}
    causal_path=REPO/'market-adjusted/causal-coverage/summary.json'
    if ALPHA!=10:
        obj['model_note']=f'Fixed sensitivity run with alpha={ALPHA:g}, not a selected alternative. Primary specification remains raw prices and alpha=10. All later-cycle predictions use the predetermined expanding training window.'
    obj['summary']['period']=f'{d.year.min()}–{d.year.max()}'
    if causal_path.exists():
        obj['causal_coverage']=json.loads(causal_path.read_text())
        obj['tests']['causal']='The existing 65-pair primary cohort yields only two exact pre-cutoff market matches, both with the higher-donor contender losing. Neither has its full cumulative donor window covered by odds. There is no treated arm and no causal estimate.'
    primary='national_new_donors'
    dm0=dm[(dm.measure==primary)&(dm.year.isin([2020,2022]))]
    sentences=[]
    for year,g in dm0.groupby('year'):
        a=g[g.model=='context'].iloc[0];b=g[g.model=='market'].iloc[0]
        gain=100*(a.log_mae-b.log_mae)/a.log_mae
        sentences.append(f'{year}: log-scale donation error {a.log_mae:.3f} without odds versus {b.log_mae:.3f} with odds ({abs(gain):.1f}% {"lower" if gain>0 else "higher"}; {int(a.races)} matched races).')
    if sentences:obj['tests']['fundraising']='National first-observed disclosed donors. '+' '.join(sentences)+' This tests fundraising prediction, not charisma.'
    v0=vm[(vm.measure==primary)&(vm.year.isin([2020,2022]))&(vm.model=='market_adjusted')] if len(vm) else pd.DataFrame()
    if len(v0):
        ss=[]
        for r in v0.itertuples():ss.append(f'{r.year}: own-vote error {r.raw_support_mae_pp:.2f} pp with raw support versus {r.mae_pp:.2f} pp with market-adjusted support (gain {r.gain_vs_raw_pp:+.2f} pp; bootstrap 95% interval {r.gain_vs_raw_low95:+.2f} to {r.gain_vs_raw_high95:+.2f}; {r.races} races).')
        obj['tests']['appeal']=' '.join(ss)+' No independent paired appeal survey is available. This is an exploratory predictive criterion, not a charisma or coattails validation.'
        improvement=(v0.gain_vs_raw_pp>0).all()
        obj['summary']['verdict']='The adjusted donor measure '+('improves on raw support in both later-cycle own-vote checks' if improvement else 'does not consistently outperform raw support in the later-cycle own-vote checks')+'. It remains a conditional fundraising measure; charisma and causal coattails are not established.'
    write_json(RESULTS/'dashboard.json',obj)
    return obj

def main():
    global RESULTS, ALPHA
    ap=argparse.ArgumentParser();ap.add_argument('--donations',type=Path,nargs='+',required=True);ap.add_argument('--odds',type=Path,required=True);ap.add_argument('--normalized-odds',action='store_true');ap.add_argument('--results-dir',type=Path,default=RESULTS);ap.add_argument('--alpha',type=float,default=10.);a=ap.parse_args();RESULTS=a.results_dir;ALPHA=a.alpha
    RESULTS.mkdir(parents=True,exist_ok=True)
    d=load_panel(a.donations,a.odds,a.normalized_odds)
    pred,dm=donation_predictions(d);s,st=scores(pred);vp,vm=vote_validation(s)
    dashboard=make_dashboard(d,pred,s,dm,st,vm)
    write_json(RESULTS/'run_manifest.json',{'input_donations':[str(p) for p in a.donations],'input_odds':str(a.odds),'donation_sha256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in a.donations},'odds_sha256':hashlib.sha256(a.odds.read_bytes()).hexdigest(),'protocol_sha256':hashlib.sha256((HERE/'PROTOCOL.md').read_bytes()).hexdigest(),'normalized_odds':a.normalized_odds,'alpha':ALPHA,'rows':len(d),'races':d.race_id.nunique(),'candidates':d.candidate_key.nunique(),'years':sorted(d.year.unique()),'model':f'Ridge alpha{ALPHA:g} log1p with training residual smearing','causal_effect_estimated':False})
    print(json.dumps(clean_json({'coverage':dashboard['summary'],'donation_metrics':dm.to_dict('records'),'vote_metrics':vm.to_dict('records')}),indent=2))

if __name__=='__main__':main()
