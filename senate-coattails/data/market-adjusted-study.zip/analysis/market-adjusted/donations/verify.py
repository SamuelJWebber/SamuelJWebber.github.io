"""Verify accounting identities and panel uniqueness without exporting identities."""
from pathlib import Path
import csv,json,collections
P=Path(__file__).resolve().parent
results=[]
for path in sorted(P.glob('weekly_donations_*.csv')):
 year=int(path.stem.rsplit('_',1)[1]);a=json.loads((P/f'audit_{year}.json').read_text())
 seen=set();totals=collections.Counter();largest_repeat=0
 for r in csv.DictReader(path.open()):
  key=(r['candidate_id'],r['week_start']);assert key not in seen;seen.add(key)
  n,i,new,inew,g,tx=[int(r[k]) for k in ['national_donors','in_state_donors','national_new_donors','in_state_new_donors','gt200_donors','transactions']]
  assert 0<=i<=n<=tx and 0<=new<=n and 0<=inew<=i and 0<=g<=n
  assert r['retrospective_receipt_date']=='True' and r['filing_asof_verified']=='False'
  assert float(r['dollars'])>=0 and int(r['missing_identity_records'])<=tx
  totals['unique_donor_candidate_pairs']+=new;totals['positive_individual_records']+=tx
  totals['weekly_unique_donor_appearances']+=n
 assert len(seen)==a['weekly_rows']
 for k in ['unique_donor_candidate_pairs','positive_individual_records']:assert totals[k]==a[k],(year,k,totals[k],a[k])
 assert a['filter']['target_campaign_records']==a['campaign_records']
 results.append(dict(year=year,rows=len(seen),**totals,duplicate_sub_ids_removed=a.get('duplicate_sub_ids_removed',0),repeat_electronic_id_fraction=a.get('repeated_electronic_id_committee_report_date',0)/a['positive_individual_records'],checks_passed=True))
(P/'verification.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
