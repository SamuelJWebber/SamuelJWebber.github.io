"""Independent exact-date checkpoint verification against the earlier extraction.

Only four public candidate-level aggregate comparisons are exported; donor
identity sets exist only during execution. Run after the weekly extraction.
"""
import csv,json,re,sys
from pathlib import Path
from datetime import datetime,date
from collections import defaultdict
P=Path(__file__).resolve().parent;raw=Path(sys.argv[1]);prior=P.parents[1]/'stage3/fundraising/nominee_breadth_features.csv'
chosen={2016:'S0FL00338',2018:'S8TX00285',2020:'S8GA00180',2022:'S6PA00274'}
reference={(int(r['year']),r['candidate_id'],r['window']):r for r in csv.DictReader(prior.open())}
comparisons=[]
for year,cid in chosen.items():
 mapping={r['committee_id'] for r in csv.DictReader((P/f'committee_mapping_{year}.csv').open()) if r['candidate_id']==cid}
 rr=[r for r in csv.DictReader((P/f'candidate_roster_{year}.csv').open()) if r['candidate_id']==cid][0];state=rr['state_abbrev']
 sets=defaultdict(set)
 with (raw/f'senate_{year}.txt').open(encoding='latin1') as f:
  for line in f:
   if line[:9] not in mapping:continue
   r=line.rstrip('\r\n').split('|')
   if len(r)!=21 or r[5] not in ['15','15E'] or r[6] not in ['','IND']:continue
   try:amount=float(r[14]);d=datetime.strptime(r[13].zfill(8),'%m%d%Y').date()
   except ValueError:continue
   if amount<=0 or d<date(year-1,1,1):continue
   name=re.sub(r'\s+',' ',re.sub('[^A-Z0-9 ]',' ',r[7].upper())).strip();z=r[10][:5]
   if not name or len(z)!=5 or not z.isdigit():continue
   identity=(name,z)
   for window,cut in [('june30',date(year,6,30)),('sept30',date(year,9,30))]:
    if d<=cut:
     sets[window,'national'].add(identity)
     if r[9]==state:sets[window,'in_state'].add(identity)
 for window in ['june30','sept30']:
  ref=reference[year,cid,window]
  for geo in ['national','in_state']:
   observed=len(sets[window,geo]);expected=int(float(ref[f'approx_contributors_{geo}']))
   comparisons.append(dict(year=year,candidate_id=cid,candidate=ref['benchmark_candidate'],window=window,geography=geo,independently_counted=observed,prior_extraction=expected,match=observed==expected))
   # A discrepancy is retained for investigation, never silently corrected to the prior result.
 print('Compared',year,cid,flush=True)
(P/'independent_checkpoint_verification.json').write_text(json.dumps(comparisons,indent=2)+'\n')
