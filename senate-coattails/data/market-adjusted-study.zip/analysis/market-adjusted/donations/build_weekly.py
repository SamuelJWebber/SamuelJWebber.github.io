"""Aggregate official FEC receipts into weekly Senate-candidate donor proxies.

Only aggregate outputs enter the public repository. Donation identity keys and
records remain private scratch. Current bulk vintage is retrospectively amended;
receipt-date alignment does not establish information availability on that date.
"""
from pathlib import Path
from collections import defaultdict,Counter
from datetime import datetime,date,timedelta
import argparse,csv,json,zipfile,subprocess,hashlib,re,sys,time
P=Path(__file__).resolve().parent
CN=['candidate_id','candidate_name','party','election_year','state_abbrev','office','district','incumbent_status','status','principal_committee','street1','street2','city','state2','zip']
CCL=['candidate_id','candidate_election_year','cycle','committee_id','committee_type','designation','linkage_id']
F=['committee_id','amendment','report_type','election_type','image','transaction_type','entity_type','name','city','donor_state','zip','employer','occupation','date','amount','other_id','transaction_id','file_number','memo','memo_text','sub_id']

def rows(path,names):
 import io
 with zipfile.ZipFile(path) as z:
  with z.open(z.namelist()[0]) as f:
   for row in csv.reader(io.TextIOWrapper(f,encoding='latin1'),delimiter='|',quoting=csv.QUOTE_NONE):yield dict(zip(names,row))

def roster(raw,year):
 candidates={r['candidate_id']:r for r in rows(raw/f'cn{year%100:02d}.zip',CN) if r['office']=='S' and r['candidate_id'].startswith('S')}
 links=defaultdict(set)
 for r in rows(raw/f'ccl{year%100:02d}.zip',CCL):
  if r['candidate_id'] in candidates and r['committee_type']=='S' and r['designation'] in ['P','A']:links[r['committee_id']].add(r['candidate_id'])
 for candidate,r in candidates.items():
  if r['principal_committee'].startswith('C'):links[r['principal_committee']].add(candidate)
 # Established duplicate-registration alias, independently used in previous study.
 aliases={'S8WV00119':'S0WV00215'} if year==2020 else {}
 for committee,ids in links.items():links[committee]={aliases.get(x,x) for x in ids}
 candidates={c:r for c,r in candidates.items() if c not in aliases}
 bad={cm:sorted(ids) for cm,ids in links.items() if len(ids)>1}
 mapping={cm:next(iter(ids)) for cm,ids in links.items() if len(ids)==1 and next(iter(ids)) in candidates}
 mapped=set(mapping.values())
 return {c:r for c,r in candidates.items() if c in mapped},mapping,bad

def build(year,raw,out):
 t=time.time();candidates,mapping,bad=roster(raw,year);suffix=f'{year%100:02d}'
 out.mkdir(parents=True,exist_ok=True)
 for name,rr,fields in [('candidate_roster',list(candidates.values()),CN),('committee_mapping',[{'committee_id':cm,'candidate_id':cid} for cm,cid in sorted(mapping.items())],['committee_id','candidate_id'])]:
  with (out/f'{name}_{year}.csv').open('w') as f:
   w=csv.DictWriter(f,fieldnames=[x for x in fields if x not in ['street1','street2','city','state2','zip']]);w.writeheader();w.writerows({k:v for k,v in r.items() if k in w.fieldnames} for r in rr)
 committee_file=raw/f'committees_{year}.txt';committee_file.write_text('\n'.join(mapping)+'\n')
 filtered=raw/f'senate_{year}.txt'
 if not filtered.exists():
  subprocess.run(['g++','-O3','-o',str(raw/'filter'),str(P/'filter.cpp')],check=True)
  with filtered.open('wb') as f:
   p=subprocess.Popen(['unzip','-p',str(raw/f'indiv{suffix}.zip'),'itcont.txt'],stdout=subprocess.PIPE)
   q=subprocess.run([str(raw/'filter'),str(committee_file)],stdin=p.stdout,stdout=f,stderr=subprocess.PIPE,check=True);p.stdout.close();returncode=p.wait()
   if returncode:raise RuntimeError(f'Unzip failed {returncode}')
  (raw/f'filter_audit_{year}.json').write_bytes(q.stderr);print(year,'filtered',filtered.stat().st_size,flush=True)
 stats=defaultdict(Counter);donors=defaultdict(set);instate=defaultdict(set);large=defaultdict(set);first=defaultdict(dict);first_inside=defaultdict(dict)
 seen_sub=set();seen_electronic=set();audit=Counter();normal=re.compile('[^A-Z0-9 ]');spaces=re.compile(r'\s+')
 begin=date(year-1,1,1);end=date(year,11,7) # Further general-election cutoffs applied by the model.
 datecache={}
 with filtered.open(encoding='latin1') as f:
  for i,row in enumerate(csv.reader(f,delimiter='|',quoting=csv.QUOTE_NONE)):
   audit['campaign_records']+=1
   if len(row)!=21:audit['bad_column_count']+=1;continue
   cm,typ,entity,ds,dt,amt,sub=row[0],row[5],row[6],row[9],row[13],row[14],row[20]
   if typ not in ['15','15E']:audit['excluded_type']+=1;continue
   if entity not in ['', 'IND']:audit['excluded_entity']+=1;continue
   try:amount=float(amt)
   except ValueError:audit['excluded_bad_amount']+=1;continue
   if amount<=0:audit['excluded_nonpositive']+=1;continue
   if dt not in datecache:
    try:datecache[dt]=datetime.strptime(dt.zfill(8),'%m%d%Y').date()
    except ValueError:datecache[dt]=None
   d=datecache[dt]
   if d is None:audit['excluded_bad_date']+=1;continue
   if not begin<=d<=end:audit['excluded_outside_window']+=1;continue
   if sub and sub in seen_sub:audit['duplicate_sub_ids_removed']+=1;continue
   if sub:seen_sub.add(sub)
   cid=mapping[cm];week=d-timedelta(days=d.weekday());key=(cid,week)
   s=stats[key];s['transactions']+=1;s['dollars']+=amount;s['memo_records']+=int(row[18]=='X');s['unspecified_entity_records']+=int(not entity)
   if row[16]:
    # Diagnose repeated IDs without claiming reconstructed report-amendment chains.
    ek=(cm,row[2],row[16],dt)
    if ek in seen_electronic:audit['repeated_electronic_id_committee_report_date']+=1
    else:seen_electronic.add(ek)
   name=spaces.sub(' ',normal.sub(' ',row[7].upper())).strip();z=row[10][:5]
   if not name or len(z)!=5 or not z.isdigit():s['missing_identity_records']+=1;continue
   # Internal 64-bit digest only; neither hash nor source identities are exported.
   h=int.from_bytes(hashlib.blake2b((name+'|'+z).encode(),digest_size=8).digest(),'little')
   donors[key].add(h)
   old=first[cid].get(h)
   if old is None or d<old:first[cid][h]=d
   if ds==candidates[cid]['state_abbrev']:
    instate[key].add(h);old=first_inside[cid].get(h)
    if old is None or d<old:first_inside[cid][h]=d
   if amount>200:large[key].add(h)
   if i and i%1000000==0:print(year,'parsed',i,'seconds',round(time.time()-t),flush=True)
 new=Counter();newinside=Counter()
 for cid,dd in first.items():
  for d in dd.values():new[cid,d-timedelta(days=d.weekday())]+=1
 for cid,dd in first_inside.items():
  for d in dd.values():newinside[cid,d-timedelta(days=d.weekday())]+=1
 outrows=[]
 # Include zeros only for committees observed in complete source; roster mapping
 # alone does not establish candidate active status, which remains a model filter.
 week=begin-timedelta(days=begin.weekday())
 while week<=end:
  for cid,r in candidates.items():
   key=(cid,week);s=stats[key]
   outrows.append(dict(year=year,candidate_id=cid,candidate_name=r['candidate_name'],state_abbrev=r['state_abbrev'],party=r['party'],incumbent_status=r['incumbent_status'],week_start=week.isoformat(),week_end=(week+timedelta(days=6)).isoformat(),window_start=max(begin,week).isoformat(),window_end=min(end,week+timedelta(days=6)).isoformat(),national_donors=len(donors[key]),in_state_donors=len(instate[key]),national_new_donors=new[key],in_state_new_donors=newinside[key],gt200_donors=len(large[key]),transactions=s['transactions'],dollars=round(s['dollars'],2),missing_identity_records=s['missing_identity_records'],memo_records=s['memo_records'],unspecified_entity_records=s['unspecified_entity_records'],retrospective_receipt_date=True,filing_asof_verified=False))
  week+=timedelta(days=7)
 with (out/f'weekly_donations_{year}.csv').open('w') as f:
  w=csv.DictWriter(f,fieldnames=list(outrows[0]));w.writeheader();w.writerows(outrows)
 audit.update(mapped_candidates=len(candidates),mapped_committees=len(mapping),conflicting_committees=len(bad),weekly_rows=len(outrows),unique_donor_candidate_pairs=sum(map(len,first.values())),positive_individual_records=sum(r['transactions'] for r in outrows))
 details=dict(year=year,**audit,seconds=round(time.time()-t,2),conflicting_committee_mapping=bad,source=json.loads((raw/f'indiv{suffix}.zip.json').read_text()),filter=json.loads((raw/f'filter_audit_{year}.json').read_text()))
 (out/f'audit_{year}.json').write_text(json.dumps(details,indent=2)+'\n')
 print(json.dumps({k:v for k,v in details.items() if k!='conflicting_committee_mapping'}),flush=True)

if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('--raw',type=Path,required=True);a.add_argument('--output',type=Path,default=P);a.add_argument('--years',nargs='+',type=int,required=True);args=a.parse_args()
 for y in args.years:build(y,args.raw,args.output)
