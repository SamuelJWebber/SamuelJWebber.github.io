"""Download official FEC bulk source archives to a private scratch directory."""
from pathlib import Path
import urllib.request,concurrent.futures,time,json,hashlib,sys
root=Path(sys.argv[1]);root.mkdir(parents=True,exist_ok=True)
years=[int(y) for y in sys.argv[2:]] or [2016,2018,2020,2022]
def fetch(y,kind):
 filename=f'{kind}{y%100:02d}.zip';path=root/filename
 url=f'https://www.fec.gov/files/bulk-downloads/{y}/{filename}'
 if path.exists():return
 t=time.time();h=hashlib.sha256();count=0
 with urllib.request.urlopen(url,timeout=180) as response,(root/(filename+'.partial')).open('wb') as f:
  size=int(response.headers.get('Content-Length',0));print(json.dumps(dict(event='start',year=y,kind=kind,bytes=size)),flush=True)
  while b:=response.read(8*1024*1024):f.write(b);h.update(b);count+=len(b)
 if size and count!=size:raise ValueError('Incomplete source')
 (root/(filename+'.partial')).rename(path)
 info=dict(url=url,bytes=count,sha256=h.hexdigest(),seconds=round(time.time()-t,1),retrieved_at=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()))
 (root/(filename+'.json')).write_text(json.dumps(info,indent=2)+'\n');print(json.dumps(dict(event='complete',year=y,kind=kind,**info)),flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:list(pool.map(lambda p:fetch(*p),[(y,k) for y in years for k in ['cn','ccl','indiv']]))
