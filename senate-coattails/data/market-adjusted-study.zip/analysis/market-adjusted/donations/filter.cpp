// Filter official FEC bulk records to campaign committees. Output is private.
#include <iostream>
#include <fstream>
#include <unordered_set>
#include <string>
int main(int argc,char**argv){
 if(argc!=2)return 2;
 std::ios_base::sync_with_stdio(false);std::cin.tie(nullptr);
 std::unordered_set<std::string> committees;std::ifstream f(argv[1]);std::string line;
 while(std::getline(f,line))committees.insert(line);
 unsigned long long n=0,kept=0;
 while(std::getline(std::cin,line)){++n;if(line.size()>9&&line[9]=='|'&&committees.count(line.substr(0,9))){std::cout<<line<<'\n';++kept;}}
 std::cerr<<"{\"raw_records\":"<<n<<",\"target_campaign_records\":"<<kept<<"}\n";
}
