# Weekly disclosed Senate-donor panel

This module downloads official FEC bulk individual receipts and makes **candidate-week aggregates only**. It is a retrospective measurement panel, not a reconstruction of information publicly available in real time.

## Reproduce

```sh
python download.py /absolute/private/raw 2016 2018 2020 2022
python build_weekly.py --raw /absolute/private/raw --years 2016 2018 2020 2022
```

Requires Python 3, a C++ compiler (`g++`), and `unzip`. Only standard Python packages are required. Raw archives exceed 14 GB compressed across the four cycles. The `itcont.txt` member alone is read: `by_date/` members are redundant partitions of the same file and must not be concatenated as independent observations. Raw filtered records and identity hashes are never published. Pipe-delimited input is parsed with literal quote characters (`csv.QUOTE_NONE`), rather than CSV quote escaping. Only records with exactly 21 columns enter the receipt aggregation.

## Population and committee mapping

Official candidate master records whose office is Senate are linked through principal/authorized Senate committee links and the candidate master's principal committee field. All parties are retained; downstream models select the candidate-market matches. Ambiguous committee-to-candidate links are excluded and recorded in each audit. The historical duplicate registration `S8WV00119` is aliased to `S0WV00215` in 2020, matching the existing independently audited study. This is a broad roster: mapping does **not** establish that a person was an active candidate that week. Later-stage filtering must establish the actual election and nominee/contender.

The incumbent/challenger/open-seat field is the value in the retrieved cycle candidate master. The candidate election-year field is included in the roster. This is not independently verified contemporaneous incumbency information and should not automatically be treated as an ex-ante covariate.

## Receipts and identity

Retain transaction types `15` (individual contribution) and `15E` (earmarked individual contribution), entity type `IND` or blank, and positive amounts. This excludes candidate self-financing, PAC/party transfers, refunds, and known organizational entities. Memo-marked entries are retained, consistent with the FEC's instructions for this particular bulk file; their count is exported as a diagnostic. No generic rule that all memo records should be dropped is applied.

Receipt dates must be valid and between January 1 of the year preceding the cycle and November 7 of the election year. Downstream analysis must cut at the actual election date and use complete weekly windows. Duplicate FEC `SUB_ID` rows are removed. Repeated committee/report/transaction-ID/receipt-date combinations are diagnosed, but full report-amendment chains are **not** reconstructed. Thus `transactions` means retained positive receipt records, and `dollars` means gross recorded positive individual dollars; neither is asserted to equal audited net campaign revenue.

Approximate donor identity is uppercase normalized full name plus five-digit ZIP. Internal 64-bit BLAKE2 hashes bound memory; neither names, ZIPs, nor hashes are exported. Spelling changes or ZIP changes can split one person; common name/ZIP collisions can merge people. The very small hash-collision probability adds to those ordinary identity limitations. Missing names/ZIPs contribute to gross receipt counts/dollars but not donor counts.

## Weekly fields

Weeks run Monday–Sunday. `window_start` and `window_end` show any truncation at cycle boundaries; the market model should retain complete weeks only.

- `national_donors`, `in_state_donors`: unique approximate donor identities observed **during that week**. Never sum these and call the result total unique donors.
- `national_new_donors`: identities whose first observed eligible receipt in the cycle occurs during the week. These can be summed across weeks to obtain first-seen donor totals.
- `in_state_new_donors`: identities whose first observed eligible *in-state* receipt in the cycle occurs during the week. A mover can be new to this subset after previously appearing out of state.
- `gt200_donors`: weekly unique identities with an individual positive gift greater than $200; a sensitivity that reduces dependence on later gifts retrospectively triggering itemization.
- `transactions`, `dollars`: retained positive receipt records and gross recorded positive dollars, subject to the amendment caveat above.
- `missing_identity_records`, `memo_records`, `unspecified_entity_records`: data-quality diagnostics.

Zeros are created for mapped candidates over the complete downloaded source window. They are not evidence a campaign was active. Weekly rows are not independent candidates or independent elections.

## Timing limitations

The FEC bulk files include later amendments and retrospective itemization. An early receipt date does not establish that the receipt was publicly disclosed by that date. All rows therefore explicitly state `retrospective_receipt_date=True` and `filing_asof_verified=False`. This prevents interpreting a held-out-cycle retrospective test as an available-in-real-time trading or forecasting backtest. A pre-primary causal design requires reconstructing or independently validating the as-of filing vintage, in addition to correctly timed market odds.

## Primary sources

- FEC individual-contributions bulk documentation: https://www.fec.gov/campaign-finance-data/contributions-individuals-file-description/
- FEC candidate master documentation: https://www.fec.gov/campaign-finance-data/candidate-master-file-description/
- FEC candidate–committee linkage documentation: https://www.fec.gov/campaign-finance-data/candidate-committee-linkage-file-description/
- Exact archive URLs, retrieval times, byte counts and SHA-256 digests are retained in the download manifest and year audits.

## Verification

`verify.py` checks candidate-week uniqueness, donor-subset inequalities, first-seen donor accounting, positive receipt accounting and provenance flags. All four cycles pass. Rebuilding all four panels using literal quote parsing produced byte-identical files relative to parsing the already committee-filtered extracts; those hashes are in `quote_none_comparison.json`. `verify_checkpoints.py` independently reads raw candidate receipts with literal pipe splitting at exact June 30 and September 30 dates and compares them with the previous published extraction. Discrepancies remain visible in `independent_checkpoint_verification.json`; the previous extraction is a comparison, not an asserted ground truth.

The four Fetterman 2022 checkpoint comparisons are 13 national donors and 8 in-state donors above the prior extraction at both dates (less than 0.1%). Independent literal-pipe and campaign-filtered pandas reads agree with the new counts. A full-file default-quote pandas diagnostic failed on a 22-field source line; because the earlier extraction selected a subset of columns, that failure alone does not establish the exact cause of the older discrepancy. The new weekly results are unchanged by the explicit literal-quote correction. Details are retained in `parser_diagnostic.json`.
