"""Reproduce from frozen aggregate data; no donor identity data needed."""
from pathlib import Path
import argparse
import shutil
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--main-only', action='store_true')
    args = parser.parse_args()
    parts = [HERE / f'donations/weekly_donations_{year}.csv' for year in [2016, 2018, 2020, 2022]]
    command = [sys.executable, str(HERE / 'model/analyze.py'), '--donations', *map(str, parts),
               '--odds', str(HERE / 'odds/odds_main.csv')]
    subprocess.run(command, cwd=ROOT, check=True)
    if not args.main_only:
        for label, flags in [('normalized', ['--normalized-odds']),
                             ('alpha1', ['--alpha', '1']), ('alpha100', ['--alpha', '100'])]:
            subprocess.run(command + ['--results-dir', str(HERE / 'model/sensitivity' / label)] + flags,
                           cwd=ROOT, check=True)
        subprocess.run([sys.executable, str(HERE / 'model/summarize_sensitivity.py')], cwd=ROOT, check=True)
    dest = ROOT / 'dist/data'
    dest.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(HERE / 'model/results/dashboard.json', dest / 'market-adjusted.json')

if __name__ == '__main__':
    main()
