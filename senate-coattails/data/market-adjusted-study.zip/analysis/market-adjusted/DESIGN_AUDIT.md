# Market-adjusted donor appeal: implementation audit

This is a measurement proposal, not a causal estimate of charisma or coattails. The user's assumption of perfectly calibrated market probabilities is maintained.

## Recommended minimal implementation

- Unit: candidate-week. Target distinct newly observed individual donors within the campaign cycle; separately model positive individual donation transactions and positive individual dollars. A person contributing in three weeks counts once in the campaign's cumulative donor-breadth score, not three times.
- Odds: last genuine historical price known strictly before the contribution week. Set a maximum staleness policy and preserve both quote timestamp and week start. Do not interpolate through future prices, substitute resolved 0/1 values, or treat missing market history as zero.
- Predict each week's donations with a small regularized model: flexible signed win probability (including asymmetry between 20% underdog and 80% favorite), time to relevant election, time since entry, electorate size, incumbency, party, and predetermined baseline race fundamentals. Interact primary/general period where both are pooled. A proportional population denominator alone is too restrictive for national donations.
- Fit candidate-blind expectations: do not include candidate fixed effects in the score-generating model, since these absorb the persistent excess support being measured. Candidate fixed effects can be a separate within-candidate competitiveness check, not the main ranking.
- Aggregate observed and expected counts over identical eligible weeks. Display observed/expected support ratio plus uncertainty and coverage. For log-outcome models, use an out-of-fold training-only smearing correction before claiming an expected count ratio; exp(predicted log(1+y)) - 1 is not generally E[y]. A count GLM avoids this specific retransformation issue.
- Record dollars, transaction count, active donor count, newly seen donor count, in-state donor count and out-of-state donor count separately. Never label itemized donor records as all unique donors.

## Honest out-of-sample tests

1. Donation prediction: compare fundamentals-only, fundamentals plus lagged odds, and a simple party/time baseline with exactly the same observations. Fit all encoders, scaling, spline knots and hyperparameters inside training folds. Hold all observations from one race-election out together, including both nominees. If historical coverage spans cycles, train only on earlier cycles and evaluate later ones; leave-one-cycle-out that trains on the future is grouped cross-validation, not prospective OOT.
2. Score stability: predeclare first-half versus second-half matched-window persistence and rank correlation. This validates persistent donor appeal, not charisma.
3. External validation: independently collected candidate appeal/favorability or same-opponent hypothetical matchup polls, dated after a frozen score cutoff. Where absent, report that charisma validation remains untested. Residual own-race vote performance is at most an additional predictive validation because electoral conditions and odds enter both quantities.
4. Do not choose the best quality proxy on the same teammate outcomes used to estimate coattails. If proxy selection uses teammate outcomes, reserve an untouched independent causal test cohort and call selection exploratory.
5. Sample size is the number of independent race-elections/cycles, not the number of daily rows. Cluster uncertainty by race-election, with state grouping sensitivity where repeated states are present. Report low power rather than using a large time-series row count to imply precision.

## A useful within-primary comparison

Let expected donor flow for contenders A and B in the same party's primary be D_A = C_race,week * A_A and D_B = C_race,week * A_B. Then D_A / D_B = A_A / A_B: a common multiplicative seat-competitiveness component cancels. This gives a direct check of the market adjustment against same-party donor share or log donor ratio, without fitting cross-state fundraising demand.

This cancellation is an assumption, not a result. Nomination chances, campaign age, donor networks and candidates' different expected general-election viability can still affect their shares. A market for the party winning the seat supplies a shared race factor; it is not the chance that each contender wins the general election conditional on nomination. Test whether contender rankings change under the cross-race market model. If they do not, the market adjustment adds comparability across races but not much new identification within primaries.

## Coattails stage

- Freeze contender scores before the decisive primary, preferably with a buffer and verified historical filing availability. Compare narrow wins and losses by the predesignated higher-score contender.
- Nominee-only post-primary scores can support a descriptive candidate ranking but cannot retroactively classify losing primary candidates or generate a nomination RD.
- Main outcome should preserve mobilization and persuasion, e.g. other same-party votes per fixed pre-assignment electorate, with vote-share outcomes as companions. Do not condition the causal outcome model on post-nomination odds, turnout, fundraising, spending or campaign effort.
- Inspect balance in prior teammate outcomes, density/manipulation, sample definitions, bandwidth sensitivity and leave-one-state-out stability. When these fail or the close sample is too small, publish the measured proxy and the failed/unsupported causal test separately.
- The design estimates the effect of nominating the stronger measured donor-appeal candidate among nearly tied primaries. It does not identify a universal charisma effect nor automatically generalize to stars who win primaries easily.

## FEC integrity requirements

- Public individual records are not a census of small donors. Campaigns must itemize individual donors over the applicable $200 cumulative threshold; optional small-donor itemization varies. Donor-breadth counts must carry this qualification.
- Use FEC's individual-transaction definitions and avoid double-counting candidate receipts and conduit pass-through transactions. Do not blanket-drop every memo entry: FEC bulk-file documentation specifically says relevant attribution memo items should be included.
- Amendments and repeated transaction identifiers require the correct report/transaction selection. Preserve transaction dates and report/file dates separately.
- A donation dated before the primary but only disclosed later can leak later information into an allegedly real-time score. Archive-as-of filings are needed for a strict live historical backtest; otherwise label the reconstruction retrospective by donation date.
- A donor may become identifiable only after crossing the itemization threshold later in the cycle. Filtering donation date alone does not establish that the identity was observable at the cutoff.

## Primary sources located

1. Feigenbaum and Shelton, The Vicious Cycle: Fundraising and Perceived Viability in U.S. Presidential Primaries, QJPS 8(1), 2013. Uses daily FEC receipts/expenditures and Iowa Electronic Markets probabilities; estimates feedback in both directions. Author manuscript also discusses weekday, within-quarter and quarter-end seasonality. https://scholarship.claremont.edu/cmc_fac_pub/139/ ; https://www1.cmc.edu/pages/faculty/CShelton/ViciousCycle.pdf ; DOI 10.1561/100.00011094. This supports the market/fundraising pairing, not the validity of a residual as charisma.
2. FEC contributions by individuals file description: https://www.fec.gov/campaign-finance-data/contributions-individuals-file-description/
3. FEC methodology, individual-contribution classification: https://www.fec.gov/campaign-finance-data/about-campaign-finance-data/methodology/
4. FEC individual-contribution reporting and optional itemization: https://www.fec.gov/updates/individual-contributions-federal-candidates-and-committees/
5. FEC earmarked contributions and conduit reporting: https://www.fec.gov/updates/earmarked-contributions/
6. Meisels, Clinton and Huber, Giving to the Extreme? Experimental Evidence on Donor Response to Candidate and District Characteristics. Donor-vignette evidence that competitiveness and opponent ideology affect giving alongside congruence. https://www.cambridge.org/core/journals/british-journal-of-political-science/article/giving-to-the-extreme-experimental-evidence-on-donor-response-to-candidate-and-district-characteristics/BB4D94BE12341AC58E659E4A157A830A

Prepared November 6, 2026. No fitted estimates or completed validation are claimed in this audit.
