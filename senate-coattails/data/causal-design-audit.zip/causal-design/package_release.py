"""Package the evidence audit; no outcome estimation is performed."""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parent
SITE = ROOT.parents[1]
DEST = SITE / "dist" / "data" / "causal-design-audit.zip"

def main():
    required = [ROOT / "nomination-audit" / "README.md", ROOT / "PROTOCOL.md"]
    for path in required:
        if not path.is_file():
            raise FileNotFoundError(path)
    paths = sorted(p for p in ROOT.rglob("*") if p.is_file() and
                   "__pycache__" not in p.parts and p.name != "RELEASE.json")
    with zipfile.ZipFile(DEST, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in paths:
            info = zipfile.ZipInfo("causal-design/" + str(path.relative_to(ROOT)),
                                   date_time=(2026, 11, 5, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, path.read_bytes())
    report = {"files": len(paths), "bytes": DEST.stat().st_size,
              "sha256": hashlib.sha256(DEST.read_bytes()).hexdigest(),
              "archive": str(DEST.relative_to(SITE)),
              "new_causal_effect_estimated": False}
    (ROOT / "RELEASE.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report))

if __name__ == "__main__":
    main()
