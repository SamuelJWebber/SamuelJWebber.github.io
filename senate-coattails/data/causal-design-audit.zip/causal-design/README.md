# Candidate appeal and close nominations: evidence audit

Samuel Webber · November 5, 2026

This release adds a proposed causal design and verified source coverage to the Senate Coattails project. **It contains no new estimate of coattails and no fitted donor-to-appeal model.** The earlier donor study remains a separate, inconclusive analysis.

The target is the effect on same-party teammates of nominating a contender with greater measured general-election appeal instead of their actual primary rival. Same-survey hypothetical matchups measure appeal before nomination. A close, nomination-deciding primary or runoff is the proposed source of assignment variation. Neither a successful prediction model nor a close vote margin establishes the design's validity by itself.

## What is new

- Seven original-source survey examples, including Ossoff/Tomlinson/Amico against Perdue, Booker/McGrath against McConnell, and Cochran/McDaniel against Childers. Two examples are different dates in the same Colorado contest; they are not separate nomination assignments.
- A portable polling-archive audit: 74 candidate-pair slots, 5 matched nomination cases, 13 surveys, and 18 question-pair versions. The archives do not cover most older cases. These counts are not a census of available polls.
- Fourteen potential additions within five top-two-margin points: nine cases identified in Cowburn's primary data, four officially checked final runoffs, and one decisive first-round election in a runoff state. These are candidates for an expanded analysis, before timing, appeal and outcome-coverage checks.
- A proposed protocol that freezes measurement timing, the common opponent, the prediction target and the treatment definition before any new teammate analysis.

## Files and reproduction

- `PROTOCOL.md`: proposed choices and identification conditions. This is not an external preregistration.
- `dashboard-data.json`: the exact public examples, nomination additions, source links and data map.
- `poll-coverage/`: self-contained source snapshots, matching code, coverage ledger, provenance and reproduction instructions. Run `python3 poll-coverage/audit_matchups.py` from any directory using the script's full path if needed. Standard library only.
- `nomination-audit/`: official workbook extracts and source-based reconstruction of the 14 potential additions; see its README for dependencies and the exact command.
- `VERIFICATION.json`: independent reproduction checks.

The public JSON includes seven survey examples. The archive audit's separately preserved original-source example file contains six historical examples; Kentucky is additionally verified in the dashboard data and the archive's matched records. These are overlapping evidence collections, not additive sample counts.

## Interpretation limits

The surveys document hypothetical questions, not randomized assignment of nominees. Their contrasts measure stated electoral appeal, which includes recognition, ideology and incumbency and can miss organizational mobilization. Small differences are noisy. Colorado's ranking changes by date and opponent, demonstrating why a favorable poll cannot be selected retrospectively.

The November 2013 Mississippi poll is outside the proposed 90-day main window. It demonstrates that large candidate contrasts can coexist with a later close runoff; it does not automatically qualify for the proposed main analysis. The narrower old donor cutoff is not silently reused or changed.

The added primary events are not automatically valid experiments. Some defeated nominees later ran independently or as write-ins, and a Vermont nominee withdrew. A nomination intention-to-treat analysis retains these consequences; it cannot simply relabel nomination as removal from the entire general-election ballot.

Votes per a fixed pre-election population and vote shares preserve both turnout and persuasion as possible channels. The proposed teammate model does not control for postnomination turnout, spending, fundraising or own-candidate election performance. A state-election nomination is the assignment unit regardless of the number of precincts or ballots.

The current bottleneck is the intersection of reliable pre-nomination appeal measures, credible near-tied assignments and complete teammate outcomes. The recovered direct-poll sample is too small for a persuasive new regression-discontinuity estimate.

## Sources

Original poll URLs and question numbers are recorded in `dashboard-data.json`. Federal election results come from the FEC's certified primary/runoff/general compilations. Cowburn source DOI: https://doi.org/10.7910/DVN/D03ULS. The portable polling audit credits FiveThirtyEight and its preserved mirrors and retains their source hashes. No individual donor identities or voter records are distributed.
