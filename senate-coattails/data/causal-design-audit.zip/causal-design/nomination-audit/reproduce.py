#!/usr/bin/env python3
"""Reproduce nomination-event audit offline. No causal model or downstream outcomes."""
import argparse
import hashlib
import json
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parent
FEC_URLS = {
    2006: "https://www.fec.gov/documents/1656/results06.xls",
    2008: "https://www.fec.gov/documents/1659/2008congresults.xls",
    2010: "https://www.fec.gov/documents/1677/results10.xls",
    2012: "https://www.fec.gov/documents/1682/2012congresults.xls",
    2014: "https://www.fec.gov/documents/1705/results14.xls",
    2016: "https://www.fec.gov/documents/1890/federalelections2016.xlsx",
    2018: "https://www.fec.gov/documents/2706/federalelections2018.xlsx",
    2020: "https://www.fec.gov/documents/4228/federalelections2020.xlsx",
}
COWBURN_URL = "https://dataverse.harvard.edu/api/access/datafile/10706994"
EXCLUDED_STATES = {"AL", "AR", "GA", "MS", "NC", "OK", "SC", "SD", "TX", "LA"}
EXPECTED_NINE = {
    ("CT", 2006, "D"), ("MD", 2006, "D"), ("DE", 2006, "R"),
    ("WY", 2008, "D"), ("IA", 2008, "R"), ("AK", 2010, "R"),
    ("HI", 2014, "D"), ("VT", 2018, "R"), ("KY", 2020, "D"),
}


def party(value):
    return {"DEM": "D", "REP": "R", "dem": "D", "rep": "R"}.get(str(value), str(value))


def clean(value):
    return "" if pd.isna(value) else str(value).strip()


def key(row):
    return (row["state"], int(row["year"]), party(row["party"]))


def event_id(state, year, p):
    return f"{state}_{int(year)}_{p}_SENATE"


def load_fec(year):
    ext = "xlsx" if year >= 2016 else "xls"
    path = ROOT / "data" / "fec" / f"fec{year}.{ext}"
    book = pd.ExcelFile(path)
    sheet = next(s for s in book.sheet_names if "Results" in s and "Senate" in s)
    frame = pd.read_excel(path, sheet_name=sheet, header=0)
    frame.columns = [str(c).strip() for c in frame.columns]
    columns = {
        "district": next(c for c in frame if c in ("DISTRICT", "D")),
        "name": next(c for c in frame if c in (
            "CANDIDATE NAME", "CANDIDATE NAME (Last, First)", "LAST NAME, FIRST")),
        "fec": next(c for c in frame if c in ("FEC ID", "FEC ID#")),
        "runoff": next(c for c in frame if c in ("RUNOFF", "RUNOFF VOTES")),
        "primary": next(c for c in frame if c in ("PRIMARY", "PRIMARY VOTES")),
    }
    frame["_excel_row"] = frame.index + 2
    frame = frame[frame[columns["district"]].astype(str).str.startswith("S")
                  & frame[columns["name"]].notna()].copy()
    frame["_party"] = frame["PARTY"].map(party)
    return frame, columns, path, sheet


def official_pair(year, rows, cols, path, sheet, stage):
    vote_col = cols["runoff"] if stage == "final_primary_runoff" else cols["primary"]
    rows = rows.copy()
    rows["_votes"] = pd.to_numeric(rows[vote_col], errors="raise")
    rows = rows.sort_values("_votes", ascending=False)
    assert len(rows) == 2
    winner, loser = rows.iloc[0], rows.iloc[1]
    state, p = winner["STATE ABBREVIATION"], winner["_party"]
    w, l = int(winner["_votes"]), int(loser["_votes"])
    return {
        "event_id": event_id(state, year, p), "year": year, "state": state,
        "party": p, "office": "US Senate", "district": clean(winner[cols["district"]]),
        "source_group": "official_fec", "nomination_stage": stage,
        "winner": clean(winner[cols["name"]]), "loser": clean(loser[cols["name"]]),
        "winner_votes": w, "loser_votes": l,
        "winner_share_source": w / (w + l), "loser_share_source": l / (w + l),
        "margin_pp": 100 * (w - l) / (w + l),
        "margin_verification_status": "verified_official_FEC_vote_totals",
        "nomination_date": "", "official_date_verified": False,
        "date_verification_note": "Not extracted or independently verified in this audit",
        "winner_fec_id": clean(winner[cols["fec"]]),
        "loser_fec_id": clean(loser[cols["fec"]]),
        "fec_id_verification_status": "copied_from_official_FEC_result_row_not_independently_remapped",
        "source_url": FEC_URLS[year], "source_file": str(path.relative_to(ROOT)),
        "source_sheet": sheet, "source_row_winner_excel": int(winner["_excel_row"]),
        "source_row_loser_excel": int(loser["_excel_row"]),
        "source_record_id": "", "design_flags": "nomination_and_quality_measure_audit_pending",
        "quality_data_status": "not_checked", "causal_estimate_status": "none",
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=ROOT)
    args = parser.parse_args()
    out = args.output.resolve()
    out.mkdir(parents=True, exist_ok=True)
    baseline = pd.read_csv(ROOT / "data" / "existing65_cohort_keys.csv")
    base_keys = {key(row) for _, row in baseline.iterrows()}
    assert len(baseline) == len(base_keys) == 65

    raw = pd.read_csv(ROOT / "data" / "cowburn_senate_minimal.csv")
    assert len(raw) == 544 and raw["senate"].eq(1).all()
    valid_shares = raw["winner_p"].notna() & raw["second_p"].notna()
    raw["margin_pp"] = 100 * (raw["winner_p"] - raw["second_p"]).abs() / (raw["winner_p"] + raw["second_p"])
    conventional = ~raw["state_code"].isin(EXCLUDED_STATES)
    conventional &= ~((raw["state_code"] == "CA") & (raw["year"] >= 2012))
    conventional &= ~((raw["state_code"] == "WA") & (raw["year"] >= 2008))
    close = raw[valid_shares & conventional & (raw["margin_pp"] < 10)].copy()
    close["baseline_key"] = close.apply(lambda row: (row["state_code"], int(row["year"]), row["party"]), axis=1)
    close["present_in_existing65"] = close["baseline_key"].isin(base_keys)
    new = close[(close["margin_pp"] < 5) & ~close["present_in_existing65"]].copy()
    assert len(close) == 45 and close["present_in_existing65"].sum() == 25
    assert set(new["baseline_key"]) == EXPECTED_NINE
    close.drop(columns=["baseline_key"]).sort_values(["year", "state_code", "party"]).to_csv(
        out / "cowburn_close45_comparison.csv", index=False)
    additions = []
    for _, row in new.iterrows():
        st, yr, p = row["state_code"], int(row["year"]), row["party"]
        flags = ["official_votes_dates_and_nomination_rules_pending"]
        if (st, yr) in (("CT", 2006), ("AK", 2010)):
            flags.append("loser_returned_to_general_ballot_requires_ITT_vs_replacement_review")
        if (st, yr) == ("VT", 2018):
            flags.append("nominee_withdrew_requires_ITT_vs_presence_review")
        wid, lid = clean(row["winner_fec_id"]), clean(row["second_fec_id"])
        id_status = "provisional_not_independently_verified"
        if wid and wid == lid:
            id_status = "SOURCE_ERROR_same_FEC_ID_for_both_candidates_do_not_join"
        additions.append({
            "event_id": event_id(st, yr, p), "year": yr, "state": st, "party": p,
            "office": "US Senate", "district": "source_nomination_round_not_reaudited",
            "source_group": "cowburn_provisional", "nomination_stage": "primary_pending_official_round_audit",
            "winner": clean(row["winner_name"]), "loser": clean(row["second_name"]),
            "winner_votes": None, "loser_votes": None,
            "winner_share_source": row["winner_p"], "loser_share_source": row["second_p"],
            "margin_pp": row["margin_pp"], "margin_verification_status": "provisional_Cowburn_rounded_shares",
            "nomination_date": "", "official_date_verified": False,
            "date_verification_note": "Cowburn has no primary date field; official check pending",
            "winner_fec_id": wid, "loser_fec_id": lid, "fec_id_verification_status": id_status,
            "source_url": COWBURN_URL, "source_file": "data/cowburn_senate_minimal.csv",
            "source_sheet": "", "source_row_winner_excel": None, "source_row_loser_excel": None,
            "source_record_id": int(row["unique_id"]), "design_flags": ";".join(flags),
            "quality_data_status": "not_checked", "causal_estimate_status": "none",
        })

    runoffs = []
    frames = {}
    for year in FEC_URLS:
        frame, cols, path, sheet = load_fec(year)
        frames[year] = (frame, cols, path, sheet)
        for _, group in frame.groupby(["STATE ABBREVIATION", cols["district"], "_party"]):
            group = group[pd.to_numeric(group[cols["runoff"]], errors="coerce").notna()]
            if len(group) == 0:
                continue
            assert len(group) == 2, (year, group)
            runoffs.append(official_pair(year, group, cols, path, sheet, "final_primary_runoff"))
    runoff_df = pd.DataFrame(runoffs).sort_values(["year", "state", "party"])
    assert len(runoff_df) == 14
    assert (runoff_df["margin_pp"] < 5).sum() == (runoff_df["margin_pp"] < 10).sum() == 4
    runoff_df.to_csv(out / "fec_senate_final_runoffs_2006_2020.csv", index=False)
    additions.extend(runoff_df[runoff_df["margin_pp"] < 5].to_dict("records"))

    frame, cols, path, sheet = frames[2008]
    sc = frame[(frame["STATE ABBREVIATION"] == "SC") & (frame["_party"] == "D")]
    assert len(sc) == 2 and sc[cols["runoff"]].isna().all()
    sc_record = official_pair(2008, sc, cols, path, sheet, "first_round_decisive_no_runoff")
    assert sc_record["winner_votes"] == 74185 and sc_record["loser_votes"] == 73127
    additions.append(sc_record)
    result = pd.DataFrame(additions).sort_values(["year", "state", "party"])
    result["present_in_existing65"] = result.apply(lambda row: key(row) in base_keys, axis=1)
    assert len(result) == result["event_id"].nunique() == 14
    assert not result["present_in_existing65"].any()
    assert (result["margin_pp"] < 5).all()
    result.to_csv(out / "additional_close_events.csv", index=False)

    summary = {
        "status": "nomination_event_audit_only_no_causal_estimate",
        "comparison_key": ["state", "year", "party"],
        "comparison_key_warning": "Key is sufficient for these additions; future same-year special/full-term races need seat/event ID",
        "existing_cohort_rows": 65,
        "existing_cohort_rows_margin_lt5": int((baseline["margin_corrected_pp"].abs() < 5).sum()),
        "cowburn_senate_party_races": 544,
        "cowburn_with_both_shares": int(valid_shares.sum()),
        "cowburn_all_margin_lt5": int((raw["margin_pp"] < 5).sum()),
        "cowburn_all_margin_lt10": int((raw["margin_pp"] < 10).sum()),
        "cowburn_conservative_eligible_rows": int(conventional.sum()),
        "cowburn_conservative_with_both_shares": int((conventional & valid_shares).sum()),
        "cowburn_conservative_margin_lt5": int((conventional & (raw["margin_pp"] < 5)).sum()),
        "cowburn_conservative_margin_lt10": 45,
        "cowburn_lt10_overlap_existing65": 25,
        "cowburn_lt10_new_vs_existing65": 20,
        "cowburn_lt5_new_vs_existing65": 9,
        "official_even_cycle_Senate_primary_runoffs": 14,
        "official_runoffs_margin_lt5": 4,
        "official_runoffs_margin_lt10": 4,
        "restored_decisive_first_round_SC2008": 1,
        "additional_close_events": 14,
        "additional_official_vote_verified": 5,
        "additional_provisional_vote_margin": 9,
        "additional_official_date_verified": int(result["official_date_verified"].sum()),
        "additional_events_in_existing65": int(result["present_in_existing65"].sum()),
        "causal_analysis_ready_events": "not_assessed",
        "scope": "2006–2020 even-cycle main FEC Senate result sheets; odd-year specials excluded",
    }
    (out / "audit_summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
