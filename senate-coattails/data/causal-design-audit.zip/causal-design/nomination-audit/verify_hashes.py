#!/usr/bin/env python3
"""Check all files listed in the delivered SHA256 manifest."""
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
manifest = json.loads((root / "manifest_sha256.json").read_text())
errors = []
for name, expected in manifest["files"].items():
    path = root / name
    if not path.is_file():
        errors.append(f"missing: {name}")
    elif hashlib.sha256(path.read_bytes()).hexdigest() != expected:
        errors.append(f"hash mismatch: {name}")
if errors:
    raise SystemExit("\n".join(errors))
print(f"Verified {len(manifest['files'])} file hashes.")
