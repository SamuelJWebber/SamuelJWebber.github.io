# Audit schema

## Event tables

`additional_close_events.csv` and `fec_senate_final_runoffs_2006_2020.csv` use the same core schema. The first also has `present_in_existing65`.

| Field | Meaning |
|---|---|
| `event_id` | Readable state/year/party/Senate ID for this bounded audit; not a universal identifier for special elections. |
| `year`, `state`, `party`, `office` | Election year, state abbreviation, normalized D/R party and office. |
| `district` | FEC seat label, or a marker that the Cowburn nomination round has not been reaudited. |
| `source_group` | `official_fec` or `cowburn_provisional`. |
| `nomination_stage` | Decisive final primary runoff, decisive first round, or provisional Cowburn primary. |
| `winner`, `loser` | Source candidate names. Cowburn winner means eventual nominee, which is not always the first-round plurality winner. |
| `winner_votes`, `loser_votes` | Exact official decisive-round totals for five additions; blank for provisional Cowburn cases. |
| `winner_share_source`, `loser_share_source` | Cowburn's source shares; for official rows, shares recalculated among the two decisive-round candidates. |
| `margin_pp` | Absolute top-two margin in percentage points; strictly below five selects the additions. |
| `margin_verification_status` | Distinguishes official vote-derived margins from unverified source-share-derived margins. |
| `nomination_date` | Blank; not verified in this audit. |
| `official_date_verified` | False for every event. |
| `date_verification_note` | Why the date is not verified. |
| `winner_fec_id`, `loser_fec_id` | As supplied by the source. Not corrected silently. |
| `fec_id_verification_status` | Provisional source ID, explicit source error, or official-row transcription pending independent remapping. |
| `source_url`, `source_file`, `source_sheet` | Provenance sufficient to locate the input. |
| `source_row_winner_excel`, `source_row_loser_excel` | One-based Excel row numbers including the header, for official FEC records. |
| `source_record_id` | Cowburn `unique_id`; blank for official rows. |
| `design_flags` | Unresolved nomination/design review points. Flags do not implement exclusions. |
| `quality_data_status` | `not_checked`; no all-star measure is supplied. |
| `causal_estimate_status` | `none`; no causal estimate was calculated. |
| `present_in_existing65` | Exact state/year/normalized-party membership in the pinned baseline; false for all 14 additions. |

## Cowburn inputs and comparison

`data/cowburn_senate_minimal.csv` is a column subset of the public `Complete Dataset.tab`, restricted to `senate == 1`. It retains original name spellings and IDs. `winner_p` and `second_p` are proportions, not 0–100 percentages. The comparison CSV adds calculated `margin_pp` and `present_in_existing65`. Any other source information in the original 323-column dataset is intentionally omitted.

## Existing cohort

`data/existing65_cohort_keys.csv` preserves the original cohort's nine columns. It includes `myers_row`, year, state, party, two candidate names, corrected margin, winning slot and historical official-status label. The script normalizes `dem`/`rep` to D/R for matching. No matching uses downstream vote totals or donor values.

## Verification boundaries

The script verifies arithmetic, provenance rows, membership and asserted counts. It does not adjudicate source errors beyond the flagged duplicate ID, or establish random assignment, balance, exclusion restrictions, outcome comparability, donor completeness, or a valid first stage. The resulting tables are evidence for an improved sampling-frame audit.
