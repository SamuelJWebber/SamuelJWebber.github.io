#!/usr/bin/env python3
"""Reproduce the frozen alternate-nominee polling coverage audit.

Run: python3 audit_matchups.py
Uses Python 3 standard library only. Outputs are coverage.csv and
matched_same_poll_alternates.csv beside this script. This extracts coverage;
it does not estimate a causal effect, fit teammate outcomes, or rank candidates.
"""
import csv, collections, pathlib, datetime, json, re
p=pathlib.Path(__file__).resolve().parent
inputs=p/'inputs'
cohort=list(csv.DictReader(open(inputs/'frozen_main_65.csv')))
roster=list(csv.DictReader(open(inputs/'frozen_candidate_dates.csv')))
dates={r['pair_id']:r['primary_date'] for r in roster}
states={'CO':'Colorado','IL':'Illinois','MI':'Michigan','MO':'Missouri','MT':'Montana','NH':'New Hampshire','OR':'Oregon','PA':'Pennsylvania','VA':'Virginia','VT':'Vermont','WI':'Wisconsin','WV':'West Virginia','KY':'Kentucky','CT':'Connecticut','MD':'Maryland','DE':'Delaware','WY':'Wyoming','IA':'Iowa','AK':'Alaska','HI':'Hawaii'}
# These names are frozen from the Cowburn complete-primary-data audit. The
# additional dates remain explicitly unverified; only 2018 and 2020 can match
# the preserved snapshots. No teammate outcomes enter this extraction.
extra=list(csv.DictReader(open(inputs/'cowburn_additional_9.csv')))
for row in extra:
 id=row['pair_id']; dates[id]=row['primary_date']
 cohort.append(dict(myers_row=id,year=row['year'],state=row['state'],party=row['party'],name0=row['name0'],name1=row['name1']))
def dt(s):
 for fmt in ['%m/%d/%y','%m/%d/%Y','%Y-%m-%d']:
  try:return datetime.datetime.strptime(s,fmt).date()
  except ValueError:pass
 raise ValueError(s)
def norm(s):return re.sub('[^a-z]','',s.lower())
def lastmatch(full,cohortname):return norm(cohortname.split(',')[0]) in norm(full)
a=[]
for f in sorted(inputs.glob('mirror*senate*.csv')):
 for r in csv.DictReader(open(f)):
  r['candidate_party']=r.get('candidate_party',r.get('party',''));r['source_file']=f.name;a.append(r)
# same question stored in multiple mirror snapshots: dedupe by id, candidate id and value, but preserve first source.
dedupe={}
for r in a:dedupe.setdefault((r.get('question_id'),r.get('candidate_id'),r.get('pct')),r)
a=list(dedupe.values())
results=[];coverage=[]
for c in cohort:
 id=c['myers_row']; cutoff=dt(dates[id]); party={'dem':'DEM','rep':'REP'}[c['party']]
 rows=[r for r in a if r.get('cycle')==c['year'] and r.get('state')==states.get(c['state'],c['state']) and r.get('stage')=='general' and dt(r['end_date'])<cutoff]
 qs=collections.defaultdict(list)
 for r in rows:qs[r['question_id']].append(r)
 candqs=[[],[]]
 for q,rs in qs.items():
  for slot in [0,1]:
   match=[r for r in rs if lastmatch(r['candidate_name'],c[f'name{slot}']) and r['candidate_party']==party]
   if len(match)==1:candqs[slot].append((q,match[0],rs))
 start=len(results)
 for q0,r0,rs0 in candqs[0]:
  for q1,r1,rs1 in candqs[1]:
   if q0==q1: continue
   fields=['poll_id','start_date','end_date','sample_size','population','population_full','methodology']
   if not all(r0.get(k)==r1.get(k) for k in fields):continue
   others0={x['candidate_id']:x for x in rs0 if x['candidate_id']!=r0['candidate_id']}
   others1={x['candidate_id']:x for x in rs1 if x['candidate_id']!=r1['candidate_id']}
   # Require other candidate set exactly matched; one common major-party opponent.
   if set(others0)!=set(others1):continue
   commons=[x for x in others0 if others0[x]['candidate_party'] in ['DEM','REP'] and others0[x]['candidate_party']!=party]
   if len(commons)!=1:continue
   opp=commons[0];o0=others0[opp];o1=others1[opp]
   p0=float(r0['pct']);p1=float(r1['pct']);v0=float(o0['pct']);v1=float(o1['pct'])
   results.append(dict(pair_id=id,year=c['year'],state=c['state'],party=c['party'],name0=r0['candidate_name'],name1=r1['candidate_name'],common_opponent=o0['candidate_name'],poll_id=r0['poll_id'],question_id0=q0,question_id1=q1,pollster=r0['pollster'],start_date=r0['start_date'],end_date=r0['end_date'],primary_date=str(cutoff),days_before_primary=(cutoff-dt(r0['end_date'])).days,sample_size=r0['sample_size'],population=r0['population'],pct0=p0,pct1=p1,opponent_pct0=v0,opponent_pct1=v1,raw_support_difference_0minus1=p0-p1,margin_difference_0minus1=(p0-v0)-(p1-v1),two_party_share_difference_0minus1=100*(p0/(p0+v0)-p1/(p1+v1)),created_at0=r0['created_at'],created_at1=r1['created_at'],release_date_primary_source_status='not_yet_verified',url0=r0['url'],url1=r1['url'],source_file0=r0['source_file'],source_file1=r1['source_file']))
 matches=results[start:]
 coverage.append(dict(pair_id=id,year=c['year'],state=c['state'],party=c['party'],name0=c['name0'],name1=c['name1'],primary_date=str(cutoff),primary_date_status=('existing_official_date_roster' if not id.startswith('cowburn_') else 'requires_separate_official_verification'),rows_general_before_primary=len(rows),questions_for_candidate0=len(candqs[0]),questions_for_candidate1=len(candqs[1]),matched_question_pair_versions=len(matches),matched_poll_ids=len(set(x['poll_id']for x in matches)),has_30day_cutoff_match=any(x['days_before_primary']>=30 for x in matches)))
for name,data in [('matched_same_poll_alternates.csv',results),('coverage.csv',coverage)]:
 with open(p/name,'w') as f:
  w=csv.DictWriter(f,fieldnames=list(data[0]));w.writeheader();w.writerows(data)
print('Rows',len(a),'cycles',collections.Counter(r['cycle']for r in a))
print('Coverage',[(x['pair_id'],x['state'],x['year'],x['name0'],x['name1'],x['matched_question_pair_versions'],x['matched_poll_ids'],x['has_30day_cutoff_match'])for x in coverage if x['matched_poll_ids']])
print('Total main covered',sum(bool(x['matched_poll_ids']) for x in coverage if not x['pair_id'].startswith('cowburn')),'/65; extra',sum(bool(x['matched_poll_ids'])for x in coverage if x['pair_id'].startswith('cowburn')),'/9')
print('Distinctpolls',len(set(x['poll_id']for x in results)),'questionpairs',len(results))
