# Same-survey alternate-nominee polling feasibility audit

This is a source-coverage audit, not a coattail estimate. No teammate election outcomes were read or fitted. The underlying nomination cohort is the frozen 65-pair donor study, plus the nine additional close nonrunoff-state cases identified in the Cowburn primary-data audit.

## What was downloaded

The official FiveThirtyEight README links historical Senate and Governor CSVs, but both links returned ABC Politics HTML rather than CSV during this audit. `source_retrieval_audit.json` records redirects and hashes; the failed HTML responses are **not included in this package**.

Two independently hosted snapshots of FiveThirtyEight long-form polling data were retrieved. Simon Willison's mirror README explicitly states its source and mirroring purpose. Its most recent Senate-file commit is `c0bd050458f7e67bfc01c2d5d15f21c01cc73de2`, dated 2021-04-05. A second mirror, `khristel26/Senate`, supplies a 2022 snapshot with observations through 2022-11-03 as well as the older historical file. These are third-party preserved data, not an official live archive. All primary-source poll URLs remain in the extracted records. `mirror_provenance.json` records byte hashes, row counts, and retrieval times.

Combined Senate snapshots contain 6,462 unique candidate/question/value rows: 2,019 from 2018; 2,574 from 2020; 1,855 from 2022; 14 from 2024. The last group is irrelevant to this cohort. Governor data were downloaded (2,318 rows), but there is no frozen Governor-primary cohort to match in this task.

The official pollster-ratings `raw_polls.csv` was also downloaded. It is **unsuitable** for this purpose: its codebook defines candidate 1 and candidate 2 as the actual top-two election finishers, so it does not preserve general-election hypothetical matchups involving defeated primary contenders. The official `state-of-the-polls-2024/2020_polls.csv` contains survey metadata but no candidate vote shares and is likewise insufficient.

## Matching rule and observed coverage

Require general-election questions fielded before the primary; both same-party primary contenders; different question IDs; identical poll ID, start/end dates, sample size, population, full-population label, and methodology; an identical set of all other named candidates; and exactly one common opposing major-party candidate. Candidate names are matched within state/year/party, and all matches are retained for manual source verification. Each comparison is candidate A versus the common opponent minus candidate B versus the same opponent. The output contains raw support, margin, and two-party-share differences so the estimand can be selected before using downstream outcomes.

| Case | Distinct polls | Question-pair versions | At least one poll ending 30+ days before primary |
|---|---:|---:|---|
| CO 2022 Republican: Hanks / O'Dea | 1 | 1 | No |
| MO 2022 Democratic: Kunce / Busch Valentine | 2 | 6 | Yes |
| NH 2020 Republican: Bolduc / Messner | 3 | 3 | Yes |
| NH 2022 Republican: Bolduc / Morse | 6 | 7 | Yes |
| KY 2020 Democratic: McGrath / Booker, new Cowburn case | 1 | 1 | No |

The machine-readable archive match covers **4 of 65 main cases plus 1 of 9 new cases**, using **13 distinct surveys and 18 question-pair versions**. Only NH 2022 of the four matched main cases is within the existing 5-point primary-margin bandwidth. KY 2020 is also within 5 points according to Cowburn. Imposing the old donor cutoff of 30 days before the primary leaves 3 main cases, 9 distinct surveys, and no new cases. That donor cutoff is not automatically the correct polling cutoff; changing it requires a new explicit protocol before estimating downstream effects.

The Missouri poll versions use three different common Republican opponents and must not count as independent surveys. The Phillips Academy NH 2022 poll includes distinct population versions. Poll versions, repeated panels, and candidate-pair observations should not be treated as independent nomination events.

**These counts are not a census of existing polls.** Fifty-one main-cohort cases precede 2018 and are outside the recovered long-form archive years. The 2018 files also omit known alternative matchups, including Jenkins in WV, despite retaining Morrisey. Original-source recovery is therefore necessary rather than concluding that a case has no polling. The causal-shocks agent recovered original CO 2010 and WV 2018 contrasts in `original_poll_examples.json`, adding two distinct main-cohort cases beyond these archive counts. MS 2014 and GA 2014 are runoff examples outside the frozen main nonrunoff sample; GA 2020 is an illustration rather than a close-primary observation.

## Source and design caveats

- A matching metadata record does not establish randomized assignment of hypothetical nominees or that the questions were independently answered by the same respondents. The original questionnaire must establish design, versions, question order, and whether respondents saw multiple matchups. No retrieved example has yet established a randomized split-ballot experiment.
- Fieldwork ending before the primary is not by itself proof that the poll was publicly available before the primary or before a preregistered quality-freeze date. `created_at0/1` are retained, but archive creation times are not reliable substitutes for release dates. Release-date verification remains an explicit field in the extracted CSV.
- Existing 65-pair dates come from the project's audited candidate roster. New Cowburn case dates need separate official verification; Cowburn does not supply actual primary dates. Only the two new cases in archive years can affect the matching here.
- UNH's original September 2020 landing page is available at https://scholars.unh.edu/survey_center_polls/606/ and confirms release date 2020-09-02. The linked PDF returned HTTP 403 to both retrieval methods. The numerical values are therefore mirror-extracted until the questionnaire is recovered.
- The Phillips Academy original page verifies the relevant hypothetical comparison and provides full-report/methodology links: https://andoverpoll.com/2022/04/11/new-hampshire-2022-sununu-polling-at-72-5-hassan-leading-republican-opponents/ . Its registered-voter margin gives Hassan +14.9 versus Bolduc and +5.5 versus Morse. Do not combine its RV and LV versions as independent surveys.
- The quality contrast measures relative ex-ante general-election appeal against a specified opponent. It need not isolate charisma; ideology, incumbency, name recognition, and competence may all contribute. It avoids defining quality by the teammate outcome to be explained.
- Close-primary assignment could identify the effect of nominating the more appealing candidate near the cutoff. Polls alone do not make that treatment causal, and this currently verified cohort is far too small for a persuasive standalone RD estimate.

## Reproducible files

- `audit_matchups.py`: extraction and strict matching. Reads only the packaged `inputs/` snapshots and frozen rosters; no network access or external files are required.
- `coverage.csv`: all 74 case slots, including archive misses and date verification status.
- `matched_same_poll_alternates.csv`: 18 exact question-pair versions, question IDs, source URLs, timing, and alternative quality contrasts.
- `mirror_provenance.json`: hashes/provenance of downloaded long-form files.
- `original_poll_examples.json`: independent original-poll recovery by the causal-shocks agent; includes within-candidate quality-ranking reversal between May and August CO 2010 polls, illustrating why the window and aggregation rule must be frozen.

## Primary documentation

- Official polling links: https://github.com/fivethirtyeight/data/blob/master/polls/README.md
- Official ratings codebook: https://github.com/fivethirtyeight/data/blob/master/pollster-ratings/README.md
- Official survey-metadata codebook: https://github.com/fivethirtyeight/data/blob/master/state-of-the-polls-2024/README.md
- Preserved mirror provenance: https://github.com/simonw/fivethirtyeight-polls
- Additional recovered snapshot: https://github.com/khristel26/Senate
