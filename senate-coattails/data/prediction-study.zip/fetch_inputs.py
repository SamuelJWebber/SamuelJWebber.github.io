"""Download public source inputs and check the exact versions used in this benchmark."""
import argparse
import hashlib
import io
from pathlib import Path
import urllib.request
import pandas as pd

SOURCES = {
    'mit_senate.tsv': ('https://dataverse.harvard.edu/api/access/datafile/13887039', 'd4492e286046f73b111cf5706ee02be4c305897898317818afd06c0ac8a464e0'),
    'mit_president.csv': ('https://dataverse.harvard.edu/api/access/datafile/13887042', '9936410a6dd4ecc8be7fe202c6dff5b5f8fee59d88f35ab542ed12879941dcb7'),
    'H_dist_election_data.tab': ('https://dataverse.harvard.edu/api/access/datafile/11807548', 'b229f5c7e42045ff868b75f0502c10365216e3a4f5531faa2e803c38c744da5c'),
}


def fetch(destination):
    destination.mkdir(parents=True,exist_ok=True)
    for name,(url,expected) in SOURCES.items():
        request=urllib.request.Request(url,headers={'User-Agent':'SenateCandidatePrediction/1.0'})
        with urllib.request.urlopen(request,timeout=120) as response:
            content=response.read()
        actual=hashlib.sha256(content).hexdigest()
        if actual!=expected:
            raise ValueError(f'Source file version mismatch for {name}. Expected {expected}, got {actual}.')
        (destination/name).write_bytes(content)
        if name=='H_dist_election_data.tab':
            pd.read_csv(io.BytesIO(content),sep='\t',low_memory=False).to_csv(destination/'house_districts.csv',index=False)
        print(f'Fetched and verified {name}')


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input-dir',type=Path,default=Path(__file__).parent/'inputs')
    fetch(parser.parse_args().input_dir)
