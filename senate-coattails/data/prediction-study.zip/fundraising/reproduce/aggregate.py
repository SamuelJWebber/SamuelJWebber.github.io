"""Aggregate disclosed contributor-name breadth in the exact early money windows.
Names are the only donor identifiers supplied in the research replication file.
No address/ZIP or person/entity marker is available, so these are named contributor
counts, not complete individual donor counts. No such identifiers are exported.
"""
import sys,pathlib,json,re,time
import os
import pandas as pd,pyreadr,numpy as np
ROOT=pathlib.Path(os.environ['COATTAILS_FUNDRAISING_DIR'])
candidates=pyreadr.read_r(str(ROOT/'raw/descriptive_df.rds'))[None]
print('reading contributions',flush=True)
receipts=pyreadr.read_r(str(ROOT/'raw/all_itemized_contributions.rds'))[None]
print('loaded',receipts.shape,flush=True)
receipts['year']=receipts['year'].astype('int16')
receipts['Date']=pd.to_datetime(receipts['Date'])
# Preserve the source's names, standardizing punctuation/spacing only. This cannot
# distinguish same-name people or unify aliases, which remain measurement error.
receipts['name_key']=receipts['Contributor_Name'].str.upper().str.replace(r'[^A-Z0-9 ]',' ',regex=True).str.replace(r'\s+',' ',regex=True).str.strip()
meta={
 'raw_rows':int(len(receipts)),
 'columns':list(receipts.columns),
 'records_with_pac_in_name':int(receipts['name_key'].str.contains(r'\bPAC\b',na=False).sum()),
 'donor_identity':'Normalized contributor name only. Source has no address, ZIP, unique person ID, or entity type.',
 'coverage':'Disclosed itemized contributions in Case and Porter replication dataset, not all donations.'
}
result=candidates.copy();result['year']=result['year'].astype(int)
for window in ['cp','pre_filing_deadline']:
 print('window',window,flush=True)
 parts=[]
 for year in sorted(result['year'].unique()):
  window_meta=result.loc[result['year'].eq(year),['FECCandID',f'window_start_date_{window}',f'window_end_date_{window}']].rename(columns={f'window_start_date_{window}':'start',f'window_end_date_{window}':'end'})
  temp=receipts.loc[receipts['year'].eq(year),['FECCandID','Date','Amount','name_key']].merge(window_meta,on='FECCandID',how='inner',validate='many_to_one')
  temp=temp.loc[temp['Amount'].gt(0)&temp['name_key'].ne('')&temp['Date'].ge(pd.to_datetime(temp['start']))&temp['Date'].le(pd.to_datetime(temp['end']))]
  agg=temp.groupby('FECCandID').agg(**{f'observed_contributor_names_{window}':('name_key','nunique'),f'itemized_positive_amount_{window}':('Amount','sum'),f'itemized_transactions_{window}':('Amount','size')}).reset_index()
  agg['year']=year;parts.append(agg)
  print(year,'eligible receipts',len(temp),'candidates with receipts',len(agg),flush=True)
 result=result.merge(pd.concat(parts),on=['FECCandID','year'],how='left',validate='one_to_one')
 validwindow=result[f'window_start_date_{window}'].notna()&result[f'window_end_date_{window}'].notna()
 for c in [f'observed_contributor_names_{window}',f'itemized_positive_amount_{window}',f'itemized_transactions_{window}']:
  result.loc[validwindow,c]=result.loc[validwindow,c].fillna(0)
result=result.rename(columns={'state_postal':'state_abbrev','FECCandID':'candidate_id','cand_party':'party','cd':'district','winwin':'primary_winner','wingen':'general_winner'})
result['office']='House'
result['early_window_days']=(pd.to_datetime(result['window_end_date_cp'])-pd.to_datetime(result['window_start_date_cp'])).dt.days+1
result.to_csv(ROOT/'house_early_fundraising_with_breadth.csv',index=False)
(ROOT/'house_breadth_metadata.json').write_text(json.dumps(meta,indent=2))
print('done',len(result),flush=True)
