"""Export the validation-selected model without accessing test outcomes.
The scorer uses the fixed development choice and trains through 2016 only.
"""
import sys,pathlib,json,joblib
import os
import pandas as pd,numpy as np
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OneHotEncoder,StandardScaler
from sklearn.linear_model import LogisticRegression
ROOT=pathlib.Path(os.environ['COATTAILS_FUNDRAISING_DIR'])
d=pd.read_csv(ROOT/'house_benchmark_features.csv');d=d.loc[d.year.le(2016)].copy()
d['candidate_quality']=d.candidate_quality.fillna('Missing');d['log_field_size']=np.log1p(d.candnumber);d['log_breadth']=np.log1p(d.observed_contributor_names_pre_filing_deadline)
num=['inc','log_field_size','log_breadth'];cat=['candidate_quality','party','primary_type','state_abbrev']
trans=ColumnTransformer([('numeric',Pipeline([('impute',SimpleImputer(strategy='median')),('scale',StandardScaler())]),num),('category',OneHotEncoder(handle_unknown='ignore'),cat)])
chosen=json.loads((ROOT/'house_development_selection.json').read_text())
assert chosen['selected_model']=='observed_contributor_breadth'
m=Pipeline([('features',trans),('model',LogisticRegression(C=chosen['chosen']['observed_contributor_breadth']['C'],max_iter=3000,solver='lbfgs'))]).fit(d,d.primary_winner.astype(int))
coefs=m.named_steps['model'].coef_[0];scaler=m.named_steps['features'].named_transformers_['numeric'].named_steps['scale'];encoder=m.named_steps['features'].named_transformers_['category']
coefraw=coefs[:len(num)]/scaler.scale_
intercept=float(m.named_steps['model'].intercept_[0]-np.sum(coefs[:len(num)]*scaler.mean_/scaler.scale_))
catmapping={};offset=len(num)
for key,categories in zip(cat,encoder.categories_):
 catmapping[key]=dict(zip(categories.tolist(),coefs[offset:offset+len(categories)].tolist()));offset+=len(categories)
obj={'label':'Early contributor breadth model for own primary success','selected_using':'2014 and 2016 development Brier score','training_years':[2004,2006,2008,2010,2012,2014,2016],'frozen_test_years':[2018,2020],'training_rows':len(d),'target':'Probability of winning own partisan House primary in the historical candidate cohort','intercept':intercept,'numeric_coefficients':dict(zip(num,coefraw.tolist())),'categorical_coefficients':catmapping,'formula':'z = intercept + numeric coefficients * [inc, ln(1+field size), ln(1+observed contributor names)] + category coefficients; probability = 1/(1+exp(-z)). Unseen categories contribute zero.','limitations':['Not a charisma or coattail effect estimate.','Observed distinct contributor names includes entities and may merge different people or split aliases.','Candidates in source reached $5,000 by primary; predictor is not validated for complete entrant population.','Retrospective receipt-date records lack disclosure-vintage reconstruction.','Use the state filing deadline for breadth. No in-state donor filter is available.']}
# Confirm portable coefficients reproduce the sklearn pipeline exactly on training rows.
z=np.full(len(d),intercept)
for c,v in obj['numeric_coefficients'].items():z+=d[c].to_numpy()*v
for c,mapping in catmapping.items():z+=d[c].map(mapping).fillna(0).to_numpy()
p=1/(1+np.exp(-z));assert np.max(np.abs(p-m.predict_proba(d)[:,1]))<1e-12
(ROOT/'house_selected_scorer.json').write_text(json.dumps(obj,indent=2));joblib.dump(m,ROOT/'house_selected_model.joblib')
print(json.dumps({'file':str(ROOT/'house_selected_scorer.json'),'training_rows':len(d),'max_portable_error':float(np.max(np.abs(p-m.predict_proba(d)[:,1])))}))
