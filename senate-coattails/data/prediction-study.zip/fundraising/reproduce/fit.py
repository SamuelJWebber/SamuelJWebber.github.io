"""Temporal holdout benchmark of early funding vs contributor-name breadth.
Protocol in house_protocol.json is frozen before fitting. No site or Senate model
files are changed. Exports only candidate aggregates and predictions.
"""
import sys,pathlib,json,hashlib,warnings
import os
import pandas as pd,numpy as np
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OneHotEncoder,StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import brier_score_loss,log_loss,roc_auc_score,accuracy_score
ROOT=pathlib.Path(os.environ['COATTAILS_FUNDRAISING_DIR'])
protocol=json.loads((ROOT/'house_protocol.json').read_text())
d=pd.read_csv(ROOT/'house_early_fundraising_with_breadth.csv')
cut=pd.to_datetime(d.window_end_date_pre_filing_deadline)
start=pd.to_datetime(d.window_start_date_pre_filing_deadline)
primary=pd.to_datetime(d.window_end_date_pre_primary)
nonpartisan=d.state_abbrev.eq('LA')|(d.state_abbrev.eq('WA')&d.year.ge(2008))|(d.state_abbrev.eq('CA')&d.year.ge(2012))
valid=(d.contested.eq('Opposed Primary')&d.candnumber.gt(1)&cut.lt(primary)&cut.ge(start)&~nonpartisan)
cols=['primary_winner','itemized_positive_amount_pre_filing_deadline','observed_contributor_names_pre_filing_deadline']
valid &= d[cols].notna().all(axis=1)
exclusions={'source_rows':len(d),'uncontested_rows':int(d.contested.ne('Opposed Primary').sum()),'cutoff_not_strictly_before_primary':int((~cut.lt(primary)).sum()),'nonpartisan_rows':int(nonpartisan.sum()),'final_rows':int(valid.sum())}
d=d.loc[valid].copy()
d['candidate_quality']=d.candidate_quality.fillna('Missing')
d['log_field_size']=np.log1p(d.candnumber)
d['log_early_dollars']=np.log1p(d.itemized_positive_amount_pre_filing_deadline)
d['log_breadth']=np.log1p(d.observed_contributor_names_pre_filing_deadline)
d['log_source_total_early_dollars']=np.log1p(d.fundraising_amount_pre_filing_deadline)
d['split']=np.select([d.year.le(2012),d.year.le(2016)],['train','development'],default='test')
# Export compact, documented candidate features without downstream total receipts.
compact=['year','state_abbrev','district','office','candidate_id','candidate','party','raceid','split','primary_winner','inc','candidate_quality','primary_type','candnumber','window_start_date_pre_filing_deadline','window_end_date_pre_filing_deadline','window_end_date_pre_primary','itemized_positive_amount_pre_filing_deadline','observed_contributor_names_pre_filing_deadline','itemized_transactions_pre_filing_deadline','fundraising_amount_pre_filing_deadline']
d[compact].to_csv(ROOT/'house_benchmark_features.csv',index=False)
cat=['candidate_quality','party','primary_type','state_abbrev'];base=['inc','log_field_size']
features={'baseline':[],'early_itemized_dollars':['log_early_dollars'],'observed_contributor_breadth':['log_breadth'],'dollars_and_breadth':['log_early_dollars','log_breadth']}
def pipeline(extra,C):
 transform=ColumnTransformer([('numeric',Pipeline([('impute',SimpleImputer(strategy='median')),('scale',StandardScaler())]),base+extra),('category',OneHotEncoder(handle_unknown='ignore'),cat)])
 return Pipeline([('features',transform),('model',LogisticRegression(C=C,max_iter=3000,solver='lbfgs'))])
def metrics(y,p):return {'n':int(len(y)),'brier':float(brier_score_loss(y,p)),'log_loss':float(log_loss(y,p)),'auc':float(roc_auc_score(y,p)),'accuracy':float(accuracy_score(y,p>=0.5))}
train=d.loc[d.split.eq('train')];dev=d.loc[d.split.eq('development')];test=d.loc[d.split.eq('test')]
ytrain=train.primary_winner.astype(int);ydev=dev.primary_winner.astype(int);ytest=test.primary_winner.astype(int)
tuning=[];chosen={}
for name,extra in features.items():
 for C in protocol['regularization_grid_C']:
  m=pipeline(extra,C).fit(train,ytrain)
  p=m.predict_proba(dev)[:,1]
  tuning.append({'model':name,'C':C,**metrics(ydev,p)})
 best=min([r for r in tuning if r['model']==name],key=lambda r:r['brier'])
 chosen[name]=best
winner=min(chosen,key=lambda k:chosen[k]['brier'])
# Save and freeze the selected models before any test predictions exist.
(ROOT/'house_development_selection.json').write_text(json.dumps({'chosen':chosen,'selected_model':winner,'grid':tuning},indent=2))
fit=d.loc[d.split.ne('test')];yfit=fit.primary_winner.astype(int)
results=[];preds=test[compact].copy();modelparams={}
for name,extra in features.items():
 m=pipeline(extra,chosen[name]['C']).fit(fit,yfit)
 p=m.predict_proba(test)[:,1];preds['p_'+name]=p
 results.append({'model':name,'selected_on_development':name==winner,'C':chosen[name]['C'],'development':chosen[name],'test':metrics(ytest,p),'test_by_year':{str(int(y)):metrics(test.loc[test.year.eq(y),'primary_winner'],p[test.year.eq(y)]) for y in sorted(test.year.unique())}})
 modelparams[name]={'intercept':m.named_steps['model'].intercept_.tolist(),'coefficients':dict(zip(m.named_steps['features'].get_feature_names_out(),m.named_steps['model'].coef_[0].tolist()))}
# Source-estimated total dollars is a fixed, separately labeled timing sensitivity.
sensitivity=[]
for name,extra,mainname in [('source_total_dollars',['log_source_total_early_dollars'],'early_itemized_dollars'),('source_total_dollars_and_breadth',['log_source_total_early_dollars','log_breadth'],'dollars_and_breadth')]:
 m=pipeline(extra,chosen[mainname]['C']).fit(fit,yfit);p=m.predict_proba(test)[:,1]
 preds['p_'+name]=p;sensitivity.append({'model':name,'test':metrics(ytest,p),'C_inherited_from_main':chosen[mainname]['C']})
# Paired bootstrap resamples whole primary races using fixed held-out predictions.
rng=np.random.default_rng(2062026);groups=[np.array(g.index) for _,g in preds.reset_index(drop=True).groupby('raceid')]
predreset=preds.reset_index(drop=True);yv=predreset.primary_winner.to_numpy();boot={}
for a,b in [('baseline',winner),('early_itemized_dollars','observed_contributor_breadth'),('early_itemized_dollars','dollars_and_breadth')]:
 loss_a=(yv-predreset['p_'+a].to_numpy())**2;loss_b=(yv-predreset['p_'+b].to_numpy())**2
 draws=[]
 for z in range(2000):
  ix=np.concatenate([groups[j] for j in rng.integers(0,len(groups),len(groups))]);draws.append(float(np.mean(loss_a[ix]-loss_b[ix])))
 boot[f'{a}_minus_{b}']={'brier_improvement':float(np.mean(loss_a-loss_b)),'ci95_cluster_race':np.quantile(draws,[.025,.975]).tolist(),'bootstrap_draws':2000}
summary={'protocol':protocol,'exclusions':exclusions,'sample_by_split':d.groupby('split').agg(n=('candidate_id','size'),races=('raceid','nunique'),winners=('primary_winner','sum')).to_dict('index'),'sample_by_year':d.groupby('year').size().to_dict(),'selected_model':winner,'main_results':results,'secondary_source_dollars_sensitivity':sensitivity,'paired_bootstrap':boot,'source_sha256':hashlib.sha256((ROOT/'house_early_fundraising_with_breadth.csv').read_bytes()).hexdigest()}
(ROOT/'house_results.json').write_text(json.dumps(summary,indent=2))
(ROOT/'house_model_parameters.json').write_text(json.dumps(modelparams,indent=2))
preds.to_csv(ROOT/'house_test_predictions.csv',index=False)
pd.DataFrame([{'model':r['model'],'selected_on_development':r['selected_on_development'],'C':r['C'],'dev_brier':r['development']['brier'],**{'test_'+k:v for k,v in r['test'].items()}} for r in results]).to_csv(ROOT/'house_scoreboard.csv',index=False)
print(json.dumps({'selected_model':winner,'sample':summary['sample_by_split'],'results':results,'bootstrap':boot,'sensitivity':sensitivity},indent=2))
