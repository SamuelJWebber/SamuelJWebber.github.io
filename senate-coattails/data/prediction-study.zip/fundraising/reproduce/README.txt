Early fundraising and observed contributor breadth: temporal holdout benchmark

Purpose
Compare early itemized dollars and observed contributor-name breadth on the same
House-primary candidates. Predicts the candidate's own nomination success; it
neither estimates charisma nor effects on other candidates.

Reproduce
1. Use Python 3.10+ and a virtual environment.
2. pip install -r requirements.txt
3. python run.py --out ./output
The public, checksum-pinned inputs total about 133 MB. Processing the 9.26 million
transaction rows can require several GB of memory. Source data and donor names
are fetched from Harvard Dataverse directly into output/raw. This bundle does not
redistribute individual contributor records. All exported CSVs are candidate-level.
The data URL and hashes are in sources.json. No FEC API key is needed for this
House benchmark. The separate attempted Senate collection is not part of it.

Protocol and inputs
protocol.json records the frozen model specifications and temporal split.
Training: 2004, 2006, 2008, 2010, 2012.
Development/model choice: 2014 and 2016.
Final held-out evaluation: 2018 and 2020.
All four models use exactly the same candidate rows. Each model chooses logistic
regularization on development Brier score, then refits through 2016. The winning
feature model is also chosen on development Brier score, never on test results.

Sources
Colin R. Case and Rachel Porter (2025), Conceptualizing and measuring early
campaign fundraising in congressional elections, Political Science Research and
Methods, DOI: 10.1017/psrm.2025.10014.
Replication data version 1, released 2025-04-17: DOI 10.7910/DVN/FVLHCX.
Source authors combine OpenSecrets itemized transactions and FEC reports.

Cutoff and measurement
Positive itemized receipts are selected using transaction receipt date from cycle
start through the source's state filing deadline. Names are uppercased, punctuation
removed, and repeated whitespace collapsed before counting distinct names within
candidate/year. There is no ZIP, person ID, residence state, or person/entity flag.
The count includes any observed contributor names (potentially PACs), can merge
same-name people or split aliases, and does not count all small donors.

This is a retrospective reconstruction, not an archival real-time forecast.
Records lack original filing timestamp and amendment history, so contributions
cannot be proved available to the public at the cutoff. Source cohort selection
requires raising $5,000 by primary, which itself occurs after the early cutoff.
No cycle-end fundraising totals are used as predictive features.

Timing audit excludes any filing cutoff that is not strictly before the source
primary date, or before cycle start. This catches 81 source rows with cutoff at
or after primary, including Indiana 2018 with a 2020 cutoff. Some exclusions
overlap other restrictions. Nonpartisan primary systems are excluded. The main
benchmark retains 5,476 opposed-primary candidate rows. First-90-day source
windows sometimes end before they start and are not used in the main benchmark.

Target
Source winwin, interpreted as nomination success; it follows recorded runoff
winners where applicable. Includes incumbent and open-seat contests, and open,
closed, and partially closed partisan-primary rules. It is not a general-election
or Senate outcome. Race candidate lists can be incomplete because of source
fundraising thresholds. Probabilities are candidate-level, not forced to sum to
one within race. Results need not transfer to a complete entrant population.

Secondary dollar sensitivity
Source fundraising_amount_pre_filing_deadline adds estimated unitemized funds.
Those funds are prorated from quarterly report totals; the cutoff can therefore
use information from beyond that date. It is reported separately with fixed main
model hyperparameters. It uses the identical 1,768 test candidates. This broader
dollar measure predicts about as well as contributor breadth, so the results do
not establish that donor counts beat every reasonable dollar measure.

Outputs
house_scoreboard.csv: four main model comparisons.
house_results.json: complete metrics, CIs, sample/exclusion counts, protocol.
house_benchmark_features.csv: candidate-level inputs and outcome.
house_test_predictions.csv: untouched-period probabilities for every model.
house_selected_scorer.json: portable coefficients for the validation-selected
model, trained through 2016. Formula applies log1p to field size and breadth.
house_selected_model.joblib: same scikit-learn pipeline (load only trusted files).

Interpretation
On the development set, breadth wins by a tiny margin over dollars plus breadth.
The combined model happens to have the lowest test Brier score; it is not
retroactively selected. Breadth improves held-out Brier score over baseline by
about 4.5%. Paired bootstrap intervals resample primary races, not election years;
they condition on the two observed test cycles and fixed trained models.
