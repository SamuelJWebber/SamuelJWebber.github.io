#!/usr/bin/env python3
"""Download pinned public inputs, aggregate names locally, and reproduce benchmark.
No credentials needed. Raw contributor names stay in the local raw directory and
are never included in the exported candidate-level files.
"""
import argparse,pathlib,json,urllib.request,hashlib,runpy,os,shutil
HERE=pathlib.Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--out',type=pathlib.Path,default=HERE/'output');p.add_argument('--skip-aggregation',action='store_true',help='Reuse an existing house_early_fundraising_with_breadth.csv at --out');a=p.parse_args()
out=a.out.resolve();(out/'raw').mkdir(parents=True,exist_ok=True)
manifest=json.loads((HERE/'sources.json').read_text())
def digest(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  while b:=f.read(1024*1024):h.update(b)
 return h.hexdigest()
if not a.skip_aggregation:
 for source in manifest['files']:
  target=out/'raw'/source['filename']
  if target.exists() and digest(target)==source['sha256']:continue
  print('Downloading',source['filename'],flush=True)
  request=urllib.request.Request(source['url'],headers={'User-Agent':'research-replication/1.0'})
  temp=target.with_suffix(target.suffix+'.partial')
  with urllib.request.urlopen(request,timeout=300) as response,temp.open('wb') as file:shutil.copyfileobj(response,file)
  if digest(temp)!=source['sha256']:raise RuntimeError('Pinned source checksum mismatch: '+source['filename'])
  temp.replace(target)
 if not (out/'raw/dataverse_metadata.json').exists():
  request=urllib.request.Request(manifest['metadata_url'],headers={'User-Agent':'research-replication/1.0'})
  with urllib.request.urlopen(request,timeout=120) as response:(out/'raw/dataverse_metadata.json').write_bytes(response.read())
if not (out/'house_protocol.json').exists():shutil.copy2(HERE/'protocol.json',out/'house_protocol.json')
else:
 if (out/'house_protocol.json').read_bytes()!=(HERE/'protocol.json').read_bytes():raise RuntimeError('Output has different frozen protocol; choose a new --out')
shutil.copy2(HERE/'sources.json',out/'house_source_manifest.json')
os.environ['COATTAILS_FUNDRAISING_DIR']=str(out)
if not a.skip_aggregation:runpy.run_path(str(HERE/'aggregate.py'),run_name='__main__')
elif not (out/'house_early_fundraising_with_breadth.csv').exists():raise FileNotFoundError('No existing aggregate for --skip-aggregation')
runpy.run_path(str(HERE/'fit.py'),run_name='__main__')
runpy.run_path(str(HERE/'export_scorer.py'),run_name='__main__')
print('Outputs:',out)
