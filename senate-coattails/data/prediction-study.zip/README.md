# Candidate-quality prediction benchmarks
Analysis: Samuel Webber — https://www.linkedin.com/in/samuelwebber/
Public dashboard: https://senate-coattails.smartgoldfish.chatgpt.site/
Calculated November 5, 2026. These are retrospective backtests, not forecasts issued before the elections.

## Main conclusion
Prior electoral performance is the development-selected, broad-coverage Senate default among the eligible models. Its 2016–22 test MAE is 5.0363 percentage points versus6.0088 for baseline; 2024 is4.5027 versus5.4162. Officeholding and endorsement scores have smaller, separately compared coverage. Endorsements are reconstructed using the full historical source and are not real-time features.

Early contributor-name breadth is selected on2014–16 House primaries and improves2018–20 Brier score from0.16650 to0.15900. It beats itemized dollars from the same records but ties estimated total dollars. This is nomination success, including runoffs, not Senate general-election performance. Contributor names may include organizations or multiple people; small donors may be missing. Retrospective receipt dates do not establish contemporaneous filing availability.

Expert campaign ratings improve the2006→2010 House forecast, but national-wave bias explains much of the gain. Photo ratings add weak and inconsistent information. Paid video impressions do not improve a small11-state2022 holdout. Rally and organic-engagement sources cannot support a fair ranking with the verified data acquired.

No result here identifies personal charisma, an individual candidate's counterfactual vote, or causal coattails. A vote forecast is a validation gate for a quality proxy, not a causal design. Different datasets/targets cannot be placed in one numerical ranking.

## Reproduce
Install requirements.txt in a Python environment. Source datasets remain under their publishers' terms; raw author data are fetched, not redistributed here. Candidate-only aggregates and numerical outputs are supplied where appropriate. No donor-level records are included.

1. `python fetch_inputs.py --input-dir inputs` (check its --help if flags change).
2. `python benchmark.py --input-dir inputs --output-dir .` regenerates sample.csv and the Senate results directory. See README_benchmark.md for exact flags and methods.
3. `python history_ablation.py` and `python finalize.py` reproduce the main diagnostic and summary.
4. Fundraising: see fundraising/reproduce/README.txt. Its runner downloads pinned public files, builds aggregates and fits the selected predictor. The portable scorer is fundraising/results/house_selected_scorer.json.
5. Ratings: see ratings/README_REPRODUCE.md. Fetch and clean UCD data, then run the two rating benchmarks. Their files refer to inputs/house_districts.csv and sample.csv generated above.
6. Paid video: `python video_ads/run_video_ads.py`; see its README for snapshot windows and source licensing (CC BY-NC4.0).
7. Rallies: see rallies/README.md. This is an incomplete, tiered source audit, with no fitted prediction model; reproducing acquisition does not recreate human article judgments automatically.

## Interpretation
Mean absolute error (MAE) and root mean squared error (RMSE) are vote-share percentage points. Brier scores are squared errors for nomination probabilities (lower is better); log loss is a second probability score. They have different units and targets.

The Senate baseline uses prior presidential lean, incumbency and known White House/midterm status. The target is D/(D+R), including races with independents in the election, so it is not overall seat-winning probability. Eligibility is based on ballot structure, not an observed winning margin. See provenance.json and result-specific READMEs for all sample restrictions and timing problems.

Intervals resample held-out units conditional on the fitted model. They do not cover all model selection, future national shocks, measurement error, or unmeasured confounding. Existing coattail associations remain in the dashboard's separate original study archive.
