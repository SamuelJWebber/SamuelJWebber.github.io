# Candidate-proxy prediction audit

Audit date: 2026-11-05. Scope: the Senate benchmark implementation and generated sample/results, matched proxy comparisons, UC Davis expert-rating benchmark, and fundraising/video result descriptions in the dashboard. This is an analytical audit, not an independent re-collection of every source record.

## Conclusion

No blocking numerical or target-outcome leakage error was found in the main Senate benchmark. The dashboard's main values match the final result tables: mean absolute error falls from 6.0088 to 5.0363 percentage points on 120 test races in 2016–2022, and from 5.4162 to 4.5027 on 31 races in 2024. These are tests of own-race prediction, not estimates of causal candidate quality or coattails.

## Checks completed

- The sample has 689 unique state-election rows: 445 training, 93 development, 120 test, and 31 confirmation. There are no duplicate state-election keys.
- Every current-race presidential baseline predates the target election. Every observed candidate-history election predates its target. No missing values occur in the core baseline or history score.
- Historical performance can use presidential results and the nationwide Senate median from its own earlier election because these precede the later prediction target. It does not use target-election returns.
- Training-only imputation/scaling and fitting are implemented. Development fits through 2008, test through 2014, and confirmation through 2022. The candidate-exclusion and state-exclusion checks remove the specified observations from model fitting.
- Main-model paired comparisons use the same test races and fitting rows as their baseline. The post-selection history ablation distinguishes numerical previous performance from merely having a previous observed race.
- Supplemental `matched_proxies.py` also holds both fitting and evaluation rows constant across baseline, prior performance, alternative proxy, and their combination. It adds no tuning or winner selection.
- UC Davis uses fixed models trained on 2006 and evaluated on 2010. Its strict lane estimates survey partisan adjustment on 2006 informants and uses explicitly pre-election 2010 responses. No AIC or outcome-fitted feature extraction is used in this implementation.

## Matched-proxy results

Mean absolute error in percentage points; all four models in a row use identical fitting and test cohorts.

| Cohort / period | Training races | Test races | Baseline | Prior performance | Proxy | Prior + proxy |
|---|---:|---:|---:|---:|---:|---:|
| Experience / development 2010–2014 | 435 | 87 | 5.366 | 4.941 | 5.283 | 4.832 |
| Experience / test 2016 | 522 | 31 | 5.516 | 4.685 | 5.638 | 4.945 |
| Retrospective endorsements / development 2010–2014 | 255 | 27 | 3.611 | 3.459 | 3.974 | 3.980 |
| Retrospective endorsements / test 2016–2022 | 282 | 22 | 5.589 | 4.828 | 4.790 | 4.261 |

On the experience test cohort, adding experience to prior performance changes MAE improvement by −0.261 points, with a paired state-bootstrap 95% interval of [−0.784, +0.257]. On the endorsement cohort, endorsement alone and prior performance are effectively tied: improvement +0.038 [−0.727, +0.780]. Their combination improves on prior performance by +0.567 [+0.094, +1.069], but endorsements are retrospectively calibrated and performed worse in development. This does not establish a deployable winner.

## Interpretation limits

- Prior performance includes opponent strength, local party conditions, campaign circumstances, and noise. Predictive value is not proof of personal charisma, and it says nothing by itself about effects on other candidates.
- Candidate-exclusion validation still permits the held-out nominees' historical results as input features. It means their races were excluded from model fitting, not that their electoral histories were unknown. The no-history subgroup means no prior comparable regular Senate race in this source; special-election veterans can be included.
- Endorsement scores use full-sample newspaper-bias calibration, making them a retrospective measurement lane. Experience's recent test coverage is only 2016. Comparisons across different cohorts cannot support a universal ranking.
- The UC Davis baseline's 2010 mean error is +13.973 points; adding campaign ratings reduces it to +10.427. Most of the 3.511-point MAE improvement reflects correction of the 2006-to-2010 national shift. Centered RMSE changes only from 4.881 to 4.772. Contemporary expert judgments can reflect the electoral environment and polling. Selecting a preferred model on this one holdout is not an additional independently confirmed result.
- Fundraising predicts House primary success, not Senate general-election appeal. Contributor-name breadth is not a verified census of individuals; source inclusion requires reaching $5,000 by the primary, and retrospective transaction dates do not fully reconstruct filing availability. The matched itemized-dollar comparison and estimated-total-dollar sensitivity answer different questions.
- Paid video exposure uses a small, selected single-cycle archive and leave-one-state-out evaluation. It is retrospective out-of-sample evidence, not temporal confirmation, voluntary audience engagement, or a causal advertising effect.
- Bootstrap intervals condition on the fitted predictions and observed evaluation cycles. They do not cover all fitting/selection uncertainty or arbitrary future national waves. Results are retrospective held-out benchmarks, not preregistered prospective forecasts.

## Minor non-blocking data note

Two reversed-order names in 2022 (Bob McDermott and Adam Paul Laxalt) are not normalized into conventional person keys by the selective comma parser. They have no repeated comparable Senate appearance in the current sample, so this does not alter the reported estimates. The conservative identity scheme remains a limitation for future extensions.
