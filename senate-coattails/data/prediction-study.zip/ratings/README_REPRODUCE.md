Candidate rating benchmark reproducibility component

Extract this archive into the root of the main coattails prediction package. Its top-level ratings/ directory should sit beside fetch_inputs.py, benchmark.py, inputs/, and sample.csv. This component does not redistribute source datasets, respondent records, or source PDFs. Original data are downloaded directly from their public hosts and verified by SHA256. The archive includes analysis code, provenance, and aggregate prediction/result outputs.

Use Python3.10+ and install pandas2.2+ (clean.py uses include_groups=False), numpy, and scikit-learn. From the main package root:

    python -m pip install "pandas>=2.2" numpy scikit-learn
    python fetch_inputs.py
    python benchmark.py
    python ratings/ucd/acquire.py
    python ratings/ucd/clean.py
    python ratings/ucd/benchmark_ratings.py
    python ratings/video/acquire_clean.py
    python ratings/video/benchmark_faces.py

The main fetcher creates inputs/house_districts.csv by converting its pinned tab-separated scholarly input. The main benchmark creates sample.csv. UCD's benchmark reads ../../inputs/house_districts.csv relative to its script; the photo benchmark reads ../../sample.csv. No working-directory-specific absolute paths are required.

UCD acquire.py reads ucd/sources.json, verifies source bytes, and extracts the2006 ZIPs into ucd/raw/2006/, preserving the filenames expected by clean.py. Pass --include-docs to download the original PDF codebooks too. The default fetch downloads the underlying Stata and ZIP data. A source hash mismatch stops execution rather than silently switching versions. Photos are fetched from a fixed QSS Git commit, with hash checking in video/acquire_clean.py.

Existing result files are included for inspection before downloads. Running the scripts regenerates them; local path and download-time metadata may differ, while model results should match with the same inputs and numerical-library behavior. No raw source or respondent table is present in this archive. Generated local cleaned data and joined case-audit tables appear only after running acquisition and analysis.

UCD: results in ratings/ucd/results/. Primary2006->2010 strict-date delegate benchmark; source-purged secondary and tiny endorsement overlap reported separately. The simple training election cannot learn the opposite2010 national wave; see README.md and results.json before interpreting gains as durable candidate talent.

Photos: results in ratings/video/benchmark/. Primary2000/2002->2004 own-Senate-vote test;2006 is secondary with unresolved rating provenance. This measures facial perceived competence, not general talent. The Benjamin–Shapiro governor-video numeric dataset was not recovered and is not represented as tested.

These are predictive own-vote comparisons across distinct samples; they do not estimate causal coattails or establish a common-sample winner among all measures. All model formulas, case filtering, and original reported numerical results are unchanged in this portability package.
