"""Fetch pinned UC Davis source files from sources.json; never bundled with this package.
Run python ratings/ucd/acquire.py [--include-docs] from the project root.
"""
from pathlib import Path
from urllib.request import Request,urlopen
from concurrent.futures import ThreadPoolExecutor
import argparse,hashlib,json,zipfile
P=Path(__file__).resolve().parent

def acquire(item):
    target=P/item['file']; target.parent.mkdir(parents=True,exist_ok=True)
    if not target.exists():
        request=Request(item['url'],headers={'User-Agent':'CandidateRatingsReplication/1.0'})
        with urlopen(request,timeout=120) as response: content=response.read()
    else: content=target.read_bytes()
    actual=hashlib.sha256(content).hexdigest()
    if actual!=item['sha256']:
        raise ValueError(f'Source version mismatch: {target.name}. Expected {item["sha256"]}, got {actual}.')
    if not target.exists(): target.write_bytes(content)
    if target.suffix=='.zip':
        extraction=P/'raw/2006'; extraction.mkdir(parents=True,exist_ok=True)
        with zipfile.ZipFile(target) as archive:
            for entry in archive.infolist():
                if '__MACOSX' in Path(entry.filename).parts: continue
                destination=(extraction/entry.filename).resolve()
                if not destination.is_relative_to(extraction.resolve()):
                    raise ValueError('Unsafe archive member path')
                archive.extract(entry,extraction)
    return {'file':item['file'],'url':item['url'],'sha256':actual,'bytes':len(content)}

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--include-docs',action='store_true',help='Also fetch original PDF codebooks and questionnaires.')
    args=parser.parse_args()
    manifest=json.loads((P/'sources.json').read_text())
    selected=[x for x in manifest if args.include_docs or not x['file'].lower().endswith('.pdf')]
    with ThreadPoolExecutor(max_workers=4) as pool: records=list(pool.map(acquire,selected))
    (P/'downloaded_manifest.json').write_text(json.dumps(records,indent=2)+'\n')
    for r in records: print(f'Verified {r["file"]} ({r["bytes"]} bytes)')
