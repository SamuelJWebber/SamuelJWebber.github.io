"""Fixed 2006->2010 own-House-vote benchmark. No test tuning or outcome fitted feature extraction."""
from pathlib import Path
import json
import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
P=Path(__file__).resolve().parent; C=P/'clean'; O=P/'results';O.mkdir(exist_ok=True)
d=pd.read_csv(C/'house_ratings_2006_2010.csv')
traits={'attention':'atten','integrity':'integ','self_fund':'fundown','fundraising':'fundraise','name_recognition':'namerec','public_persuasion':'public','professional_campaign':'prof','work_with_leaders':'workoth','competence':'comp','issue_grasp':'grasp','problem_solving':'solve','qualifications':'qual','overall_campaigner':'camp','overall_public_servant':'serv'}
campaign=['attention','self_fund','fundraising','name_recognition','public_persuasion','professional_campaign','overall_campaigner']
character=['integrity','work_with_leaders','competence','issue_grasp','problem_solving','qualifications','overall_public_servant']
e06=pd.read_stata(P/'raw/2006/2006 Expert Informant Data/2006_ucd_ces_expert_survey_data.dta',convert_categoricals=False)
e10=pd.read_stata(P/'raw/2010_ucd_ces_expert_survey_data.dta',convert_categoricals=False)
ids=set(d.district_id);e06=e06.loc[e06.district.isin(ids)].copy(); e10=e10.loc[e10.district.isin(ids)&e10.inftype.eq(2)&e10.endtime.notna()&e10.endtime.lt(pd.Timestamp('2010-11-02'))].copy()
def party_score(s):return s.map({1:-1,2:-1,3:-1,4:0,5:1,6:1,7:1})
e06['pid']=party_score(e06.informantptyid);e10['pid']=party_score(e10.ipid)
coeffs=[]
for t,short in traits.items():
 for party in ['d','r']:
  col06=party+short;col10=party+{'prof':'profcamp','qual':'qualif'}.get(short,short)
  y=e06[col06].where(e06[col06].between(1,7));valid=y.notna()&e06.pid.notna()
  # Survey-bias correction is estimated on training-wave informants only, not outcomes.
  bias=LinearRegression().fit(e06.loc[valid,['pid']],y[valid]).coef_[0]
  coeffs.append({'trait':t,'party':party,'training_party_bias_slope':float(bias),'n':int(valid.sum())})
  for year,e,col in [(2006,e06,col06),(2010,e10,col10)]:
   val=e[col].where(e[col].between(1,7))-bias*e.pid
   m=val.groupby(e.district).mean();d.loc[d.year.eq(year),f'{party}_{t}_strict_trainadjust']=d.loc[d.year.eq(year),'district_id'].map(m)
 for prefix in ['strict_trainadjust']:
  d[f'delta_{t}_{prefix}']=d[f'd_{t}_{prefix}']-d[f'r_{t}_{prefix}']
for component,ts in [('campaign',campaign),('character',character)]:
 cols=[f'delta_{t}_strict_trainadjust' for t in ts]
 d[f'{component}_strict']=d[cols].mean(axis=1).where(d[cols].notna().all(axis=1))
 d[f'{component}_published']=d[f'delta_{component}_delegate_purged_mean']
# Join independently assembled paper candidate names and retrospective endorsement scores.
h=pd.read_csv(P.parent.parent / 'inputs' / 'house_districts.csv').rename(columns={'dist':'district','news_quality':'endorsements_retrospective'})
assert not h.duplicated(['state_abbrev','district','year']).any()
d=d.merge(h[['state_abbrev','district','year','cand_d','cand_r','endorsements_retrospective']],on=['state_abbrev','district','year'],how='left',validate='one_to_one')
d.to_csv(C/'benchmark_sample_features.csv',index=False)
pd.DataFrame(coeffs).to_csv(O/'training_party_bias_coefficients.csv',index=False)
BASE=['prior_dem_share','prior_pres_dem_share','incumbency_dem_minus_rep','open_seat','outparty_candidate_prior_office']
METRICS=[];PREDS=[];COEFS=[];COMPARISONS=[];SAMPLE=[]
rng=np.random.default_rng(20261105)
for lane in ['strict_pre_election','published_purged','published_with_endorsements_retrospective']:
 tag='strict' if lane=='strict_pre_election' else 'published'
 features={'baseline':BASE,'campaign':BASE+[f'campaign_{tag}'],'character':BASE+[f'character_{tag}'],'campaign_and_character':BASE+[f'campaign_{tag}',f'character_{tag}']}
 required=BASE+[f'campaign_{tag}',f'character_{tag}','target_dem_share']
 if 'endorsements' in lane:
  features['endorsements_retrospective']=BASE+['endorsements_retrospective']
  features['all_retrospective']=BASE+[f'campaign_{tag}',f'character_{tag}','endorsements_retrospective']
  required+=['endorsements_retrospective']
 sample=d.loc[d[required].notna().all(axis=1)&d.no_challenger.eq(0)&d.target_dem_share.gt(0)&d.target_dem_share.lt(1)].copy()
 train=sample.loc[sample.year.eq(2006)];test=sample.loc[sample.year.eq(2010)]
 SAMPLE.append({'lane':lane,'n_train':len(train),'n_test':len(test),'n_districts_test':test.district_id.nunique()})
 if len(train)<15 or len(test)<5: continue
 losses={};preds={}
 for model,ff in features.items():
  means=train[ff].mean();scales=train[ff].std().replace(0,1)
  x=(train[ff]-means)/scales;xt=(test[ff]-means)/scales
  fit=LinearRegression().fit(x,train.target_dem_share)
  pred=np.clip(fit.predict(xt),0,1);err=100*(pred-test.target_dem_share.to_numpy())
  losses[model]=np.abs(err);preds[model]=err
  METRICS.append({'lane':lane,'model':model,'train_n':len(train),'test_n':len(test),'mae_pp':float(np.mean(abs(err))),'rmse_pp':float(np.sqrt(np.mean(err**2))),'bias_pp':float(np.mean(err)),'diagnostic_centered_rmse_pp':float(np.std(err)),'selection_eligible':bool(len(test)>=30 and 'retrospective' not in lane)})
  for f,co in zip(ff,fit.coef_):COEFS.append({'lane':lane,'model':model,'variable':f,'coefficient_per_training_sd':float(co),'training_mean':float(means[f]),'training_sd':float(scales[f])})
  COEFS.append({'lane':lane,'model':model,'variable':'INTERCEPT','coefficient_per_training_sd':float(fit.intercept_)})
  for j,(_,r) in enumerate(test.iterrows()):PREDS.append({'lane':lane,'model':model,'state_abbrev':r.state_abbrev,'district_id':r.district_id,'year':int(r.year),'observed_share':r.target_dem_share,'predicted_share':float(pred[j]),'error_pp':float(err[j]),'cand_d':r.cand_d,'cand_r':r.cand_r})
 # Each2010 district appears once. Paired bootstrap resamples districts, keeps fitted model fixed.
 ix=rng.integers(0,len(test),size=(10000,len(test)))
 comparisons=[('baseline',x) for x in features if x!='baseline']+[('character','campaign'),('campaign','campaign_and_character')]
 for ref,model in comparisons:
  delta=losses[ref]-losses[model];bs=delta[ix].mean(axis=1)
  rmse_bs=np.sqrt((preds[ref][ix]**2).mean(axis=1))-np.sqrt((preds[model][ix]**2).mean(axis=1))
  COMPARISONS.append({'lane':lane,'reference':ref,'model':model,'mae_improvement_pp':float(delta.mean()),'mae_improvement_ci_low':float(np.quantile(bs,.025)),'mae_improvement_ci_high':float(np.quantile(bs,.975)),'rmse_improvement_pp':float(np.sqrt(np.mean(preds[ref]**2))-np.sqrt(np.mean(preds[model]**2))),'rmse_improvement_ci_low':float(np.quantile(rmse_bs,.025)),'rmse_improvement_ci_high':float(np.quantile(rmse_bs,.975))})
for name,data in [('metrics',METRICS),('predictions',PREDS),('coefficients',COEFS),('paired_comparisons',COMPARISONS),('samples',SAMPLE)]:pd.DataFrame(data).to_csv(O/f'{name}.csv',index=False)
result={'split':{'train':2006,'holdout':2010},'estimator':'OLS with intercept; training-only scaling; fixed compact features; predictions clipped[0,1]; no tuning','primary':'strict_pre_election','samples':SAMPLE,'metrics':METRICS,'comparisons':COMPARISONS,'measurement':{'strict':'2006 political delegates/legislators. Item1–7;8 DontKnow->missing. Regress each party-specific item on informant PID in2006. Subtract2006 slope*PID in both waves.2010 delegates limited to explicitly dated completion before2010-11-02; exclude165 missing dates and1 election-day respondent.7-item complete-case D-R campaign and character means.','published':'Source-provided partisan-purged delegate district means;2010 contains unknown/election-day date cases.','endorsements':'Retrospectively estimated full-sample newspaper-endorsement candidate valence; not an historically obtainable real-time feature.'},'baseline':BASE,'uncertainty':'10000 paired holdout-district bootstraps, fitted training model fixed; positive difference means improvement. Same train/test complete-case rows within each lane. Lanes can have different samples.','limitations':['Own-House-vote predictive test, not coattail effect or candidate causal talent.','Only one independent election-cycle transition;2006 D wave to2010 R wave. Baseline uses previous presidential vote and has no national swing forecast.','Holdout same districts may include same incumbents.','Partisan adjustments2006 fitted solely on training informants; strict2010 measured from fewer respondents.','Final ranking is model selection on this holdout, not an additional untouched confirmation.','diagnostic_centered_rmse_pp removes the holdout mean error ex post and is not a deployable forecast.','Bootstrap intervals condition on this single election; they do not represent uncertainty across future national election cycles.','Endorsement overlap only63train/8test; computed exploratory comparison ineligible for winner selection.','Observed vote shares use released Jacobson data rounded one decimal in2010.']}
(O/'results.json').write_text(json.dumps(result,indent=2));print(pd.DataFrame(METRICS).to_string(index=False));print(pd.DataFrame(COMPARISONS).to_string(index=False))
