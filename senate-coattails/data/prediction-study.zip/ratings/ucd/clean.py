"""Reproduce harmonized pre-election expert-rating features. No fitted outcome model."""
from pathlib import Path
import pandas as pd
import numpy as np
import json
import warnings
warnings.filterwarnings("ignore",category=pd.errors.PerformanceWarning)
P=Path(__file__).resolve().parent; R=P/'raw'; C=P/'clean'; C.mkdir(exist_ok=True)
D={2006:pd.read_stata(R/'2006/2006_ucd_ces_district_data.dta',convert_categoricals=False),2010:pd.read_stata(R/'2010_ucd_ces_district_data.dta',convert_categoricals=False)}
D[2006]=D[2006].loc[D[2006].informant_n.notna()].rename(columns={'distid':'district'}).copy()
E={2006:pd.read_stata(R/'2006/2006 Expert Informant Data/2006_ucd_ces_expert_survey_data.dta',convert_categoricals=False),2010:pd.read_stata(R/'2010_ucd_ces_expert_survey_data.dta',convert_categoricals=False)}
# Valid substantive ratings are1–7;2006 uses8 for Don't Know.
traits={'attention':'atten','integrity':'integ','self_fund':'fundown','fundraising':'fundraise','name_recognition':'namerec','public_persuasion':'public','professional_campaign':'prof','work_with_leaders':'workoth','competence':'comp','issue_grasp':'grasp','problem_solving':'solve','qualifications':'qual','overall_campaigner':'camp','overall_public_servant':'serv'}
campaign=['attention','self_fund','fundraising','name_recognition','public_persuasion','professional_campaign','overall_campaigner']
character=['integrity','work_with_leaders','competence','issue_grasp','problem_solving','qualifications','overall_public_servant']
def suffix_trait(short,y): return {'prof':'profcamp','qual':'qualif'}.get(short,short) if y==2010 else short
rows=[]; mapping=[]
for y,d in D.items():
 out=pd.DataFrame({'district_id':d.district,'year':y,'state_abbrev':d.district.str[:2], 'district':d.district.str[2:].replace('AL','0').astype(int), 'office':'US House'})
 out['target_dem_share']=d['demvote06' if y==2006 else 'demvote10']/100
 out['prior_dem_share']=d['demvote04' if y==2006 else 'demvote08']/100
 out['prior_pres_dem_share']=d['dpresvote04' if y==2006 else 'dpresvote08']/100
 out['incumbent_party_before_election']=d['pty109' if y==2006 else 'pty111'].map({1:'D',2:'R'})
 out['incumbent_running']=d['incran06' if y==2006 else 'incran10']
 out['incumbency_dem_minus_rep']=out.incumbent_party_before_election.map({'D':1,'R':-1})*out.incumbent_running
 out['open_seat']=d['open06gj' if y==2006 else 'open10']
 out['no_challenger']=d['nochall06' if y==2006 else 'nochall10']
 out['outparty_candidate_prior_office']=d['chexp06gj' if y==2006 else 'chexp10']
 out['sample_random']=d.sample06
 out['random_sample_party_weight']=d['ptyweight' if y==2006 else 'ptyweight06']
 out['delegate_n']=d['informant_n' if y==2006 else 'n_d10']
 out['combined_n']=d['informant_n' if y==2006 else 'n_c10']
 for group in ['delegate','combined']:
  suff='_pmn' if y==2006 else ('_pd10' if group=='delegate' else '_pc10')
  for trait,short in traits.items():
   for party in ['d','r']:
    old=party+suffix_trait(short,y)+suff; new=f'{party}_{trait}_{group}_purged'
    out[new]=d[old]
    mapping.append({'year':y,'new_variable':new,'source_variable':old,'construction':'Source-provided partisan-bias-purged district mean. Scale original1–7, adjusted values may exceed bounds.'})
   out[f'delta_{trait}_{group}_purged']=out[f'd_{trait}_{group}_purged']-out[f'r_{trait}_{group}_purged']
  for component,ts in [('campaign',campaign),('character',character)]:
   for party in ['d','r']:
    cols=[f'{party}_{t}_{group}_purged' for t in ts]
    # Complete seven-item means keep equal measurement across cases.
    out[f'{party}_{component}_{group}_purged_mean']=out[cols].mean(axis=1).where(out[cols].notna().all(axis=1))
   out[f'delta_{component}_{group}_purged_mean']=out[f'd_{component}_{group}_purged_mean']-out[f'r_{component}_{group}_purged_mean']
 # Raw unpurged means permit an outcome-free sensitivity independent of released global party adjustments.
 e=E[y]; e=e.loc[e.district.isin(d.district)].copy()
 for group in ['delegate','combined','delegate_strict_date']:
  eg=e.copy()
  if y==2010 and group.startswith('delegate'): eg=eg.loc[eg.inftype.eq(2)]
  if group=='delegate_strict_date' and y==2010:
   eg=eg.loc[eg.endtime.notna() & eg.endtime.lt(pd.Timestamp('2010-11-02'))]
  for trait,short in traits.items():
   for party in ['d','r']:
    old=party+suffix_trait(short,y)
    vals=eg[old].where(eg[old].between(1,7)).groupby(eg.district).mean();out[f'{party}_{trait}_{group}_raw']=out.district_id.map(vals)
   out[f'delta_{trait}_{group}_raw']=out[f'd_{trait}_{group}_raw']-out[f'r_{trait}_{group}_raw']
  if group=='delegate_strict_date': out['delegate_strict_date_n']=out.district_id.map(eg.groupby('district').size())
 # Candidate names are retained in a separate audit file due to observed inconsistent assignment in source.
 rows.append(out)
out=pd.concat(rows,ignore_index=True);out.to_csv(C/'house_ratings_2006_2010.csv',index=False)
pd.DataFrame(mapping).to_csv(C/'variable_mapping.csv',index=False)
# Unaltered names as audit aid, not merge keys or verification of identity.
e=E[2010];names=e.groupby(['district','housecanddemname','housecandrepname'],dropna=False).size().reset_index(name='respondent_n');names.to_csv(C/'candidate_names_2010_source_unverified.csv',index=False)
# Earlier independent incumbent ratings, no challenger scores: 2009 -> 2010.
a=pd.read_stata(R/'2009_ucd_ces_district_data.dta',convert_categoricals=False);b=D[2010]
early=a.merge(b[['district','pty111','incran10','demvote10','demvote08','dpresvote08']],on='district',validate='one_to_one')
early['state_abbrev']=early.district.str[:2];early['district_number']=early.district.str[2:].replace('AL','0').astype(int);early['rating_year']=2009;early['target_year']=2010
early.to_csv(C/'incumbent_ratings_2009_with_2010_target.csv',index=False)
manifest={'unit':'US House district-election, Democratic minus Republican candidate ratings','rows':len(out),'rows_by_year':out.year.value_counts().to_dict(),'predictor_timing':{'2006':'October2006 mailed expert survey; released file has no individual timestamps.','2010':'October2010 survey; dates in individual data run2010-10-07 through2010-11-02. Three on election day,165 delegates missing date. Source-provided district aggregate includes these; strict-date raw version excludes missing/election-day dates.'},'primary_complete_rows_per_year':out.groupby('year').apply(lambda z: int(z[['target_dem_share','prior_pres_dem_share','delta_campaign_delegate_purged_mean','delta_character_delegate_purged_mean']].notna().all(axis=1).sum()),include_groups=False).to_dict(),'traits':traits,'campaign_traits':campaign,'character_traits':character,'recommended_split':{'train':2006,'test':2010},'targets':['target_dem_share'],'pre_election_controls':['prior_dem_share','prior_pres_dem_share','incumbency_dem_minus_rep','open_seat','outparty_candidate_prior_office'],'candidate_features':[x for x in out.columns if x.startswith('delta_')],'limitations':['House not Senate; cannot validate statewide Senate-to-House spillovers.','Same districts2006 and2010; no new-district test. Incumbent individuals often repeat.','October expertise can incorporate polling, fundraising and expected outcome; independent measurement of realized outcomes is not causal randomization.','Released party adjustments estimated on all respondents within wave without realized-election outcomes. Strict training-only preprocessing can instead use raw features.','Sample oversamples competitive/open2006 races.','2006 source has182 rows:155 sample rows plus27 incomplete extras; extras excluded by missing informant_n.','No cross-wave verified candidate IDs; use district-year-party join to trusted election data. Source2010 name assignments contain apparent discrepancies, e.g.MD06 lists DonnaEdwards.','Full district files contain post-election variables and future election outcomes. Only allowlisted controls and candidate rating columns should be predictors.','Missing2010 target for five no-challenger races; no imputed outcomes.']}
(P/'feature_manifest.json').write_text(json.dumps(manifest,indent=2))
print(json.dumps({k:v for k,v in manifest.items() if k in ['rows','rows_by_year','primary_complete_rows_per_year']},indent=2))
print(out.groupby('year')[['delta_campaign_delegate_purged_mean','delta_character_delegate_purged_mean','delta_campaign_combined_purged_mean']].count())
