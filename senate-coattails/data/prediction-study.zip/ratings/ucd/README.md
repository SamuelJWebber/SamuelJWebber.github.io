Portable distribution note: original source data and PDFs described below are not included. Run the commands in ../README_REPRODUCE.md to download inputs and rebuild outputs.

UC Davis Congressional Election Study candidate ratings

Acquired from the investigators' public UC Davis site on 2026-11-05. No authors contacted. Exact downloaded URLs, SHA256 hashes, and byte counts are in sources.json; acquire.py reproduces downloads, clean.py builds the harmonized features. Requires pandas and numpy.

Primary analysis file: clean/house_ratings_2006_2010.csv
Unit: one US House district-election; 155 districts in 2006 and the same155 in2010. Keys: year,state_abbrev,district; district_id retains original IDs such as AR01 and VTAL. Numerical district0 means at-large. Names are not validated identifiers. The separate2010 source-name table has apparent mistakes and must not override an independently verified election table.

Outcome: target_dem_share is Democratic two-party vote share /100 from original Jacobson-derived demvote06/demvote10; it is a target, not a predictor. Five2010 unchallenged races have no outcome in the released source. Controls: prior_dem_share (2004 or2008), prior_pres_dem_share (2004 or2008), incumbency_dem_minus_rep (+1 D incumbent actually runs,-1 R incumbent actually runs,0 open), open_seat, outparty_candidate_prior_office. Do not use other same-election results as inputs when testing prediction.

All14 common candidate traits use the original1–7 survey scale (higher=stronger). The released purged means subtract the regression coefficient on informant party(-1 D,0 I,+1 R), times that party variable, from each rating; they can therefore lie outside1–7. There is no realized-election outcome in this adjustment. However, the original adjustment is estimated across the entire wave rather than from only training observations. Raw ratings are provided for sensitivity or stricter pipeline choices.

Seven campaign traits: attention, self_fund, fundraising, name_recognition, public_persuasion, professional_campaign, overall_campaigner.
Seven character traits: integrity, work_with_leaders, competence, issue_grasp, problem_solving, qualifications, overall_public_servant.
For each, d_ and r_ variables are levels and delta_ is D-R. delegate_purged uses source2006 _pmn and2010 _pd10; combined_purged uses all available respondents (_pmn in2006,_pc10 in2010). No nonpolitical Polimetrix informants were surveyed in2006. The *_campaign_*_mean and *_character_*_mean are our simple seven-item complete-case averages, not the studies' principal components and not estimated from election results. Estimating a component or standardization from training data only is possible using the14 individual traits.

There are126 complete2006 and129 complete2010 rows with source-purged delegate campaign+character, outcome and presidential baseline. Further prior-vote exclusions may reduce counts. Restricting both elections to contested two-party races is advisable for a like-for-like own-vote test. A2006->2010 holdout tests forecasting in a later election cycle in the same districts; it does not by itself test unseen districts or candidates, and cannot estimate statewide coattails.

Sampling:100 randomly selected contiguous-US districts and55 purposive competitive/open districts. The full2006 Stata file contains182 rows despite the readme's155:27 incomplete extras are excluded using nonmissing informant_n (retaining genuine zero-informant sample districts, with ratings missing). The file retains sample_random and source random-sample party weight for inspection.

Timing:2006 informants were surveyed by mail in October2006 according to the official readme; individual dates are absent.2010 is described as October, but individual date fields range October7 through November2. Three responses occurred on election day (one delegate, two Polimetrix) and165 delegates have no dates. Source-purged means include these. delegate_strict_date_raw drops election-day and missing-date2010 records and is provided for sensitivity; the2006 version is identical to raw delegates because individual dates are unavailable. None of the observed2010 records have dates after election day. The incumbent2009 ratings were gathered in early summer2009, but only rate the sitting incumbent, not both nominees. clean/incumbent_ratings_2009_with_2010_target.csv preserves this distinct earlier horizon, with2010 incumbent-running status for selecting candidates who actually appeared.

Limits:Informants are knowledgeable observers and may know current polling or expected winner. Independence from realized election outcomes does not make ratings random, purely innate talent, or causal spillover instruments. Neither dataset estimates Senate candidate effects on fellow-party candidates. Full district CSV exports contain post-election variables; use the clean feature allowlist in feature_manifest.json. Final total campaign spending in the source is not a pre-election timestamped donation proxy and is deliberately not harmonized into the predictive feature file.

Primary sources:
https://electionstudy.ucdavis.edu/index.html
https://electionstudy.ucdavis.edu/2006-study/2006_ucd_ces_readme.pdf/@@download/file/2006_ucd_ces_readme.pdf
https://electionstudy.ucdavis.edu/2010-study/2010_ucd_ces_readme.pdf/@@download/file/2010_ucd_ces_readme.pdf

Published measurement papers:
Stone and Simas(2010), Candidate Valence and Ideological Positions in U.S. House Elections, American Journal of Political Science.
Buttice and Stone(2012), Candidates Matter: Policy and Quality Differences in Congressional Elections, Journal of Politics.

Executed out-of-time benchmark

Run benchmark_ratings.py after clean.py. Results are in results/results.json and parallel CSVs. Primary strict_pre_election compares baseline, campaign, character, and both on identical126 training2006 and109 holdout2010 contested complete-case districts. Baseline includes previous House share, previous presidential share, incumbent party/running status, open seat, and out-party prior elected-office experience. Five controls + up to two fixed equal-weight composites; OLS with intercept and training-only scaling; no holdout tuning; predictions clipped to[0,1].

For the primary strict-date measurement, each party/item's informant-partisanship coefficient is estimated only from valid2006 informant ratings, then applied unchanged to2006 and strictly dated pre-election2010 ratings. This avoids learning a measurement adjustment from holdout observations. Don't-Know8 in2006 is set missing; validation reproduces published unpurged means within5e-7. Source-purged ratings provide a separate secondary benchmark with126/118 cases.

Primary MAE in percentage points: baseline13.978; campaign10.467; character13.753; both10.438. Baseline-to-campaign MAE gain3.511pp, paired district-bootstrap95% interval[2.765,4.285]. Character alone gain.226pp[-.320,.773]. Both improves on campaign only.029pp; its character coefficient is close to zero. This is a candidate's own House result, not a coattail estimate.

Calibration is a serious limitation: the baseline's mean holdout error is+13.97pp, campaign+10.43pp. A single training D-wave election2006 to R-wave2010 test has no learned national swing effect. An explicitly post-hoc diagnostic subtracting each model's holdout mean error gives centered RMSE4.88baseline versus4.77campaign. That centered number uses holdout outcomes and is not a forecast. Much observed forecast improvement is wave-level calibration; the study does not establish durable individual talent. Bootstrap intervals condition on the single2010 cycle and fixed fitted model, not uncertainty over future election cycles.

Newspaper endorsement same-row overlap is only63training/8test; results are exploratory and flagged ineligible for winner selection. The scores were retrospectively estimated using the full historical endorsement network. Primary conclusions should not be based on this tiny subset. Benchmark source names join the previously acquired scholarly House election table inputs/house_districts.csv rather than inconsistent survey name fields.
