"""Acquire/standardize the public QSS face-competence teaching data. No modeling.
Run python acquire_clean.py [--refresh] to rebuild source-derived CSVs.
Original replication rows for Benjamin-Shapiro 2009 were not located.
"""
import csv, hashlib, json, sys, urllib.request
from pathlib import Path
from datetime import datetime, timezone
P=Path(__file__).resolve().parent
COMMIT='59933ec09aa53fbab7b6100e7f8330aa757e77e9'
URL=f'https://raw.githubusercontent.com/kosukeimai/qss-package/{COMMIT}/data-raw/csv/face.csv'
RAW=P/'qss_data-raw_csv_face.csv'
if '--refresh' in sys.argv or not RAW.exists():
    RAW.write_bytes(urllib.request.urlopen(URL,timeout=40).read())
expected_sha256='15d5a88ff030d7ecddf85f2dfe20b2eec70c4481cc80a55cd819f4038b4e7db3'
if hashlib.sha256(RAW.read_bytes()).hexdigest()!=expected_sha256:
    raise ValueError('QSS face.csv differs from the frozen source used in this benchmark.')
rows=list(csv.DictReader(RAW.open()))
assert len(rows)==119
assert len({(x['state'],x['year']) for x in rows})==119
clean=[]
long=[]
for r in rows:
    year=int(r['year']);d=float(r['d.comp']);g=float(r['r.comp'])
    # QSS source typos, independently identified by candidate names in canonical
    # MIT Senate returns; preserve source label and state the exact correction.
    state_corrections={(2000,'MO','Lott'):'MS',(2004,'KY','Brownback'):'KS',
                       (2004,'KZ','Bunning'):'KY',(2004,'MS','Bond'):'MO'}
    source_state=r['state']
    actual_state=state_corrections.get((year,source_state,r['winner']),source_state)
    dv=int(r['d.votes']);rv=int(r['r.votes'])
    assert {r['w.party'],r['l.party']}=={'D','R'} and abs(d+g-1)<1e-7
    assert 0<=d<=1 and 0<=g<=1 and dv>0 and rv>0
    dn=r['winner'] if r['w.party']=='D' else r['loser']
    rn=r['winner'] if r['w.party']=='R' else r['loser']
    if year==2004:
        timing='pre_election_study_verified';period='Approximately two weeks before 2004-11-02';provenance='Todorov et al 2005 methods correspond to year and 32 races'
    elif year==2006:
        timing='pre_election_probable_source_mapping_unverified';period='Before 2006 election in Ballew and Todorov 2007';provenance='QSS only cites 2005 paper; 2006 study attribution inferred, not explicitly documented in QSS'
    else:
        timing='retrospective_blinded';period='Fall 2003, early 2004, May 2004';provenance='Todorov et al 2005 retrospective ratings; QSS exact aggregation across waves not documented'
    x=dict(state_abbrev=actual_state,source_state_abbrev=source_state,
           state_label_corrected=int(actual_state!=source_state),year=year,office='US SENATE',dem_candidate=dn,rep_candidate=rn,
           dem_face_competence=d,rep_face_competence=g,face_competence_gap=d-g,
           dem_votes=dv,rep_votes=rv,dem_two_party_share=dv/(dv+rv),dem_won=int(dv>rv),
           rating_timing=timing,rating_collection_period=period,provenance_note=provenance,
           source_dataset='Kosuke Imai QSS face.csv',source_url=URL)
    clean.append(x)
    for party,name,score,votes in [('D',dn,d,dv),('R',rn,g,rv)]:
        long.append(dict(state_abbrev=actual_state,source_state_abbrev=source_state,state_label_corrected=int(actual_state!=source_state),year=year,office='US SENATE',party=party,candidate=name,face_competence=score,votes=votes,rating_timing=timing,rating_collection_period=period,source_url=URL))
for filename,data in [('face_races_clean.csv',clean),('face_candidates_clean.csv',long)]:
    with (P/filename).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(data[0]));w.writeheader();w.writerows(data)
meta=dict(source_url=URL,source_commit=COMMIT,source_sha256=hashlib.sha256(RAW.read_bytes()).hexdigest(),rows=len(clean),candidate_rows=len(long),years={str(y):sum(x['year']==y for x in clean) for y in [2000,2002,2004,2006]},status='numeric alternate proxy acquired; not Benjamin-Shapiro video ratings',downloaded_utc=datetime.now(timezone.utc).isoformat(),checks=['119 unique state-year rows','all D/R pairs','no missing raw fields','paired competence scores sum to one','strictly positive party vote totals'],limitations=['Facial perceived competence is not comprehensive candidate talent','Race-relative D/R comparison, not a common scale of absolute candidate competence','Teaching dataset has no respondent-level ratings or precise collection dates','2006 attribution to Ballew-Todorov inferred; QSS references only 2005 paper','No Benjamin-Shapiro numeric dataset recovered'])
meta['state_corrections']=[dict(year=x['year'],source_state=x['source_state_abbrev'],corrected_state=x['state_abbrev'],dem_candidate=x['dem_candidate'],rep_candidate=x['rep_candidate']) for x in clean if x['state_label_corrected']]
meta['outcome_warning']='QSS vote totals have discrepancies; separate benchmark uses canonical MIT-derived Senate dshare, not the QSS outcomes.'
(P/'face_provenance.json').write_text(json.dumps(meta,indent=2)+'\n')
print(json.dumps(meta,indent=2))
