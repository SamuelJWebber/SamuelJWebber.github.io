Portable distribution note: original source data and PDFs described below are not included. Run the commands in ../README_REPRODUCE.md to download inputs and rebuild outputs.

# Visual candidate ratings: acquisition result

## Ready numeric data (alternative to requested silent-video ratings)

`face_races_clean.csv` has 119 U.S. Senate races (2000:29, 2002:30, 2004:32, 2006:28). `face_candidates_clean.csv` has the corresponding 238 candidate-election rows. The raw public teaching file is `qss_data-raw_csv_face.csv`; a byte-identical download from the original QSS book repository is `qss_original_face`. `acquire_clean.py` rebuilds the clean files and `face_provenance.json` records the frozen source and file hash. A separately documented chronological prediction benchmark is now available in `benchmark/`; see the final section below.

Source: Kosuke Imai's official QSS package, https://kosukeimai.github.io/qss-package/reference/face.html; frozen raw CSV https://raw.githubusercontent.com/kosukeimai/qss-package/59933ec09aa53fbab7b6100e7f8330aa757e77e9/data-raw/csv/face.csv . This is a teaching extract, not an original author replication archive. Its documentation cites Todorov et al. (2005), although the file includes 2006 races. It does not document the full original-to-teaching-data transformation.

Clean race schema:

| Field | Meaning |
|---|---|
| state_abbrev, year, office | Corrected race identifiers; no duplicate state-year in this extract |
| source_state_abbrev, state_label_corrected | Preserve raw QSS state label and flag candidate-identity corrections |
| dem_candidate, rep_candidate | Names copied from source, sometimes abbreviated |
| dem_face_competence, rep_face_competence | Relative perceived facial competence, each 0–1; sum to 1 |
| face_competence_gap | Democratic minus Republican score |
| dem_votes, rep_votes | Raw QSS vote counts; some disagree with canonical election returns and are not used as benchmark outcomes |
| dem_two_party_share | D votes / (D + R votes) |
| dem_won | Whether D votes exceed R votes |
| rating_timing | Explicit prospective/retrospective qualification |
| rating_collection_period | Date information justified below |
| provenance_note, source_dataset, source_url | Traceability and unresolved mapping caveat |

These are pairwise face judgments, not a common scale of absolute candidate talent. A high score measures how competent one candidate appears compared with that race's opponent. Do not rank candidates across races as if scores were absolute talent. The extract includes Obama's 2004 contest: D perceived competence 0.164835165, R 0.835164835, illustrating that facial impression differs markedly from comprehensive political skill.

## Timing audit

Todorov et al. (2005), *Science* 308:1623–1626, DOI https://doi.org/10.1126/science.1110589 . The author-hosted PDF, saved as `todorov_science2005.pdf`, contains the online supplement. Senate 2000/2002 ratings were collected in Fall 2003, early 2004, and May 2004 (supplement pp4–6). These are retrospective judgments, with recognized candidates excluded. Senate 2004 competence judgments were collected approximately two weeks before November 2, 2004 (supplement p7), from 127 participants for 32 candidate pairs. Recognized faces were excluded, leaving 91–127 ratings per race.

Ballew and Todorov (2007), *PNAS* 104:17948–17953, DOI https://doi.org/10.1073/pnas.0705435104 . The author-hosted paper is `ballew_todorov2007.pdf`. Experiment3 collected judgments before the 2006 elections, involving 64 participants and 29 Senate races. However, the QSS extract includes 28 D/R contests and only cites the 2005 paper, so attribution of its 2006 rows to that prospective experiment is plausible but NOT explicitly established by the QSS documentation. Those rows are flagged `pre_election_probable_source_mapping_unverified`. Do not silently treat this provenance inference as verified. The paper excludes four Senate races: two famous incumbents (Clinton and Lieberman) and two with unknown/unavailable challengers at collection time.

The raw CSV contains no respondent-level information, survey dates, competence standard errors, party-blinding flags, or incumbency control. No imputations, synthetic scores, or reconstructed scatterplot points have been added.

## Requested Benjamin–Shapiro video study: original numeric rows not recovered

Benjamin and Shapiro (2009), *Review of Economics and Statistics* 91(3):523–536, DOI https://doi.org/10.1162/rest.91.3.523; NBER WP12660 (November2006). Author PDF is saved as `author_pdf.pdf`, extracted text as `author_pdf.txt`.

The study used 10-second C-SPAN debate clips for 58 governor elections from 1988–2002, comprising 68 debates in37states. Both candidates' clips came from the same debate. It measures personality judgments and prediction of the winner. The 264 undergraduate raters participated May7/9/10/12/13,2005; Jan8/9/10/11,2006; or Mar2/4,2006. Thus the videos predate elections but the ratings are retrospective. The procedure excluded a participant's home-state contests and recognized candidates, and excluded Massachusetts from the analysis.

Search/download audit:

- Both current author pages checked: https://shapiro.scholars.harvard.edu/publications/thin-slice-forecasts-gubernatorial-elections and https://www.danieljbenjamin.com/publications.html . Each exposes the paper PDF only for this article.
- Full author PDF downloaded: https://shapiro.scholars.harvard.edu/sites/g/files/omnuum7731/files/shapiro/files/thinslice.pdf . No data URL or row-level appendix found.
- Full PMC manuscript checked: https://pmc.ncbi.nlm.nih.gov/articles/PMC2860970/ . Only article tables/figures, no numeric data supplement found. Direct shell fetch yielded a browser-check page; the web retrieval tool returned complete readable text.
- Harvard Dataverse exact-phrase API `q="Thin-Slice"` returned3unrelated datasets. Broad author/title and DOI searches produced unrelated results; no matching deposit located.
- RePEc and NBER pages link the article/working-paper PDF only.
- Crossref DOI metadata lists publisher PDF, with empty relation metadata.
- Publisher DOI returned HTTP403 through direct download; publisher web retrieval also unavailable.
- Internet Archive CDX search for old Shapiro files returned HTTP503. No successful archived source recovered.
- Both routine and stronger web search engines queried exact title with replication/data/archive/supplement plus author/filename combinations; no usable numeric dataset surfaced.

Do not claim the video study was newly benchmarked. Its published leave-one-election-out validation is not an out-of-time validation, and its results cannot be ranked against fresh comparisons on different samples as if they shared a test set. No clean video feature CSV was created because original numeric rows were not acquired. This is an acquisition limitation, not proof that no data exist anywhere.

## Additional potentially useful dataset not recovered

Atkinson, Enos and Hill (2009), *Quarterly Journal of Political Science*4:229–249, DOI https://doi.org/10.1561/100.00008062 . Their face scores are on a common within-chamber scale using random pairings across all candidates, for 972 candidates including Senate1990–2006 and House2004. This improves cross-candidate comparability. Paper's replication DOI https://doi.org/10.1561/100.00008062_supp returned404; publisher page returned403. Author pages checked so far link PDF only. This is also retrospective rating evidence and should not be assumed pre-election-timestamped.


## Source errors corrected before matching

The QSS teaching CSV has four state-label typos, identified from its candidate names and checked against the canonical MIT Senate returns in `sample.csv`:

| Election | Raw label | Corrected state | Candidate pair |
|---|---|---|---|
| 2000 | MO | MS | Troy Brown / Trent Lott |
| 2004 | KY | KS | Lee Jones / Sam Brownback |
| 2004 | KZ | KY | Daniel Mongiardo / Jim Bunning |
| 2004 | MS | MO | Nancy Farmer / Kit Bond |

Corrections are transparent in the acquisition script and clean-file source-state fields; the raw download remains unchanged. All matched candidate pairs were inspected against canonical names. Several QSS vote totals differ from canonical returns (particularly WV2006). Thus the benchmark uses canonical `dshare`, with QSS used only for face scores and source identifiers.

## Completed chronological benchmark

`benchmark_faces.py` fits six fixed linear models, without hyperparameter tuning or model selection. It trains on 55 matched 2000/2002 contests and tests on 31 matched 2004 contests. The 2004 ratings were collected prospectively. The omitted source cases are GA2000, LA/MN/MO2002 and LA2004, which lack a canonical unique regular two-major-party race. The endpoint is the canonical Democratic two-party Senate share. Models are compared on exactly the same cases.

| Model | 2004 MAE, percentage points | 2004 RMSE, percentage points |
|---|---:|---:|
| Training mean | 12.390 | 15.132 |
| Face score alone | 12.582 | 15.560 |
| Canonical fundamentals | 6.020 | 7.870 |
| Canonical fundamentals + face | 5.544 | 7.684 |
| Prior presidential lean + incumbency | 6.034 | 7.814 |
| Prior presidential lean + incumbency + face | 5.602 | 7.620 |

Canonical fundamentals comprise prior presidential lean, incumbent party, White House party and midterm White House party. With only two training cycles, its national controls are confounded (design rank4with5columns including intercept), so the full-rank two-control sensitivity was specified before inspecting predictions. The added face score improves primary MAE by0.477points and RMSE by0.186points. The conditional heldout-race bootstrap95%interval for MAE change is−1.218to+0.287points; it does not establish a reliable gain. It conditions on the fitted model and ignores training uncertainty.

A separate, secondary extension trains on2000/2002/2004 and tests on28matched2006cases. Its rating-study provenance is unverified, so it is not the primary claim. Here adding faces worsens canonical MAE from8.403to8.996points and RMSE from10.386to11.065points; the sparse sensitivity also worsens.

Outputs: `benchmark/metrics.csv`, `benchmark/paired_comparisons.csv`, `benchmark/predictions.csv`, `benchmark/coefficients.json`, `benchmark/metadata.json`, and `benchmark/joined_and_excluded.csv`. The results offer weak/mixed incremental prediction evidence, do not estimate coattails, and must not be ranked against other proxies tested on different samples as if they shared a common holdout.
