"""Fixed, chronological benchmark for QSS Senate facial-competence data.
No model selection or holdout tuning. Primary train2000/2002 -> test2004;
2006 is secondary because source mapping of its ratings is not verified.
Uses canonical Senate outcome/control rows, not QSS vote totals.
"""
from pathlib import Path
import json, hashlib
import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
P=Path(__file__).resolve().parent
CANONICAL=P.parent.parent / 'sample.csv'
FACES=P/'face_races_clean.csv'
OUT=P/'benchmark'
OUT.mkdir(exist_ok=True)
BASE=['prior_pres_lean','incumbency','white_house_party','midterm_white_house']
SPARSE=['prior_pres_lean','incumbency']
FACE=['face_competence_gap']
MODELS={'mean_only':[], 'face_only':FACE, 'canonical_baseline':BASE,
        'canonical_plus_face':BASE+FACE,'sparse_baseline':SPARSE,'sparse_plus_face':SPARSE+FACE}
f=pd.read_csv(FACES); c=pd.read_csv(CANONICAL)
m=f.merge(c,on=['state_abbrev','year'],how='left',validate='one_to_one',indicator=True)
m['included']=m['_merge'].eq('both') & m[BASE+['dshare']].notna().all(axis=1)
m['exclude_reason']=np.where(m['included'],'','No canonical unique regular two-major-party race / missing baseline')
m.to_csv(OUT/'joined_and_excluded.csv',index=False)
use=m.loc[m.included].copy()
assert len(use.loc[use.year.isin([2000,2002])])==55
assert len(use.loc[use.year.eq(2004)])==31
assert len(use.loc[use.year.eq(2006)])==28
assert (use.pres_previous_year<use.year).all()
results=[];preds=[];coefs=[];comparison=[]
for split,trainyears,testyear in [('primary_2004',[2000,2002],2004),('secondary_2006_unverified_rating_provenance',[2000,2002,2004],2006)]:
    tr=use.loc[use.year.isin(trainyears)].copy();te=use.loc[use.year.eq(testyear)].copy()
    ytr=tr.dshare.to_numpy();yte=te.dshare.to_numpy();trainmean=ytr.mean();saved={}
    for model,features in MODELS.items():
        if features:
            fit=LinearRegression().fit(tr[features],ytr)
            pred=fit.predict(te[features]);coef=dict(zip(features,fit.coef_));intercept=fit.intercept_
            rank=int(np.linalg.matrix_rank(np.column_stack([np.ones(len(tr)),tr[features].to_numpy()])))
        else:
            pred=np.full(len(te),trainmean);coef={};intercept=trainmean;rank=1
        saved[model]=pred
        err=(pred-yte)*100
        results.append(dict(split=split,model=model,n_train=len(tr),n_test=len(te),features=';'.join(features),
                            mae_pp=float(np.mean(np.abs(err))),rmse_pp=float(np.sqrt(np.mean(err**2))),
                            mean_error_pp=float(np.mean(err)),accuracy=float(np.mean((pred>.5)==(yte>.5))),
                            test_r2_vs_training_mean=float(1-np.mean(err**2)/np.mean(((trainmean-yte)*100)**2)),
                            design_rank=rank,design_columns=len(features)+1,
                            caveat='National controls confounded across only two training cycles' if split=='primary_2004' and model.startswith('canonical') else ''))
        coefs.append(dict(split=split,model=model,intercept=float(intercept),coefficients={k:float(v) for k,v in coef.items()}))
        for i,(_,r) in enumerate(te.iterrows()):
            preds.append(dict(split=split,model=model,state_abbrev=r.state_abbrev,year=int(r.year),
                              dem_candidate=r.dem_candidate,rep_candidate=r.rep_candidate,
                              actual_dem_share=float(yte[i]),predicted_dem_share=float(pred[i]),error_pp=float(err[i])))
    rng=np.random.default_rng(20261105)
    for b,a in [('canonical_baseline','canonical_plus_face'),('sparse_baseline','sparse_plus_face')]:
        baseerr=(saved[b]-yte)*100;adderr=(saved[a]-yte)*100
        delta=np.abs(adderr)-np.abs(baseerr)
        bs=np.mean(delta[rng.integers(0,len(delta),size=(10000,len(delta)))],axis=1)
        comparison.append(dict(split=split,baseline=b,augmented=a,
                               mae_change_pp=float(delta.mean()),rmse_change_pp=float(np.sqrt(np.mean(adderr**2))-np.sqrt(np.mean(baseerr**2))),
                               conditional_test_race_bootstrap_mae_low_pp=float(np.quantile(bs,.025)),
                               conditional_test_race_bootstrap_mae_high_pp=float(np.quantile(bs,.975))))
pd.DataFrame(results).to_csv(OUT/'metrics.csv',index=False)
pd.DataFrame(preds).to_csv(OUT/'predictions.csv',index=False)
pd.DataFrame(comparison).to_csv(OUT/'paired_comparisons.csv',index=False)
(OUT/'coefficients.json').write_text(json.dumps(coefs,indent=2)+'\n')
metadata=dict(primary_train_years=[2000,2002],primary_test_year=2004,primary_n_train=55,primary_n_test=31,
              model_selection='None: six prespecified linear models, no tuning, no selection among two baseline definitions',
              endpoint='Democratic two-party Senate share from canonical source; independent of QSS vote totals',
              canonical_path=str(CANONICAL),canonical_sha256=hashlib.sha256(CANONICAL.read_bytes()).hexdigest(),
              faces_path=str(FACES),faces_sha256=hashlib.sha256(FACES.read_bytes()).hexdigest(),
              feature_availability='2004 photo ratings collected pre-election;2000/2002 retrospective but collected before2004 election;strictly prior presidential lean;current incumbency',
              no_clipping=True,bootstrap='10000 test-race resamples;conditional on fitted model;ignores training uncertainty',
              limitations=['Small single test election cycle','Relative facial competence is not comprehensive candidate talent','Retrospective2000/2002 training ratings','Canonical national controls rank deficient with only2trainingcycles','2006 provenance mapping unverified;secondary only','Does not estimate causal coattails or select best proxy across different samples'])
(OUT/'metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
print(pd.DataFrame(results)[['split','model','n_train','n_test','mae_pp','rmse_pp','design_rank','design_columns']].to_string(index=False))
print(pd.DataFrame(comparison).to_string(index=False))
