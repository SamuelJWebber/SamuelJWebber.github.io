"""Freeze development-based choice and prepare a strict JSON payload for the dashboard."""
import json
from pathlib import Path
import pandas as pd

ROOT=Path(__file__).resolve().parent
metrics=pd.read_csv(ROOT/'results/metrics.csv')
predictions=pd.read_csv(ROOT/'results/predictions.csv')
sample=pd.read_csv(ROOT/'sample.csv')
main=metrics.query("validation=='out_of_time' and subgroup=='all'")
# Only these model definitions have reproducible inputs across the entire requested
# forecast interval including the untouched 2024 confirmation year.
eligible=['baseline','prior_performance']
dev=main.query("stage=='development' and model in @eligible")
choice=dev.sort_values(['mae_pp','rmse_pp']).iloc[0]['model']
summary={
    'selected_model':choice,
    'selection_rule':'Lowest development (2010–2014) MAE among models with source inputs for all 2016–2024 races. Only baseline and prior performance meet that availability rule.',
    'selection_eligible_models':eligible,
    'selection_stage':'development',
    'selection_frozen':True,
    'main_outcome':'Democratic share of votes cast for the Democratic and Republican nominees',
    'primary_unit':'State regular Senate election',
    'main_features':['State Democratic lean at the previous presidential election','Democratic/Republican incumbent status','Party controlling White House before election day','Midterm interaction with White House party','Last observable Senate overperformance for each nominee','Indicators for each nominee having earlier Senate results'],
    'proxy_interpretation':'Prior result includes the candidate, opposing nominee, campaign environment and random variation. This exercise tests predictability, not causal personal charisma or causal coattails.',
    'independent_sample':'Regular elections with exactly one named non-write-in nominee from each major party. No current-result percentage cutoff.',
    'phase_labels':{'development':'Choose model, 2010–2014','test':'Evaluate frozen choice, 2016–2022','confirmation':'Confirm frozen choice, 2024'},
    'group_labels':{'new_candidates':'Remove every training race involving either test nominee','unseen_states':'Remove the test state from historical training','out_of_time':'Train entirely before the heldout years'},
    'subgroup_labels':{'all':'All eligible races','both_first_Senate_run':'Neither nominee has a prior comparable Senate result in source data','at_least_one_prior_Senate_run':'At least one nominee has a prior comparable Senate result'},
    'source_coverage_notes':['Experience test coverage is 2016 only (31 races), with no 2018–2024 observations in the source.','Endorsement test coverage is 22 races across 2016–2022, with no 2024 observations. Endorsement scores were calibrated retrospectively using the full historical source.','The selected prior-performance score covers all 120 test races and 31 confirmation races, with zero scores and separate history indicators for nominees with no prior comparable Senate result.'],
    'selected_metrics':json.loads(metrics.query("model==@choice").to_json(orient='records')),
    'comparison_metrics':json.loads(metrics.to_json(orient='records')),
    'history_ablation':json.loads(pd.read_csv(ROOT/'results/history_ablation.csv').to_json(orient='records')),
    'history_value_increment':json.loads(pd.read_csv(ROOT/'results/history_value_increment.csv').to_json(orient='records')),
    'ablation_note':'Post-selection diagnostic only. Adding the prior-performance value improves over indicators for having previously run. This diagnostic did not change selection.',
}
(ROOT/'results/summary.json').write_text(json.dumps(summary,indent=2,allow_nan=False))
payload={'summary':summary,'predictions':json.loads(predictions.to_json(orient='records')),
         'candidate_features':json.loads(sample.to_json(orient='records'))}
(ROOT/'results/dashboard_payload.json').write_text(json.dumps(payload,allow_nan=False))
print(choice)
print(dev[['model','mae_pp','rmse_pp']].to_string(index=False))
print('payload_bytes',(ROOT/'results/dashboard_payload.json').stat().st_size)
