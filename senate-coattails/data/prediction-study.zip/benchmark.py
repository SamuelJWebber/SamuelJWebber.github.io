"""Out-of-time Senate candidate-proxy benchmark with matched-row baseline comparisons.

Only data from years before the evaluation year enter historical candidate features.
Endorsement scores are retrospective full-sample estimates, reported separately.
"""
from pathlib import Path
import argparse
import os
import json
import re
import hashlib

import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression

BASE = Path(__file__).resolve().parent
SOURCE = Path(os.environ.get('COATTAILS_INPUT_DIR', str(BASE / 'inputs')))
KEY = ['state_abbrev', 'year']
BASELINE = ['prior_pres_lean', 'incumbency', 'white_house_party', 'midterm_white_house']
HISTORY = ['prior_candidate_advantage', 'prior_D_observed', 'prior_R_observed']
MODELS = {
    'baseline': BASELINE,
    'prior_performance': BASELINE + HISTORY,
    'experience': BASELINE + ['experience'],
    'prior_plus_experience': BASELINE + HISTORY + ['experience'],
    'endorsements_retrospective': BASELINE + ['endorsement'],
    'prior_plus_endorsements_retrospective': BASELINE + HISTORY + ['endorsement'],
    'all_three_retrospective': BASELINE + HISTORY + ['experience', 'endorsement'],
}
ALIASES = {'WEICHER':'WEICKER', 'PEREY':'PERCY', 'CHAFFEE':'CHAFEE'}
GIVEN_ALIASES = {'BOB':'ROBERT','BILL':'WILLIAM','DICK':'RICHARD','JIM':'JAMES',
                 'TED':'EDWARD','TOM':'THOMAS','CHUCK':'CHARLES','JOE':'JOSEPH',
                 'JACK':'JOHN','BEN':'BENJAMIN','JERRY':'GERALD','DAVE':'DAVID',
                 'MIKE':'MICHAEL','STEVE':'STEVEN','JON':'JOHN'}


def candidate_key(name, state):
    """Conservative state + surname + first initial identity, with audited exceptions."""
    name = str(name).upper().strip()
    if name.startswith(('SCHATZ,', 'CORTEZ MASTO,')):
        last, first = name.split(',', 1)
        name = first + ' ' + last
    tokens = re.sub('[^A-Z ]', ' ', name).split()
    tokens = [x for x in tokens if x not in {'JR','SR','II','III','IV','V','DR','SENATOR'}]
    last = ALIASES.get(tokens[-1],tokens[-1])
    first = next((x for x in tokens[:-1] if len(x)>1),tokens[0])
    first = GIVEN_ALIASES.get(first,first)
    if state == 'FL' and last == 'NELSON':
        first = 'WILLIAM'
    if state == 'TX' and last == 'CRUZ':
        first = 'RAFAEL'
    # These relatives are intentionally distinct even when some official names abbreviate.
    return state + '|' + last + '|' + first[0]


def major_races(raw, regular=True):
    """Use unique named ballot nominees, never choose nominees using their vote totals."""
    x = raw.copy()
    if 'special' in x and regular:
        x = x.loc[~x.special]
    if 'stage' in x:
        x['stage'] = x.stage.str.lower()
        has_first = x.loc[x.stage.eq('pre'), ['state_po','year']].drop_duplicates().assign(first=True)
        x = x.merge(has_first, on=['state_po','year'],how='left')
        x = x.loc[x.stage.eq(np.where(x['first'].eq(True),'pre','gen'))]
    x = x.dropna(subset=['candidate']).copy()
    x['candidate'] = x.candidate.str.upper().str.strip()
    if 'writein' in x:
        x = x.loc[~x.writein.eq(True)]
    major = x.loc[x.party_simplified.isin(['DEMOCRAT','REPUBLICAN'])]
    nominees = major[['state_po','year','candidate','party_simplified']].drop_duplicates()
    counts = nominees.groupby(['state_po','year','party_simplified']).size().unstack(fill_value=0)
    allowed = counts.index[(counts.get('DEMOCRAT',0)==1)&(counts.get('REPUBLICAN',0)==1)]
    nominees = nominees.set_index(['state_po','year']).loc[allowed].reset_index()
    totals = x.groupby(['state_po','year','candidate']).candidatevotes.sum().rename('votes')
    nominees = nominees.merge(totals,on=['state_po','year','candidate'])
    table = nominees.pivot(index=['state_po','year'],columns='party_simplified',values=['votes','candidate'])
    table.columns = ['_'.join(c) for c in table.columns]
    table = table.reset_index().rename(columns={'state_po':'state_abbrev'})
    table['dshare'] = table.votes_DEMOCRAT/(table.votes_DEMOCRAT+table.votes_REPUBLICAN)
    all_votes = x.groupby(['state_po','year']).totalvotes.max().rename('ballots').reset_index().rename(columns={'state_po':'state_abbrev'})
    table = table.merge(all_votes,on=KEY)
    table['major_party_fraction'] = (table.votes_DEMOCRAT+table.votes_REPUBLICAN)/table.ballots
    return table


def prepare_sample():
    senate_raw = pd.read_csv(SOURCE/'mit_senate.tsv',sep='\t')
    senate = major_races(senate_raw)
    senate = senate.loc[senate.year.mod(2).eq(0)].copy()
    president = major_races(pd.read_csv(SOURCE/'mit_president.csv'))
    national = president.groupby('year')[['votes_DEMOCRAT','votes_REPUBLICAN']].sum()
    national['national_D'] = national.votes_DEMOCRAT/(national.votes_DEMOCRAT+national.votes_REPUBLICAN)
    president = president.merge(national[['national_D']],on='year')
    president['pres_lean'] = president.dshare-president.national_D
    pres = president[['state_abbrev','year','pres_lean']]
    senate['pres_previous_year'] = senate.year-1-(senate.year-1)%4
    senate = senate.merge(pres.rename(columns={'year':'pres_previous_year','pres_lean':'prior_pres_lean'}),on=['state_abbrev','pres_previous_year'],how='left')
    # Past performance may use its own election's presidential information because all
    # of that election is in the past when this score becomes a later race's feature.
    senate['pres_score_year'] = senate.year-senate.year%4
    senate = senate.merge(pres.rename(columns={'year':'pres_score_year','pres_lean':'historical_pres_lean'}),on=['state_abbrev','pres_score_year'],how='left')
    residual = senate.dshare-senate.historical_pres_lean
    senate['historical_advantage'] = residual-residual.groupby(senate.year).transform('median')
    senate['candidate_D_id'] = [candidate_key(n,s) for n,s in zip(senate.candidate_DEMOCRAT,senate.state_abbrev)]
    senate['candidate_R_id'] = [candidate_key(n,s) for n,s in zip(senate.candidate_REPUBLICAN,senate.state_abbrev)]
    # Florida's 2012 nominee Connie Mack IV is the son of Senator Connie Mack III.
    mack_son = senate.state_abbrev.eq('FL') & senate.year.eq(2012)
    senate.loc[mack_son,'candidate_R_id'] = 'FL|MACK|C|IV'
    senate['prior_D_advantage'] = 0.
    senate['prior_R_advantage'] = 0.
    senate['prior_D_observed'] = 0
    senate['prior_R_observed'] = 0
    senate['prior_D_year'] = np.nan
    senate['prior_R_year'] = np.nan
    senate['incumbency_inferred'] = 0
    history = {}
    for year in sorted(senate.year.unique()):
        current = senate.loc[senate.year.eq(year)]
        for idx,row in current.iterrows():
            for party,sign in [('D',1),('R',-1)]:
                identifier = row[f'candidate_{party}_id']
                if identifier in history:
                    score, previous_year, prior_win = history[identifier]
                    senate.loc[idx,f'prior_{party}_advantage'] = score
                    senate.loc[idx,f'prior_{party}_observed'] = 1
                    senate.loc[idx,f'prior_{party}_year'] = previous_year
                    if prior_win and previous_year == year-6:
                        senate.loc[idx,'incumbency_inferred'] += sign
        for _,row in current.iterrows():
            for party,sign in [('D',1),('R',-1)]:
                identifier = row[f'candidate_{party}_id']
                score = sign*row.historical_advantage
                won = (row.dshare>.5)==(party=='D')
                if pd.notna(score):
                    history[identifier] = score,year,won
    h = pd.read_csv(SOURCE/'house_districts.csv')
    # These metadata facts are prior to voting, even though this file was assembled later.
    fields = ['incumbency_S','hs_qual_diff_S','news_quality_S']
    meta = h.groupby(KEY,as_index=False)[fields].first().rename(columns={'incumbency_S':'incumbency_documented','hs_qual_diff_S':'experience','news_quality_S':'endorsement'})
    senate = senate.merge(meta,on=KEY,how='left')
    senate['incumbency'] = senate.incumbency_documented.fillna(senate.incumbency_inferred)
    senate['incumbency_source'] = np.where(senate.incumbency_documented.notna(),'published_pre_election_status','six_year_prior_winner_identity')
    # Congressional biographical records establish incumbency in the two Louisiana
    # cases whose preceding jungle-election results lack one nominee per party.
    for year, status in [(2008, 1), (2010, -1)]:
        selected = senate.state_abbrev.eq('LA') & senate.year.eq(year)
        senate.loc[selected, 'incumbency'] = status
        senate.loc[selected, 'incumbency_source'] = 'Congressional_Biographical_Directory'
    senate['prior_candidate_advantage'] = senate.prior_D_advantage-senate.prior_R_advantage
    senate['both_first_Senate_run'] = (senate.prior_D_observed+senate.prior_R_observed).eq(0)
    # Party controlling the White House before election day, entirely known beforehand.
    democrat_years = {1978,1980,1994,1996,1998,2000,2010,2012,2014,2016,2022,2024}
    senate['white_house_party'] = np.where(senate.year.isin(democrat_years),1,-1)
    senate['midterm_white_house'] = senate.white_house_party*senate.year.mod(4).eq(2)
    senate['split'] = np.select([senate.year.le(2008),senate.year.le(2014),senate.year.le(2022)],['train','development','test'],default='confirmation')
    senate = senate.loc[senate.year.between(1982,2024)].copy()
    for feature_file in sorted((BASE/'features').glob('*.csv')):
        f = pd.read_csv(feature_file)
        if f.duplicated(KEY).any():
            raise ValueError(f'Duplicate feature state-election keys: {feature_file}')
        new_columns = [c for c in f if c not in KEY and c not in senate]
        senate = senate.merge(f[KEY+new_columns],on=KEY,how='left',validate='one_to_one')
    return senate


def predict(train,test,features):
    # Every fitted quantity, including imputation and scale, uses training observations.
    numeric_train = train[features].astype(float)
    numeric_test = test[features].astype(float)
    means = numeric_train.mean().fillna(0.)
    scale = numeric_train.std().replace(0,1).fillna(1.)
    x_train = (numeric_train.fillna(means)-means)/scale
    x_test = (numeric_test.fillna(means)-means)/scale
    model = LinearRegression().fit(x_train,train.dshare)
    return np.clip(model.predict(x_test),0.,1.)


def scores(y,p):
    e = np.asarray(p)-np.asarray(y)
    return {'mae_pp': float(np.abs(e).mean()*100),'rmse_pp':float(np.sqrt(np.mean(e**2))*100),
            'major_party_head_to_head_accuracy':float(np.mean((p>=.5)==(np.asarray(y)>=.5)))}


def paired_uncertainty(rows):
    state = rows.groupby('state_abbrev',sort=True).apply(lambda x: pd.Series({'gain':(np.abs(x.actual-x.baseline_prediction)-np.abs(x.actual-x.prediction)).sum()*100,'n':len(x)}),include_groups=False)
    if len(state)<2:
        return np.nan,np.nan
    rng=np.random.default_rng(20261105)
    draws=rng.integers(0,len(state),size=(2000,len(state)))
    gains=state.gain.to_numpy()[draws].sum(axis=1)/state.n.to_numpy()[draws].sum(axis=1)
    return tuple(np.quantile(gains,[.025,.975]))


def run_benchmark(sample):
    all_rows=[]
    stages=[('development',2008),('test',2014),('confirmation',2022)]
    for model,features in MODELS.items():
        proxy_features=[f for f in features if f not in BASELINE and f not in HISTORY]
        eligible=sample.dropna(subset=BASELINE+proxy_features)
        for stage,cutoff in stages:
            train=eligible.loc[eligible.year.le(cutoff)]
            test=eligible.loc[eligible.split.eq(stage)]
            if len(train)<max(30,3*len(features)) or len(test)==0:
                continue
            for validation in ['out_of_time','new_candidates','unseen_states']:
                out=[]
                baseline=[]
                actual_training_sizes=len(train)
                if validation=='out_of_time':
                    out=predict(train,test,features);baseline=predict(train,test,BASELINE)
                elif validation=='new_candidates':
                    people=set(test.candidate_D_id)|set(test.candidate_R_id)
                    clean=train.loc[~train.candidate_D_id.isin(people)&~train.candidate_R_id.isin(people)]
                    if len(clean)<30:
                        continue
                    out=predict(clean,test,features);baseline=predict(clean,test,BASELINE)
                    actual_training_sizes=len(clean)
                else:
                    actual_training_sizes=[]
                    for _,row in test.iterrows():
                        clean=train.loc[train.state_abbrev.ne(row.state_abbrev)]
                        actual_training_sizes.append(len(clean))
                        out.append(predict(clean,row.to_frame().T,features)[0])
                        baseline.append(predict(clean,row.to_frame().T,BASELINE)[0])
                result=test[KEY+['candidate_DEMOCRAT','candidate_REPUBLICAN','both_first_Senate_run','major_party_fraction','incumbency_source']].copy()
                result['actual']=test.dshare.to_numpy()
                result['model']=model;result['validation']=validation;result['stage']=stage
                result['prediction']=out;result['baseline_prediction']=baseline
                result['training_races']=actual_training_sizes
                all_rows.append(result)
    predictions=pd.concat(all_rows,ignore_index=True)
    metrics=[]
    for keys,rows in predictions.groupby(['model','validation','stage']):
        for subgroup in ['all','both_first_Senate_run','at_least_one_prior_Senate_run']:
            frame=rows
            if subgroup=='both_first_Senate_run':
                frame=rows.loc[rows.both_first_Senate_run]
            if subgroup=='at_least_one_prior_Senate_run':
                frame=rows.loc[~rows.both_first_Senate_run]
            if len(frame)==0:
                continue
            record=dict(zip(['model','validation','stage'],keys))
            record.update({'subgroup':subgroup,'races':len(frame),'states':frame.state_abbrev.nunique(),'years':','.join(map(str,sorted(frame.year.unique())))})
            record.update(scores(frame.actual.to_numpy(),frame.prediction.to_numpy()))
            b=scores(frame.actual.to_numpy(),frame.baseline_prediction.to_numpy())
            record['matched_baseline_mae_pp']=b['mae_pp'];record['matched_baseline_rmse_pp']=b['rmse_pp']
            record['mae_gain_pp']=b['mae_pp']-record['mae_pp'];record['rmse_gain_pp']=b['rmse_pp']-record['rmse_pp']
            record['mae_gain_low95'],record['mae_gain_high95']=paired_uncertainty(frame)
            metrics.append(record)
    return predictions,pd.DataFrame(metrics)


def main():
    global BASE, SOURCE
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input-dir', type=Path, default=SOURCE)
    parser.add_argument('--output-dir', type=Path, default=BASE)
    args = parser.parse_args()
    SOURCE = args.input_dir.resolve()
    BASE = args.output_dir.resolve()
    BASE.joinpath('results').mkdir(parents=True, exist_ok=True)
    sample=prepare_sample()
    sample.to_csv(BASE/'sample.csv',index=False)
    predictions,metrics=run_benchmark(sample)
    predictions.to_csv(BASE/'results/predictions.csv',index=False)
    metrics.to_csv(BASE/'results/metrics.csv',index=False)
    source_files=['mit_senate.tsv','mit_president.csv','house_districts.csv']
    provenance={'design':'retrospective benchmark with fixed temporal train1982-2008, development2010-2014, test2016-2022, confirmation2024',
        'unit':'regular state Senate election with one named nonwritein nominee from each major party',
        'outcome':'Democratic share of Democratic plus Republican votes. Third parties excluded from denominator; no outcome-based inclusion threshold.',
        'models':MODELS,'download_urls':{'mit_senate.tsv':'https://dataverse.harvard.edu/api/access/datafile/13887039','mit_president.csv':'https://dataverse.harvard.edu/api/access/datafile/13887042','H_dist_election_data.tab':'https://dataverse.harvard.edu/api/access/datafile/11807548'},'incumbency_exception_sources':['https://history.house.gov/People/Detail/17280','https://history.house.gov/People/Detail/21030'], 'source_sha256':{name:hashlib.sha256((SOURCE/name).read_bytes()).hexdigest() for name in source_files},
        'warnings':['Endorsements are retrospective full-sample estimated scores and cannot be called genuine historical real-time forecasts.',
        'Experience is relevant officeholding experience, not charisma, and is unavailable in 2024 source metadata.',
        'Prior performance can include opponent strength, campaign conditions and noise. It does not identify personal charisma.',
        'The new_candidates check removes training races involving either heldout nominee; prior performances remain legitimate prior information.',
        'Independent and multiparty election systems make major-party head-to-head accuracy different from winning the actual Senate seat.',
        'Confidence intervals resample states for paired errors on the fixed heldout predictions; they do not cover all model-selection uncertainty.'],
        'split_counts':sample.groupby('split').size().to_dict()}
    (BASE/'provenance.json').write_text(json.dumps(provenance,indent=2))
    print(sample.groupby('split').size())
    print(metrics.query("validation=='out_of_time' and subgroup=='all'")[['model','stage','races','mae_pp','matched_baseline_mae_pp','mae_gain_pp','rmse_pp']].to_string(index=False))

if __name__=='__main__':
    main()
