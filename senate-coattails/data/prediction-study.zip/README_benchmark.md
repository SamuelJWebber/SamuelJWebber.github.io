# Senate candidate prediction benchmark

The benchmark predicts the Democratic share of votes cast for the Democratic and Republican nominees in a regular U.S. Senate election. Historical candidate performance improves heldout prediction relative to a baseline containing prior presidential lean, incumbency and the known White House party. Endorsement and experience models use smaller matched samples, and their results require separate interpretation.

## Reproduce

Python 3.10+ with numpy, pandas, scipy and scikit-learn is required.

    python fetch_inputs.py
    OPENBLAS_NUM_THREADS=1 python benchmark.py
    python history_ablation.py
    python finalize.py

The downloader verifies fixed SHA-256 fingerprints before using the public source data. It retrieves the authors' district file directly from Harvard Dataverse and converts it locally to the input CSV. You may point the benchmark at prepared inputs with `--input-dir PATH` or `COATTAILS_INPUT_DIR` and choose a destination with `--output-dir PATH`.

## Temporal evaluation

Training data cover 1982–2008. The development set covers 2010–2014. Test elections cover 2016–2022. The 2024 data provide a further confirmation period. For the test period, coefficients are reestimated using all data through 2014. For confirmation, coefficients are reestimated through 2022. Model inputs and fitting rules remain fixed. This is a retrospective benchmark with a development-based selection rule, and the analyst knows the historical setting.

The selected model has all the source inputs needed in every test and confirmation election. The eligible broad-coverage choices are the baseline and the model adding prior candidate results. The latter has lower development MAE. The experience source ends in 2016 and the endorsement source has no 2024 measurements. Raw errors from those smaller samples cannot establish a universal winning proxy. Every proxy receives its own baseline comparison trained and scored on exactly the same eligible observations.

The candidate exclusion check removes training elections involving either nominee in a heldout cohort. It preserves the legitimately available pre-election prior results used as predictor inputs. The state exclusion check fits each test prediction after removing that state from training. These checks examine generalization of fitted coefficients.

## Features

The baseline uses the state's Democratic presidential vote share minus the national Democratic share from the latest presidential election strictly before the Senate election, incumbent party, White House party before election day and an interaction identifying midterms under each White House party.

Prior performance uses the nominee's latest earlier comparable Senate result. It subtracts the corresponding state's presidential lean and that Senate cycle's median adjusted performance. All those earlier-cycle results are known before the target election. Each nominee's score is oriented toward their own party. The race predictor is the Democratic nominee's score minus the Republican nominee's score. Nominees without an earlier comparable observation receive zero plus a separate observed-history indicator. These are earlier Senate candidacies, so a first-time Senate nominee may have extensive experience in other offices.

A post-selection ablation checks whether improvement is attributable to the actual earlier performance or merely to the indicators of previous participation. That diagnostic preserves the initial selection.

The endorsement measure is a relative Democratic-versus-Republican matchup score. It was estimated retrospectively using the full historical source, so its results are labeled as retrospective score tests. The experience measure records a differential in relevant officeholding experience.

## Coverage and exclusions

Each included regular election has exactly one named non-write-in nominee identified on the ballot from each major party. Fusion lines for the same named candidate are combined. Contests with multiple major-party nominees are outside this target definition. The sample uses the first-round `pre` stage where the returns record it and the `gen` stage otherwise. Special elections are excluded. There is no inclusion threshold based on current vote share or the combined major-party fraction.

Because the target denominator is Democratic plus Republican votes, its classification statistic is explicitly major-party head-to-head accuracy. Independent candidates can win the actual seat. The output includes the share of all votes won by the two major nominees for inspection.

Candidate identities use the state, normalized surname and first initial, with documented alias handling. Connie Mack IV in Florida in 2012 is separated from his father. The four Louisiana races absent from published incumbency metadata are supplemented from prior winner identity, with authoritative Congressional Biographical Directory corrections establishing Landrieu's incumbency in 2008 and Vitter's in 2010.

## Uncertainty and interpretation

MAE and RMSE are percentage points of two-party vote share. Paired MAE improvement compares the model with its baseline on the same rows. Its 95% interval resamples states 2,000 times using a fixed seed. These intervals describe heldout error differences and do not encompass all model-selection uncertainty.

Prior candidate performance also contains opponent strength, campaign circumstances and noise. This benchmark establishes predictive value under the stated temporal evaluation. A causal estimate of charisma or spillovers to other offices requires a separate design.

## Outputs

`sample.csv` contains election keys, nominee names, historical features and outcomes. `results/predictions.csv` contains each actual outcome, model and matched baseline prediction, evaluation period, validation type and actual training count. `results/metrics.csv` contains overall and prior-candidacy subgroups. `results/summary.json` freezes selection and records coverage. `results/dashboard_payload.json` packages the same data for the dashboard. `provenance.json` provides checksums and source documentation.
