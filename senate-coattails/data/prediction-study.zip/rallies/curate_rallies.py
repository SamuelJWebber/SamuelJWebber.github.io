"""Conservative rally audit. Provisional rows are not validated quality predictors.
Uses audit_ccc.py review queue. Manual decisions reference immutable CCC row IDs.
"""
import pathlib,json
import pandas as pd
B=pathlib.Path(__file__).resolve().parent
q=pd.read_csv(B/'candidate_mentions_review.csv');r=pd.read_csv(B/'candidate_roster.csv')
# Candidate is the focal campaign subject in CCC/linked-source metadata; full source
# reread remains pending except for rows explicitly marked independently_verified.
choices=[
('RICK SCOTT',2018,[20077]),('HEIDI HEITKAMP',2018,[30744]),('SHERROD BROWN',2018,[27855]),
('PHIL BREDESEN',2018,[29897,30695,29898]),('MARSHA BLACKBURN',2018,[29896,30228]),
("BETO O'ROURKE",2018,[27623,28050,30010,30422,30726,30728,30730,30751,30752,30754]),
('TED CRUZ',2018,[28328,29833,30515,30638,30727,30749,30750,30753,30755]),
('TAMMY BALDWIN',2018,[29109]),('TIMOTHY M. KAINE',2018,[19726]),('COREY A. STEWART',2018,[30581]),('JOE MANCHIN',2018,[30648]),('TINA SMITH',2018,[29126]),
('DOUG JONES',2020,[65240]),('JOHN W. HICKENLOOPER',2020,[66361]),('JON OSSOFF',2020,[68047]),('DAVID A. PERDUE',2020,[68364]),('RAPHAEL WARNOCK',2020,[68285]),('AMY MCGRATH',2020,[68133]),
('EDWARD J. MARKEY',2020,[62102,62400,68136]),('SARA I. GIDEON',2020,[68667]),('JAIME HARRISON',2020,[67871]),('LINDSEY GRAHAM',2020,[68570,68829]),('JOHN CORNYN',2020,[68335]),
('MICHAEL BENNET',2022,[59866]),("JOE O'DEA",2022,[59712]),('MARCO RUBIO',2022,[61334]),('RAPHAEL WARNOCK',2022,[60183,60184]),
('HERSCHEL JUNIOR WALKER',2022,[42296,44613,55509,59727]),('MICHAEL FRANKEN',2022,[61497]),('CHERI BEASLEY',2022,[60866]),
('JOHN K FETTERMAN',2022,[53708,54154,55844,56059,56476,58879,59084,61110,62021]),('MEHMET C OZ',2022,[61378,61541]),('MANDELA BARNES',2022,[52782]),
('ROYCE WHITE',2024,[121816]),('LUCAS KUNCE',2024,[128560,133369,134115]),('JOSH HAWLEY',2024,[125487]),('JON TESTER',2024,[131761]),('DAVE MCCORMICK',2024,[130318]),('TED CRUZ',2024,[132450,132701,133580])]
# Independent source article actually inspected; source may only give vague magnitude.
verified={
(2018,30638):('https://www.kbtx.com/content/news/Hundreds-attend-Ted-Cruz-rally-at-Brazos-County-Expo--499475661.html','Reporter describes hundreds; CCC conservatively encodes 200. Candidate focal; no star guest reported.',200,None,'hundreds'),
(2022,60183):('https://flagpole.com/news/city-dope/2022/10/26/sen-raphael-warnock-stops-in-athens-to-turn-out-students-and-black-voters/','Reporter describes several hundred at Triangle Plaza. Mayor introduced candidate.',300,None,'several hundred'),
(2022,60184):('https://flagpole.com/news/city-dope/2022/10/26/sen-raphael-warnock-stops-in-athens-to-turn-out-students-and-black-voters/','Reporter estimates about 250 at UGA Chapel. Mayor and attorney-general candidate also introduced/spoke; not literally a one-speaker event.',250,250,'about 250'),
(2024,125487):('https://www.kfvs12.com/2024/08/12/sen-hawley-campaign-kickoff-tour-stop-scott-county/','Supplemental independent report confirms same location/date and dozens attending. Candidate focal; no star guest reported.',24,None,'dozens'),
(2024,133369):('https://www.firstalert4.com/2024/10/25/lucas-kunce-holds-rally-uaw-local-wentzville/','Reporter says more than 150 UAW members. CCC midpoint 175 retained separately; independent report alone establishes lower bound, not exact175.',150,None,'more than 150')}
rows=[]
for candidate,year,ids in choices:
 for rid in ids:
  hit=q[q.office.eq('senate')&q.candidate.eq(candidate)&q.year.eq(year)&q.event_id.str.endswith(':'+str(rid))].copy()
  if len(hit)!=1:
   print('Skipped nonunique/absent',candidate,year,rid,len(hit));continue
  row=hit.iloc[0].to_dict();row['classification']='provisional_focal_campaign';row['independently_verified']=False;row['eligible_for_prediction']=False
  row['appearance_note']='Focal campaign per CCC text and/or cited headline; complete source, attendance independence, and other-speaker audit pending.'
  row['verified_source_url']='';row['independent_count_lower']=None;row['independent_count_upper']=None;row['independent_count_text']=''
  if (year,rid) in verified:
   u,n,lo,hi,ct=verified[(year,rid)];row.update({'classification':'verified_focal_campaign','independently_verified':True,'appearance_note':n,'verified_source_url':u,'independent_count_lower':lo,'independent_count_upper':hi,'independent_count_text':ct})
  row['capacity_binding']='unknown';row['crowd_demand_estimate']=None
  rows.append(row)
e=pd.DataFrame(rows);e.to_csv(B/'candidate_events_curated.csv',index=False)
for name,x in [('provisional',e),('verified',e[e.independently_verified])]:
 ag=x.groupby('candidate_key').agg(observed_events=('event_id','size'),ccc_mean_observed_size=('size_mean','mean'),ccc_median_observed_size=('size_mean','median'),ccc_max_observed_size=('size_mean','max')).reset_index()
 out=r[r.office.eq('senate')].merge(ag,on='candidate_key',how='left');out['coverage_status']=out.observed_events.notna().map({True:name+'_events_available',False:'unobserved_not_zero'})
 out['quality_score']=None;out['prediction_eligible']=False;out.to_csv(B/('candidate_elections_'+name+'.csv'),index=False)
 pairs=out[out.observed_events.notna()].groupby(['year','state','special']).filter(lambda z:set(z.party)=={'DEMOCRAT','REPUBLICAN'})
 pairs.to_csv(B/('matched_pairs_'+name+'.csv'),index=False)
 print(name,'events',len(x),'candidate_elections',x.candidate_key.nunique(),'paired_races',pairs.groupby(['year','state','special']).ngroups)
summary=[]
for year, rr in r[r.office.eq('senate')].groupby('year'):
 qq=q[q.office.eq('senate')&q.year.eq(year)];ee=e[e.year.eq(year)];vv=ee[ee.independently_verified]
 summary.append({'year':int(year),'nominee_elections':len(rr),'any_name_match_candidate_elections':qq.candidate_key.nunique(),'any_size_name_match_candidate_elections':qq[qq.size_mean.notna()].candidate_key.nunique(),'provisional_focal_candidate_elections':ee.candidate_key.nunique(),'verified_focal_candidate_elections':vv.candidate_key.nunique(),'verified_focal_events':len(vv)})
pd.DataFrame(summary).to_csv(B/'coverage_summary.csv',index=False)
print(pd.DataFrame(summary).to_string(index=False))
