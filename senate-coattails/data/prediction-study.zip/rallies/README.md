# Rally-draw feasibility audit

Result: the acquired data do not support a defensible out-of-time/out-of-state prediction contest for candidate quality yet. No rally predictor was admitted to the model leaderboard. Missing rallies and missing crowd estimates were never converted into zero appeal.

## Actual acquired coverage

Official Crowd Counting Consortium (CCC) releases contain 72,181 event records for 2017–2020 and 139,823 for 2021–2024, totaling 212,004. Original CSVs, Dataverse TSVs, both dictionaries, metadata, IDs and checksums are in `raw/` and `provenance.json`. Original CSV MD5s match Dataverse metadata. Dataverse's MD5 describes the original CSV, not its ingested TSV; TSVs have separately recorded SHA256s.

The Senate screen covers the leading Democratic and Republican general-election candidates in MIT's coding, within each state/year/special-contest cell. It selects the highest-vote candidate for a party when the election has multiple candidates from that party. This is a roster for a retrospective coverage audit, not a model feature. There are 268 candidate-contest records across 2018, 2020, 2022 and 2024. These are not 268 independent campaigns: regular and special contests sometimes have the same candidates. Independent candidates, primary losers, January runoffs, and the 2017 Alabama special election are not in this roster screen. The MIT file has no 2017 general-election records. The governor screen uses the team's available nominee roster through 2020 and covers 2017–2020 only; it is not a claim about 2021–2024 governor coverage.

| Year | Senate candidate-contest roster | Any name match | Name match plus numeric CCC size | Provisional focal-candidate coverage | Independently verified focal-candidate coverage |
|---|---:|---:|---:|---:|---:|
| 2018 | 68 | 38 | 33 | 12 | 1 |
| 2020 | 67 | 36 | 28 | 11 | 0 |
| 2022 | 65 | 34 | 31 | 10 | 1 |
| 2024 | 68 | 45 | 41 | 6 | 2 |
| Total | 268 | 153 | 133 | 39 | 4 |

The automated counts are exact for the documented screen, **not counts of rallies attended by those candidates**. A name can occur in an opponent's rally story, a protest against the candidate, a shared presidential rally, or a hyperlink discussing both sides. For example, one source reports a Blackburn and a Bredesen event and appears in both event records; counting every name in its URL as an attendee would misattribute both crowds.

The manually curated provisional file contains 79 potentially focal-candidate events across 39 candidate contests and nine D/R race pairs. These are a review shortlist, not validated measurements. The available-source verification is incomplete and establishes a **lower bound**: five independently reported focal events for four candidate contests, with one D/R race pair (Missouri 2024). This lower bound is not an estimate of how many more events a complete archive investigation could verify. Some cited historical pages cannot currently be retrieved. One verified Warnock event includes a down-ballot candidate speaking, so even verified focal events are not necessarily literally solo. No campaign-wide completeness denominator, invitation counts, or consistent capacity measure exists.

The nine provisional pairs are listed in `matched_pairs_provisional.csv`. They are concentrated in few states, include 2020's exceptional event restrictions, and some rely on a single social-media source or an unverified speaker roster. Their small and selective coverage cannot support reliable chronological holdouts and state holdouts against other proxy models. A numerical regression on them would mostly describe these selected races. No evidence about predictive superiority follows from having counts.

## Screening and audit rules

1. Read official historical releases with immutable event IDs `filename:one_based_row_number`.
2. Match a nominee to an event in the same state and calendar election year, strictly before the November general election day. Exclude online events. This prevents later runoffs and post-election celebrations from entering the same-election measure. It does not prove a source was published before election day: source-publication dates must be audited before a predictive study.
3. Normalize punctuation and accented characters. Reorder `Surname, Given name` roster names. Match flexible first/last names or a surname accompanied by electoral language. Search event metadata and source URLs to create a deliberately permissive review queue.
4. Inspect claims, organizers, event notes and linked headlines to distinguish potential focal campaign rallies from other political gatherings. The resulting `candidate_events_curated.csv` retains raw CCC low/high/mean sizes and original source URLs.
5. For the small verified tier, inspect independent news reports for the actual candidate appearance and attendance description. Store the verified-source URL, count wording, count lower/upper bound where available, and attribution note. A reporter's vague estimate is not an exact headcount. Unretrieved source pages are not silently accepted as verified. A media outlet quoting the campaign is not an independent count.
6. No zero imputation. Candidate aggregates retain missing mean/max/median when unobserved. Counts of observed events describe this dataset's coverage, not the campaign's complete schedule. All quality scores are deliberately null and `prediction_eligible` is false.

## Important audit findings

* McSally 2018 rows with 200–300 attendees include Lindsey Graham or Donald Trump Jr. appearances.
* Donnelly's 2018 2,300-person event was a Joe Biden rally; Rosen's 2,000 included Jimmy Kimmel and Kamala Harris; Cantwell's 500 included Cory Booker.
* O'Rourke's 31,000-person Austin event included Willie Nelson. It cannot be wholly attributed to the Senate candidate.
* A 2022 Tim Ryan record (CCC phase-2 row 60484) links to a report about a Trump rally in Texas. That record is not used in the curated shortlist.
* Cruz's 2018 Laredo event (phase-1 row 30426) is incorrectly described as Trump-organized in CCC metadata; the actual article describes Cruz's rally. Its 700 figure is attributed to Cruz's campaign, it reached venue capacity, and Mike Lee introduced him. It is excluded from the independent focal-count tier.
* The verified Kunce event's CCC midpoint is 175, while the inspected article says more than 150. The independent wording and lower bound are retained rather than relabeling 175 as a precise reporter headcount.

These are reasons to audit each event, not reasons to discard CCC's broader purpose as a protest-event resource.

## Files and reproduction

Use Python 3 with pandas. Run from any directory:

```
python acquire_ccc.py
python audit_ccc.py
python curate_rallies.py
```

`audit_ccc.py` defaults to the roster inputs included under `raw/` and accepts `--senate` and `--governor` overrides. `acquire_ccc.py` uses only the standard library. Re-running acquisition reuses existing downloaded files and verifies original-file checksums. It does not overwrite edited analysis outputs except the acquisition manifest.

* `candidate_mentions_review.csv`: full candidate-event matching queue, including false positives. Not a modeling dataset.
* `candidate_events_curated.csv`: 79 manually shortlisted candidate-event rows with evidence tiers; five have inspected independent source support.
* `candidate_elections_provisional.csv`, `candidate_elections_verified.csv`: all 268 roster rows joined to observed-event aggregates. Nulls remain null. These are coverage files, not candidate-quality scores.
* `matched_pairs_provisional.csv`, `matched_pairs_verified.csv`: corresponding D/R overlap.
* `coverage_summary.csv`, `raw_coverage.json`: exact programmatic counts.
* `source_audit_examples.csv`: important rejected/shared-source examples.
* `provenance.json`: raw source URLs, checksums and roster origins.

No model is fitted, no outcome values are used to select a winning proxy, and no claim of a natural experiment is made. The useful next collection would begin with a complete candidate event schedule, add source-independent attendance and guest lists, and record capacity/censoring and event format before evaluating predictive value.

Official sources: https://doi.org/10.7910/DVN/6OPP7H (phase 1), https://doi.org/10.7910/DVN/9MMYDI (phase 2), https://ash.harvard.edu/programs/crowd-counting-consortium/ . Both CCC releases are CC0. The Senate roster derives from https://doi.org/10.7910/DVN/PEJ5QU .
