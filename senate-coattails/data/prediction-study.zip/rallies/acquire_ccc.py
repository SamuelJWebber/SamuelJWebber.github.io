"""Acquire official historical CCC metadata, data, and dictionaries (CC0).
Run with Python 3; stdlib only. Raw bytes and checksums recorded in provenance.json.
"""
import concurrent.futures,hashlib,json,pathlib,time,urllib.request
BASE=pathlib.Path(__file__).resolve().parent; RAW=BASE/'raw';RAW.mkdir(exist_ok=True)
HEADERS={'User-Agent':'Mozilla/5.0 (research replication)','Accept':'*/*'}
def get(url,path):
    if not path.exists():
        for attempt in range(3):
            try:
                with urllib.request.urlopen(urllib.request.Request(url,headers=HEADERS),timeout=120) as r:
                    path.write_bytes(r.read())
                break
            except Exception:
                if attempt==2:raise
    b=path.read_bytes()
    return {'url':url,'file':str(path.relative_to(BASE)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'md5':hashlib.md5(b).hexdigest()}
records=[]; downloads=[]
for doi in ['6OPP7H','9MMYDI']:
    for name,suffix in [('metadata','/export?exporter=dataverse_json&persistentId='),('files','/:persistentId/versions/:latest/files?persistentId=')]:
        url='https://dataverse.harvard.edu/api/datasets'+suffix+'doi:10.7910/DVN/'+doi
        path=RAW/(doi+'_'+name+'.json');records.append(get(url,path))
        if name=='files':
            for f in json.loads(path.read_text())['data']:
                d=dict(f['dataFile'],dataset_doi='10.7910/DVN/'+doi);downloads.append(('https://dataverse.harvard.edu/api/access/datafile/'+str(d['id']),RAW/d['filename'],d))
                if d.get('tabularData'):
                    orig=dict(d,tabularData=False); downloads.append(('https://dataverse.harvard.edu/api/access/datafile/'+str(d['id'])+'?format=original',RAW/d['originalFileName'],orig))
def download(task):
    u,p,d=task;r=get(u,p);r.update({'doi':d.get('dataset_doi'),'dataverse_id':d['id'],'expected_md5':d.get('checksum',{}).get('value')})
    if not d.get('tabularData') and r['expected_md5'] and r['md5']!=r['expected_md5']:raise ValueError('Checksum mismatch '+str(p))
    print('Saved',p.name,r['bytes'],flush=True);return r
with concurrent.futures.ThreadPoolExecutor(4) as ex:records+=list(ex.map(download,downloads))
old=json.loads((BASE/'provenance.json').read_text()) if (BASE/'provenance.json').exists() else {}
(BASE/'provenance.json').write_text(json.dumps({'accessed_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'sources':records,'nominee_roster_sources':old.get('nominee_roster_sources',[])},indent=2))
