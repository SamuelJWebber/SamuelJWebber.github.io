"""Screen official CCC event records against Senate and governor nominee rosters.
The output is a REVIEW QUEUE, not automatically verified rally attendance.
"""
import argparse,pathlib,re,unicodedata,datetime,json
import pandas as pd
B=pathlib.Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--senate',default=str(B/'raw/senate_returns.tsv'));p.add_argument('--governor',default=str(B/'raw/gov_nominees.csv'));a=p.parse_args()
def norm(s):return re.sub(r'[^A-Z0-9]+',' ',unicodedata.normalize('NFKD',str(s)).encode('ascii','ignore').decode().upper()).strip()
def election_day(y):
 d=datetime.date(y,11,2)
 return d+datetime.timedelta(days=(1-d.weekday())%7)
s=pd.read_csv(a.senate,sep='\t');s=s[(s.year>=2017)&s.stage.str.lower().eq('gen')&s.party_simplified.isin(['DEMOCRAT','REPUBLICAN'])]
s=s.groupby(['year','state_po','special','party_simplified','candidate'],as_index=False).candidatevotes.sum()
s=s.loc[s.groupby(['year','state_po','special','party_simplified']).candidatevotes.idxmax()]
s=s.rename(columns={'state_po':'state','party_simplified':'party'});s['office']='senate'
g=pd.read_csv(a.governor);g=g[g.year>=2017];gs=[]
for part,col in [('DEMOCRAT','dem_nominee'),('REPUBLICAN','rep_nominee')]:
 t=g[['year','state_abbrev',col]].rename(columns={'state_abbrev':'state',col:'candidate'});t['party']=part;t['office']='governor';t['special']=False;gs.append(t)
r=pd.concat([s,*gs],ignore_index=True);r['candidate']=r.candidate.astype(str).str.strip();r=r[r.candidate.str.lower().ne('nan')]
r['candidate_key']=r.office+'_'+r.state+'_'+r.year.astype(str)+'_'+r.party+'_'+r.special.astype(str)
r['candidate_norm']=r.candidate.map(lambda x: norm(' '.join(reversed(x.split(',',1)))) if ',' in x else norm(x));r.to_csv(B/'candidate_roster.csv',index=False)
allrows=[];coverage=[]
for fname in ['ccc_compiled_20172020.tab','ccc_compiled_20212024.tab']:
 d=pd.read_csv(B/'raw'/fname,sep='\t',low_memory=False);d['event_id']=fname+':'+(d.index+1).astype(str);d['year']=pd.to_datetime(d.date).dt.year
 d['source_file']=fname
 textcols=[c for c in ['title','actors','organizations','participants','claims','claims_summary','notes','location_detail'] if c in d]
 d['event_text']=d[textcols].fillna('').agg(' | '.join,axis=1)
 sourcecols=[c for c in d if c.startswith('source_') and c!='source_file'];d['source_urls']=d[sourcecols].fillna('').astype(str).agg(' | '.join,axis=1).str.strip(' |')
 d['matchtext']=(d.event_text+' '+d.source_urls).map(norm)
 coverage.append({'file':fname,'events':len(d),'first_date':d.date.min(),'last_date':d.date.max(),'crowd_size_present':int(d.size_mean.notna().sum())})
 for row in r.itertuples():
  x=d[(d.state.eq(row.state))&(d.year.eq(row.year))&(d.date<str(election_day(row.year)))&(~d.online.eq(1))]
  name=row.candidate_norm.split();name=[z for z in name if z not in ['JR','SR','II','III','IV']]
  if len(name)<2:continue
  first,last=name[0],name[-1]
  # First+last flexible middle; exact full surname can enter queue if an electoral claim.
  full_pat=r'\b'+re.escape(first)+r'(?: [A-Z]+){0,3} '+re.escape(last)+r'\b'
  full=x.matchtext.str.contains(full_pat,regex=True)
  surname=x.matchtext.str.contains(r'\b'+re.escape(last)+r'\b',regex=True)
  camp=x.matchtext.str.contains(r'\b(?:CAMPAIGN|ELECT|REELECT|VOTE|GOVERNOR|SENATE|SENATOR)\b',regex=True)
  hit=x[full|(surname&camp)].copy()
  if hit.empty:continue
  hit['match_kind']=['full_name' if b else 'surname_electoral' for b in full.loc[hit.index]]
  for c in ['candidate_key','candidate','office','party','special']:hit[c]=getattr(row,c)
  allrows.append(hit)
q=pd.concat(allrows,ignore_index=True) if allrows else pd.DataFrame()
cols=['candidate_key','candidate','office','party','special','year','event_id','date','state','locality','type','match_kind','event_text','size_text','size_low','size_high','size_mean','source_urls','fips_code','source_file']
q[cols].to_csv(B/'candidate_mentions_review.csv',index=False)
(B/'raw_coverage.json').write_text(json.dumps(coverage,indent=2))
print('Roster',r.groupby(['office','year']).size().to_dict());print('Queue',len(q),'events',q.event_id.nunique(),'candidate elections',q.candidate_key.nunique());print(q.groupby(['office','year']).agg(matches=('event_id','size'),events=('event_id','nunique'),candidates=('candidate_key','nunique')).to_string())
# Human readable reduced review (one event row, candidates retained separately).
q[['event_id','date','state','locality','event_text','size_mean','source_urls']].drop_duplicates('event_id').to_csv(B/'events_review.csv',index=False)
