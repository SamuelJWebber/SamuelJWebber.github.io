"""Post-selection diagnostic: separate previous participation from prior performance."""
from pathlib import Path
import json
import pandas as pd
from benchmark import BASELINE, HISTORY, predict, scores, paired_uncertainty

ROOT=Path(__file__).parent
sample=pd.read_csv(ROOT/'sample.csv')
rows=[]
gains=[]
for stage,cutoff in [('development',2008),('test',2014),('confirmation',2022)]:
    train=sample.loc[sample.year.le(cutoff)].dropna(subset=BASELINE)
    test=sample.loc[sample.split.eq(stage)].dropna(subset=BASELINE)
    main=predict(train,test,BASELINE+HISTORY)
    for label,features in [('baseline',BASELINE),('prior_participation_only',BASELINE+['prior_D_observed','prior_R_observed']),('prior_score_only',BASELINE+['prior_candidate_advantage']),('selected_prior_model',BASELINE+HISTORY)]:
        p=predict(train,test,features)
        m=scores(test.dshare,p)
        rows.append({'model':label,'stage':stage,'races':len(test),**m,'diagnostic_only':True})
    frame=pd.DataFrame({'state_abbrev':test.state_abbrev,'actual':test.dshare,'prediction':main,'baseline_prediction':predict(train,test,BASELINE+['prior_D_observed','prior_R_observed'])})
    lo,hi=paired_uncertainty(frame)
    gain=(abs(frame.actual-frame.baseline_prediction)-abs(frame.actual-frame.prediction)).mean()*100
    gains.append({'stage':stage,'races':len(test),'mae_gain_pp':gain,'low95':lo,'high95':hi})
    print(stage,'performance value gain beyond history indicator',gain,'CI',lo,hi)
out=pd.DataFrame(rows)
out.to_csv(ROOT/'results/history_ablation.csv',index=False)
pd.DataFrame(gains).to_csv(ROOT/'results/history_value_increment.csv',index=False)
print(out.to_string(index=False))
