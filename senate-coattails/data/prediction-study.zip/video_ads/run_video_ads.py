"""CREATIVE 2022 candidate-sponsored Google video reach and Senate results.

Reproduce with: python run_video_ads.py
Dependencies: pandas, numpy, scikit-learn. Downloads public source files if absent.
This is retrospective, single-cycle leave-one-state-out prediction, not a causal
coattail estimate or an out-of-time forecast. The supplied sample is the separately
constructed Senate benchmark; no outcomes enter mapping or exposure construction.
"""
from pathlib import Path
import argparse
import hashlib
import json
import urllib.request

import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression

HERE = Path(__file__).resolve().parent
SOURCES = {
    'google_core.csv.gz': 'https://ndownloader.figshare.com/files/54499229',
    'wmpcand_120223_wmpid.csv': 'https://raw.githubusercontent.com/Wesleyan-Media-Project/datasets/5a9e15225c6bf909aa5f1367c5e83c63bc7e7d0d/candidates/wmpcand_120223_wmpid.csv',
    'codebook.xlsx': 'https://ndownloader.figshare.com/files/53956769',
}
BASELINE = ['prior_pres_lean', 'incumbency', 'white_house_party', 'midterm_white_house']
MODELS = {
    'baseline': [],
    'plus_video_impressions_midpoint': ['log_impressions_midpoint_DminusR'],
    'plus_video_spend_midpoint': ['log_spend_midpoint_DminusR'],
    'plus_video_impressions_and_spend': ['log_impressions_midpoint_DminusR', 'log_spend_midpoint_DminusR'],
    'plus_video_impressions_lower': ['log_impressions_lower_DminusR'],
    'plus_video_impressions_upper': ['log_impressions_upper_DminusR'],
}
# Official general-election list contains additional names in five state-party
# cells. Resolve these by the named nominee in the independently built benchmark.
# OK regular race is Madison Horn/Lankford; Kendra Horn/Mullin is the special race.
NAME_RESOLUTIONS = {
    ('IN', 'DEM'): 'S2IN00208', ('MO', 'REP'): 'S2MO00544',
    ('OK', 'DEM'): 'S2OK00152', ('OK', 'REP'): 'S4OK00232',
    ('WI', 'DEM'): 'S2WI00441',
}
WINDOWS = {
    'completed_by_election': 'Primary: ad active in Sept 1-Nov 8 window, lifecycle ended no later than Nov 8',
    'entire_archive_lifecycles': 'Sensitivity: all archived overlapping ads, includes some post-election exposure',
    'contained_final_window': 'Sensitivity: entire ad lifecycle within Sept 1-Nov 8',
}


def source_files():
    manifest = []
    for filename, url in SOURCES.items():
        path = HERE / filename
        if not path.exists():
            urllib.request.urlretrieve(url, path)
        manifest.append({'filename': filename, 'url': url,
                         'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                         'bytes': path.stat().st_size})
    (HERE / 'source_manifest.json').write_text(json.dumps({
        'paper': 'https://doi.org/10.1038/s41597-025-05228-w',
        'dataset_version': 'https://doi.org/10.25438/wes02.26124355.v3',
        'license': 'CC BY-NC 4.0; https://creativecommons.org/licenses/by-nc/4.0/',
        'files': manifest}, indent=2) + '\n')


def map_candidates(sample):
    candidates = pd.read_csv(HERE / 'wmpcand_120223_wmpid.csv')
    candidates = candidates.loc[candidates.cand_office.eq('S') & candidates.genelect_cd.eq(1)]
    rows = []
    for _, race in sample.iterrows():
        for party, long_party in [('DEM', 'DEMOCRAT'), ('REP', 'REPUBLICAN')]:
            c = candidates.loc[candidates.cand_office_st.eq(race.state_abbrev)
                               & candidates.cand_party_affiliation.eq(party)]
            chosen = NAME_RESOLUTIONS.get((race.state_abbrev, party))
            if chosen:
                c = c.loc[c.cand_id.eq(chosen)]
            if len(c) != 1:
                raise ValueError(f'Unresolved candidate: {race.state_abbrev} {party}')
            r = c.iloc[0]
            rows.append({'state_abbrev': race.state_abbrev, 'party': party,
                         'benchmark_candidate': race[f'candidate_{long_party}'],
                         'cand_id': r.cand_id, 'official_name': r.cand_name,
                         'official_full_name': r.full_name})
    mapping = pd.DataFrame(rows)
    assert not mapping.cand_id.duplicated().any()
    mapping.to_csv(HERE / 'candidate_mapping.csv', index=False)
    return mapping


def features(sample, mapping):
    raw = pd.read_csv(HERE / 'google_core.csv.gz', low_memory=False)
    assert not raw.ad_id.duplicated().any(), 'Ad IDs must be counted exactly once'
    campaign_rows = raw.loc[raw.wmp_office.eq('us senate') & raw.wmp_spontype.eq('campaign')]
    all_format_counts = campaign_rows.groupby('cand_id').size().rename('all_formats_archive_ad_count')
    # VIDEO is Google's ad type. Impressions are paid ad displays, not unique viewers,
    # organic video views, subscribers, or exclusively YouTube viewing.
    ads = raw.loc[raw.wmp_office.eq('us senate') & raw.wmp_spontype.eq('campaign')
                  & raw.ad_type.eq('VIDEO')].copy()
    assert ads.cand_id.notna().all()
    audit = ads.merge(mapping[['cand_id','party']], on='cand_id', how='inner')
    assert audit.party.eq(audit.party_all).all(), 'Source party must agree with candidate metadata'
    bounds = ads.impressions.str.extract(r'^(\d+)-(\d+)$')
    assert bounds.notna().all().all(), 'An unbounded range requires an explicit revised specification'
    ads['impressions_lower'] = bounds[0].astype(float)
    ads['impressions_upper'] = bounds[1].astype(float)
    ads['impressions_midpoint'] = ads[['impressions_lower', 'impressions_upper']].mean(axis=1)
    ads['spend_lower'] = ads.spend_range_min_usd
    ads['spend_upper'] = ads.spend_range_max_usd
    assert (ads.spend_upper >= ads.spend_lower).all()
    ads['spend_midpoint'] = ads[['spend_lower', 'spend_upper']].mean(axis=1)
    ads['start'] = pd.to_datetime(ads.date_range_start)
    ads['end'] = pd.to_datetime(ads.date_range_end)
    start, end = pd.Timestamp('2022-09-01'), pd.Timestamp('2022-11-08')
    ads = ads.loc[(ads.start <= end) & (ads.end >= start)].copy()
    masks = {
        'completed_by_election': ads.end.le(end),
        'entire_archive_lifecycles': pd.Series(True, index=ads.index),
        'contained_final_window': ads.end.le(end) & ads.start.ge(start),
    }
    value_cols = ['impressions_lower', 'impressions_upper', 'impressions_midpoint',
                  'spend_lower', 'spend_upper', 'spend_midpoint']
    all_coverage, all_features = [], []
    for window, mask in masks.items():
        eligible_ads = ads.loc[mask]
        totals = eligible_ads.groupby('cand_id')[value_cols].sum()
        totals['ad_count'] = eligible_ads.groupby('cand_id').size()
        totals['earliest_ad_start'] = eligible_ads.groupby('cand_id').start.min()
        totals['latest_ad_end'] = eligible_ads.groupby('cand_id').end.max()
        coverage = mapping.merge(totals, on='cand_id', how='left', validate='one_to_one')
        coverage = coverage.merge(all_format_counts, on='cand_id', how='left', validate='one_to_one')
        coverage['video_observed'] = coverage.ad_count.notna()
        coverage['coverage_status'] = np.select(
            [coverage.video_observed, coverage.all_formats_archive_ad_count.notna()],
            ['eligible_video_observed', 'campaign_in_archive_but_no_eligible_video'],
            default='no_candidate_campaign_ads_in_archive')
        coverage['window'] = window
        all_coverage.append(coverage)
        pairs = coverage.pivot(index='state_abbrev', columns='party', values=value_cols+['ad_count'])
        pairs.columns = [f'{v}_{p[0]}' for v, p in pairs.columns]
        pairs = pairs.reset_index().merge(sample, on='state_abbrev', validate='one_to_one')
        pairs['eligible'] = pairs.ad_count_D.notna() & pairs.ad_count_R.notna()
        for col in value_cols:
            pairs[f'log_{col}_DminusR'] = np.log1p(pairs[col+'_D'])-np.log1p(pairs[col+'_R'])
        pairs['window'] = window
        all_features.append(pairs)
    pd.concat(all_coverage, ignore_index=True).to_csv(HERE / 'candidate_coverage.csv', index=False)
    f = pd.concat(all_features, ignore_index=True)
    # Keep useful audit columns and avoid copying unrelated licensed metadata.
    keep = ['state_abbrev','year','candidate_DEMOCRAT','candidate_REPUBLICAN','dshare'] + BASELINE
    keep += [c for c in f if c.startswith(('impressions_', 'spend_', 'log_', 'ad_count_'))]
    keep += ['window','eligible']
    f = f[keep]
    f.to_csv(HERE / 'paired_features.csv', index=False)
    return f, {'archive_ads': len(raw), 'candidate_senate_video_ads': len(ads),
               'candidate_senate_video_fec_ids': int(ads.cand_id.nunique()),
               'benchmark_races_2022': len(sample), 'benchmark_nominees_2022': len(mapping)}


def predict(train, test, columns):
    # Match benchmark model: train-only imputation/scaling, OLS, clip probability.
    numeric_train, numeric_test = train[columns].astype(float), test[columns].astype(float)
    mean = numeric_train.mean().fillna(0.)
    sd = numeric_train.std().replace(0, 1).fillna(1.)
    x = (numeric_train.fillna(mean)-mean)/sd
    xt = (numeric_test.fillna(mean)-mean)/sd
    model = LinearRegression().fit(x, train.dshare)
    return float(np.clip(model.predict(xt), 0, 1)[0])


def evaluate(f):
    predictions = []
    for window in WINDOWS:
        s = f.loc[f.window.eq(window) & f.eligible].dropna(subset=BASELINE).copy()
        if len(s) < 8:
            raise ValueError(f'Too few paired races in {window}: {len(s)}')
        for _, held in s.iterrows():
            test = held.to_frame().T
            train = s.loc[s.state_abbrev.ne(held.state_abbrev)]
            baseline = predict(train, test, BASELINE)
            for name, extra in MODELS.items():
                p = baseline if not extra else predict(train, test, BASELINE+extra)
                predictions.append({'window':window, 'model':name, 'state_abbrev':held.state_abbrev,
                                    'actual':held.dshare, 'prediction':p, 'baseline_prediction':baseline,
                                    'train_n':len(train)})
    predictions = pd.DataFrame(predictions)
    predictions.to_csv(HERE / 'loso_predictions.csv', index=False)
    metrics = []
    for (window, model), group in predictions.groupby(['window', 'model'], sort=False):
        actual, p, base = [group[k].to_numpy(float) for k in ['actual','prediction','baseline_prediction']]
        gains = (np.abs(actual-base)-np.abs(actual-p))*100
        rng = np.random.default_rng(20261105)
        draws = rng.integers(0, len(gains), size=(10000,len(gains)))
        lo, hi = np.quantile(gains[draws].mean(axis=1), [.025,.975])
        metrics.append({'window':window,'model':model,'races':len(group),'training_races_per_fold':len(group)-1,
                        'mae_pp':np.abs(actual-p).mean()*100,
                        'rmse_pp':np.sqrt(((actual-p)**2).mean())*100,
                        'baseline_mae_pp':np.abs(actual-base).mean()*100,
                        'mae_gain_pp':gains.mean(),'gain_bootstrap_95_lo':lo,'gain_bootstrap_95_hi':hi,
                        'head_to_head_accuracy':np.mean((p>=.5)==(actual>=.5))})
    metrics = pd.DataFrame(metrics)
    metrics.to_csv(HERE / 'metrics.csv', index=False)
    return metrics


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--sample', type=Path, default=HERE/'senate_benchmark_2022.csv')
    args = parser.parse_args()
    sample = pd.read_csv(args.sample).query('year==2022').copy()
    assert sample.state_abbrev.is_unique
    source_files()
    mapping = map_candidates(sample)
    f, counts = features(sample, mapping)
    counts['eligible_races_by_window'] = f.groupby('window').eligible.sum().to_dict()
    counts['sample_sha256'] = hashlib.sha256(args.sample.read_bytes()).hexdigest()
    (HERE/'counts.json').write_text(json.dumps(counts, indent=2)+'\n')
    metrics = evaluate(f)
    print(metrics.to_string(index=False, float_format=lambda v:f'{v:.4f}'))


if __name__ == '__main__':
    main()
