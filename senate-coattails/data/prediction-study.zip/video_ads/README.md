# Paid video exposure and 2022 Senate prediction

This is a retrospective, one-cycle prediction check using actual archived Google video-ad impressions and spending. The data measure paid advertising reach. They do not measure organic video popularity, charisma, or a causal effect on either the candidate's result or another candidate's result.

## Result

On the same 11 eligible 2022 Senate races, leaving one state out at a time, adding the Democratic–Republican log impression ratio did not improve prediction of the Senate Democratic two-party vote share.

| Model | Held-out MAE, percentage points | Held-out RMSE, percentage points |
|---|---:|---:|
| Presidential lean and incumbency baseline | 2.1645 | 2.6985 |
| Baseline + video impression midpoint ratio | 2.3827 | 2.8000 |
| Baseline + video spending midpoint ratio | 2.3897 | 2.8249 |
| Baseline + both video measures | 2.6964 | 3.0545 |

The impression model's MAE gain relative to baseline is −0.2182 points. A simple paired bootstrap of the 11 held-out state errors gives a descriptive 95% interval of −0.6261 to +0.1379. Negative gain means worse prediction. This interval resamples fixed cross-validation errors; it does not account fully for overlapping training sets or model-selection uncertainty. The small sample makes this a limited diagnostic, not evidence that paid advertising cannot matter.

## Coverage and measurement

The CREATIVE core file contains 80,247 unique ad IDs. Its Senate campaign VIDEO subset contains 3,730 ad IDs for 46 FEC candidate identifiers. The supplied election benchmark contains 27 clean regular D-vs-R Senate races in 2022, with 54 nominees. Mapping uses official Wesleyan Media Project candidate data; the candidate names and exact identifiers are exported in `candidate_mapping.csv` for inspection. Five state-party cells with extra metadata candidates are resolved explicitly by nominee identity in the script: Indiana Democratic, Missouri Republican, Wisconsin Democratic, and both parties in Oklahoma, where the regular and special races must be distinguished.

For the main window, 34 of 54 benchmark nominees have eligible archived campaign video ads. Six other nominees have campaign ads in other formats or outside the eligible video window; 14 have no campaign ads in this source under their mapped candidate IDs. Missing records are not assumed to mean zero exposure. Requiring observed video ads for both nominees leaves Colorado, Florida, Georgia, Kansas, Missouri, North Carolina, New Hampshire, Nevada, Ohio, Pennsylvania, and Wisconsin. These are 11 selected states, not a representative national sample. This benchmark's race-selection rules also exclude some 2022 Senate races before the advertising merge.

The primary filter selects `wmp_office == 'us senate'`, `wmp_spontype == 'campaign'`, and `ad_type == 'VIDEO'`. It uses candidate identifiers to attribute an ad to the sponsoring campaign. Party and outside-group ads are excluded; machine-inferred partisan content is not used. Each unique ad ID is counted once. Shared creative IDs are retained because different ads can deliver separate impressions. Google VIDEO includes YouTube advertising; this dataset does not provide a placement field here that isolates YouTube alone. Impressions count ad displays, not distinct people or completed video views. Campaign totals can also include out-of-state fundraising advertisements; this analysis does not isolate impressions actually delivered to the state's electorate.

Ad lifecycle dates must overlap September 1–November 8, 2022. The main window also requires lifecycle completion by November 8. The reported exposure is the ad's lifetime total, so an ad that began before September can include earlier exposure. The earliest included nominee ad started April 27, 2022. We do not prorate exposure by days, since daily delivery is unavailable. Two sensitivities are included in `metrics.csv`:

* The entire archived overlapping lifecycle, including ads ending after Election Day. It gives baseline MAE 2.1645 versus 2.4304 with impressions, on the same 11 states.
* Ads whose entire lifecycle lies within September 1–November 8. This drops Colorado because its Republican campaign's single observed video started earlier. On 10 paired states, baseline MAE is 2.4865 versus 2.5628 with impressions.

Google supplies impression and spending ranges. We sum each candidate's range midpoints and create `log(1 + Democratic total) − log(1 + Republican total)`. Lower-bound and upper-bound impression totals are also evaluated; the main-window MAEs are 2.3793 and 2.3857. No selected candidate-campaign video ad has an open-ended impression range. Range-sensitivity fits are measurement checks, not formal confidence bounds on the prediction effect.

## Model and reproducibility

Run `python run_video_ads.py` with Python 3 and `pandas`, `numpy`, and `scikit-learn`. The script downloads the public Google core, codebook, and official candidate list if absent. `--sample PATH` accepts an alternative benchmark with the same schema. The included `senate_benchmark_2022.csv` is the 2022 slice of the independently built Senate benchmark and includes only the nominee identities, outcome, and baseline inputs used here. Its vote-share and prior-presidential-lean fields derive from public MIT Election Data and Science Lab returns; the 2022 incumbency variable uses the benchmark's prior winner identity rule.

For every held-out state, fit OLS separately to the other 10 states. The baseline uses prior presidential lean, incumbency, pre-election White House party, and its midterm interaction. The last two are constants in 2022 and add no cross-state information. Every fitted preprocessing quantity uses training rows only. Predictions are clipped to [0,1], matching the main benchmark. Every augmented model is compared with a baseline trained and evaluated on exactly the same rows. No tuning search is performed. Models with both advertising variables are reported as additional checks, alongside the single-variable tests.

This is single-cycle leave-one-state-out evaluation. It is not an out-of-time validation. Exposure compilation was retrospective: the paper says Google data were downloaded shortly after Election Day, and additional 2022 ads appeared in summer 2023. End dates do not establish when these data were available to a forecaster. Campaign advertising is also chosen in response to money, competitiveness, polling, and campaign strategy. No causal or natural-experiment interpretation follows from this test.

Files written by the script:

* `source_manifest.json`: exact source URLs, downloaded sizes and SHA-256 hashes.
* `candidate_mapping.csv` and `candidate_coverage.csv`: nominee join and coverage audit.
* `paired_features.csv`: totals and modeling inputs for each race/window, retaining missing exposure as missing.
* `loso_predictions.csv`: held-out predictions and matched baselines.
* `metrics.csv`: all declared models and windows, with errors and paired bootstrap diagnostics.
* `counts.json`: source/sample counts and the benchmark input hash.

## Sources and permissions

Zhang, Meiqing, et al. (2025), “Comparable 2022 General Election Advertising Datasets from Meta and Google,” *Scientific Data* 12, 968. [Paper](https://doi.org/10.1038/s41597-025-05228-w).

The public Google core is [version 3, DOI 10.25438/wes02.26124355.v3](https://doi.org/10.25438/wes02.26124355.v3), associated with [Figshare article 26124355](https://api.figshare.com/v2/articles/26124355). [Direct compressed CSV](https://ndownloader.figshare.com/files/54499229); [codebook](https://ndownloader.figshare.com/files/53956769). The aggregate CREATIVE article 28288016 only provides an access-instructions PDF; the paper's individual Google core DOI provides the downloadable file used here.

[Official candidate metadata](https://github.com/Wesleyan-Media-Project/datasets/blob/main/candidates/wmpcand_120223_wmpid.csv). Names and IDs are used for the join; demographic attributes and election-result metadata in that file are not used as model predictors.

The Figshare source is licensed [CC BY-NC 4.0](https://creativecommons.org/licenses/by-nc/4.0/). Public access does not remove its noncommercial restriction. This scratch analysis does not publish the raw ad dataset or make a licensing claim for commercial reuse. All source information used is publicly available aggregate advertising or election data; no private account or personal communications data are used.
