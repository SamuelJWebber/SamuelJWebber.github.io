# Candidate strength benchmark audit

This is an internal specification and feature audit. Candidate-quality prediction and causal coattails estimation are separate tasks. Selecting a proxy by its prediction of its own Senate result does not identify the effects on other races.

## The prediction target

Use Democratic votes divided by Democratic plus Republican votes in the same regular Senate election, with one state-election as the observation. Evaluate named D/R nominees and include fusion ballot votes consistently. Record multi-round, write-in, two-Senate-race, third-party, and absent-major-party exclusions explicitly. Do not condition benchmark eligibility on the final margin, D+R fraction, the eventual winner, or either candidate's final vote share.

The old curr_own is Senate performance adjusted by the concurrent cycle's results. Do not use it as the main real-time forecast target. Do not train a normal-vote baseline from the target election's presidential, House or other Senate returns.

## Fixed chronology

Follow the prediction engine's locked chronology.
- Training elections through 2008.
- Development elections in 2010, 2012 and 2014.
- Untouched test elections in 2016, 2018, 2020 and 2022.
- 2024 is potentially a further confirmation cohort if all required pre-election metadata are sourced without extrapolating the paper's 2022 endpoint.

Choose model family, regularization, features, transformations and any candidate-strength cutoffs on training and development data only. Once chosen, the model can refit on all data through 2014, then score every test election with that fitted model. A separately labelled expanding-window exercise may train on earlier test-cycle outcomes for the next cycle. Do not mix its results with the frozen-model test.

Simple nested models are preferable with these sample sizes. If hyperparameters are used, tune in chronological folds inside development. Fit imputers, scaling, donor residualization and composite-score weights on each training split only.

Year fixed effects learned from the held-out election's results are forbidden. Features may include election timing and other facts known before voting. A model conditional on the realized national swing must be explicitly labelled retrospective and kept outside a real-time ranking.

## Feature availability

| Field or proxy | Temporal status and required treatment |
|---|---|
| State's preceding presidential lean relative to the nation | Safe if presidential year is strictly less than the target year. |
| Senate incumbent party or open seat | A known pre-election attribute, safe after verifying metadata against the race and nominees. |
| Candidate's prior election performance | Safe if a correctly linked prior election occurred before the target. Can use the presidential returns and national Senate median of that earlier election because they were known historically. |
| Prior officeholding experience | Pre-election biographical attribute. Date and code coverage still need checking. |
| Scandal flag | Some records indicate scandals during the whole term. For an early forecast cutoff the precise disclosure date is required. Treat undated flags as election-eve or retrospective availability. |
| Newspaper endorsement score | The released latent score was reconstructed using a historical model of newspaper bias. Verify whether future elections help estimate that bias. Until proven otherwise label this a retrospective reconstructed measure; holdout prediction conditional on this fixed measure is not an honest real-time endorsement forecast. Raw dated endorsements and within-training calibration would be needed for that claim. |
| Donation counts | Unique people, not transaction counts. Only receipts dated and filed by the fixed forecast cutoff qualify. Count in-state and out-of-state separately. Normalize with a pre-election population denominator. Report incomplete itemization and matching coverage. |
| Donation dollars | Prefer individual receipts with self-funding and transfers identified. Full-cycle amounts can contain post-election receipts, so need a temporal filter. |
| Donor score adjusted for closeness | Use baseline state partisanship or archived pre-cutoff competitiveness. Final margin and late matchup polling can partly be outcomes of the candidate's appeal. |
| Published DIME ideology scores | A separate construct from candidate quality. Score construction may use data across years, requiring a similar temporal-availability check. |
| Mass or expert ratings | Use only dated pre-election ratings. State clearly which offices/years they cover and whether political popularity already enters them. |
| Rally attendance or online followers | Require historical snapshots and comparable denominators. A handful of named current cases cannot compete with nationwide historical models. Mark measured pilot/coverage unavailable as appropriate. |

## Same-candidate and same-state generalization

The main time split answers whether earlier election relationships predict future elections, which may include returning politicians.

Add a candidate-disjoint check by deleting from training every election involving either nominee who appears in the held-out cohort. Match both Democratic and Republican candidate identities, including name aliases. Historical personal performance remains an allowed input to a known-history forecast. Report a separate coverage-limited first-time-nominee analysis if the question is performance for candidates without a personal record.

An additional leave-state-out check must refit every fitted transform without that state's training observations. It asks about geographic transportability and should be labelled separately from ordinary temporal holdout.

## Fair proxy comparison

For each proxy, score baseline and baseline-plus-proxy on precisely the same eligible train/development/test elections. Use the same target, observation weights, cutoff, and baseline controls. Report:
- test MAE in percentage points and paired MAE reduction against baseline;
- test RMSE and paired RMSE reduction;
- development results, number of elections, distinct states, nominees and test cycles;
- missing coverage and the reason it is missing;
- enough race-level predictions to inspect large errors.

A lower MAE on a different sample is insufficient to rank two proxies. A common complete-case tournament is useful only if it retains an adequate sample and its selection is described. Otherwise show separate paired improvements and explicit coverage. Missingness imputation must be fitted within training and accompanied by availability indicators and a sensitivity analysis.

For a combined score, fit simple regularized weights on training/development data, freeze them, and test once. No post-test adjustment of weights or selective choice of a flattering subgroup. Predictive accuracy measures an election-specific advantage involving both nominees, not intrinsic charisma.

## Coverage already observed

Raw state-year coverage in the paper input, before clean Senate-result matching, for 1978–2022:

| Proxy | Through 2004 | 2006–2014 | 2016–2022 |
|---|---:|---:|---:|
| Senate newspaper score | 253 | 61 | 22 |
| Senate officeholding advantage | 438 | 149 | 31 |
| Senate scandal indicator | 410 | 150 | 60 |
| Senate incumbency | 457 | 164 | 131 |

For the engine's 2010–2014 development window, newspaper scores exist for only 29 raw state-years. Recent fundraising will likely require its own temporal cohort. These counts shrink when nominees, timing and features are matched. A universal winner requires stronger overlap than these figures promise.

## Uncertainty and selection

Use paired out-of-sample errors. Bootstrap whole states for repeated state elections rather than individual House rows, and show each held-out cycle separately. A four-cycle test provides limited evidence about future national environments. Leave-one-test-cycle-out results complement state-cluster uncertainty; neither makes four cycles a large sample.

Do not present a numerical winner as statistically established when the paired interval includes zero or when the best model was chosen after seeing the test. Use 'lowest error in this holdout' and include its uncertainty and sample. Never pick a quality proxy because it produces a desired coattails coefficient.

## Consequence for the coattails dashboard

A forecasting benchmark validates a proxy's ability to predict the nominee's own vote. Coattails remain separately estimated associations unless there is exogenous nominee variation. For total coattails, include turnout and persuasion in the estimand and do not adjust away campaign spending, mobilization or turnout. Prior same-office results and pretrends help diagnose persistent party strength but cannot by themselves establish causality.
