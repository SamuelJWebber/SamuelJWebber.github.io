"""Supplemental proxy comparisons with identical eligible fitting and evaluation rows.

No new tuning or selection. Endorsements remain a retrospective measurement lane.
These estimates assess own-race prediction, not causal coattails or pure charisma.
"""
from pathlib import Path
import json
import pandas as pd
from benchmark import BASELINE, HISTORY, KEY, predict, scores, paired_uncertainty

BASE = Path(__file__).resolve().parent


def main():
    sample = pd.read_csv(BASE / 'sample.csv')
    output = []
    predictions = []
    for proxy in ['experience', 'endorsement']:
        eligible = sample.dropna(subset=BASELINE + HISTORY + [proxy])
        for stage, cutoff in [('development', 2008), ('test', 2014)]:
            train = eligible.loc[eligible.year.le(cutoff)].copy()
            test = eligible.loc[eligible.split.eq(stage)].copy()
            if len(train) < 30 or not len(test):
                continue
            models = {
                'baseline': BASELINE,
                'prior_performance': BASELINE + HISTORY,
                'proxy': BASELINE + [proxy],
                'prior_plus_proxy': BASELINE + HISTORY + [proxy],
            }
            fitted = {model: predict(train, test, features) for model, features in models.items()}
            for model, values in fitted.items():
                rows = test[KEY + ['candidate_DEMOCRAT', 'candidate_REPUBLICAN']].copy()
                rows['actual'] = test.dshare.to_numpy()
                rows['prediction'] = values
                rows['baseline_prediction'] = fitted['baseline']
                rows['prior_prediction'] = fitted['prior_performance']
                rows['cohort'] = proxy
                rows['stage'] = stage
                rows['model'] = model
                predictions.append(rows)
                result = {'cohort': proxy, 'stage': stage, 'model': model,
                          'train_races': len(train), 'test_races': len(test),
                          'test_states': test.state_abbrev.nunique(),
                          'test_years': ','.join(map(str, sorted(test.year.unique()))),
                          'retrospective_proxy': proxy == 'endorsement'}
                result.update(scores(rows.actual, rows.prediction))
                for reference in ['baseline', 'prior']:
                    refcol = reference + '_prediction'
                    result[f'mae_gain_vs_{reference}_pp'] = (
                        scores(rows.actual, rows[refcol])['mae_pp'] - result['mae_pp'])
                    compared = rows.copy()
                    compared['baseline_prediction'] = rows[refcol]
                    low, high = paired_uncertainty(compared)
                    result[f'mae_gain_vs_{reference}_low95'] = low
                    result[f'mae_gain_vs_{reference}_high95'] = high
                output.append(result)
    table = pd.DataFrame(output)
    table.to_csv(BASE / 'results/matched_proxy_metrics.csv', index=False)
    pd.concat(predictions, ignore_index=True).to_csv(BASE / 'results/matched_proxy_predictions.csv', index=False)
    (BASE / 'results/matched_proxy_protocol.json').write_text(json.dumps({
        'purpose': 'Pure prior-performance comparison against experience or endorsements on identical eligible fitting and evaluation rows.',
        'estimator': 'Existing benchmark.predict; OLS, training-only scaling, predictions clipped to [0,1]. No tuning or model selection.',
        'split': 'Fit through 2008 for 2010-2014 development; fit through 2014 for 2016-2022 test.',
        'caveats': ['Endorsement scores are future-calibrated retrospective measurements.',
                    'Experience test coverage contains only 2016.',
                    'States are bootstrapped over fixed paired evaluation errors; intervals exclude model fitting and model selection uncertainty.',
                    'This is own-vote prediction, not causal coattails.']
    }, indent=2))
    print(table[['cohort', 'stage', 'model', 'train_races', 'test_races', 'mae_pp', 'mae_gain_vs_prior_pp', 'mae_gain_vs_prior_low95', 'mae_gain_vs_prior_high95']].to_string(index=False))


if __name__ == '__main__':
    main()
