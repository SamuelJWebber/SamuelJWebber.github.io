from pathlib import Path
import json,hashlib,collections,re,unicodedata,csv,math
R=Path(__file__).parent;draws=json.load(open(R/'draws.json'));panel=json.load(open(R/'outcome_panel.json'))['rows'];res=json.load(open(R/'pilot_results_final.json'))
def norm(x):return re.sub('[^a-z0-9]','',unicodedata.normalize('NFKD',x).encode('ascii','ignore').decode().lower())
def tok(x):return set(re.findall('[a-z]+',unicodedata.normalize('NFKD',x).encode('ascii','ignore').decode().lower()))-{'hon','rt','dr','sir','dame'}
def nameparts(x):
 surname=x.split(',')[0] if ',' in x else ('van de Molen' if x.endswith('van de Molen') else x.split()[-1]);ts=tok(x.split(',',1)[1] if ',' in x else x[:-len(surname)])
 aliases={'jim':'james','chris':'christopher','matt':'matthew','tim':'timothy','nicky':'nicola','nikki':'nicola','jacqui':'jacqueline','kris':'kristopher','phil':'philip','jenny':'jennifer','ginny':'virginia','jo':'anne','steph':'stephanie','greg':'gregory','winnie':'winifred'}
 return norm(surname),ts|{aliases[x] for x in ts if x in aliases}
def matches(a,b):
 sa,ta=nameparts(a);sb,tb=nameparts(b)
 return sa==sb and bool(ta&tb)
# Use each cohort's observed source name for later-exposure matching; no outcome filtering.
later=[]
for r in [x for x in panel if x['primary']]:
 events=[]
 for d in draws:
  if r['draw_date']<d['date']<f"{r['following_year']}-01-01":
   for w in d['main_winners']:
    if matches(r['member'],w['member']):events.append({'date':d['date'],'member_as_reported':w['member'],'source':d['url']})
 later.append({'draw_date':r['draw_date'],'member':r['member'],'initial_selected':r['selected'],'known_later_main_wins':events})
(R/'later_lottery_exposure_audit.json').write_text(json.dumps({'records':later,'warning':'Lower bound from the incomplete recovered archive only; excludes follow-up election calendar year conservatively. Never used to select or adjust the analysis cohort.'},ensure_ascii=False,indent=2))
checks={}
checks['seven_original_replication_checksums_match']=json.load(open(R/'fleming_reproduction_status.json'))['all_original_published_md5_checks_pass']
checks['90_unique_draw_dates']=len(draws)==len({d['date'] for d in draws})==90
checks['5871_roster_entries']=sum(len(d['entrants']) for d in draws)==5871
checks['235_main_winners']=sum(len(d['main_winners']) for d in draws)==235
checks['all_source_html_cached']=all((R/d['raw_html']).exists() for d in draws)
checks['winner_ids_present_in_every_nonflagged_draw']=all(all(w['ballot_id'] in {e['ballot_id'] for e in d['entrants']} for w in d['main_winners']) for d in draws if d['probability'])
checks['no_bill_title_in_member_fields']=not any(' Bill' in e['member'] or ' Amendment' in e['member'] for d in draws for e in d['entrants'])
checks['all_primary_outcomes_joined']=len([r for r in panel if r['primary']])==74
checks['five_primary_treated']=sum(r['selected'] for r in panel if r['primary'])==5
checks['frozen_cohort_sha256_unchanged']=hashlib.sha256((R/'baseline_cohorts_before_outcomes.json').read_bytes()).hexdigest()==json.load(open(R/'cohort_freeze.json'))['sha256']
checks['exact_assignments_enumerated']=sum(x['possible_assignments'] for x in res['per_draw'])==74953
checks['all_primary_stages_unambiguous']=all(d['probability'] and d['probability']['type']=='single_stage' for d in draws if d['date'] in [x['draw_date'] for x in res['per_draw']])
assert all(checks.values()),checks
report={'checks':checks,'known_later_wins_among_initial_controls':sum(not r['initial_selected'] and bool(r['known_later_main_wins']) for r in later),'initial_controls':69,'known_later_wins_among_initial_treated':sum(r['initial_selected'] and bool(r['known_later_main_wins']) for r in later),'note':'No later exposure is used as a conditioning variable.'}
(R/'validation.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
# Keep a compact artifact for the parent dashboard.
compact=[]
for d in draws:
 compact.append({'date':d['date'],'url':d['url'],'roster_n':len(d['entrants']),'entries':[[r['ballot_id'],r['member']] for r in d['entrants']],'main_winners':[[r['ballot_id'],r['member']] for r in d['main_winners']],'preliminary_winners':[[r['ballot_id'],r['member']] for r in d['preliminary_winners']],'withdrawn':d['withdrawn'],'probability':d['probability'],'flags':d['flags']})
(R/'draws_compact.json').write_text(json.dumps(compact,ensure_ascii=False,separators=(',',':')))
# Hash every saved input/code/output except this manifest.
manifest=[]
for p in sorted(R.rglob('*')):
 if p.is_file() and p.name!='manifest_sha256.json':manifest.append({'path':str(p.relative_to(R)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(R/'manifest_sha256.json').write_text(json.dumps(manifest,indent=2));print('manifest_files',len(manifest),'compact_bytes',(R/'draws_compact.json').stat().st_size)
