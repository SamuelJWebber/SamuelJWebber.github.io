# New Zealand exploratory lottery analysis plan

Frozen before constructing the full electoral outcome panel, 2026-11-06. This is a within-session analysis specification, not an external preregistration. Several published winner examples were inspected before this plan.

Treatment is selection in one members' bill lottery, not innate candidate quality. The primary estimand is a local same-party ballot spillover from a randomly assigned legislative opportunity, among baseline electorate MPs who entered the selected lottery.

Select the earliest indexed draw after each preceding general election in the recovered archive. Select dates from archive metadata, before election outcomes are joined. Restrict the primary analysis to parliamentary terms without an intervening electorate redistribution: 2008 to 2011, 2014 to 2017, and 2020 to 2023. The 2011 to 2014 and 2017 to 2020 terms may be shown as a sensitivity analysis with the changed-boundary limitation, not pooled silently.

Map entrants to the electorate and party they won at the preceding general election, using official results. This baseline-defined cohort excludes list-only MPs and later by-election entrants. Verify any party affiliation change between that election and the selected draw; hold ambiguous mappings aside without reference to subsequent outcomes. Keep entrants whether or not they subsequently rerun, switch party, retire, or win again. Follow the baseline party in the baseline named electorate at the subsequent general election. Do not condition on later bill-lottery entry or eventual success.

Use every winner and loser in each original lottery risk set when simulating assignment, even when some lack electorate outcomes. Hold draws with unresolved eligibility, missing winners, or unresolved duplicate IDs outside the primary analysis. Account explicitly for preliminary lotteries. No individual-level or draw-entry pseudo-replication.

Primary observed outcome: change in baseline-party votes divided by the baseline election's valid party votes in that electorate. This fixed preassignment scale preserves increases through turnout and persuasion but is not turnout per eligible resident. Secondary outcomes: subsequent party-vote share, change in party-vote share, total party ballots per baseline total ballots, and the entrant's own candidate vote where available as a descriptive mechanism check only. Do not adjust for posttreatment turnout or condition on survey voters.

Estimator: equal-MP Horvitz-Thompson difference using known draw probabilities; report the number of distinct draw events, eligible MPs, and treated eligible MPs. Randomization test under the sharp null of no effects, drawing the exact observed number of winners from each full risk set, with fixed outcomes and cohort. A randomization p-value does not solve candidate/party interference or identify innate talent. Report very weak precision and any effect estimate only if assignments and joins pass the audit. Do not interpret multiple years for one MP as independent evidence.

National party spillovers are outside the local differential estimand. Bill policy can directly affect party support, so lottery assignment cannot serve as an exclusion-valid instrument for pure candidate charisma. MMP list seats require separate seat allocation modeling. No estimate here should be described as the effect of an Obama-quality candidate.

## Inference correction after the initial outcome join

The initial pooled fixed-roster permutation test was computed, then replaced after a design audit: future historical risk sets may depend on earlier assignments. Final inference enumerates all assignments within each selected draw separately, then uses Bonferroni to combine three exact p-values without independence. The weighted point summary remains descriptive of these conditional experiments. This correction was made before examining the separate draw p-values; the earlier pooled output is retained under audit_superseded and is not used in the report.
