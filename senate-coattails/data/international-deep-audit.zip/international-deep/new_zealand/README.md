# New Zealand lottery coattails data and exploratory pilot

This package contains an actual recovered lottery dataset and an executed next-election party-vote pilot. It does **not** estimate the effect of innate candidate talent or an all-star candidate.

The official Parliament archive yielded 90 indexed draw documents, dated 24 September 2009 through 8 December 2022. The parser recovered 5,871 named entrant rows, 235 main-winner records, two preliminary-winner records and six withdrawn placeholders. These are repeated participation records, not independent people or experiments. The archive has conspicuous gaps, including 2011 and most of 2014, so absence from this extract does not establish that no draw occurred.

## What was estimated

The treatment is selection in an early members' bill lottery. The outcome is the next general election's baseline-party votes in the entrant's baseline electorate, including changes through both turnout and persuasion. The primary scale is the change in party votes per 100 valid party votes at the baseline election. This denominator is fixed before assignment; it is not an estimate of turnout among eligible residents.

The cohort rule was written before the complete outcome panel was constructed. It chooses the earliest indexed draw in each parliamentary term and uses the three terms without intervening electorate-boundary changes. Eligible outcome units are MPs who won an electorate at the preceding general election and entered that draw. List-only MPs remain in the assignment risk set but do not receive invented local outcomes. Nobody is removed because of later retirement, party switching, failure to rerun, or another lottery win. An absent baseline party receives zero follow-up votes.

| Draw | Baseline to follow-up | All entrants / winners | Eligible MP-term units / treated | Primary HT effect | Exact two-sided p |
|---|---|---:|---:|---:|---:|
| 24 September 2009 | 2008 to 2011 | 33 / 1 | 12 / 1 | −17.457 | 0.273 |
| 19 March 2015 | 2014 to 2017 | 68 / 3 | 34 / 1 | +3.526 | 0.698 |
| 11 March 2021 | 2020 to 2023 | 54 / 3 | 28 / 3 | +1.442 | 0.971 |

Effects are party votes per 100 baseline valid party votes, not percentage-point changes in the subsequent party-vote share. Inverse-probability estimates can be unstable when very few winners are observed in the eligible subgroup.

There are **74 eligible MP-term units and five treated units across three draw events**. Their eligible-unit-weighted point summary is **−0.665** on the stated scale. The conservative Bonferroni combination of three exact randomization tests is **p = 0.818**. This is inconclusive, not evidence that coattails are zero. The tests enumerate all **74,953** within-draw possible assignments (33 + 50,116 + 24,804), keeping the original numbers of winners and including all entrants. Per-draw tests are combined without assuming independence across historical risk sets. No confidence interval for an average treatment effect is claimed; the saved sharp-null reference intervals are not effect confidence intervals.

The five treated eligible MPs are Nanaia Mahuta (2009), Meka Whaitiri (2015), and Terisa Ngobi, Matt Doocey and Todd Muller (2021). Their outcome rows and every control row are in outcome_panel.json. The two additional boundary-changing terms are joined for data auditing, with explicit name crosswalks, but excluded from primary estimation.

## Why this is not a talent estimate

Lottery selection changes legislative opportunity, publicity and potentially policy. It is not a measured increase in candidate appeal. Policy and party-brand effects prevent using it as an exclusion-valid instrument for pure charisma. The direct local effect also depends on assumptions about spillovers between MPs and electorates. The exact sharp null tested is that no choice of winners changes any measured outcome in the given experiment; a rejection would not uniquely identify a candidate-personality channel.

Later lotteries remain part of the next-election intention-to-treat contrast. At least **37 of 69 initial controls** are observed winning a later lottery in the recovered archive, even conservatively excluding the follow-up election's calendar year. One initially treated MP is observed winning again. These are lower bounds from an incomplete archive, not complete exposure histories. They are never used to remove or adjust units. Later opportunities can dilute or offset the original assignment contrast.

The result concerns a separate party ballot, which can help same-party list candidates in MMP. It does not measure a national party total, another district candidate's personal vote, or the number of list seats. MMP compensation requires a separate seat-allocation calculation.

## Source anomalies and probabilities

Eighty-five draws have structurally coherent single-stage risk sets; two have explicit preliminary lotteries; three retain unresolved source anomalies. A structural pass is not proof that every historical eligibility rule or source record has been independently verified.

- 10 February 2010: IDs 16 (Hone Harawira) and 29 (Mita Ririnui) compete in a preliminary lottery; 29 advances. There are 36 original proposals and 35 main-ballot entries. One main winner is selected. The disputed entrants' unconditional selection probability is 1/70; ordinary entrants' probability is 1/35.
- 20 September 2012: IDs 20 (Hone Harawira) and 22 (David Shearer) compete in a preliminary lottery; 20 advances. There are 68 original proposals and 67 main-ballot entries. Two main winners are selected. The disputed entrants' unconditional selection probability is 1/67; ordinary entrants' probability is 2/67.
- 11 May 2017: the source duplicates ID 3 where the ordered sequence would suggest 13. The original ID is preserved. No probability is assigned in the compact export.
- 12 December 2019: the roster lists 81 named proposals, omitting the two reported winner IDs 43 and 79. The union would contain 83, but that reconstructed denominator is not silently treated as verified.
- 2 July 2020: the text declares five available places but reports three winners. A withdrawn placeholder is also retained. Probability is unresolved.

The primary three draws have none of these anomalies and no preliminary stage.

## Files and reproduction

- draws.json: full structured extract, bill titles, source URLs and raw HTML hashes.
- draws_compact.json: all 90 records with IDs, names, winners, stage probabilities and flags, without bill titles.
- raw/: cached source HTML for 90 draw pages and five index pages.
- results_raw/: 18 official CSV downloads for six elections, covering party votes, turnout and elected candidates.
- results_sources.json: exact machine download URLs.
- baseline_cohorts_before_outcomes.json and cohort_freeze.json: baseline mappings and frozen content hash.
- outcome_panel.json: matched party-vote and turnout panel; no missing joins.
- pilot_results_final.json: authoritative final numerical results.
- later_lottery_exposure_audit.json: observed later treatment, explicitly not used for selection.
- validation.json and manifest_sha256.json: executed checks and file hashes.
- audit_superseded/: an initial pooled simulation retained for transparency; it is not used in the report because later historical risk sets may depend on earlier assignments.

Run, with requests, beautifulsoup4 and numpy installed:

```bash
python rebuild_archive.py
python fetch_results.py
python build_cohort.py
python build_outcome_panel.py
python exact_inference.py
python validate_and_document.py
```

The parser uses the actual HTML table shape rather than assuming all years share one column order. Baseline name matches use exact surnames plus explicit common-name aliases, and were manually inspected before outcome construction. No later election performance enters name matching.

## Published study and source provenance

Fleming, Thomas G., *Partisanship and the Effectiveness of Personal Vote Seeking*, Legislative Studies Quarterly 47(3), 505–538: https://onlinelibrary.wiley.com/doi/full/10.1111/lsq.12335 . Its actual replication dataset is **https://doi.org/10.7910/DVN/ADOPTC**. The previously associated DOI **10.7910/DVN/EYVIDZ** belongs to Williams and Indriðason's earlier *Luck of the Draw?* study, not Fleming's replication.

Fleming's New Zealand individual survey analysis studies voting for the MP, not the separate party-ballot coattail outcome. It conditions on rerunning in the same electorate/party and restricts draws, so its published personal-vote coefficients cannot simply be relabeled total party spillovers. The present pilot is a fresh official-record reconstruction, not a replication of those published coefficients.

Official draw archive: https://www3.parliament.nz/en/pb/bills-and-laws/members-bills-ballots-archive/ . Exact individual pages accompany every draw.

Official boundary sources: https://elections.nz/democracy-in-nz/historical-events/2014-electorate-boundaries and https://elections.nz/democracy-in-nz/historical-events/boundary-review-2019-2020 . The unchanged 2014/2017 and 2020/2023 boundaries are explicitly documented there.


## Completed published replication audit

All seven original Fleming files were retrieved and all seven published MD5 checks pass. Three Dataverse normalized TAB exports have different checksums from their original CSVs; requesting `?format=original` recovers the CSVs that match the published checksums. The package records both forms and the distinction.

Using the authors' filtering and model formulas, Python/statsmodels reproduces the four Table 1 bill-drawn log-odds coefficients and conventional standard errors:

| Model | N | Log-odds coefficient | Standard error |
|---|---:|---:|---:|
| All parties | 5,474 | 0.097782 | 0.056391 |
| Party fixed effects | 5,474 | 0.163507 | 0.060328 |
| Labour | 2,470 | 0.200939 | 0.088196 |
| National | 2,306 | 0.196189 | 0.097597 |

This verifies reproducibility of the published personal-vote result. It does not turn the coefficients into party-ballot coattails. The codebook confirms `voter.party` is party identification. The data provides neither a separate party-ballot outcome nor draw-by-draw entry risk sets. The published 102 MP-term file supplies cumulative attempts/draws, which cannot reconstruct exact sequential assignment probabilities by itself.

The public bundle includes source-fetching scripts and aggregate replication checks. It omits the original research files because their redistribution license was not independently verified. Run `fetch_fleming.py`, `download_fleming_files.py`, then `replicate_fleming.py` to retrieve and reproduce them from the public data-access endpoints. `fleming_reproduction_status.json` lists every exact download URL and original checksum.

This report's final inference is in `pilot_results_final.json`; no file under `audit_superseded` belongs in the public bundle.
