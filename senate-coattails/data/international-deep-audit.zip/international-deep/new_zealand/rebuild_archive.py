from pathlib import Path
import requests, bs4, re, json, hashlib, datetime, concurrent.futures, collections
BASE='https://www3.parliament.nz/en/pb/bills-and-laws/members-bills-ballots-archive/'
ROOT=Path(__file__).parent
RAW=ROOT/'raw';RAW.mkdir(exist_ok=True)
def fetch(url,stem):
 p=RAW/(stem+'.html')
 if p.exists():return p.read_text()
 for retry in range(3):
  try:
   r=requests.get(url,timeout=60);r.raise_for_status();p.write_text(r.text);return r.text
  except Exception:
   if retry==2:raise
urls=[]
for page in range(1,6):
 s=bs4.BeautifulSoup(fetch(BASE+('' if page==1 else '?page='+str(page)),f'index_{page}'),'html.parser')
 for a in s.find_all('a',href=True):
  u=requests.compat.urljoin(BASE,a['href'])
  if u.startswith(BASE) and len(u)>len(BASE) and '?' not in u and ('ballot-for-' in u or 'ballot-thursday' in u):
   if u not in urls:urls.append(u)
(ROOT/'archive_urls.json').write_text(json.dumps(urls,indent=2))
print('indexed',len(urls),flush=True)
def parse(u):
 stem=u.rstrip('/').split('/')[-1];html=fetch(u,stem);s=bs4.BeautifulSoup(html,'html.parser')
 text=s.get_text(' ',strip=True)
 dt=re.search(r'(?:Monday|Tuesday|Wednesday|Thursday|Friday),? (\d{1,2}) ([A-Za-z]+) (\d{4})',text)
 if not dt:raise ValueError('date '+u)
 date=datetime.datetime.strptime(' '.join(dt.groups()),'%d %B %Y').date().isoformat();modern=int(date[:4])>=2012
 d=dict(date=date,url=u,raw_html='raw/'+stem+'.html',raw_sha256=hashlib.sha256(html.encode()).hexdigest(),entrants=[],main_winners=[],preliminary_winners=[],withdrawn=[],stage_text=[],flags=[])
 mode=None
 for node in s.find_all(['p','h2','table']):
  if node.find_parent('table'):continue
  t=node.get_text(' ',strip=True)
  if node.name!='table':
   if re.search(r'Notices.*(?:proposal|intention).*received',t,re.I):mode='entrants'
   if re.search(r'preliminary ballot',t,re.I):mode='preliminary_winners';d['stage_text'].append(t)
   elif re.search(r'(?:main )?ballot was held.*following.*drawn',t,re.I):mode='main_winners'
   m=re.search(r'\b(one|two|three|four|five|six|seven|eight|nine) places? (?:are|were|is|was)? ?(?:available|on the Order Paper)',t,re.I)
   if m:d['slots_declared']={'one':1,'two':2,'three':3,'four':4,'five':5,'six':6,'seven':7,'eight':8,'nine':9}[m[1].lower()]
   continue
  if not mode:continue
  for tr in node.find_all('tr'):
   c=[x.get_text(' ',strip=True) for x in tr.find_all(['td','th'])]
   if not c or not re.fullmatch(r'\d+\.?',c[0]):continue
   n=int(c[0].rstrip('.'))
   if any('withdrawn' in x.lower() for x in c):d['withdrawn'].append([n,*c[1:]]);continue
   if len(c)>=4:member,bill=c[1]+', '+c[2],c[3]
   elif re.search(r'\bBill\b',c[2]):member,bill=c[1:3]
   elif modern:bill,member=c[1:3]
   else:member,bill=c[1:3]
   d[mode].append({'ballot_id':n,'member':member,'bill':bill})
 if not d['entrants']:d['flags'].append('no_entrants')
 if not d['main_winners']:d['flags'].append('no_main_winners')
 ids=[x['ballot_id'] for x in d['entrants']]
 if len(set(ids))!=len(ids):d['flags'].append('duplicate_source_id')
 if any(x['ballot_id'] not in ids for x in d['main_winners']):d['flags'].append('winner_omitted_from_roster')
 if d.get('slots_declared')!=len(d['main_winners']):d['flags'].append('slots_winners_disagree')
 if d['preliminary_winners']:d['flags'].append('preliminary_lottery')
 if d['withdrawn']:d['flags'].append('withdrawn_before_draw')
 n,k=len(ids),len(d['main_winners'])
 if any(x in d['flags'] for x in ('duplicate_source_id','winner_omitted_from_roster','slots_winners_disagree','no_entrants','no_main_winners')):d['probability']=None
 elif d['preliminary_winners']:
  group=[16,29] if date=='2010-02-10' else [20,22] if date=='2012-09-20' else None
  d['probability']={'type':'two_stage','group_ids':group,'preliminary_success':[1,2],'main_n':n-1,'main_k':k,'ordinary_before_preliminary':[k,n-1],'group_before_preliminary':[k,2*(n-1)]}
 else:d['probability']={'type':'single_stage','each':[k,n]}
 return d
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
 data=list(pool.map(parse,urls))
data.sort(key=lambda x:x['date'])
(ROOT/'draws.json').write_text(json.dumps(data,ensure_ascii=False,indent=2))
summary={'draws':len(data),'named_roster_entries':sum(len(d['entrants']) for d in data),'main_winner_records':sum(len(d['main_winners']) for d in data),'preliminary_winner_records':sum(len(d['preliminary_winners']) for d in data),'withdrawn_placeholders':sum(len(d['withdrawn']) for d in data),'single_stage_draws':sum(bool(d['probability']) and d['probability']['type']=='single_stage' for d in data),'two_stage_draws':sum(bool(d['probability']) and d['probability']['type']=='two_stage' for d in data),'unresolved_probability_draws':sum(d['probability'] is None for d in data)}
(ROOT/'archive_audit.json').write_text(json.dumps({'summary':summary,'flagged_draws':[{k:d[k] for k in ['date','flags','slots_declared']} for d in data if d['flags']]},indent=2))
print(json.dumps(summary),flush=True)
print([(d['date'],d['flags']) for d in data if d['flags']],flush=True)
