from pathlib import Path
import requests,concurrent.futures,json
root=Path(__file__).parent;raw=root/'results_raw';raw.mkdir(exist_ok=True)
jobs=[]
for year in [2008,2011,2014,2017,2020,2023]:
 for kind,old,new in [('parties','e9_part4','votes-for-registered-parties-by-electorate'),('turnout','e9_part9_1','party-votes-and-turnout-by-electorate'),('winners','e9_part6','winning-electorate-candidates')]:
  tail=f'e9/csv/{old}.csv' if year<2017 else f'statistics/csv/{new}.csv'
  jobs.append((year,kind,f'https://archive.electionresults.govt.nz/electionresults_{year}/{tail}'))
def get(job):
 year,kind,u=job;p=raw/f'{year}_{kind}.csv'
 if not p.exists():
  r=requests.get(u,timeout=60);r.raise_for_status();p.write_bytes(r.content)
 return {'year':year,'kind':kind,'url':u,'path':str(p),'bytes':p.stat().st_size}
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
 data=list(pool.map(get,jobs))
(root/'results_sources.json').write_text(json.dumps(data,indent=2))
for d in data:print(d['year'],d['kind'],d['bytes'])
