from pathlib import Path
import json,csv,re,unicodedata,numpy as np,hashlib
ROOT=Path(__file__).parent
def norm(x):return re.sub('[^a-z0-9]','',unicodedata.normalize('NFKD',x).encode('ascii','ignore').decode().lower())
def read(y,k):return list(csv.reader((ROOT/'results_raw'/f'{y}_{k}.csv').read_text(encoding='utf-8-sig').splitlines()))
def partydata(y):
 rows=read(y,'parties');header=rows[1];out={}
 for row in rows[2:]:
  if len(row)!=len(header) or not row[1].isdigit():continue
  out[norm(row[0])]={norm(k):int(v) for k,v in zip(header[1:],row[1:])}
 return out,header

def turnoutdata(y):
 rows=read(y,'turnout');out={}
 for row in rows[5:]:
  if len(row)<12 or not row[1].isdigit():continue
  out[norm(row[0])]=dict(valid=int(row[3]),informal=int(row[6]),votes_cast_including_disallowed=int(row[9]),master_roll=int(row[10]),electoral_population=int(row[11]))
 return out
cohorts=json.load(open(ROOT/'baseline_cohorts_before_outcomes.json'))['cohorts'];panel=[];unmatched=[]
renames={'rimutaka':'remutaka','dunedinnorth':'dunedin','dunedinsouth':'taieri','cluthasouthland':'southland','helensville':'kaiparakimahurangi','rodney':'whangaparaoa','hunua':'portwaikato','porthills':'bankspeninsula'}
for d in cohorts:
 b,f=d['baseline_year'],d['following_year'];pb,hb=partydata(b);pf,hf=partydata(f);tb=turnoutdata(b);tf=turnoutdata(f)
 for r in d['rows']:
  if 'excluded_reason' in r:continue
  e=norm(r['baseline_electorate']);ef=e if e in pf else renames.get(e,e)
  if e not in pb or ef not in pf:unmatched.append([d['date'],r['member'],e,ef]);continue
  p=norm(r['baseline_party']);pnext='tepatimaori' if p=='maoriparty' and f==2023 else p
  bv=pb[e].get(p,0);fv=pf[ef].get(pnext,0);bt=pb[e]['totalvalidpartyvotes'];ft=pf[ef]['totalvalidpartyvotes']
  assert bt==tb[e]['valid'] and ft==tf[ef]['valid']
  panel.append({**r,'draw_date':d['date'],'baseline_year':b,'following_year':f,'primary':d['primary'],'risk_set_n':d['risk_set_n'],'main_k':d['main_k'],'p':d['main_k']/d['risk_set_n'],'outcome_electorate_key':ef,'party_absent_next_election':pnext not in pf[ef],'baseline_party_votes':bv,'following_party_votes':fv,'baseline_valid_party_votes':bt,'following_valid_party_votes':ft,'baseline_turnout':tb[e],'following_turnout':tf[ef],'vote_change_per_baseline_valid_pp':100*(fv-bv)/bt,'next_party_share_pp':100*fv/ft,'party_share_change_pp':100*(fv/ft-bv/bt),'ballots_cast_per_baseline_cast_change_pp':100*(tf[ef]['votes_cast_including_disallowed']/tb[e]['votes_cast_including_disallowed']-1),'draw_source':d['url']})
(ROOT/'outcome_panel.json').write_text(json.dumps({'rows':panel,'unmatched':unmatched},ensure_ascii=False,indent=2))
print('Joined outcome rows:',len(panel),'unmatched:',len(unmatched))
