import requests,json,concurrent.futures
from pathlib import Path
root=Path(__file__).parent/'fleming_replication';root.mkdir(exist_ok=True)
urls={
 'version':'https://dataverse.harvard.edu/api/datasets/4304035/versions/1.0',
 'export':'https://dataverse.harvard.edu/api/datasets/export?exporter=dataverse_json&persistentId=doi:10.7910/DVN/ADOPTC',
 'file_search':'https://dataverse.harvard.edu/api/search?q=parentId:4304035&type=file&per_page=100',
 'html':'https://dataverse.harvard.edu/dataset.xhtml?persistentId=doi:10.7910/DVN/ADOPTC'
}
def get(item):
 k,u=item;r=requests.get(u,timeout=45);(root/(k+'.txt')).write_text(r.text)
 return k,r.status_code,len(r.content),r.text[:150]
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as p:
 for x in p.map(get,urls.items()):print(x,flush=True)
