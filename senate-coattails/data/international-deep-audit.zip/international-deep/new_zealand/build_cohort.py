from pathlib import Path
import json,csv,re,unicodedata,collections
root=Path(__file__).parent
def norm(x):return re.sub('[^a-z0-9]','',unicodedata.normalize('NFKD',x).encode('ascii','ignore').decode().lower())
def tokens(x):return set(re.findall('[a-z]+',unicodedata.normalize('NFKD',x).encode('ascii','ignore').decode().lower()))-{'hon','rt','dr','sir','dame'}
def readrows(y,k):return list(csv.reader((root/'results_raw'/f'{y}_{k}.csv').read_text(encoding='utf-8-sig').splitlines()))
draws=json.load(open(root/'draws.json'));cohorts=[];ambiguous=[]
for baseline,following,primary in [(2008,2011,True),(2011,2014,False),(2014,2017,True),(2017,2020,False),(2020,2023,True)]:
 d=next(d for d in draws if baseline<int(d['date'][:4])<following)
 winners=[dict(electorate=r[0],candidate=r[1],party=r[2],candidate_votes=int(r[3])) for r in readrows(baseline,'winners')[2:] if len(r)>3 and r[3].isdigit()]
 cohort=[]
 for ordinal,e in enumerate(d['entrants']):
  name=e['member'];ename=norm(name);ts=tokens(name)
  aliases={'jim':'james','chris':'christopher','matt':'matthew','tim':'timothy','nicky':'nicola','nikki':'nicola','jacqui':'jacqueline','kris':'kristopher','phil':'philip','jenny':'jennifer','ginny':'virginia','jo':'anne','steph':'stephanie','greg':'gregory','winnie':'winifred'}
  ts=ts|{aliases[x] for x in ts if x in aliases}
  surname=name.split(',')[0].strip() if ',' in name else ('van de Molen' if name.endswith('van de Molen') else name.split()[-1])
  if name=='Steph Lewis':surname='LEWIS CARR'
  possible=[w for w in winners if norm(w['candidate'].split(',')[0])==norm(surname) and len(ts&tokens(w['candidate'].split(',')[-1]))>0]
  if len(possible)==1:
   w=possible[0];cohort.append(dict(row_ordinal=ordinal,ballot_id=e['ballot_id'],member=name,baseline_electorate=w['electorate'],baseline_candidate=w['candidate'],baseline_party=w['party'],selected=e['ballot_id'] in [x['ballot_id'] for x in d['main_winners']]))
  elif len(possible)>1:ambiguous.append(dict(date=d['date'],member=name,candidates=possible))
  else:cohort.append(dict(row_ordinal=ordinal,ballot_id=e['ballot_id'],member=name,excluded_reason='No preceding-general-election electorate winner match',selected=e['ballot_id'] in [x['ballot_id'] for x in d['main_winners']]))
 cohorts.append(dict(baseline_year=baseline,following_year=following,primary=primary,date=d['date'],url=d['url'],risk_set_n=len(d['entrants']),main_k=len(d['main_winners']),probability=d['probability'],rows=cohort))
(root/'baseline_cohorts_before_outcomes.json').write_text(json.dumps({'cohorts':cohorts,'ambiguous':ambiguous},ensure_ascii=False,indent=2))
for d in cohorts:
 eligible=[r for r in d['rows'] if 'excluded_reason' not in r]
 print(d['date'],'n',d['risk_set_n'],'k',d['main_k'],'eligible',len(eligible),'treated',[r['member'] for r in eligible if r['selected']])
 print('EXCLUDED',[(r['member'],r['selected']) for r in d['rows'] if 'excluded_reason' in r])
 print('MAPPED',[(r['member'],r['baseline_candidate'],r['baseline_party'],r['baseline_electorate']) for r in eligible])
print('AMBIGUOUS',ambiguous)
