from pathlib import Path
import requests,json,hashlib,concurrent.futures
import pandas as pd,statsmodels.formula.api as smf,statsmodels.api as sm
r=Path(__file__).parent/'fleming_replication';items=json.load(open(r/'file_search.txt'))['data']['items']
def original(x):
 z=requests.get(x['url']+'?format=original',timeout=45);name=x['name'].replace('.tab','.csv');(r/name).write_bytes(z.content)
 return {'name':name,'status':z.status_code,'bytes':len(z.content),'md5':hashlib.md5(z.content).hexdigest(),'expected_md5':x['md5'],'matches':hashlib.md5(z.content).hexdigest()==x['md5']}
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:originals=list(pool.map(original,[x for x in items if x['name'].endswith('.tab')]))
(r/'original_download_audit.json').write_text(json.dumps(originals,indent=2))
d=pd.read_csv(r/'study1_analysis_data.tab',sep='\t');d.columns=[x.replace('.','_') for x in d.columns]
d=d[(d.attempts>0)&(d.standing=='yes')&(d.drawn!=2)]
models=[]
for label,formula,part in [('All parties','supported_MP ~ drawn + attempts + C(surveyyear)',None),('Party fixed effects','supported_MP ~ drawn + attempts + C(MP_party) + C(surveyyear)',None),('Labour','supported_MP ~ drawn + attempts + C(surveyyear)','labour'),('National','supported_MP ~ drawn + attempts + C(surveyyear)','national')]:
 x=d if part is None else d[d.MP_party==part]
 m=smf.glm(formula,data=x,family=sm.families.Binomial()).fit()
 models.append({'model':label,'n':int(m.nobs),'drawn_log_odds':float(m.params['drawn']),'standard_error_as_published_conventional':float(m.bse['drawn']),'p_as_published_conventional':float(m.pvalues['drawn'])})
summary={'doi':'10.7910/DVN/ADOPTC','study1_raw_rows':18599,'study1_variables':13,'randomization_rows':102,'years':sorted(int(x) for x in d.surveyyear.unique()),'models':models,'important':'voter.party is PARTY IDENTIFICATION, not party-ballot choice. No separate party-vote outcome or draw-level risk sets is in these seven replication files. Coefficients are log odds, not percentage-point coattails. Models reproduce published rerun and eventual-entry conditioning; these are not a new causally improved specification.','original_format_hash_checks':originals}
(r/'replication_audit.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
