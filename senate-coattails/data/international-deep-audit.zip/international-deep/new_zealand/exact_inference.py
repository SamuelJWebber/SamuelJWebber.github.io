from pathlib import Path
import json,itertools,math,numpy as np
R=Path(__file__).parent
panel=json.load(open(R/'outcome_panel.json'))['rows'];cohorts=json.load(open(R/'baseline_cohorts_before_outcomes.json'))['cohorts']
fields=['vote_change_per_baseline_valid_pp','next_party_share_pp','party_share_change_pp','ballots_cast_per_baseline_cast_change_pp'];perdraw=[]
for d in [x for x in cohorts if x['primary']]:
 rows=[r for r in panel if r['draw_date']==d['date']];n,k=d['risk_set_n'],d['main_k'];p=k/n;N=len(rows)
 y=np.zeros((n,len(fields)));z=np.zeros(n)
 for r in rows:y[r['row_ordinal']]=[r[f] for f in fields];z[r['row_ordinal']]=r['selected']
 ids=np.array(list(itertools.combinations(range(n),k)),dtype=int);picked=y[ids].sum(axis=1)
 sim=(picked/p-(y.sum(axis=0)-picked)/(1-p))/N
 assert np.max(np.abs(sim.mean(axis=0)))<1e-9, 'Sharp-null enumeration must be centered at zero'
 obs=(y[z.astype(bool)].sum(axis=0)/p-y[~z.astype(bool)].sum(axis=0)/(1-p))/N
 out={'draw_date':d['date'],'baseline_year':d['baseline_year'],'following_year':d['following_year'],'full_risk_set_n':n,'main_k':k,'eligible_units':N,'eligible_treated':int(z.sum()),'possible_assignments':math.comb(n,k),'exact_enumeration':True,'results':{}}
 for j,f in enumerate(fields):out['results'][f]={'ht_effect_pp':float(obs[j]),'sharp_null_p_two_sided':float(np.mean(np.abs(sim[:,j])>=abs(obs[j])-1e-12)),'sharp_null_reference_interval_95':[float(x) for x in np.quantile(sim[:,j],[.025,.975])],'reference_interval_is_not_confidence_interval':True}
 perdraw.append(out)
pooled={}
for f in fields:
 pooled[f]={'weighted_point_summary_pp':sum(x['eligible_units']*x['results'][f]['ht_effect_pp'] for x in perdraw)/sum(x['eligible_units'] for x in perdraw),'bonferroni_global_sharp_null_p':min(1.0,len(perdraw)*min(x['results'][f]['sharp_null_p_two_sided'] for x in perdraw)),'pooled_independent_roster_permutation_test_used':False}
res={'status':'exploratory randomization pilot; inconclusive for coattails','estimand':'Next-general-election local baseline-party vote effect of one random legislative opportunity, with later lotteries allowed. Not measured candidate appeal or intrinsic talent.','primary_outcome':'Change in baseline-party votes per 100 valid baseline-election party votes in the same electorate','draw_events':3,'eligible_mp_term_units':74,'treated_eligible_mp_term_units':5,'full_risk_set_entries':155,'per_draw':perdraw,'summary':pooled,'inference_notes':['Exact within-draw assignment enumeration uses every roster entrant, including list-only MPs outside the outcome cohort.','Per-draw sharp null: no choice of winners changes any measured eligible-electorate outcome.','Bonferroni combination is conservative and does not assume independence across historical risk sets.','Weighted point summary has no effect confidence interval here; null reference intervals are not effect uncertainty intervals.','Per-draw direct-effect interpretation requires assumptions about cross-electorate and same-party interference; national spillovers are not identified.','Control MPs may win later lotteries; do not exclude them. The contrast is next-election ITT for one early draw, potentially diluted or offset by later exposure.','Selection changes legislative opportunities, policy and publicity. It does not experimentally manipulate a measured candidate-quality score.','The archive is incomplete. Earliest indexed draws are a reproducible cohort rule, not necessarily each terms first actual draw.','Cohort follows baseline party even if a candidate retires, changes party, or does not rerun. A party absent at follow-up receives zero votes.','Outcomes are party-ballot spillovers; MMP compensation and list-seat allocation are not estimated.']}
(R/'pilot_results_final.json').write_text(json.dumps(res,ensure_ascii=False,indent=2));print(json.dumps(res,ensure_ascii=False,indent=2))
