from pathlib import Path
import requests,json,concurrent.futures,hashlib
r=Path(__file__).parent/'fleming_replication';items=json.load(open(r/'file_search.txt'))['data']['items']
def get(x):
 z=requests.get(x['url'],timeout=45);p=r/x['name']
 if z.status_code==200:p.write_bytes(z.content)
 return {'name':x['name'],'url':x['url'],'status':z.status_code,'bytes':len(z.content),'saved':p.exists(),'md5':hashlib.md5(z.content).hexdigest(),'expected_md5':x['md5']}
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as p:
 results=list(p.map(get,items))
(r/'download_audit.json').write_text(json.dumps(results,indent=2));print(json.dumps(results,indent=2))
