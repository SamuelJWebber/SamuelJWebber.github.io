# Candidate coattails: extended evidence audit

Prepared for Samuel Webber. Updated November 6, 2026.

The target is the effect on other same-party candidates when a party nominates a candidate with greater support before the nomination, allowing the ensuing campaign to mobilize and persuade. The interventions below remain separate. There is no pooled international “all-star” coefficient.

## What would identify the target?

The ideal experiment assigns one of two nominees to otherwise comparable constituencies, then counts votes for other candidates on independently voted ballots. A close decisive nomination is a possible historical approximation. Define the contender trait before looking at teammate outcomes; orient the vote margin toward that contender; compare its narrow victories with its narrow defeats. Nomination assignment, not subtraction of the previous election, supplies the identifying variation.

A donor-rich nominee is a legitimate treatment definition without proving donations measure innate talent. Calling that treatment “charisma” or “all-star quality” requires separate validation against independent appeal. Unique people, contribution receipts and dollars are different measurements. Race competitiveness can affect all three. Within-race ranking and pre-treatment covariates help define the comparison but do not make the proxy a universal talent scale.

The principal outcome should be teammate votes divided by a fixed pre-assignment electorate or population. Report vote share and turnout as complementary outcomes. A fixed earlier valid-vote denominator also retains turnout effects, although it is not an eligible-voter rate. Avoid conditioning on later fundraising, turnout, rerunning, party switching or rival entry: these can be consequences of the assignment. A treatment-induced change in who runs for council is part of the candidate package; it cannot simply be dropped to obtain a preferred answer.

## Executed work and scope

The country folders contain scripts, provenance and machine-readable results. The dashboard ledger in `../../dist/data/international-deep.json` gives the current counts, findings, failed checks and outstanding requirements. See each folder's README for commands and source-specific qualifications.

* **United States:** a new official-primary/experience comparison is distinguished from the existing Senate donor study. Independent appeal measurement and donor interpretation are audited separately from assignment.
* **Argentina:** the 75 close mayoral-list primaries now have candidate identity and separate provincial-outcome joins. A concrete previous-election-winner trait is tested for coverage. Missing identities and insufficient discordant pairs remain visible.
* **Chile:** official primary candidates, finance records and separate council outcomes are joined; older primary cycles expand the available nomination pool. All 202 contests now join to general outcomes, and six close 2016 contests have distinguishable observed donor-ID counts. Anonymous and missing contributor information prevents treating raw worksheet counts as unique donors.
* **New Zealand:** official parliamentary bill-draw rosters are reconstructed and joined to separate party ballots. This is random opportunity assignment, not random candidate talent; the independent pilot is small and interference remains a concern.
* **Germany:** the published election-concurrency baseline is extended to controls, placebos and trend diagnostics. A separate constituency-incumbency reconstruction and two nomination examples are labeled exploratory. Restricted nomination data have not been acquired under a contract.
* **Spain:** the deposited party-ban analysis is translated to Python, including municipality aggregation and municipality-clustered uncertainty. It studies party availability, and its support measure includes invalid ballots. Additional entropy balancing and parallel-trend sensitivity are tracked in the country report.
* **Brazil:** official council results and historical audit-draw rosters are assembled. The official draw roster does not exactly reproduce the published disclosure roster. No causal effect is manufactured from that mismatch.

## Main empirical findings

| Comparison | Executed result | Interpretation |
| --- | --- | --- |
| US prior-office nomination, 24 contests | +5.08 pp; 95% interval −40.40 to +50.57 | Imprecise and unstable; party-balance concern |
| US money-ranked matched sample, 38 contests | Current −17.69 pp; prior −16.99 pp; change −0.70 pp [−5.24, +3.83] | Preexisting partisan differences explain the apparent association; diagnostic only |
| Chile, six reported-donor contrasts | Three higher-donor wins, three losses; descriptive difference −4.26 pp | Coverage, cutoff and coalition checks prevent causal interpretation |
| New Zealand early bill opportunity | −0.665 party votes per 100 baseline valid votes; conservative exact-test p=.818 | 74 eligible units, five treated; inconclusive |
| Germany election concurrency | Turnout +3.03 pp; incumbent-party council share +0.95 pp | Reproduced timing benchmark; auxiliary diagnostics qualify inference |
| Spain selective party bans | Baseline/adjusted support ratios .274/.315; entropy-weighted .397/.401 | Different specifications; reduced-form sensitivity can include zero |
| Argentina prior-winner contrast | Three discordant close pairs | Too little support to fit a meaningful effect |
| Brazil audit disclosure | 56,948 council-party outcomes; recovered roster 670 towns versus published 669 | Assignment roster and timing not validated; no effect fitted |

For exact denominators, model definitions, source differences and uncertainty, use `study_ledger.json` and the country reports. These rows are not estimates of a common treatment. The apparent number of observations cannot be added across them as one causal sample.

## Inference and validation rules

Count independent nominations or lottery assignments rather than precincts, transactions or repeated MP entries. Close nominations require the actual decisive round, exact vote totals where available, continuity/balance checks, bandwidth sensitivity and an appropriate dependence structure. Multi-candidate contests and party coalitions require explicit handling. A narrow observed margin alone does not establish random assignment.

Randomization tests require the actual lottery risk set and allocation mechanism. A null randomization reference interval is not a confidence interval for the treatment effect. Later risk sets may depend on earlier treatment; per-draw inference avoids treating a long panel of selected entrants as independent fixed cohorts. National party spillovers can violate the no-interference assumption even within a lottery.

Predictive validation is a separate task. Choose between donors, polls, endorsements, attendance or attention measures using held-out independent appeal, with all candidates and surveys in one contest in the same fold. Do not choose the quality measure because it maximizes teammate lift. Historical rally attendance and YouTube views have no verified complete comparable pre-nomination panel here; paid impressions and platform changes add further measurement problems. Becoming president is a future outcome, not an admissible pre-nomination quality label for this analysis.

For retrospective research, records of pre-nomination events may be published later if their measurement is not itself affected by nomination success. A real-time prediction claim additionally needs the information's historical public-release vintage. These are distinct requirements.

## Corrections to the earlier release

1. The New Zealand DOI `10.7910/DVN/EYVIDZ` belongs to Williams and Indridason's *Luck of the Draw*, not the Fleming paper. The correct Fleming deposit is `10.7910/DVN/ADOPTC`; all seven files were subsequently recovered and its own-candidate-vote Table 1 reproduced. Its `voter.party` variable measures party identification, not a separate party-ballot outcome.
2. Chile's 2024 workbooks contain 6,230 finance records and 944 transfer records after excluding headers/blanks; 6,239 and 952 were worksheet row counts.
3. The German baseline CR1 finite-sample correction now includes the common intercept to match Stata 15's `xtreg, fe vce(cluster)` convention. Independent Python validation matches all eight printed standard errors in the official manual example. Rounded headline estimates are unchanged. This was not execution in Stata.
4. Reproduction of published coefficients is not verification of causal assumptions. Some newly clustered German auxiliary trend tests reject zero interactions; they are reported alongside the published specifications and the true pre-treatment tests.
5. The US 2008 presidential district variable has a different vote-share construction from later presidential years. It cannot silently enter a uniform two-party-share analysis.

## Public release boundary

No individual contributor identities, restricted GLES data, private Pages, credentials, raw DeLuca source files or row-level derivatives containing DeLuca outcomes are included. Files whose redistribution permission is unclear are represented by source URLs, retrieval scripts and hashes. Derived candidate/election facts and aggregate model outputs are provided with attribution. The previous Senate donor study and its original frozen protocol remain separately available.

The audit records genuine access, sample-size and measurement blockers. It does not certify that every historical candidate or possible international design has been exhausted. No external researchers were contacted and no data-access agreement was accepted.
