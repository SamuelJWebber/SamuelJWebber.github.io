# House nominee coattail audit

This pipeline was executed on 6 November 2026. It joins official FEC House primary vote totals to named candidate attributes in Danielle Thomsen's 2025 replication, then measures the party's concurrent presidential vote within the same district. The design and outcome checks were frozen before joining candidate attributes to outcomes. The present data do not support a defensible all-star coattail number.

## Results

| Contrast | Main sample | Estimate | 95% state-cluster interval | Interpretation |
|---|---:|---:|---:|---|
| Prior elected office versus no prior elected office | 24 nominations, 15 states | +5.08 percentage points | −40.40 to +50.57 | Too imprecise; bandwidth sensitivity and party balance also fail |
| Higher versus lower first-report receipts | 64 nominations, 22 states | −8.75 percentage points | −16.53 to −0.96 | Conditional diagnostic only: source lacks report dates and prior-party balance fails |

The second result should not be presented as negative causal coattails. In the same 38 nominations with a usable prior presidential outcome, the current-election contrast is −17.69 points and the already-existing contrast is −16.99 points. The difference is −0.70 points, with an interval from −5.24 to +3.83. This matched-sample difference is a post-fit diagnostic, not a new primary model chosen to rescue identification.

The experience result changes from +18.75 points at a 2.5-point primary bandwidth to −4.01 at 10 points, with very wide intervals throughout. A nominal party-balance failure also cautions against interpreting a small-sample threshold estimate as a reliable causal quantity. This is not evidence of zero coattails.

## What was actually assembled

* Four official FEC primary workbooks: 2008, 2012, 2016, 2020. Named candidates, exact primary votes, IDs, primary winner and runner-up are reconstructed directly. Affiliate/fusion party labels and within-party write-ins are handled; unnamed total rows are excluded. Mixed repeated candidate groups are flagged rather than treated as one primary.
* Thomsen 2025 named candidate data: 26,617 rows, prior elected office and first-report fundraising measures. Names are matched within year/state/district/party. All nonexact matches in the main and 10-point sensitivity samples were reviewed. Missing or ambiguous matches are not filled from subsequent election performance.
* A check of the earlier Thomsen 2023 archive found 33,047 anonymous candidate rows with only vote/receipt shares and two flags. Its race-level files have no candidate identities. That archive alone cannot determine which candidate was the richer nominee. The newer named archive resolves the identity gap.
* DeLuca–Moskowitz–Schneer district presidential shares, already used in the original project as part of its election-data sources. No claim that this study is newly discovered.
* Independent current-year validation against presidential totals in seven at-large states. The 2008 field matches all-vote shares rounded to whole percentage points, despite the two-party label in the codebook. It is excluded from the main uniform outcome. The 2012/2016/2020 field agrees with current two-party shares within 0.1 percentage point after accounting for its common district-level mean.

Main 2012/2016/2020 coverage is 79 eligible close nominations within 5 points, all with outcomes; 24 provide different prior-office classifications and 64 different first-report receipt amounts. The two treatment samples are different, not alternative classifications of an identical set of experiments.

## Estimator and checks

The primary estimator uses a 5-percentage-point primary vote margin, triangular weights, local linear slopes on either side of zero, party-by-year fixed effects and state-clustered standard errors with a finite-cluster t interval. The running variable is the vote-share margin among all recorded party-primary candidate votes, signed positive when the higher-trait contender wins. Sensitivities use 2.5 and 10 points. Exact primary arithmetic and published FEC shares match for every used main/sensitivity row. Independent NumPy calculations reproduce both the main coefficient and cluster standard error to numerical tolerance.

The outcome is presidential vote share and is analyzed as an outcome, never a contemporaneous control. It captures the combined consequences of turnout and persuasion for that share, but does not decompose the mechanisms or measure additional votes per fixed population. Primary winner assignment is retained even if the person subsequently withdraws; no rerunning or general-election-success selection is imposed.

## Reproduce

Use Python with pandas, numpy, scipy, statsmodels, openpyxl and xlrd. The scripts read old XLS workbooks directly through xlrd, avoiding pandas engine/version changes.

Run `python run_all.py --workdir /absolute/path/outside/the/public/repository`. This downloads pinned sources, validates SHA-256 hashes and builds the analysis in that external directory. The work directory must be outside the public code checkout. The signed protocol is copied into it. No raw district outcomes are written beside the public code.

## Remaining requirements

1. More independent close nominations and convincing baseline continuity are needed before a precise causal claim. The current sample is too small, particularly for experience.
2. Each first-report receipt measure needs a verified reporting-period end before nomination. The released named file contains no such dates. Its measure also includes dollars, not unique donors. No causal early-money headline is authorized by this audit.
3. Calling either trait an all-star score needs independent validation of candidate appeal and a frozen out-of-time prediction target. That validation is not necessary to define the narrower prior-office or disclosed-donor treatment, but it is necessary for the broader talent interpretation.
4. Separate turnout/party-vote counts on a fixed pre-campaign denominator remain unavailable in this particular district-outcome file. The larger project must retain that requirement separately.

## Distribution boundary

`public_handoff` contains only code, the protocol, aggregate results, aggregate verification and a manifest of source URLs/hashes. It contains no original DeLuca district data, no candidate-to-district outcome crosswalk and no merged district rows. The DeLuca archive has limited reuse information; the public package follows the original project's rule of providing source links and reconstruction code instead of redistributing its observations. No author outreach, identity submission, contract or agreement was performed.
