import os,json,hashlib
from pathlib import Path
import pandas as pd,numpy as np
from fit_models import fit
r=Path(os.environ['COATTAILS_QUALITY_WORKDIR']).resolve();s=pd.read_csv(r/'analysis/PRIVATE_merged_outcome_panel.csv');q=s[s.candidate_sample&s.year.ge(2012)&s.margin_pp.lt(5)].copy();checks=[]
for trait in ['experience_treatment','money_treatment']:
 z=q[q[trait].notna()&q.outcome_pp.notna()].copy();z['D']=z[trait];z['m']=z.margin_pp*np.where(z.D.eq(1),1,-1);z['Dm']=z.D*z.m
 fe=z.year.astype(int).astype(str)+'-'+z.party;X=pd.concat([pd.Series(1.,index=z.index,name='const'),z[['D','m','Dm']],pd.get_dummies(fe,drop_first=True,dtype=float)],axis=1).to_numpy(float);w=1-z.margin_pp.to_numpy()/5;Y=z.outcome_pp.to_numpy();B=np.linalg.lstsq(X*np.sqrt(w[:,None]),Y*np.sqrt(w),rcond=None)[0];e=Y-X@B;bread=np.linalg.inv(X.T@(w[:,None]*X));meat=np.zeros((X.shape[1],X.shape[1]));groups=z.state.to_numpy()
 for g in np.unique(groups):
  idx=groups==g;score=X[idx].T@(w[idx]*e[idx]);meat+=np.outer(score,score)
 n,k=X.shape;G=len(np.unique(groups));V=(G/(G-1))*((n-1)/(n-k))*bread@meat@bread;se=np.sqrt(V[1,1]);answer=fit(z,trait,h=5)
 assert abs(answer['estimate_pp']-B[1])<1e-8
 assert abs(answer['se_pp']-se)<1e-8
 checks.append({'trait':trait,'independent_numpy_beta_difference':float(answer['estimate_pp']-B[1]),'independent_numpy_cluster_se_difference':float(answer['se_pp']-se)})
# Audit exact primary-source arithmetic and uniqueness on all matching-ready main/sensitivity rows.
z=s[s.candidate_sample&s.year.ge(2012)&s.margin_pp.lt(10)&(s.money_treatment.notna()|s.experience_treatment.notna())]
assert z.event_id.is_unique
assert np.allclose(z.margin_pp,100*(z.winner_votes-z.second_votes)/z.primary_total_votes)
assert z.winner_name.notna().all()&z.second_name.notna().all()
assert (z.winner_votes>z.second_votes).all()
# Published FEC share tolerates tiny differences when scattered primary votes appear on their own lines.
share_delta=(z.winner_p-z.winner_published_primary_share).abs();assert share_delta.max()<.001
summary={'numerical_checks':checks,'candidate_primary_arithmetic_verified':True,'main_and_sensitivity_rows':len(z),'max_winner_share_difference_vs_published_FEC':float(share_delta.max()),'negative_first_receipt_values_in_used_rows':int(z[['winner_first_receipts_2021','second_first_receipts_2021']].lt(0).any(axis=1).sum()),'nonexact_name_review':'All nonexact used candidate matches in2012/2016/2020 within10pp were visually inspected: nickname/middle-name/compound-name variants; unmatched names not imputed.','public_release_rule':'No raw DeLuca district observations or merged district outcome rows are included in public_handoff.'}
(r/'verification_summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
