import os
from pathlib import Path
import pandas as pd,numpy as np,json,hashlib
r=Path(os.environ['COATTAILS_QUALITY_WORKDIR']).resolve();raw=r/'raw';out=r/'analysis'
x=pd.read_csv(raw/'H_dist_election_data.tab',sep='\t');p=pd.read_csv(raw/'presidential_raw.csv')
major=p[p.party_simplified.isin(['DEMOCRAT','REPUBLICAN'])].sort_values('candidatevotes',ascending=False).drop_duplicates(['year','state_po','party_simplified'])[['year','state_po','candidate','party_simplified']].rename(columns={'party_simplified':'nominee_party'})
p=p.merge(major,on=['year','state_po','candidate'],how='inner');v=p.groupby(['year','state_po','nominee_party']).candidatevotes.sum().unstack();v['dem2p']=v.DEMOCRAT/(v.DEMOCRAT+v.REPUBLICAN);v=v.reset_index()
z=x[x.dist.eq(0)&x.year.isin([2008,2012,2016,2020])].merge(v,left_on=['year','state_abbrev'],right_on=['year','state_po'],validate='one_to_one')
tot=p.groupby(['year','state_po']).totalvotes.max().reset_index();z=z.merge(tot,on=['year','state_po']);z['dem_all_votes']=z.DEMOCRAT/z.totalvotes
z['implied_national_district_mean']=z.dem2p-z.normalvote_demean
# Confirm same-year current presidential outcomes by differences across at-large states, without assuming a national vote-weighted mean.
check=z.groupby('year').implied_national_district_mean.agg(['count','min','max','std']);check['range']=check['max']-check['min']
z[['year','state_po','DEMOCRAT','REPUBLICAN','dem2p','normalvote_demean','implied_national_district_mean','dem_all_votes']].to_csv(out/'presidential_outcome_atlarge_checks.csv',index=False)
check.to_csv(out/'presidential_outcome_atlarge_summary.csv')
summary={'codebook_definition':'Democratic two-party presidential share from most recent presidential election minus national district-level average.','verification':'For each current presidential year, compare seven at-large district outcomes to independent MIT state presidential totals. A common demeaning constant should reconcile all states; this tests same-year reference.','checks':check.reset_index().to_dict('records'),'main_2012_plus_same_year_two_party_within_0_1pp':bool(check.loc[[2012,2016,2020],'range'].max()<.001),'year_2008_two_party_gate':'FAILED: seven at-large states differ by1.46 percentage points after common demeaning.','year_2008_alternative_check':float((z[z.year.eq(2008)].dem_all_votes.round(2)-z[z.year.eq(2008)].normalvote_demean).max()-(z[z.year.eq(2008)].dem_all_votes.round(2)-z[z.year.eq(2008)].normalvote_demean).min()),'year_2008_conclusion':'Matches all-vote presidential share rounded to whole percentage points to floating-point tolerance. Excluded from main two-party outcome.','warning':'Only presidential-year observations can be current outcomes. Vote share combines turnout and persuasion without separately identifying either. Counts are not provided by district source; cannot estimate votes per fixed population.'}
(r/'presidential_outcome_verification.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
