import os
from pathlib import Path
import importlib.util,pandas as pd,json
r=Path(os.environ['COATTAILS_QUALITY_WORKDIR']).resolve()
from fit_models import fit
s=pd.read_csv(r/'analysis/PRIVATE_merged_outcome_panel.csv');s=s[s.candidate_sample&s.year.ge(2012)&s.prior_outcome_pp.notna()].copy();s['change_pp']=s.outcome_pp-s.prior_outcome_pp
rows=[]
for trait,label in [('experience_treatment','prior_elected_office'),('money_treatment','higher_first_report_receipts')]:
 for outcome in ['outcome_pp','prior_outcome_pp','change_pp']:
  rows.append({'trait':label,'outcome':outcome,'status_note':'Post-fit diagnostic on identical sample; not a rescued causal headline or a new prespecified primary model.',**fit(s,trait,dep=outcome,h=5)})
(r/'matched_balance_diagnostic.json').write_text(json.dumps(rows,indent=2));print('MATCHED DIAGNOSTIC',json.dumps(rows,indent=2))
