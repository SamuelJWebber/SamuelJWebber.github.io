import os
from pathlib import Path
import pandas as pd,numpy as np,xlrd,openpyxl,json,re
r=Path(os.environ['COATTAILS_QUALITY_WORKDIR']).resolve();raw=r/'raw';out=r/'analysis';rows=[];dates=[]
for y in [2008,2012,2016,2020]:
 p=raw/('fec'+str(y)+('.xlsx' if y>=2016 else '.xls'))
 if y<2016:
  b=xlrd.open_workbook(p);s=next(s for s in b.sheet_names() if 'Results' in s and 'House' in s);z=b.sheet_by_name(s);data=[z.row_values(i) for i in range(z.nrows)]
 else:
  b=openpyxl.load_workbook(p,data_only=True,read_only=True);s=next(s for s in b.sheetnames if 'Results' in s and 'House' in s);data=list(b[s].values)
 columns=[str(v).strip() if v is not None else 'blank'+str(i) for i,v in enumerate(data[0])];x=pd.DataFrame(data[1:],columns=columns);x['excel_row']=x.index+2
 dist=next(k for k in ['D','DISTRICT'] if k in x);votes=next(k for k in ['PRIMARY','PRIMARY VOTES'] if k in x);fid=next(k for k in ['FEC ID','FEC ID#'] if k in x)
 x['district']=pd.to_numeric(x[dist],errors='coerce');x['votes']=pd.to_numeric(x[votes],errors='coerce');x['state']=x['STATE ABBREVIATION'];
 def party(v):
  z=str(v).upper().replace('\\xa0','').strip().replace('*','').replace('#','').replace(' ','')
  if z in ['DFL','DNL','DEM']:return 'D'
  if z in ['GOP','REP']:return 'R'
  ds=bool(re.search(r'(^|[/()])D($|[/()])',z));rs=bool(re.search(r'(^|[/()])R($|[/()])',z))
  return 'D' if ds and not rs else 'R' if rs and not ds else None
 x['party']=x.PARTY.map(party)
 x=x[x.district.notna()&x.party.isin(['D','R'])&x['CANDIDATE NAME'].notna()&x['CANDIDATE NAME'].astype(str).str.strip().ne('')&x.votes.notna()].copy();x['district']=x.district.astype(int).replace(0,1);x['year']=y;x['name']=x['CANDIDATE NAME'].astype(str).str.strip();x['fec_id']=x[fid];x['source_sheet']=s;x['published_primary_share']=pd.to_numeric(x['PRIMARY %'],errors='coerce')
 x[['year','state','district','party','name','fec_id','votes','excel_row','source_sheet','FOOTNOTES','published_primary_share']].to_csv(out/('fec_primary_candidates_'+str(y)+'.csv'),index=False)
 for (st,di,pa),g in x.groupby(['state','district','party']):
  g=g.sort_values('votes',ascending=False);total=g.votes.sum()
  if len(g)<2 or total<=0:continue
  w,l=g.iloc[:2].iloc[0],g.iloc[:2].iloc[1]
  z={'year':y,'state':st,'district':di,'party':pa,'rep':int(pa=='R'),'event_id':f'{y}-{st}-{di}-{pa}','winner_name':w['name'],'second_name':l['name'],'winner_votes':w.votes,'second_votes':l.votes,'primary_total_votes':total,'n_candidates':len(g),'duplicate_named_candidates':bool(g['name'].str.upper().duplicated().any()),'winner_published_primary_share':w.published_primary_share,'second_published_primary_share':l.published_primary_share,'winner_fec_id':w.fec_id,'second_fec_id':l.fec_id,'winner_p':w.votes/total,'second_p':l.votes/total,'margin_pp':100*(w.votes-l.votes)/total,'source_sheet':s,'source_file':p.name,'winner_excel_row':w.excel_row,'second_excel_row':l.excel_row,'winner_footnotes':w.FOOTNOTES,'second_footnotes':l.FOOTNOTES}
  z['excluded_state']=st in {'AL','AR','GA','MS','NC','OK','SC','SD','TX','LA'} or st=='WA' and y>=2008 or st=='CA' and y>=2012;z['candidate_sample']=not z['excluded_state'] and z['margin_pp']>0 and not z['duplicate_named_candidates'] and st not in ['DC','GU','VI','PR','AS','MP'];rows.append(z)
a=pd.DataFrame(rows);a.to_csv(out/'official_nomination_spine.csv',index=False)
print('events',len(a),'eligible',a.candidate_sample.sum())
print(a[a.candidate_sample].groupby('year').size())
print('close5',len(a[a.candidate_sample&a.margin_pp.lt(5)]))
