import pandas as pd
import numpy as np
import statsmodels.api as sm
from scipy.stats import t as student_t

def fit(q,trait,dep='outcome_pp',h=5,kind='local_linear',party_year=True):
 q=q[q[trait].notna()&q[dep].notna()].copy();q=q[q.margin_pp.lt(h)].copy();q['D']=q[trait];q['m']=q.margin_pp*np.where(q.D.eq(1),1,-1);q['Dm']=q.D*q.m
 n=len(q);G=q.state.nunique();base={'n':n,'states':G,'higher_trait_wins':int(q.D.eq(1).sum()),'lower_trait_wins':int(q.D.eq(0).sum()),'shared_outcome_duplicates':int(q.duplicated(['state','district','year']).sum())}
 if n<8 or G<3 or q.D.nunique()<2:return {**base,'status':'insufficient_observations'}
 cols=['D','m','Dm'] if kind=='local_linear' else ['D'];X=q[cols].astype(float);fe=q.year.astype(int).astype(str)+('-'+q.party if party_year else '');X=pd.concat([X,pd.get_dummies(fe,prefix='fe',drop_first=True,dtype=float)],axis=1);X=sm.add_constant(X,has_constant='add');rank=np.linalg.matrix_rank(X);base.update(n_parameters=X.shape[1],rank=int(rank))
 if rank<X.shape[1] or n<=rank+1:return {**base,'status':'rank_or_degrees_failure'}
 w=1-q.margin_pp/h if kind=='local_linear' else np.ones(n);model=sm.WLS(q[dep],X,weights=w).fit(cov_type='cluster',cov_kwds={'groups':q.state,'use_correction':True},use_t=True)
 b=float(model.params['D']);se=float(model.bse['D']);critical=student_t.ppf(.975,G-1);return {**base,'status':'estimated','estimate_pp':b,'se_pp':se,'ci95_low_pp':b-critical*se,'ci95_high_pp':b+critical*se,'p_value':float(model.pvalues['D']),'df_cluster':G-1}

