import os
from pathlib import Path
import pandas as pd,numpy as np,json,hashlib
import statsmodels.api as sm
from scipy.stats import t as student_t,binomtest
root=Path(os.environ['COATTAILS_QUALITY_WORKDIR']).resolve();raw=root/'raw';out=root/'analysis'
s=pd.read_csv(out/'official_trait_spine_before_outcomes.csv');y=pd.read_csv(raw/'H_dist_election_data.tab',sep='\t');y=y[y.year.ge(2006)];y=y[['state_abbrev','dist','year','normalvote_demean','redist']].rename(columns={'state_abbrev':'state','dist':'district'});y['district']=y.district.replace(0,1)
assert not y.duplicated(['state','district','year']).any()
s=s.merge(y,on=['state','district','year'],how='left',validate='many_to_one');s['outcome_pp']=100*s.normalvote_demean*np.where(s.party.eq('D'),1,-1)
# Prior presidential outcomes: use source at t-2 only when previous presidential year is2012+ and no boundary change between t-4 and t; no candidate outcomes enter baseline.
prior=y.copy();prior['year']+=2;prior=prior.rename(columns={'normalvote_demean':'prior_normal','redist':'prior_redist'});s=s.merge(prior,on=['state','district','year'],how='left',validate='many_to_one');s['prior_outcome_pp']=np.where(s.year.ge(2016)&s.redist.eq(0)&s.prior_redist.eq(0),100*s.prior_normal*np.where(s.party.eq('D'),1,-1),np.nan)
# Keep row data external to public repository.
s.to_csv(out/'PRIVATE_merged_outcome_panel.csv',index=False)

from fit_models import fit

base=s[s.candidate_sample&s.year.ge(2012)].copy();res=[]
for trait,label,status in [('experience_treatment','prior_elected_office','inconclusive_precision_and_balance_gates_failed'),('money_treatment','higher_first_report_receipts','conditional_diagnostic_timing_and_balance_gates_failed')]:
 for h in [2.5,5,10]:
  q=base[base.margin_pp.lt(h)];z=fit(q,trait,h=h);res.append({'trait':label,'specification':'local_linear_party_year_FE','bandwidth_pp':h,'outcome':'same_year_presidential_party_two_party_share_demeaned','interpretation_status':status,**z})
 for h in [5]:
  res.append({'trait':label,'specification':'difference_party_year_FE','bandwidth_pp':h,'outcome':'same_year_presidential_party_two_party_share_demeaned','interpretation_status':status,**fit(base,trait,h=h,kind='difference')})
  res.append({'trait':label,'specification':'preexisting_presidential_balance','bandwidth_pp':h,'outcome':'prior_presidential_party_share_stable_boundaries','interpretation_status':'balance_diagnostic',**fit(base,trait,dep='prior_outcome_pp',h=h)})
  res.append({'trait':label,'specification':'party_balance_year_FE','bandwidth_pp':h,'outcome':'republican_indicator','interpretation_status':'balance_diagnostic',**fit(base.assign(rep_percent=100*base.rep),trait,dep='rep_percent',h=h,party_year=False)})
  if trait=='money_treatment':
   pos=base[base.winner_first_receipts_2021.gt(0)&base.second_first_receipts_2021.gt(0)]
   res.append({'trait':label,'specification':'positive_positive_local_linear','bandwidth_pp':h,'outcome':'same_year_presidential_party_two_party_share_demeaned','interpretation_status':status,**fit(pos,trait,h=h)})

# Restricted main has few independent nominations. Additional inference is not used to select a headline.
coverage=[]
for h in [2.5,5,10]:
 q=s[s.candidate_sample&s.margin_pp.lt(h)&s.year.ge(2012)];coverage.append({'bandwidth_pp':h,'eligible_nominations':len(q),'outcome_available':int(q.outcome_pp.notna().sum()),'experience_contrast':int(q.experience_treatment.notna().sum()),'experience_with_outcome':int((q.experience_treatment.notna()&q.outcome_pp.notna()).sum()),'money_contrast':int(q.money_treatment.notna().sum()),'money_with_outcome':int((q.money_treatment.notna()&q.outcome_pp.notna()).sum())})
summary={'protocol_sha256':hashlib.sha256((root/'PROTOCOL_FROZEN.md').read_bytes()).hexdigest(),'years':[2012,2016,2020],'main_bandwidth_pp':5,'coverage':coverage,'results':res,'limits':['Prior elected office is experience, not innate talent or an all-star classification.','Estimates apply to nomination winners at close conventional House primaries and presidential vote share within their district; not Senate-to-governor coattails.','State-cluster t intervals with few states are approximate and imprecise.','No simultaneous estimate of mobilization and persuasion components, nor votes per fixed population.','Early money lacks per-candidate first-report coverage dates in released replication data; its causal timing gate is incomplete.','2008 outcome is excluded because at-large audit matches rounded all-vote share rather than two-party vote share.','Election source is exact FEC primary vote counts; outcome shares have source rounding of roughly0.1 percentage point.','Missing trait matches or unidentified first-report dates are not filled by general-election outcomes.']}
(root/'house_spillover_results.json').write_text(json.dumps(summary,indent=2,allow_nan=False));pd.DataFrame(res).to_csv(root/'house_spillover_results.csv',index=False);print(json.dumps(summary,indent=2))
