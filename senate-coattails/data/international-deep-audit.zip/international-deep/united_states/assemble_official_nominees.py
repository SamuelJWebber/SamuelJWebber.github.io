import os
from pathlib import Path
import pandas as pd,numpy as np,re,json,hashlib,unicodedata
root=Path(os.environ['COATTAILS_QUALITY_WORKDIR']).resolve();raw=root/'raw';out=root/'analysis';out.mkdir(exist_ok=True)
c=pd.read_csv(out/'official_nomination_spine.csv');t=pd.read_csv(raw/'POMRS8_replicationdata.tab',sep='\t')

def toks(s):
 s=unicodedata.normalize('NFKD',str(s)).encode('ascii','ignore').decode().upper();return [x for x in re.findall('[A-Z]+',s) if x not in {'MR','MRS','MS','DR','JR','SR','II','III','IV'}]
def norm(s):return ' '.join(sorted(toks(s)))
t['name_norm']=t.name.map(norm)
t['rep']=pd.to_numeric(t.rep,errors='coerce');t['district']=t.district.replace(0,1)
index={k:g for k,g in t.groupby(['year','state','district','rep'],dropna=False)}
rows=[]
for r in c.itertuples():
 for side in ['winner','second']:
  name=getattr(r,side+'_name');gg=index.get((r.year,r.state,r.district,r.rep),t.iloc[:0]);n=norm(name);matches=gg[gg.name_norm.eq(n)];method='exact_normalized'
  if len(matches)!=1:
   # Require all full surname tokens, given-name first initial, and a unique within-contest candidate.
   parts=str(name).split(',',1);last=toks(parts[0]);given=toks(parts[1]) if len(parts)>1 else []
   if given:
    def match(s):
     z=toks(s);return len(z)>0 and all(v in z for v in last) and any(v.startswith(given[0][0]) for v in z if v not in last)
    matches=gg[gg.name.map(match)];method='surname_given_initial_unique'
  if len(matches)!=1:matches=gg.iloc[:0];method='unmatched_or_ambiguous'
  z={'event_id':r.event_id,'side':side,'source_name':name,'match_method':method,'n_contest_candidates':len(gg)}
  if len(matches)==1:
   a=matches.iloc[0];z.update(thomsen_name=a['name'],dropout=a.dropout,qual=a.qual,first_receipts_2021=a.totalfirstreport_adj_hundthou*100000,ratio_first=a.ratio_maxfirstreport,shareloan=a.shareloan,sharepac=a.sharepac,thomsen_row=int(a.name) if isinstance(a.name,(int,np.integer)) else None)
  rows.append(z)
x=pd.DataFrame(rows);x.to_csv(out/'official_candidate_crosswalk.csv',index=False)
for side in ['winner','second']:
 z=x[x.side.eq(side)].drop(columns='side');z=z.rename(columns={col:side+'_'+col for col in z if col!='event_id'});c=c.merge(z,on='event_id',validate='one_to_one')
c['complete_early_money']=c[['winner_first_receipts_2021','second_first_receipts_2021']].notna().all(axis=1)&c.winner_dropout.eq(0)&c.second_dropout.eq(0)
c['money_rank_diff']=c.winner_first_receipts_2021-c.second_first_receipts_2021
c['money_treatment']=np.where(c.complete_early_money&c.money_rank_diff.ne(0),c.money_rank_diff.gt(0).astype(float),np.nan)
c['complete_experience']=c.winner_qual.isin([0,1])&c.second_qual.isin([0,1])&c.winner_dropout.eq(0)&c.second_dropout.eq(0)
c['experience_treatment']=np.where(c.complete_experience&c.winner_qual.ne(c.second_qual),c.winner_qual,np.nan)
c.to_csv(out/'official_trait_spine_before_outcomes.csv',index=False)
summary={'protocol_sha256':hashlib.sha256((root/'PROTOCOL_FROZEN.md').read_bytes()).hexdigest(),'official_party_primary_events':len(c),'candidate_matches':x.match_method.value_counts().to_dict(),'thomsen_named_candidate_rows':len(t),'eligible_assignment_events':int(c.candidate_sample.sum()),'notes':'No outcome joined in this stage; money dates need source audit. Qual=prior elected office among nonincumbents.'}
summary['counts']=[]
for h in [2.5,5,10]:
 q=c[c.candidate_sample&c.margin_pp.lt(h)];p=q[q.year.mod(4).eq(0)]
 summary['counts'].append({'bandwidth_pp':h,'nomination_events':len(q),'presidential_year_events':len(p),'pres_earlymoney_different':int(p.money_treatment.notna().sum()),'pres_earlymoney_higher_wins':int(p.money_treatment.eq(1).sum()),'pres_earlymoney_lower_wins':int(p.money_treatment.eq(0).sum()),'pres_experience_different':int(p.experience_treatment.notna().sum()),'pres_experienced_wins':int(p.experience_treatment.eq(1).sum()),'pres_inexperienced_wins':int(p.experience_treatment.eq(0).sum())})
(root/'official_assembly_summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
