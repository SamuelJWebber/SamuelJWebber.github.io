"""Download only pinned inputs into an explicitly external work directory."""
import os,json,hashlib,urllib.request
from pathlib import Path
root=Path(os.environ['COATTAILS_QUALITY_WORKDIR']).resolve();raw=root/'raw';raw.mkdir(parents=True,exist_ok=True)
for item in json.loads((root/'source_manifest.json').read_text()):
 if not item['required_for_pipeline']:continue
 p=raw/item['filename']
 if not p.exists():
  req=urllib.request.Request(item['url'],headers={'User-Agent':'CoattailsResearchReproduction/1.0 Mozilla/5.0'})
  with urllib.request.urlopen(req,timeout=120) as response:data=response.read()
  assert hashlib.sha256(data).hexdigest()==item['sha256'],f'Source changed: {p.name}'
  p.write_bytes(data)
 assert hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256'],f'Cached source changed: {p.name}'
 print('Verified',p.name)
