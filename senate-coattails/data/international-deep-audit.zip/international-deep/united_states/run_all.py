import argparse,os,shutil,subprocess,sys,json
from pathlib import Path
code=Path(__file__).resolve().parent
parser=argparse.ArgumentParser(description='Reproduce House nomination audit outside any public repository.')
parser.add_argument('--workdir',type=Path,required=True);args=parser.parse_args();work=args.workdir.resolve()
if '.sites-checkout' in work.parts or 'public_handoff' in work.parts:raise ValueError('Use an external work directory, not the public code checkout or handoff directory.')
work.mkdir(parents=True,exist_ok=True);(work/'analysis').mkdir(exist_ok=True)
for name in ['PROTOCOL_FROZEN.md','source_manifest.json']:
 if (code/name).resolve()!=(work/name).resolve():shutil.copyfile(code/name,work/name)
env=os.environ.copy();env['COATTAILS_QUALITY_WORKDIR']=str(work)
steps=['download_sources.py','build_official_primary.py','assemble_official_nominees.py','verify_presidential_outcome.py','estimate_house_spillovers.py','matched_balance_diagnostic.py','verify_analysis.py']
for step in steps:
 with (work/(step+'.log')).open('w') as log:subprocess.run([sys.executable,str(code/step)],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 print('Completed',step)
result=json.loads((work/'house_spillover_results.json').read_text());print('Models executed; precision, balance or timing gates fail. No verified all-star coattail estimate.')
print(json.dumps(result['coverage'],indent=2))
