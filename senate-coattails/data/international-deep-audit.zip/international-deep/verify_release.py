"""Check the assembled public evidence package, without downloading private inputs."""
from pathlib import Path
import csv, json, hashlib

ROOT=Path(__file__).resolve().parent
checks={}
def read(p): return json.loads((ROOT/p).read_text())
def rows(p):
    with (ROOT/p).open(newline='',encoding='utf-8-sig') as f:return list(csv.DictReader(f))

a=read('argentina/join_summary.json')
checks['argentina_75_events_67_named_71_outcomes']=(a['near_tie_screen_events'],a['both_names_matched'],a['governor_outcomes_matched'])==(75,67,71)
checks['argentina_three_prior_winner_pairs']=len(read('argentina/prior_winner_trait_summary.json')['discordant_near_tie_pairs'])==3
c=read('chile/coattails_event_panel_all_cycles.json')
checks['chile_202_distinct_events']=len(c)==202 and len({(x['primary_year'],x['commune'],x['pact']) for x in c})==202
checks['chile_31_near_ties']=len(read('chile/near_primary_events_31.json'))==31
checks['chile_six_reported_donor_comparisons']=len(read('chile/donor_id_gap_six_2016.json'))==6
n=read('new_zealand/pilot_results_final.json')
checks['nz_74_units_5_winners_3_draws']=(n['eligible_mp_term_units'],n['treated_eligible_mp_term_units'],n['draw_events'])==(74,5,3)
checks['nz_74953_exact_allocations']=sum(x['possible_assignments'] for x in n['per_draw'])==74953
checks['nz_final_not_independent_pooled_test']=not n['summary']['vote_change_per_baseline_valid_pp']['pooled_independent_roster_permutation_test_used']
u=read('united_states/quality_completion_summary.json')
checks['us_79_nominations_24_experience_64_money']=(u['nominations_within_5pp'],u['experience_nominations'],u['money_nominations'])==(79,24,64)
checks['us_failed_gates_labeled']=all('failed' in x['interpretation_status'] for x in u['primary_results'])
checks['us_matched_placebo_38_events']=all(x['n']==38 for x in u['matched_money_diagnostic'])
for folder,count in [('spain_results',3360),('spain_results_cluster_municipal',3360),('spain_results_municipal',2184)]:
    checks['spain_'+folder+'_saved_rows']=len(rows('shocks/'+folder+'/analysis_panel.csv'))==count
checks['spain_honestdid_validation']=read('shocks/spain_results_honestdid/honestdid_validation.json')['passes']
checks['spain_45_honestdid_intervals']=len(rows('shocks/spain_results_honestdid/all_relative_magnitude_bounds.csv'))==45
checks['brazil_56948_party_rows']=len(rows('shocks/brazil_prepared/council_party_outcomes_2004.csv'))==56948
checks['no_private_row_files']=not any('PRIVATE_' in p.name for p in ROOT.rglob('*') if p.is_file())
checks['no_private_pages_in_outputs']=not any('https://chatgpt.com/space/' in p.read_text(errors='ignore') for p in ROOT.rglob('*') if p.suffix in ('.json','.csv','.md'))
checks['json_outputs_parse']=True
for p in ROOT.rglob('*.json'):
    json.loads(p.read_text(),parse_constant=lambda v: (_ for _ in ()).throw(ValueError(f'{p}: nonstandard {v}')))

ledger=ROOT/'study_ledger.json'
if ledger.exists():
    studies=json.loads(ledger.read_text())['studies']
    checks['seven_unique_dashboard_studies']=len(studies)==len({s['id'] for s in studies})==7
    checks['dashboard_has_no_fake_nan']='NaN' not in ledger.read_text()

result={'status':'passed' if all(checks.values()) else 'failed','checks':checks,'note':'Consistency checks verify the public artifacts, not the causal identifying assumptions.'}
(ROOT/'RELEASE_VERIFICATION.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
assert all(checks.values()),'Public release checks failed'
