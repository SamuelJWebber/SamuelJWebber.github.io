# Chile coattails data audit

Executed 6 November 2026. This package contains 560 primary candidates, 202 commune-by-pact nomination contests, and subsequent general mayor/council outcomes for every event. It is a reproducible data audit with a descriptive six-case comparison, not a confirmatory causal coattails estimate.

| Primary → general cycle | Candidates | Contests | Margin ≤5 pp | Margin ≤10 pp |
| --- | ---: | ---: | ---: | ---: |
| 2016 → 2016 | 248 | 96 | 15 | 26 |
| 2020 → 2021 | 103 | 40 | 12 | 15 |
| 2024 → 2024 | 209 | 66 | 4 | 12 |
| Total | 560 | 202 | 31 | 53 |

The margin is 100 × (winner votes − runner-up votes)/(winner votes + runner-up votes). The all-valid-vote margin is also retained. It is not a signed quality running variable until a candidate-support ranking is fixed. The 2024 accepted roster was independently extracted from official bulletins and reconciles exactly to the 209 final historical candidate results; all 66 plurality winners agree with the nomination flags.

## Main outputs

- `coattails_event_panel_all_cycles.csv` and `.json`: all 202 joined events.
- `near_primary_events_31.csv` and `.json`: the complete ≤5 pp screen.
- `donor_id_gap_six_2016.csv` and `.json`: six close events with separated reported donor-ID intervals.
- `candidate_donor_features_YEAR`: candidate support and missingness at day-before and fourteen-day-before cutoffs.
- `exploratory_six_case_contrast.json`: descriptive comparison and explicit assumptions.
- `source_manifest.json`: actual download URLs, byte lengths and SHA-256 checksums.
- `PUBLIC_FILES.json`: exact release whitelist. Raw donor names and RUTs are not included in released data.

## What the donor audit found

2016's 1,172 income rows contain usable donor identifiers: 141/153 code-125 rows and 231/241 code-135 rows have checksum-valid RUTs. The scripts exclude identifiable self gifts, deduplicate IDs across public and anonymous code categories, and filter document dates before the primary. Checksum validity establishes a well-formed source ID, not independent verification of a person. Of 248 primary candidates, 209 match income records; unmatched candidates remain missing, never zero.

2020 has 8,175 substantive income/expense rows and 101/103 mayor candidates match income records. Donor identities are generally missing or placeholders, so receipt counts and public-name labels are available, not a verified unique-person count. 2024 has 6,230 substantive finance records and 944 transfer records (the previously counted 6,239/952 included headers or blanks). 382/383 code-115 finance rows omit donor RUT. The 2024 transfer file distinguishes natural-person and party transfers but contains no RUT. Some party transfers are misclassified as code 115 in finance accounts; the natural-person transfer type is therefore used for the main conditional name intervals.

For 2016, a conditional donor-count interval has lower = observed distinct valid IDs and upper = lower + unidentified eligible receipt rows + positive cash rows with unknown date. It assumes an unidentified row represents at most one original gift and that dated records are accurate. Missing accounts invalidate full coverage. For 2024, conditional intervals additionally assume normalized public-name labels identify unique people. The legal-cap bound is documented in the research appendix but not substituted for unverified receipt granularity or identity data.

Six 2016 close cases have separated day-before reported-ID counts: Concón 2 vs 3; Linares 1 vs 0; Ñuñoa 30 vs 1; Lanco 1 vs 0; Puchuncaví 0 vs 1; Tiltil 0 vs 2 (winner first). Higher-support candidates win three and lose three. Only Ñuñoa shows a large donor gap. At the fourteen-day cutoff, four comparisons become 0–0; only Concón and Ñuñoa remain separated. Thus donor counts do not yet supply a broadly valid all-star treatment.

The six-case mean difference in coalition council votes/registered electorate is −4.26 percentage points (15.96% when the higher-reported-donor candidate wins versus 20.22% when they lose). This is descriptive, not causal lift: five gaps concern only 0–3 donors, the coalition composition differs between groups, full campaign coverage and preprimary disclosure vintages are unverified, and council slates respond to nomination. The optional permutation calculation assumes unrestricted label exchangeability, which is not established. It must not be presented as proof of no effect. No local-linear regression was fitted to these cases or the two conditionally ranked 2024 cases.

## Outcome and institutional caveats

The outcome sums council votes over a national party-family set fixed independently of the primary winner's party, divided by the reported registered electorate. The crosswalk includes affiliated independents and accounts for the CS/RD → Frente Amplio merger. It still requires local preprimary pact and sponsorship verification. General accepted-candidate workbooks do not provide stable person IDs. Exact normalized full-name links and unique token-subset links are separated; token-subset links require manual confirmation.

Chile's binding primary selects the general mayoral nominee, while a primary loser may run for council. In 2024, 26 runners-up have exact name matches on council ballots and 14 more have probable token-subset matches. Three of the four close cases have a loser on the council ballot. Consequently the coalition outcome includes the defeated contender's own council votes and any nomination-induced slate/campaign response. It measures the nomination package if identified, not a pure effect on an unchanged set of other candidates. Simply subtracting an observed loser's votes does not fix the counterfactual slate problem.

General elections were voluntary in 2016/2021 and compulsory in 2024; primaries were voluntary. Keep cycle regimes separate. The reported general electorate is not automatically a pretreatment denominator in every cycle. For 2024 the eligibility reference closed 8 June, one day before the primary; final administrative roll changes still require verification.

Actual historical primary counts in Guaitecas are 262–245, superseding preliminary 262–244. General mayor votes for Bans Puinao are 583, not 1,155 (the latter is all ballots). The council coalition total 500 and 1,155 total ballots reconcile with the judicial judgments.

## Reproduce

Use Python 3 with `openpyxl` and `requests`, plus system `libarchive` for RAR decompression. Keep this directory private while downloading raw finance files. The derived package's scripts use paths relative to themselves and do not depend on the original workspace.

```bash
python fetch_sources.py
python analyze_chile.py
python join_outcomes.py
python extend_older.py
python finalize_public.py
```

`fetch_sources.py` verifies every recorded checksum and stops if source content changes. Archives contain extra large demographic sheets; the analysis reads commune aggregates and participation, not individual voter data. The accepted roster JSON is supplied as an independently extracted validation input. The final aggregation expects the small source download metadata files shipped in the whitelist as well as the main manifest.

## What remains necessary for a causal claim

For a causal donor-rich nomination contrast, recover/reconcile complete original receipts, fix the ranking using pre-treatment events and audit whether later reporting depends on who won. Validate the local coalition definition, identities, outcome denominator, manipulation, covariate/prior-election balance, third-place separation and sample support. Specify the cohort, bandwidth and whether the estimand includes nomination-induced slate changes before fitting outcomes. Do not condition away those changes if estimating the total nomination package.

A historical public-release vintage is additionally required for a real-time forecasting claim; it is not automatically required for retrospective measurement of an earlier event. Independent appeal validation is required to describe donor breadth as all-star talent. A valid donor-rich treatment contrast does not require proving that it measures every aspect of candidate quality. No out-of-time model winner has been established here.

Primary sources: [SERVEL historical results](https://www.servel.cl/biblioteca-de-documentos/resultados-electorales-historicos/), [SERVEL 2024 primary documents](https://www.servel.cl/biblioteca-de-documentos/procesos-electorales/elecciones-2024/documentos-elecciones-2024/documentos-elecciones-primarias-2024/), [official document index](https://www-doc.servel.cl/table-data.json), [primary law 20.640](https://www.bcn.cl/leychile/navegar?idNorma=1046533), and [campaign-finance DFL 3](https://www.bcn.cl/leychile/navegar?i=1107658). Exact direct file URLs and hashes are in the manifest.
