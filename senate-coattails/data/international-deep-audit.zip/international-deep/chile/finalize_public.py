"""Build aggregate-only Chile release manifest and exploratory six-case audit."""
import pathlib,json,csv,collections,hashlib,itertools,statistics
ROOT=pathlib.Path(__file__).parent

def save(n,x):
    (ROOT/(n+'.json')).write_text(json.dumps(x,ensure_ascii=False,indent=2))
    if isinstance(x,list) and x:
        with (ROOT/(n+'.csv')).open('w',newline='') as f:
            w=csv.DictWriter(f,fieldnames=list(dict.fromkeys(k for r in x for k in r)));w.writeheader();w.writerows(x)
rows=[]
for year in [2016,2020,2024]:
    a=json.loads((ROOT/f'coattails_event_panel_{year}.json').read_text())
    for r in a:
        r['primary_year']=year;r['general_year']=2016 if year==2016 else 2021 if year==2020 else 2024
        if year==2024:
            for role in ['winner','runner']:
                r[role+'_general_office']={'ALCALDE':'mayor','CONCEJAL':'council'}.get(r.get(role+'_general_offices'))
                r[role+'_general_link']=r.get(role+'_general_match')
    rows+=a
save('coattails_event_panel_all_cycles',rows)
near=[r for r in rows if r['margin_top2_pp']<=5]
fields=['primary_year','general_year','commune','pact','winner','runner','winner_votes','runner_votes','margin_top2_pp','registered','general_ballots','coalition_council_votes','coalition_council_votes_per_registered','winner_general_votes','runner_general_office','runner_general_votes','winner_checksum_valid_distinct_donor_ids','runner_checksum_valid_distinct_donor_ids','winner_donor_receipt_rows','runner_donor_receipt_rows','donor_id_interval_rank_conditional','donor_interval_rank_conditional','council_coalition_mapping_status','causal_estimate']
near=[{k:r.get(k) for k in fields} for r in near]
save('near_primary_events_31',near)
six=[r for r in rows if r['primary_year']==2016 and r['margin_top2_pp']<=5 and r['donor_id_interval_rank_conditional'] in ['winner_higher','runner_higher']]
f={(r['commune'],r['name'],r['cutoff']):r for r in json.loads((ROOT/'candidate_donor_features_2016.json').read_text())}
for r in six:
    r['higher_reported_donor_nominee_won']=r['donor_id_interval_rank_conditional']=='winner_higher'
    for role in ['winner','runner']:
        z=f[(r['commune'],r[role],'2016-06-05')];r[role+'_donors_14_days_before']=z['checksum_valid_distinct_donor_ids']
    r['rank_14_days_before']='winner_higher' if r['winner_donors_14_days_before']>r['runner_donors_14_days_before'] else 'runner_higher' if r['winner_donors_14_days_before']<r['runner_donors_14_days_before'] else 'tied'
save('donor_id_gap_six_2016',six)
y=[r['coalition_council_votes_per_registered'] for r in six];t=[i for i,r in enumerate(six) if r['higher_reported_donor_nominee_won']];control=[i for i in range(len(six)) if i not in t]
diff=statistics.mean(y[i] for i in t)-statistics.mean(y[i] for i in control)
perms=[statistics.mean(y[i] for i in c)-statistics.mean(y[i] for i in range(6) if i not in c) for c in itertools.combinations(range(6),len(t))]
contrast=dict(status='descriptive_only_not_causal_coattails_estimate',n=6,higher_donor_candidate_wins=len(t),higher_donor_candidate_loses=len(control),outcome='coalition council votes / reported general registered electorate',mean_higher_donor_wins=statistics.mean(y[i] for i in t),mean_higher_donor_loses=statistics.mean(y[i] for i in control),difference_pp=100*diff,illustrative_label_permutation_p=sum(abs(z)>=abs(diff)-1e-12 for z in perms)/len(perms),permutations=len(perms),permutation_assumption='Unrestricted exchangeability of 3 winning labels among 6 events; this is NOT established by the data audit. P-value does not establish validity or no effect.',cutoff_sensitivity='At 14 days before the primary only Concon (higher donor loses) and Nunoa (higher donor wins) retain non-tied ranks. Other four are 0-0.',limitations=['Six events, five donor gaps distinguish only 0-3 reported donors; not an externally validated all-star metric.','All three higher-donor wins are Nueva Mayoria; two of three losses are Chile Vamos. No balance/density/placebo validation.','Files are ex-post accounts with preprimary document dates; missing campaigns/receipts and historic-publication vintage unresolved.','Council outcome includes defeated-primary candidates who later join council slates; total nomination-package outcome, not unchanged teammates.','Final registered-electorate denominators and local pact mapping require preprimary validation.','Cross-cycle voting rules differ; no pooled causal model fitted.'])
save('exploratory_six_case_contrast',contrast)
urls={r['name']:r['url'] for r in json.loads((ROOT/'download_manifest.json').read_text())}
for y in [2016,2020]:urls[f'primary{y}.rar']=f'https://recursos-powerbi.s3.us-east-1.amazonaws.com/download/{y}/'+('2016_06_AlcaldesPrimaria_DatosEleccion.rar' if y==2016 else '2020_11_AlcaldesPrimarias_Datos_Eleccion.rar')
for r in json.loads((ROOT/'older_finance_downloads.json').read_text()):urls[f"finance{r['year']}.xlsx"]=r['url']
for r in json.loads((ROOT/'general2016_downloads.json').read_text()):urls[r['file']]=r['url']
urls.update({'general_mayor2021.rar':'https://recursos-powerbi.s3.us-east-1.amazonaws.com/download/2021/2021_05_Alcaldes_Datos_Eleccion.rar','general_council2021.rar':'https://recursos-powerbi.s3.us-east-1.amazonaws.com/download/2021/2021_05_Concejales_DatosEleccion.rar','general_mayor2024.zip':'https://recursos-powerbi.s3.us-east-1.amazonaws.com/download/2024/2024_10_Alcaldes_Datos_Eleccion.zip','general_council2024.zip':'https://recursos-powerbi.s3.us-east-1.amazonaws.com/download/2024/2024_10_Concejales_DatosEleccion.zip'})
manifest=[]
for name,url in urls.items():
    p=ROOT/name
    if p.exists():manifest.append(dict(file=name,url=url,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),retrieved_utc_date='2026-11-06',public_source=True,redistribute_raw=False if name.startswith(('finance','contributions')) else True))
save('source_manifest',manifest)
summary=dict(status='executed_data_audit_not_confirmatory_causal_model',candidates=560,events=202,events_with_general_outcome=202,near5_events=31,near10_events=53,near5_2016_id_separated_events=6,near5_2024_conditional_name_ranked_events=2,donor_metric='2016: reported checksum-valid donor-ID counts; 2020/2024: reported receipts or normalized public-name labels. Neither is automatically charisma.',counts_by_cycle=[dict(primary_year=y,candidates=len(json.loads((ROOT/f'primary_candidate_results_{y}.json').read_text())),events=sum(r['primary_year']==y for r in rows),near5=sum(r['primary_year']==y for r in near)) for y in [2016,2020,2024]])
save('completion_summary',summary)
public=[]
for pattern in ['primary_candidate_results_*.json','primary_candidate_results_*.csv','primary_contests_*.json','primary_contests_*.csv','candidate_donor_features_*.json','candidate_donor_features_*.csv','coattails_event_panel_*.json','coattails_event_panel_*.csv','general_council_candidates_*.json','general_council_candidates_*.csv','general_mayor_candidates_*.json','general_mayor_candidates_*.csv','general_participation_*.json','general_participation_*.csv','coalition_crosswalk_*.json','near_primary_events_31.*','donor_id_gap_six_2016.*','exploratory_six_case_contrast.json','completion_summary.json','source_manifest.json','download_manifest.json','older_finance_downloads.json','general2016_downloads.json','audit.json','outcome_join_audit.json','older_finance_outcome_audit.json','accepted_roster_2024.json','README.md','analyze_chile.py','join_outcomes.py','extend_older.py','finalize_public.py','fetch_sources.py','extract_rar.py']:
    public += [p.name for p in ROOT.glob(pattern)]
(ROOT/'PUBLIC_FILES.json').write_text(json.dumps({'policy':'Only explicitly listed aggregate data, candidate results and scripts may be copied to public dashboard. No raw finance/contribution workbooks, donor names/RUTs, private page snapshots, archive module files, or raw source directory sync.','files':sorted(set(public))},indent=2))
print(json.dumps(summary,indent=2));print(json.dumps(contrast,indent=2))
