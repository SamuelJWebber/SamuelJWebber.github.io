"""Download the recorded public SERVEL files and unpack analysis workbooks.
Raw financial files contain personal data: keep them private. Publish only PUBLIC_FILES.json entries.
Dependencies: requests; system libarchive for RAR. Existing matching files are reused.
"""
import pathlib,json,hashlib,zipfile
import requests
from extract_rar import unpack
ROOT=pathlib.Path(__file__).parent
for entry in json.loads((ROOT/'source_manifest.json').read_text()):
    p=ROOT/entry['file']
    if not p.exists():
        r=requests.get(entry['url'],timeout=180);r.raise_for_status();p.write_bytes(r.content)
    got=hashlib.sha256(p.read_bytes()).hexdigest()
    if got!=entry['sha256']:
        raise RuntimeError(f'Source content changed for {p.name}; inspect and deliberately update the manifest before analysis.')
    if p.suffix.lower() not in ['.zip','.rar'] or 'provisional' in p.name:continue
    dest=ROOT/p.stem
    if dest.exists() and list(dest.glob('*.xlsx')):continue
    dest.mkdir(exist_ok=True)
    if p.suffix.lower()=='.zip':
        with zipfile.ZipFile(p) as z:
            for n in z.namelist():
                if n.lower().endswith('.xlsx'):(dest/pathlib.Path(n).name).write_bytes(z.read(n))
    else:unpack(p,dest)
    print('verified',p.name)
