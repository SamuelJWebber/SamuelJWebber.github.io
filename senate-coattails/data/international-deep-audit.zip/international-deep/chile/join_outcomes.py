import pathlib,json,collections,unicodedata,csv
import openpyxl
ROOT=pathlib.Path(__file__).parent
def norm(x):return ' '.join(unicodedata.normalize('NFKD',str(x or '')).encode('ascii','ignore').decode().upper().split())
def save(n,x):
    (ROOT/(n+'.json')).write_text(json.dumps(x,indent=2,ensure_ascii=False))
    if isinstance(x,list) and x:
        with (ROOT/(n+'.csv')).open('w',newline='') as f:
            w=csv.DictWriter(f,fieldnames=list(dict.fromkeys(k for r in x for k in r)));w.writeheader();w.writerows(x)
CW=openpyxl.load_workbook(next((ROOT/'general_council2024').glob('*.xlsx')),read_only=True,data_only=True)
MW=openpyxl.load_workbook(next((ROOT/'general_mayor2024').glob('*.xlsx')),read_only=True,data_only=True)
council=[];mayors=[];population=collections.defaultdict(lambda:dict(registered=0,voted=0,mesas=0));seen=set()
for r in CW['Votación por comuna'].iter_rows(min_row=8,values_only=True):
    if not r[6] or not isinstance(r[13],(int,float)):continue
    council.append(dict(commune=norm(r[4]),pact=norm(r[6]),subpact=norm(r[7]),party=norm(r[8]),name=norm(' '.join(str(x or '') for x in r[10:13])),votes=int(r[13]),elected=r[14]=='CONCEJAL'))
for r in MW['Votación por comuna'].iter_rows(min_row=8,values_only=True):
    if not r[6] or not isinstance(r[11],(int,float)):continue
    mayors.append(dict(commune=norm(r[4]),pact=norm(r[6]),party=norm(r[7]),name=norm(' '.join(str(x or '') for x in r[8:11])),votes=int(r[11]),elected=r[12]=='ALCALDE'))
duplicate_participation_keys=0
for r in CW['Participación'].iter_rows(min_row=8,values_only=True):
    if not r[4] or not isinstance(r[8],(int,float)):continue
    key=tuple(r[:8])
    if key in seen:duplicate_participation_keys+=1;continue
    seen.add(key);s=population[norm(r[4])];s['registered']+=int(r[8]);s['voted']+=int(r[9] or 0);s['mesas']+=1
save('general_council_candidates_2024',council);save('general_mayor_candidates_2024',mayors)
save('general_participation_2024',[dict(commune=k,**v) for k,v in population.items()])
coalitions={
 'CHILE VAMOS':['CHILE VAMOS UDI-EVOPOLI E INDEPENDIENTES','CHILE VAMOS RENOVACION NACIONAL - INDEPENDIENTES'],
 'CONTIGO CHILE MEJOR':['POR CHILE, SEGUIMOS','VERDES LIBERALES POR UNA COMUNA SEGURA','TU COMUNA RADICAL','CHILE MUCHO MEJOR'],
 'PARTIDO SOCIAL CRISTIANO E INDEPENDIENTES':['PARTIDO SOCIAL CRISTIANO E INDEPENDIENTES']}
save('coalition_crosswalk_2024',{'mapping':coalitions,'definition':'Fixed national primary coalition party families, mapped to general-election council lists. Mapping does not depend on primary winner party. Includes list-sponsored independents.','caution':'Local pact membership and independent sponsorship must be checked against preprimary registration documents; national party merger CS/RD to FA crosswalk included. This is a transparent preliminary operationalization, not complete institutional validation.'})
cg=collections.defaultdict(list);mg=collections.defaultdict(list)
for x in council:cg[x['commune']].append(x)
for x in mayors:mg[x['commune']].append(x)
contests=json.loads((ROOT/'primary_contests_joined_2024.json').read_text());features=json.loads((ROOT/'candidate_donor_features_2024.json').read_text());fg={(x['commune'],x['name'],x['cutoff']):x for x in features}
out=[]
for c in contests:
    row=dict(c);cr=cg[c['commune']];coal=[x for x in cr if x['pact'] in coalitions[c['pact']]];pop=population[c['commune']]
    row.update(registered=pop['registered'],general_ballots=pop['voted'],council_valid_votes=sum(x['votes'] for x in cr),coalition_council_votes=sum(x['votes'] for x in coal),coalition_council_seats=sum(x['elected'] for x in coal),coalition_council_votes_per_registered=sum(x['votes'] for x in coal)/pop['registered'],council_coalition_mapping_status='fixed_party_family_preliminary_local_pact_audit_pending')
    for role in ['winner','runner']:
        m=[x for x in (mg[c['commune']]+cr) if x['name']==c[role+'_general_name']]
        row[role+'_general_votes']=sum(x['votes'] for x in m) if m else None
        row[role+'_general_elected']=any(x['elected'] for x in m) if m else None
        f=fg[(c['commune'],c[role],'2024-06-08')]
        k=f['transfer_public_distinct_name_labels'];t=f['transfer_anon_rows'];a=f['transfer_anon_amount']
        row[role+'_public_name_count']=k;row[role+'_anonymous_transfer_rows']=t
        row[role+'_donor_conditional_lower']=max(k,int(a>0)) if k is not None and a is not None else None
        row[role+'_donor_conditional_upper']=k+t if k is not None and t is not None else None
    wl,wu=row['winner_donor_conditional_lower'],row['winner_donor_conditional_upper'];rl,ru=row['runner_donor_conditional_lower'],row['runner_donor_conditional_upper']
    row['donor_interval_rank_conditional']=('winner_higher' if wl>ru else 'runner_higher' if rl>wu else 'ambiguous') if None not in [wl,wu,rl,ru] else 'missing'
    row['donor_interval_assumptions']='Each normalized public name identifies one person; anonymous transfer rows each represent one original gift; file coverage complete at cutoff. These assumptions are not fully validated.'
    row['causal_estimate']=None
    out.append(row)
save('coattails_event_panel_2024',out)
audit={'general_council_candidate_rows':len(council),'general_mayor_candidate_rows':len(mayors),'general_communes':len(population),'duplicate_participation_keys':duplicate_participation_keys,'matched_event_rows':len(out),'near_5pp_events':len([x for x in out if x['margin_top2_pp']<=5]),'conditional_rank_counts_within_5pp':dict(collections.Counter(x['donor_interval_rank_conditional'] for x in out if x['margin_top2_pp']<=5)),'conditional_rank_counts_all':dict(collections.Counter(x['donor_interval_rank_conditional'] for x in out))}
save('outcome_join_audit',audit);print(json.dumps(audit,indent=2));print(json.dumps([{k:v for k,v in x.items() if k in ['commune','winner','runner','winner_votes','runner_votes','margin_top2_pp','registered','general_ballots','coalition_council_votes','coalition_council_votes_per_registered','winner_general_votes','runner_general_votes','winner_public_name_count','runner_public_name_count','winner_donor_conditional_lower','winner_donor_conditional_upper','runner_donor_conditional_lower','runner_donor_conditional_upper','donor_interval_rank_conditional']} for x in out[:4]],indent=2))
