"""Reproduce older Chile nomination, donor-audit and general-outcome aggregates.
Only candidate identities and aggregated donor counts are written. Raw donor IDs/names stay in source files.
"""
import pathlib,json,csv,collections,unicodedata,datetime
import openpyxl
ROOT=pathlib.Path(__file__).parent

def norm(x):
    x=str(x or '')
    if 'Ã' in x:
        try:x=x.encode('cp1252').decode('utf8')
        except (UnicodeDecodeError,UnicodeEncodeError):pass
    return ' '.join(unicodedata.normalize('NFKD',x).encode('ascii','ignore').decode().upper().split())
def save(n,x):
    (ROOT/(n+'.json')).write_text(json.dumps(x,ensure_ascii=False,indent=2))
    if isinstance(x,list) and x:
        with (ROOT/(n+'.csv')).open('w',newline='') as f:
            w=csv.DictWriter(f,fieldnames=list(dict.fromkeys(k for r in x for k in r)));w.writeheader();w.writerows(x)
def dt(x):
    if isinstance(x,datetime.datetime):return x.date()
    if isinstance(x,datetime.date):return x
    for fmt in ['%d/%m/%y','%d/%m/%Y','%d-%m-%Y','%Y-%m-%d','%Y-%m-%d %H:%M:%S']:
        try:return datetime.datetime.strptime(str(x).strip(),fmt).date()
        except ValueError:pass
    return None

def rut(x,d):
    try:
        a=str(int(x));v=11-sum(int(n)*([2,3,4,5,6,7][i%6]) for i,n in enumerate(a[::-1]))%11
        dv='0' if v==11 else 'K' if v==10 else str(v)
        if a=='0' or dv!=str(d).strip().upper():return None
        return a+'-'+dv
    except (ValueError,TypeError):return None

coalitions={2016:{'CHILE VAMOS':['PACTO CHILE VAMOS RN E INDEPENDIENTES','PACTO CHILE VAMOS UDI-INDEPENDIENTES','PACTO CHILE VAMOS PRI-EVOPOLI E INDEPENDIENTES'],'NUEVA MAYORIA':['PACTO NUEVA MAYORIA PARA CHILE','PACTO NUEVA MAYORIA POR CHILE']},2020:{'CHILE VAMOS':['CHILE VAMOS RENOVACION NACIONAL - INDEPENDIENTES','CHILE VAMOS UDI - INDEPENDIENTES','CHILE VAMOS EVOPOLI - INDEPENDIENTES','CHILE VAMOS - PRI E INDEPENDIENTES'],'FRENTE AMPLIO':['FRENTE AMPLIO'],'ECOLOGISTAS E INDEPENDIENTES':['ECOLOGISTAS E INDEPENDIENTES']}}
save('coalition_crosswalk_older',{'mapping':coalitions,'definition':'Fixed national primary coalition party families to general council lists, including sponsored independents. No winner-party dependent membership. Local preprimary pact and sponsorship verification pending.'})
audits=[]
for year in [2016,2020]:
    gy=2016 if year==2016 else 2021
    PW=openpyxl.load_workbook(next((ROOT/f'primary{year}').glob('*.xlsx')),read_only=True,data_only=True)
    primary=[]
    for r in PW['Votación por comuna'].iter_rows(min_row=8,values_only=True):
        if r[6] and isinstance(r[12],(int,float)):
            primary.append(dict(year=year,commune=norm(r[4]),pact=norm(r[6]),party=norm(r[7]),name=norm(' '.join(str(x or '') for x in r[9:12])),votes=int(r[12]),nominated=r[13]=='NOMINADO'))
    save(f'primary_candidate_results_{year}',primary)
    groups=collections.defaultdict(list)
    for x in primary:groups[x['commune'],x['pact']].append(x)
    contests=[]
    for (commune,pact),cs in groups.items():
        cs=sorted(cs,key=lambda c:c['votes'],reverse=True);a,b=cs[:2]
        contests.append(dict(primary_year=year,general_year=gy,commune=commune,pact=pact,winner=a['name'],winner_party=a['party'],winner_votes=a['votes'],runner=b['name'],runner_party=b['party'],runner_votes=b['votes'],candidate_count=len(cs),third_votes=cs[2]['votes'] if len(cs)>2 else None,margin_top2_pp=100*(a['votes']-b['votes'])/(a['votes']+b['votes']),margin_all_pp=100*(a['votes']-b['votes'])/sum(x['votes'] for x in cs),winner_flag_consistent=a['nominated']))
    contests.sort(key=lambda x:x['margin_top2_pp']);save(f'primary_contests_{year}',contests)
    # Finance schemas differ. Retain necessary identity fields only in memory for deduplication.
    FW=openpyxl.load_workbook(ROOT/f'finance{year}.xlsx',read_only=True,data_only=True)
    rs=[r for r in (FW['H1'] if year==2016 else FW['FORMULARIO 87 Y 88']).iter_rows(min_row=4 if year==2016 else 10,values_only=True) if r[0]]
    fg=collections.defaultdict(list)
    for r in rs:
        if year==2016:
            if r[0]!='ALCALDE':continue
            key=(norm(r[1]),norm(r[4]));record=dict(code=str(r[16]),date=dt(r[12]),id=rut(r[9],r[10]),name=norm(r[11]),amount=float(r[19] or 0),self_id=rut(r[2],r[3]))
        else:
            if norm(r[0])!='CANDIDATO' or norm(r[1])!='INGRESOS' or norm(r[2])!='ALCALDE':continue
            key=(norm(r[4]),norm(r[5]));record=dict(code=str(r[14]),date=dt(r[11]),id=rut(r[8],r[9]),name=norm(r[10]),amount=float(r[18] or 0),self_id=None)
        fg[key].append(record)
    features=[]
    cuts=['2016-06-05','2016-06-18'] if year==2016 else ['2020-11-15','2020-11-28']
    for c in primary:
        rr=fg.get((c['commune'],c['name']),[])
        for cut in cuts:
            codes=['125','135'] if year==2016 else ['114','115'];ap= codes[0];pu=codes[1]
            allcash=[r for r in rr if r['code'] in codes and r['amount']>0 and not (r['id'] and r['id']==r['self_id'])]
            eligible=[r for r in allcash if r['date'] and r['date']<=datetime.date.fromisoformat(cut)]
            unknown=[r for r in allcash if not r['date']]
            ids={r['id'] for r in eligible if r['id']};missing=[r for r in eligible if not r['id']]
            pub=[r for r in eligible if r['code']==pu];anon=[r for r in eligible if r['code']==ap]
            f=dict(primary_year=year,commune=c['commune'],name=c['name'],cutoff=cut,finance_matched=bool(rr),all_income_rows=len(rr),donor_receipt_rows=len(eligible) if rr else None,donor_receipt_amount=sum(r['amount'] for r in eligible) if rr else None,public_receipt_rows=len(pub) if rr else None,anonymous_receipt_rows=len(anon) if rr else None,public_distinct_name_labels=len({r['name'] for r in pub if r['name'] and r['name'] not in ['N/A','SIN PUBLICIDAD','APORTE SIN PUBLICIDAD']}) if rr else None,checksum_valid_distinct_donor_ids=len(ids) if rr else None,receipt_rows_missing_valid_id=len(missing) if rr else None,positive_cash_rows_unknown_date=len(unknown) if rr else None,unknown_date_cash_amount=sum(r['amount'] for r in unknown) if rr else None,donor_id_lower=len(ids) if rr else None,donor_id_upper_conditional=len(ids)+len(missing)+len(unknown) if rr else None,strict_observed_id_count_complete=bool(rr) and not missing and not unknown,metric_status='ID-deduplicated cash-donor support among reported rows' if year==2016 else 'Receipt count / public name labels; no verified unique-person count',limitations='Date-filtered ex-post filing, not archived preprimary publication; checksum validity does not prove identity accuracy; coverage/reconciliation and account classification not certified. Upper bound assumes each unidentified row at most one original gift. Zero means no eligible gifts in matched filing, not proof of no support.')
            features.append(f)
    save(f'candidate_donor_features_{year}',features)
    CW=openpyxl.load_workbook(next((ROOT/f'general_council{gy}').glob('*.xlsx')),read_only=True,data_only=True)
    MW=openpyxl.load_workbook(next((ROOT/f'general_mayor{gy}').glob('*.xlsx')),read_only=True,data_only=True)
    council=[];mayor=[];pop=collections.defaultdict(lambda:dict(registered=0,voted=0));seen=set();dup=0
    for r in CW['Votación por comuna'].iter_rows(min_row=8,values_only=True):
        if r[6] and isinstance(r[13],(int,float)):
            council.append(dict(commune=norm(r[4]),pact=norm(r[6]),subpact=norm(r[7]),party=norm(r[8]),name=norm(' '.join(str(x or '') for x in r[10:13])),votes=int(r[13]),elected=r[14]=='CONCEJAL'))
    for r in MW['Votación por comuna'].iter_rows(min_row=8,values_only=True):
        if r[6] and isinstance(r[12],(int,float)):
            mayor.append(dict(commune=norm(r[4]),pact=norm(r[6]),party=norm(r[7]),name=norm(' '.join(str(x or '') for x in r[9:12])),votes=int(r[12]),elected=r[13]=='ALCALDE'))
    for r in CW['Participación'].iter_rows(min_row=8,values_only=True):
        if r[4] and isinstance(r[8],(int,float)):
            key=tuple(r[:8])
            if key in seen:dup+=1;continue
            seen.add(key);pop[norm(r[4])]['registered']+=int(r[8]);pop[norm(r[4])]['voted']+=int(r[9] or 0)
    save(f'general_council_candidates_{gy}',council);save(f'general_mayor_candidates_{gy}',mayor);save(f'general_participation_{gy}',[dict(commune=k,**v) for k,v in pop.items()])
    cg=collections.defaultdict(list);mg=collections.defaultdict(list)
    for c in council:cg[c['commune']].append(c)
    for m in mayor:mg[m['commune']].append(m)
    ff={(f['commune'],f['name'],f['cutoff']):f for f in features}
    events=[]
    for c in contests:
        row=dict(c);cc=cg[c['commune']];coal=[r for r in cc if r['pact'] in coalitions[year][c['pact']]];p=pop[c['commune']]
        row.update(registered=p['registered'],general_ballots=p['voted'],council_valid_votes=sum(r['votes'] for r in cc),coalition_council_votes=sum(r['votes'] for r in coal),coalition_council_seats=sum(r['elected'] for r in coal),coalition_council_votes_per_registered=sum(r['votes'] for r in coal)/p['registered'],council_coalition_mapping_status='fixed_party_family_preliminary_local_pact_audit_pending')
        for role in ['winner','runner']:
            exact=[dict(r,office=o) for o,rrr in [('mayor',mg[c['commune']]),('council',cc)] for r in rrr if r['name']==c[role]]
            matches=exact
            if not exact:
                q=set(c[role].split());matches=[dict(r,office=o) for o,rrr in [('mayor',mg[c['commune']]),('council',cc)] for r in rrr if q<=set(r['name'].split()) or set(r['name'].split())<=q]
            m=matches[0] if len(matches)==1 else None
            row[role+'_general_link']='exact' if m and exact else 'probable_token_subset' if m else 'unmatched_or_ambiguous'
            row[role+'_general_name']=m['name'] if m else None;row[role+'_general_office']=m['office'] if m else None;row[role+'_general_votes']=m['votes'] if m else None
            f=ff[(c['commune'],c[role],cuts[-1])]
            for k in ['donor_receipt_rows','public_receipt_rows','anonymous_receipt_rows','checksum_valid_distinct_donor_ids','receipt_rows_missing_valid_id','positive_cash_rows_unknown_date','donor_id_lower','donor_id_upper_conditional','strict_observed_id_count_complete']:
                row[role+'_'+k]=f[k]
        lo,up=[row['winner_'+k] for k in ['donor_id_lower','donor_id_upper_conditional']];rl,ru=[row['runner_'+k] for k in ['donor_id_lower','donor_id_upper_conditional']]
        row['donor_id_interval_rank_conditional']=('winner_higher' if lo>ru else 'runner_higher' if rl>up else 'ambiguous') if None not in [lo,up,rl,ru] else 'missing'
        row['causal_estimate']=None;events.append(row)
    save(f'coattails_event_panel_{year}',events)
    audits.append(dict(primary_year=year,candidates=len(primary),contests=len(contests),finance_total_rows=len(rs),finance_matched_candidates=sum(f['finance_matched'] for f in features if f['cutoff']==cuts[-1]),strict_observed_id_count_complete_candidates=sum(f['strict_observed_id_count_complete'] for f in features if f['cutoff']==cuts[-1]),general_council_candidates=len(council),general_mayor_candidates=len(mayor),events_joined=len(events),duplicate_participation_keys=dup,near5_count=sum(c['margin_top2_pp']<=5 for c in events),near5_id_ranks=dict(collections.Counter(c['donor_id_interval_rank_conditional'] for c in events if c['margin_top2_pp']<=5)),all_id_ranks=dict(collections.Counter(c['donor_id_interval_rank_conditional'] for c in events)),near5_loser_council=sum(c['runner_general_office']=='council' for c in events if c['margin_top2_pp']<=5)))
save('older_finance_outcome_audit',audits);print(json.dumps(audits,indent=2))
