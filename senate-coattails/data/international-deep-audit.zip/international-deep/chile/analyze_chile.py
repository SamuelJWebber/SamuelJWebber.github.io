import pathlib, json, csv, collections, datetime, unicodedata, re, hashlib
import openpyxl

ROOT=pathlib.Path(__file__).parent
def norm(x):
    return ' '.join(unicodedata.normalize('NFKD',str(x or '')).encode('ascii','ignore').decode().upper().split())
def date(x):
    if isinstance(x,datetime.datetime): return x.date()
    if isinstance(x,datetime.date): return x
    for fmt in ['%d-%m-%Y','%Y-%m-%d','%d/%m/%Y']:
        try:return datetime.datetime.strptime(str(x),fmt).date()
        except ValueError:pass
    return None
def save(name,rows):
    (ROOT/(name+'.json')).write_text(json.dumps(rows,ensure_ascii=False,indent=2))
    if isinstance(rows,list) and rows:
        keys=list(dict.fromkeys(k for r in rows for k in r))
        with (ROOT/(name+'.csv')).open('w',newline='') as f:
            w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(rows)

w=openpyxl.load_workbook(ROOT/'primary2024/2024_06_AlcaldesPrimarias.xlsx',read_only=True,data_only=True)
primary=[]
for r in w['Votación por comuna'].iter_rows(min_row=8,values_only=True):
    if not r[4] or not r[6] or not isinstance(r[12],(int,float)):continue
    primary.append(dict(commune=norm(r[4]),pact=norm(r[6]),party=norm(r[7]),name=norm(' '.join(str(x or '') for x in r[9:12])),votes=int(r[12]),nominated=r[13]=='NOMINADO',source='SERVEL historical 2024_06_AlcaldesPrimarias.xlsx'))
save('primary_candidate_results_2024',primary)
contests=[]
for key,rs in collections.defaultdict(list).items():pass
groups=collections.defaultdict(list)
for r in primary:groups[(r['commune'],r['pact'])].append(r)
for (commune,pact),rs in groups.items():
    rs=sorted(rs,key=lambda x:x['votes'],reverse=True);a,b=rs[:2]
    contests.append(dict(commune=commune,pact=pact,n_candidates=len(rs),winner=a['name'],winner_party=a['party'],winner_votes=a['votes'],runner=b['name'],runner_party=b['party'],runner_votes=b['votes'],third_votes=rs[2]['votes'] if len(rs)>2 else None,valid_votes=sum(r['votes'] for r in rs),margin_top2_pp=100*(a['votes']-b['votes'])/(a['votes']+b['votes']),margin_all_pp=100*(a['votes']-b['votes'])/sum(r['votes'] for r in rs),winner_flag_consistent=a['nominated'],same_party_label=a['party']==b['party'],independent_label_not_same_party=a['party']==b['party']=='INDEPENDIENTE'))
contests.sort(key=lambda x:x['margin_top2_pp']);save('primary_contests_2024',contests)

# Retain source donor identities only in original private workbooks. Derived files contain aggregates.
w=openpyxl.load_workbook(ROOT/'finance2024.xlsx',read_only=True,data_only=True)
fin=[r[:19] for r in w.active.iter_rows(min_row=10,values_only=True) if r[0]]
fg=collections.defaultdict(list)
for r in fin:
    if r[0]=='Candidato' and r[2]=='Alcalde':fg[(norm(r[4]),norm(r[5]))].append(r)
w=openpyxl.load_workbook(ROOT/'contributions2024.xlsx',read_only=True,data_only=True)
trans=[r for r in w.active.iter_rows(min_row=9,values_only=True) if r[0]]
tg=collections.defaultdict(list)
for r in trans:
    if r[4]=='CANDIDATO' and r[5]=='ALCALDE':tg[(norm(r[6]),norm(r[3]))].append(r)

features=[]
for candidate in primary:
    key=(candidate['commune'],candidate['name']);rs=fg.get(key,[]);ts=tg.get(key,[])
    for cut in ['2024-05-26','2024-06-08']:
        cutoff=datetime.date.fromisoformat(cut)
        pub=[r for r in rs if str(r[14])=='115' and date(r[11]) and date(r[11])<=cutoff and float(r[18] or 0)>0]
        anon=[r for r in rs if str(r[14])=='114' and date(r[11]) and date(r[11])<=cutoff and float(r[18] or 0)>0]
        tpub=[r for r in ts if r[0]=='APORTE CON PUBLICIDAD' and r[2]=='PERSONA NATURAL' and date(r[9]) and date(r[9])<=cutoff]
        tanon=[r for r in ts if r[0]=='APORTE MENOR SIN PUBLICIDAD' and r[2]=='PERSONA NATURAL' and date(r[9]) and date(r[9])<=cutoff]
        pnames={norm(r[10]) for r in pub if r[10]};tnames={norm(r[1]) for r in tpub if r[1]}
        features.append(dict(commune=key[0],pact=candidate['pact'],name=key[1],cutoff=cut,finance_matched=bool(rs),transfer_matched=bool(ts),finance_any_rows=len(rs),finance_public_rows=len(pub) if rs else None,finance_public_distinct_name_labels=len(pnames) if rs else None,finance_public_rows_with_id=sum(bool(r[8]) for r in pub) if rs else None,finance_public_amount=sum(float(r[18]) for r in pub) if rs else None,finance_anon_rows=len(anon) if rs else None,finance_anon_amount=sum(float(r[18]) for r in anon) if rs else None,transfer_public_rows=len(tpub) if ts else None,transfer_public_distinct_name_labels=len(tnames) if ts else None,transfer_public_amount=sum(float(r[10]) for r in tpub) if ts else None,transfer_anon_rows=len(tanon) if ts else None,transfer_anon_amount=sum(float(r[10]) for r in tanon) if ts else None,public_name_set_matches=bool(rs and ts) and pnames==tnames,public_amount_matches=bool(rs and ts) and sum(float(r[18]) for r in pub)==sum(float(r[10]) for r in tpub),anon_amount_matches=bool(rs and ts) and sum(float(r[18]) for r in anon)==sum(float(r[10]) for r in tanon),true_unique_people=None,reason='Public finance generally omits donor RUT; distinct normalized full names are labels, not identity-verified individuals. Row-level anonymous receipts require validation.'))
save('candidate_donor_features_2024',features)

# General candidature join checks whether primary losers subsequently stood for council.
w=openpyxl.load_workbook(ROOT/'general_candidates2024.xlsx',read_only=True,data_only=True)
general=[r for r in w.active.iter_rows(min_row=2,values_only=True) if r[1]]
gg=collections.defaultdict(list)
for r in general:gg[(norm(r[2]),norm(' '.join(str(x or '') for x in r[5:8])))].append(r)
joined=[]
for c in contests:
    row=dict(c)
    for role in ['winner','runner']:
        key=(c['commune'],c[role]);match=gg.get(key,[]);method='exact_normalized' if match else 'unmatched'
        if not match:
            candidates=[(k,v) for k,v in gg.items() if k[0]==key[0] and (set(key[1].split())<=set(k[1].split()) or set(k[1].split())<=set(key[1].split()))]
            if len(candidates)==1:match=candidates[0][1];method='unique_token_subset_manual_review'
        row[role+'_general_match']=method
        row[role+'_general_offices']=';'.join(sorted(set(norm(r[1]) for r in match)))
        row[role+'_general_name']=';'.join(sorted(set(norm(' '.join(str(x or '') for x in r[5:8])) for r in match)))
        row[role+'_general_pacts']=';'.join(sorted(set(norm(r[8]) for r in match)))
        for cut in ['2024-05-26','2024-06-08']:
            feature=next(x for x in features if (x['commune'],x['name'],x['cutoff'])==(key[0],key[1],cut))
            for k in ['finance_matched','transfer_matched','finance_public_distinct_name_labels','finance_anon_rows','finance_anon_amount','transfer_public_distinct_name_labels','public_name_set_matches','public_amount_matches','anon_amount_matches']:
                row[role+'_'+cut+'_'+k]=feature[k]
    joined.append(row)
save('primary_contests_joined_2024',joined)
roster=json.loads((ROOT/'accepted_roster_2024.json').read_text())
accepted={(norm(r[0]),norm(r[4])) for r in roster['rows']};actual={(r['commune'],r['name']) for r in primary}
audit={'accepted_candidates':len(accepted),'primary_result_candidates':len(primary),'primary_contests':len(contests),'communes':len(set(x['commune'] for x in primary)),'accepted_missing_from_results':sorted(accepted-actual),'result_not_in_accepted':sorted(actual-accepted),'winner_flags_consistent':sum(r['winner_flag_consistent'] for r in contests),'within_1pp_top2':sum(r['margin_top2_pp']<=1 for r in contests),'within_2pp_top2':sum(r['margin_top2_pp']<=2 for r in contests),'within_5pp_top2':sum(r['margin_top2_pp']<=5 for r in contests),'within_10pp_top2':sum(r['margin_top2_pp']<=10 for r in contests),'finance_actual_records':len(fin),'transfer_actual_records':len(trans),'candidates_finance_exact_matched':sum((r['commune'],r['name']) in fg for r in primary),'candidates_transfers_exact_matched':sum((r['commune'],r['name']) in tg for r in primary),'runner_subsequently_council_exact':sum(r['runner_general_offices']=='CONCEJAL' and r['runner_general_match']=='exact_normalized' for r in joined),'runner_subsequently_council_token_subset':sum(r['runner_general_offices']=='CONCEJAL' and r['runner_general_match']=='unique_token_subset_manual_review' for r in joined),'hashes':{f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in ROOT.glob('*.xlsx')}}
save('audit',audit)
print(json.dumps(audit,indent=2,ensure_ascii=False));print(json.dumps(joined[:8],indent=2,ensure_ascii=False))
