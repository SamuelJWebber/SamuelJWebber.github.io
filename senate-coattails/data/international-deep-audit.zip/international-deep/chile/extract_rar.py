import ctypes,ctypes.util,pathlib,sys
lib=ctypes.CDLL(ctypes.util.find_library('archive'))
lib.archive_read_new.restype=ctypes.c_void_p
for name in ['archive_read_support_format_all','archive_read_support_filter_all','archive_read_free']:
    getattr(lib,name).argtypes=[ctypes.c_void_p]
lib.archive_read_open_filename.argtypes=[ctypes.c_void_p,ctypes.c_char_p,ctypes.c_size_t]
lib.archive_read_next_header.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_void_p)]
lib.archive_entry_pathname.argtypes=[ctypes.c_void_p];lib.archive_entry_pathname.restype=ctypes.c_char_p
lib.archive_read_data.argtypes=[ctypes.c_void_p,ctypes.c_void_p,ctypes.c_size_t];lib.archive_read_data.restype=ctypes.c_ssize_t
lib.archive_error_string.argtypes=[ctypes.c_void_p];lib.archive_error_string.restype=ctypes.c_char_p
def unpack(src,dest):
    src=pathlib.Path(src);dest=pathlib.Path(dest);dest.mkdir(exist_ok=True)
    a=lib.archive_read_new();lib.archive_read_support_format_all(a);lib.archive_read_support_filter_all(a)
    if lib.archive_read_open_filename(a,str(src).encode(),10240)!=0:raise RuntimeError(lib.archive_error_string(a))
    entry=ctypes.c_void_p();buf=ctypes.create_string_buffer(1048576)
    while True:
        rc=lib.archive_read_next_header(a,ctypes.byref(entry))
        if rc==1:break
        if rc<0:raise RuntimeError(lib.archive_error_string(a))
        name=lib.archive_entry_pathname(entry).decode();p=dest/pathlib.Path(name).name
        if name.endswith('/'):continue
        with p.open('wb') as f:
            while True:
                n=lib.archive_read_data(a,buf,len(buf))
                if n==0:break
                if n<0:raise RuntimeError(lib.archive_error_string(a))
                f.write(buf.raw[:n])
        print(str(p),p.stat().st_size,flush=True)
    lib.archive_read_free(a)
if __name__=='__main__':unpack(sys.argv[1],sys.argv[2])
