"""Rebuild manually audited public nomination/outcome fragments.

This is a source-backed feasibility fragment, not a sampling frame or causal estimate.
Only standard-library dependencies are required.
"""
import csv
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
rows = [
    dict(election_year=2021, state_code='12', district_code='059', district_name='Märkisch-Oderland – Barnim II', party='CDU', nomination_date='2020-08-15', nominee='Sabine Buder', finalist_loser='Hans-Georg von der Marwitz', nominee_votes=110, loser_votes=105, total_ballots=218, abstentions=2, invalid=1, decisive_round=1, original_aspirants=2, eligible_voters=230391, voters=177065, party_second_votes=26254, valid_second_votes=174498, nominee_first_votes=40804, valid_first_votes=174209, nominee_final_list_rank=8, loser_in_final_candidate_inventory=False, nominee_baseline_federal_incumbent=False, loser_baseline_federal_incumbent=True, pretreatment_quality_rank=None,
         nomination_source='https://www.cdu-brandenburg.de/news/lokal/734/Dr-Sabine-Buder-im-Wahlkreis-59-nominiert.html', outcome_source='https://www.bundeswahlleiterin.de/bundestagswahlen/2021/ergebnisse/bund-99/land-12/wahlkreis-59.html', list_source='https://bravors.brandenburg.de/fm/76/Amtsblatt%2030S_21.pdf', qualification='Buder already held municipal council and party leadership roles. Federal incumbency is not a validated talent ranking. Final list status is post-treatment and cannot define an unbiased inclusion rule.'),
    dict(election_year=2021, state_code='05', district_code='104', district_name='Mettmann I', party='CDU', nomination_date='2021-04-12', nominee='Klaus Wiener', finalist_loser='Annette Leonhardt', nominee_votes=96, loser_votes=91, total_ballots=None, abstentions=None, invalid=None, decisive_round=2, original_aspirants=4, eligible_voters=203030, voters=159457, party_second_votes=43354, valid_second_votes=158308, nominee_first_votes=47326, valid_first_votes=157896, nominee_final_list_rank=51, loser_in_final_candidate_inventory=False, nominee_baseline_federal_incumbent=False, loser_baseline_federal_incumbent=False, pretreatment_quality_rank=None,
         nomination_source='https://cdu-kreismettmann.de/news/lokal/367/Bundestagswahl-2021-CDU-schickt-Dr-Klaus-Wiener-ins-Rennen.html', outcome_source='https://www.bundeswahlleiterin.de/bundestagswahlen/2021/ergebnisse/bund-99/land-5/wahlkreis-104.html', list_source='https://upload.wikimedia.org/wikipedia/commons/d/da/Wahlsonderheft_Wahlkreiskandidaten_und_Landeslisten_2021.pdf', qualification='Incumbent Michaela Noll retired. Two other original aspirants were Fabian Kippenberg and Lars van der Bijl. Final-round ballots other than the two candidate totals were not reported in the reviewed nomination source.'),
]
for r in rows:
    r['nominee_minus_loser_pair_margin_pp'] = 100 * (r['nominee_votes']-r['loser_votes'])/(r['nominee_votes']+r['loser_votes'])
    r['party_second_votes_per_100_eligible'] = 100*r['party_second_votes']/r['eligible_voters']
    r['party_second_valid_share_pp'] = 100*r['party_second_votes']/r['valid_second_votes']
    r['turnout_pct'] = 100*r['voters']/r['eligible_voters']
    r['is_causal_estimate'] = False
    r['collection_scope'] = 'Purposive public-source feasibility fragment; not all contested nominations'
(ROOT/'public_nomination_rows.json').write_text(json.dumps(rows, indent=2, ensure_ascii=False)+'\n')
with (ROOT/'public_nomination_rows.csv').open('w', newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
print('Wrote two public source-backed nomination/outcome rows; no causal estimate.')
