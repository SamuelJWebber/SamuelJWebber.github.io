****************************************************************************************************************************************************************
*REPLICATION MATERIAL FOR 
*Rudolph, L., L. Arndt (2020) 
*"Coattails and Spillover-Effects: Quasi-Experimental Evidence from Concurrent Executive and Legislative Elections", 
*Electoral Studies, forthcoming.
*
*Version 1.0, written 2020-12-01
****************************************************************************************************************************************************************

****************************************************************************************************************************************************************
*This Do-File replicates the results presented in 
*Appendix Figure A.3 - A.5 and 
*Appendix Table A.3 - A.6 and A.12, A.13
****************************************************************************************************************************************************************


****************************************************************************************************************************************************************
*prepare Stata

version 15
set more off
clear all
capture log close

/* if not already installed: install the followint Stata packages in order to run this do-file: 

estout by Ben Jann in Version st0085_2 (Stata Journal 14-2) via "findit st0085_2".

*/


****************************************************************************************************************************************************************
*set working directory to folder containing the replication data ("master_pretrends.dta") 

cd ""


****************************************************************************************************************************************************************
*prepare for analysis and set macros


****************************************************************************************************************************************************************
*open data set

use master_placebo.dta, clear


********************************************************************************
* Appendix Figure A.3:
* The figure displays average levels and trends for turnout and vote shares (major
* party, SPD, CDU) in federal elections 1998{2013 for three types of municipalities: those holding
* mayoral elections concurrent with council elections (CME) in 2001 and 2006, holding first and
* only CME in 2006, and holding first and only CME in 2011.
********************************************************************************

preserve

keep if level == "btw"

foreach y in to spd cdu major  { 
foreach x in 1 2 3 { 
egen groupmean`y'`x' = mean(`y') if mayoral_group == `x', by(year)
if `x' == 1 	local label = "2001 and 2006" // "2001 first CME" 
else if `x' == 2 local label = "2006" //"2006 first CME"
else if `x' == 3 local label = "2011" //"2011 first CME"
label variable groupmean`y'`x' "`label'"
}
}

label variable year "Federal Election Year" 

foreach x in to major spd cdu { 

if `x' == to 	local label = "Turnout (%)" 
else if `x' == spd local label = "SPD (%)"
else if `x' == cdu local label = "CDU (%)"
else if `x' == major local label = "Major Party (%)"

sort id year

twoway scatter groupmean`x'1 year if mayoral_group == 1, connect(L) ///
|| scatter groupmean`x'2 year if mayoral_group == 2, connect(L) ///
|| scatter groupmean`x'3 year if mayoral_group == 3, connect(L) scheme(s1mono) name(`x', replace) ytitle("`label'") xlabel(1998 2002 2005 2009 2013) legend(row(1) col(3)) ylabel(, angle(0)) yscale(titlegap(1)) legend(stack) 
 
}
graph combine to major spd cdu, scheme(s1mono)

restore


********************************************************************************
* Appendix Table A.3: 
* OLS regression models to test for parallel trends in turnout and vote shares 
* (major party, SPD, CDU) in federal elections 1998-2013.
********************************************************************************

preserve

*prep data

drop if csoe_2011==.
drop if level == "ep"
xtset id year
gen csoe = 0
replace csoe = 1 if year == 2009 & ( id ==  457020  | id ==  461001)
foreach x in 251402	359406	453013	457401	460007	152026	352407	353406	354405	461003 {
replace csoe = 1 if id == `x' & year == 1998
}
foreach x in 153002	154013	254014	351012	360404	453012	457018	459013 {
replace csoe = 1 if id == `x' & year == 2002
}
foreach x in 153010	154404	351401	353403	455007	460001	155007 {
replace csoe = 1 if id == `x' & year == 2005
}
foreach x in 153005	153007	153008	154404	155007	155011	158404	251041	254021	256030	257009	351010	355403	451008	453003	456403	459008	459404	460001	152001	241001	241014	251040	256406	353031	353403	404000	455007 {
replace csoe = 1 if id == `x' & year == 2013
}

label variable year "Federal Election Year" 

*table

eststo m1: reg to i.year##i.mayoral_group i.mayoral_group##csoe
eststo m2: reg major i.year##i.mayoral_group i.mayoral_group##csoe
eststo m3: reg spd i.year##i.mayoral_group i.mayoral_group##csoe
eststo m4: reg cdu i.year##i.mayoral_group i.mayoral_group##csoe

esttab m1 m2 m3 m4 , noabbrev nobaselevels nogaps se b(2) ///
	mtitle("Turnout" "Major Party" "SPD" "CDU") ///
	coeflabels(2.mayoral_group "CME 2006" 3.mayoral_group "CME 2011" ///
	2002.year#2.mayoral_group "2002.year x CME 2006" ///
	2002.year#3.mayoral_group "2002.year x CME 2011" ///
	2005.year#2.mayoral_group "2005.year x CME 2006" ///
	2005.year#3.mayoral_group "2005.year x CME 2011" ///
	2009.year#2.mayoral_group "2009.year x CME 2006" ///
	2009.year#3.mayoral_group "2009.year x CME 2011" ///
	2013.year#2.mayoral_group "2013.year x CME 2006" ///
	2013.year#3.mayoral_group "2013.year x CME 2011" ///
	1.csoe "CSOE" ///
	2.mayoral_group#1.csoe "CSOE x CME 2006" ///
	3.mayoral_group#1.csoe "CSOE x CME 2011" ///
	_cons "Intercept")

restore



********************************************************************************
* Appendix Figure A.4: 
* The figure displays average levels and trends for turnout and vote shares (major
* party, SPD, CDU) in European elections 1999{2014 for three types of municipalities: those
* holding mayoral elections concurrent with council elections (CME) in 2001 and 2006, holding
* first and only CME in 2006, and holding first and only CME in 2011.
********************************************************************************

preserve

keep if level == "ep"

foreach y in to spd cdu major  { 
foreach x in 1 2 3 { 
egen groupmean`y'`x' = mean(`y') if mayoral_group == `x', by(year)
if `x' == 1 	local label = "2001 and 2006" // "2001 first CME" 
else if `x' == 2 local label = "2006" //"2006 first CME"
else if `x' == 3 local label = "2011" //"2011 first CME"
label variable groupmean`y'`x' "`label'"
}
}

label variable year "European Election Year" 

foreach x in to major spd cdu { 

if `x' == to 	local label = "Turnout (%)" 
else if `x' == spd local label = "SPD (%)"
else if `x' == cdu local label = "CDU (%)"
else if `x' == major local label = "Major Party (%)"

sort id year

twoway scatter groupmean`x'1 year if mayoral_group == 1, connect(L) ///
|| scatter groupmean`x'2 year if mayoral_group == 2, connect(L) ///
|| scatter groupmean`x'3 year if mayoral_group == 3, connect(L) scheme(s1mono) name(`x', replace) ytitle("`label'") xlabel(1999 2004 2009 2014) legend(row(1) col(3)) ylabel(, angle(0)) yscale(titlegap(1)) legend(stack) 
 
}
graph combine to major spd cdu, scheme(s1mono)

restore

********************************************************************************
* Appendix Table A.4: 
* OLS regression models to test for parallel trends in turnout and vote shares (major
* party, SPD, CDU) in European elections 1999{2014 while controlling for concurrency of EP
* election with mayoral elections, i.e., concurrent second-order elections (CSOE).
********************************************************************************

preserve

drop if csoe_2011==.
keep if level == "ep"
xtset id year
gen csoe = 0 
replace csoe = bgm if year == 2014
foreach x in 151009	151406	155008	241016	254003	255405	454019	454054	454401	454404	454408	455015	459015	460005	460009	241012	359028 {
replace csoe = 1 if id == `x' & year == 2004
}
foreach x in 153005	156009	158406	359404	361001	459020	152012	154403	352050	452023 {
replace csoe = 1 if id == `x' & year == 1999
}

eststo m1: reg to i.year##i.mayoral_group i.mayoral_group##csoe
eststo m2: reg major i.year##i.mayoral_group i.mayoral_group##csoe
eststo m3: reg spd i.year##i.mayoral_group i.mayoral_group##csoe
eststo m4: reg cdu i.year##i.mayoral_group i.mayoral_group##csoe

esttab m1 m2 m3 m4 , noabbrev nobaselevels nogaps se b(2) ///
	mtitle("Turnout" "Major Party" "SPD" "CDU") ///
	coeflabels(2.mayoral_group "CME 2006" 3.mayoral_group "CME 2011" ///
	2004.year#2.mayoral_group "2004.year x CME 2006" ///
	2004.year#3.mayoral_group "2004.year x CME 2011" ///
	2009.year#2.mayoral_group "2009.year x CME 2006" ///
	2009.year#3.mayoral_group "2009.year x CME 2011" ///
	2014.year#2.mayoral_group "2014.year x CME 2006" ///
	2014.year#3.mayoral_group "2014.year x CME 2011" ///
	1.csoe "CSOE" ///
	2.mayoral_group#1.csoe "CSOE x CME 2006" ///
	3.mayoral_group#1.csoe "CSOE x CME 2011" ///
	_cons "Intercept")
restore


********************************************************************************
* Appendix Figure A.5: 
* The figure displays predicted levels and trends for turnout and vote shares (major
* party, SPD, CDU) in European elections 1999{2014 for three types of municipalities: those
* holding mayoral elections concurrent with council elections (CME) in 2001 and 2006, holding
* first and only CME in 2006, and holding first and only CME in 2011. Predictions are based
* on the models presented in Table A.4. Before generating the predicted values we have set the
* variable CSOE to zero for all municipalities to simulate predicted values if there would have
* been no concurrency of European elections with mayoral elections in some municipalities.
********************************************************************************

preserve

drop if csoe_2011==.
keep if level == "ep"
xtset id year
gen csoe = 0 
replace csoe = bgm if year == 2014
foreach x in 151009	151406	155008	241016	254003	255405	454019	454054	454401	454404	454408	455015	459015	460005	460009	241012	359028 {
replace csoe = 1 if id == `x' & year == 2004
}
foreach x in 153005	156009	158406	359404	361001	459020	152012	154403	352050	452023 {
replace csoe = 1 if id == `x' & year == 1999
}


foreach y in to major spd cdu {

eststo m1: reg `y' i.year##i.mayoral_group i.mayoral_group##csoe
gen tmp = csoe
replace csoe = 0
predict m1pred
replace csoe = tmp

twoway scatter m1pred year if mayoral_group == 1, connect(L) legend(label(1 "2001 and 2006")) ///
|| scatter m1pred year if mayoral_group == 2, connect(L) legend(label(2 "2006")) ///
|| scatter m1pred year if mayoral_group == 3, connect(L) scheme(s1mono) name(`y', replace) ytitle("`label'") xlabel(1999 2004 2009 2014) legend(label(3 "2011") row(1) col(3)) ylabel(, angle(0)) yscale(titlegap(1)) legend(stack) 

drop tmp m1pred

}
graph combine to major spd cdu, scheme(s1mono)

restore


********************************************************************************
* SETUP FOR Appendix Table A.5 and A.6 -- run en bloc
********************************************************************************


preserve

drop if csoe_2011==.
drop if level == "ep"
xtset id year
gen csoe = 0
replace csoe = 1 if year == 2009 & ( id ==  457020  | id ==  461001)
foreach x in 251402	359406	453013	457401	460007	152026	352407	353406	354405	461003 {
replace csoe = 1 if id == `x' & year == 1998
}
foreach x in 153002	154013	254014	351012	360404	453012	457018	459013 {
replace csoe = 1 if id == `x' & year == 2002
}
foreach x in 153010	154404	351401	353403	455007	460001	155007 {
replace csoe = 1 if id == `x' & year == 2005
}
foreach x in 153005	153007	153008	154404	155007	155011	158404	251041	254021	256030	257009	351010	355403	451008	453003	456403	459008	459404	460001	152001	241001	241014	251040	256406	353031	353403	404000	455007 {
replace csoe = 1 if id == `x' & year == 2013
}

*subsequent cme
gen placebo_cme = 0
replace placebo_cme = csoe_2001 if year == 2002
replace placebo_cme = csoe_2006 if year == 2009
replace placebo_cme = csoe_2011 if year == 2013

*preceeding cme
gen placebo_cme2 = 0
replace placebo_cme2 = csoe_2001 if year == 1998
replace placebo_cme2 = csoe_2006 if year == 2005
replace placebo_cme2 = csoe_2011 if year == 2009

*closest cme
gen placebo_cme3 = 0
replace placebo_cme3 = csoe_2001 if year == 2002
replace placebo_cme3 = csoe_2006 if year == 2005
replace placebo_cme3 = csoe_2011 if year == 2009

label variable year "Election Year"
label variable major "SPD and CDU Vote (%)"
label variable placebo_cme "CME with Council Election"
label variable csoe "CME with European/Federal Election"
label variable to "Turnout (\%)"


eststo clear
eststo two: xtreg to placebo_cme2 csoe  i.year, fe cluster(id)
eststo three: xtreg to placebo_cme3 csoe i.year, fe cluster(id)
eststo twob: xtreg major placebo_cme2 csoe i.year, fe cluster(id)
eststo threeb: xtreg major placebo_cme3 csoe i.year, fe cluster(id)

restore

preserve

drop if csoe_2011==.
drop if level == "btw"
xtset id year
gen csoe = 0 
replace csoe = bgm if year == 2014
foreach x in 151009	151406	155008	241016	254003	255405	454019	454054	454401	454404	454408	455015	459015	460005	460009	241012	359028 {
replace csoe = 1 if id == `x' & year == 2004
}
foreach x in 153005	156009	158406	359404	361001	459020	152012	154403	352050	452023 {
replace csoe = 1 if id == `x' & year == 1999
}

gen placebo_cme = 0
replace placebo_cme = csoe_2001 if year == 1999
replace placebo_cme = csoe_2006 if year == 2004
replace placebo_cme = csoe_2011 if year == 2009

label variable year "Election Year"
label variable major "SPD and CDU Vote (%)"
label variable placebo_cme "CME with Council Election"
label variable csoe "CME with European/Federal Election"
label variable to "Turnout (%)"

eststo four: xtreg to placebo_cme csoe i.year, fe cluster(id)
eststo fourb: xtreg major placebo_cme csoe i.year, fe cluster(id)

restore

********************************************************************************
* Appendix Table A.5: 
* Placebo Effect of Mayoral Elections Concurrent to Local Council Elections on
* Federal and European Election Turnout
********************************************************************************


esttab two three four ///
, se(a2) b(a2) replace star(* 0.1 ** 0.05 *** 0.01)  stats(N N_clust r2_w, label(N "Clusters" "Within R^{2}")) ///
order(placebo* csoe* 2002*year* 2004*year*) ///
rename (placebo_cme2 placebo_cme placebo_cme3 placebo_cme) ///
coeflabels(placebo_cme "CME with Council Election" ///
	csoe "CME with European/Federal Election" ///
	2002.year "Election Year == 2002" ///
	2004.year "Election Year == 2004" /// 
	2005.year "Election Year == 2005" /// 
	2009.year "Election Year == 2009" /// 
	2013.year "Election Year == 2013" /// 
	2014.year "Election Year == 2014" ///
	_cons "Constant") /// 
drop() nobaselevels /// 
mtitle("Turnout (\%)" "Turnout (\%)" "Turnout (\%)") ///
mgroups("Federal Elect." "Europ. Elect.", pattern(1 0 1) prefix(\multicolumn{@span}{c}{) suffix(}) span)


********************************************************************************
* Appendix Table A.6: 
* Placebo Effect of Mayoral Elections Concurrent to Local Council Elections on
* Federal and European Election Turnout
********************************************************************************


esttab twob threeb fourb ///
, se(a2) b(a2) replace star(* 0.1 ** 0.05 *** 0.01)  stats(N N_clust r2_w, label(N "Clusters" "Within R^{2}")) ///
order(placebo* csoe* 2002*year* 2004*year*) ///
rename (placebo_cme2 placebo_cme placebo_cme3 placebo_cme) ///	
coeflabels(placebo_cme "CME with Council Election" ///
	csoe "CME with European/Federal Election" ///
	2002.year "Election Year == 2002" ///
	2004.year "Election Year == 2004" /// 
	2005.year "Election Year == 2005" /// 
	2009.year "Election Year == 2009" /// 
	2013.year "Election Year == 2013" /// 
	2014.year "Election Year == 2014" ///
	_cons "Constant") /// 
drop() nobaselevels /// 
numbers  ///
mtitle("SPD and CDU Vote (\%)" "SPD and CDU Vote (\%)" "SPD and CDU Vote (\%)") ///
mgroups("Federal Elect." "Europ. Elect.", pattern(1 0 1) prefix(\multicolumn{@span}{c}{) suffix(}) span)




*______________________________________________________________________________________________________________
****************************************************************************************************************************************************************
* END
*______________________________________________________________________________________________________________
****************************************************************************************************************************************************************

