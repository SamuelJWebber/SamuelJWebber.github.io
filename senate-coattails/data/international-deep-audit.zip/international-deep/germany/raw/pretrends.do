****************************************************************************************************************************************************************
*REPLICATION MATERIAL FOR 
*Rudolph, L., L. Arndt (2020) 
*"Coattails and Spillover-Effects: Quasi-Experimental Evidence from Concurrent Executive and Legislative Elections", 
*Electoral Studies, forthcoming.
*
*Version 1.0, written 2020-12-01
****************************************************************************************************************************************************************

****************************************************************************************************************************************************************
*This Do-File replicates the results presented in 
*Appendix Figure A.2 and 
*Appendix Table A.2
****************************************************************************************************************************************************************


****************************************************************************************************************************************************************
*prepare Stata

version 15
set more off
clear all

/* if not already installed: install the followint Stata packages in order to run this do-file: 

estout by Ben Jann in Version st0085_2 (Stata Journal 14-2) via "findit st0085_2".

*/

****************************************************************************************************************************************************************
*set working directory to folder containing the replication data ("master_pretrends.dta") 

cd ""


****************************************************************************************************************************************************************
*open data set

use master_pretrends.dta, clear

****************************************************************************************************************************************************************
*prepare for analysis and set macros

xtset id year, delta(5)

gen mayoral = date(date, "YMD")

gen first_me = .
replace first_me = 1 if mayoral >= date("1996-09-15", "YMD") & mayoral <= date("1996-09-29", "YMD") 
replace first_me = 2 if mayoral > date("1996-09-29", "YMD") & mayoral < date("2001-09-09", "YMD") 
replace first_me = 3 if mayoral >= date("2001-09-09", "YMD") & mayoral <= date("2001-09-23", "YMD") 
replace first_me = 4 if mayoral > date("2001-09-23", "YMD") & mayoral < date("2006-09-10", "YMD") 
replace first_me = 5 if mayoral >= date("2006-09-10", "YMD") & mayoral <= date("2006-09-24", "YMD") 
replace first_me = 6 if mayoral > date("2006-09-24", "YMD") & mayoral < date("2011-09-11", "YMD") 
replace first_me = 7 if mayoral >= date("2011-09-11", "YMD") 

label define mayoral 1 "1996 CME" 2 "1996-2001 ME" 3 "2001 CME" 4 "2001-2006 ME" 5 "2006 CME" 6 "2006-2011 ME" 7 "2011 CME"
label values first_me mayoral

keep if  first_me <6 // restrict to those with first CME 2001, 2006 or 2011

recode first_me (1 3 = 1 "2001 CME") (2 5 = 2 "2006 CME") (4 = 3 "2011 CME"), gen(mayoral_group)

gen major = cdu + spd
label variable major "Major party vote share"


*______________________________________________________________________________________________________________
****************************************************************************************************************************************************************
*FIGURES IN APPENDIX
*______________________________________________________________________________________________________________
****************************************************************************************************************************************************************

********************************************************************************
*Appendix Figure A.2: 
*average levels and trends for turnout and vote shares (major party, SPD, CDU) in council elections 
*1981, 1986, and 1991 for three types of municipalities:
*those holding mayoral elections concurrent with council elections (CME) in 2001 and 2006,
*holding first and only CME in 2006, and holding first and only CME in 2011.
********************************************************************************


foreach y in to spd cdu major  { 
foreach x in 1 2 3 { 
egen groupmean`y'`x' = mean(`y') if mayoral_group == `x', by(year)
if `x' == 1 	local label = "2001 and 2006" // "2001 first CME" 
else if `x' == 2 local label = "2006" //"2006 first CME"
else if `x' == 3 local label = "2011" //"2011 first CME"
label variable groupmean`y'`x' "`label'"
}
}


label variable year "Council Election Year" 

foreach x in to major spd cdu { 

if `x' == to 	local label = "Turnout (%)" 
else if `x' == spd local label = "SPD (%)"
else if `x' == cdu local label = "CDU (%)"
else if `x' == major local label = "Major Party (%)"

twoway scatter groupmean`x'1 year if mayoral_group == 1 & year < 1996, connect(L) ///
|| scatter groupmean`x'2 year if mayoral_group == 2 & year < 1996, connect(L) ///
|| scatter groupmean`x'3 year if mayoral_group == 3 & year < 1996, connect(L) scheme(s1mono) name(`x', replace) ytitle("`label'") xlabel(1981 1986 1991) legend(row(1) col(3)) ylabel(, angle(0)) yscale(titlegap(1)) legend(stack) 
 
}
graph combine to major spd cdu, scheme(s1mono)


*______________________________________________________________________________________________________________
****************************************************************************************************************************************************************
*TABLES IN APPENDIX
*______________________________________________________________________________________________________________
****************************************************************************************************************************************************************

********************************************************************************
* Appendix Table A.2:
* OLS regression models to test for parallel trends in turnout and vote shares (major
* party, SPD, CDU) in council elections 1981-1991.
********************************************************************************

eststo m1: reg to i.year##i.mayoral_group if year < 1996
eststo m2: reg major i.year##i.mayoral_group if year < 1996
eststo m3: reg spd i.year##i.mayoral_group if year < 1996
eststo m4: reg cdu i.year##i.mayoral_group if year < 1996


esttab m1 m2 m3 m4 ///
, noabbrev nobaselevels nogaps se b(2) ///
	mtitle("Turnout" "Major Party" "SPD" "CDU") ///
	coeflabels(2.mayoral_group "CME 2006" 3.mayoral_group "CME 2011" ///
	1986.year#2.mayoral_group "1986 x CME 2006" ///
	1986.year#3.mayoral_group "1986 x CME 2011" ///
	1991.year#2.mayoral_group "1991 x CME 2006" ///
	1991.year#3.mayoral_group "1991 x CME 2011" ///
	_cons "Intercept")



*______________________________________________________________________________________________________________
****************************************************************************************************************************************************************
* END
*______________________________________________________________________________________________________________
****************************************************************************************************************************************************************


