Replications Materials
======================

for 

Rudolph, Lukas and Arndt Leininger (forthcoming) “Coattails and Spillover-Effects: Quasi-Experimental Evidence from Concurrent Executive and Legislative Elections”. In: Electoral Studies

Files included
--------------

- f_timing_elections.R: produces Figures 1 and A.1 as well as content of Table A.1
- master_1996.dta: used by master_treatment.do
- master_placebo.dta: used by placebo.do, treatment.do
- master_pretrends.dta: used by pretrends.do
- master_timing.csv: used by f_timing_elections.R
- master_treatment.dta: used by treatment.do
- mayoral_timing.csv: used by f_timing_elections.R
- placebo.do: produces Figures A.3, A.4, and A.5 and Tables A.3, A.4, A.5, and A.6
- pretrends.do: produces Figure A.2 and Table A.2
- README.txt: this file
- treatment.do: produces Tables 1, 2, 3, 4, A.7, A.8, A.9, A.10, A.11, A.12, A.13, A.14, A.15 

Instructions
------------

All tables and figures presented in article and online appendix can be reproduced using the following scripts:

- f_timing_elections.R
- placebo.do
- pretrends.do
- treatment.do

These scripts can be run independently of each other to reproduce the desired tables or figures.
