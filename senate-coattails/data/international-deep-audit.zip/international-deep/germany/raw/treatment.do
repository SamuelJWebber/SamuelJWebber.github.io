****************************************************************************************************************************************************************
*REPLICATION MATERIAL FOR 
*Rudolph, L., L. Arndt (2020) 
*"Coattails and Spillover-Effects: Quasi-Experimental Evidence from Concurrent Executive and Legislative Elections", 
*Electoral Studies, forthcoming.
*
*Version 1.0, written 2020-12-01
****************************************************************************************************************************************************************

****************************************************************************************************************************************************************
*prepare Stata

version 15
set more off
clear all

/* if not already installed: install the followint Stata packages in order to run this do-file: 

estout by Ben Jann in Version st0085_2 (Stata Journal 14-2) via "findit st0085_2".

*/
****************************************************************************************************************************************************************

****************************************************************************************************************************************************************
*This Do-File replicates the results presented in 
*Tables 1, 2, 3, 4
*Appendix Tables A.7 - A.15
****************************************************************************************************************************************************************

****************************************************************************************************************************************************************
*Datasets used in this dofile: 
*master_treatment.dta; 
*master_1996.dta; 
*master_placebo.dta
****************************************************************************************************************************************************************


****************************************************************************************************************************************************************
*set working directory to folder containing the replication data ("master_treatment.dta") 

cd ""
****************************************************************************************************************************************************************


****************************************************************************************************************************************************************
*open data set

use master_treatment.dta, clear


****************************************************************************************************************************************************************
*prepare for analysis 

xtset gkz_short year, delta(5)


*______________________________________________________________________________________________________________
****************************************************************************************************************************************************************
*TABLES IN MAIN PAPER
*______________________________________________________________________________________________________________
****************************************************************************************************************************************************************

********************************************************************************
*Table 1
*The effect of concurrent mayoral elections (CMEs) on turnout and the vote shares of CDU and SPD
********************************************************************************

eststo clear
eststo to: xtreg voters_c concurrent_mayoral i.year , fe cluster(gkz)

sum voters_c if concurrent_mayoral==0
estadd scalar Control_mean = r(mean) : to
estadd scalar Control_sd = r(sd) : to


foreach y in "" {
foreach x in spd_c cdu_c   { 
eststo `x': quietly xtreg `x' concurrent_mayoral i.year `y' , fe cluster(gkz)
quietly mean `x' if concurrent_mayoral==0
quietly estat sd
 mat sd=r(sd)
 mat mean=r(mean)
estadd scalar Control_mean = mean[1,1] : `x'
estadd scalar Control_sd = sd[1,1] : `x'
}
}

esttab  ///
, keep(*concurrent_mayoral*  *.year ) label se(a2) b(a2) replace star(* 0.1 ** 0.05 *** 0.01)  stats(N N_clust r2_w Control_mean Control_sd, label(N "Clusters" "Within R^{2}" "Control group mean" "Control group SD")) ///
order(conc* ) ///
drop() nobaselevels /// 
numbers   nonote 



********************************************************************************
*Table 2
* The effect of concurrent mayoral elections on major party vote share and incumbent party vote share
********************************************************************************


eststo clear

eststo major: quietly xtreg major i.concurrent_mayoral i.year, fe cluster(gkz)
quietly mean major if concurrent_mayoral==0
quietly estat sd
 mat sd=r(sd)
 mat mean=r(mean)
estadd scalar Control_mean = mean[1,1] : major
estadd scalar Control_sd = sd[1,1] : major

eststo incumbent_vote2b: quietly xtreg incumbent_vote i.concurrent_mayoral i.year  if incumbent_indep==0, fe cluster(gkz)
quietly mean incumbent_vote if concurrent_mayoral==0 & incumbent_indep==0
quietly estat sd
 mat sd=r(sd)
 mat mean=r(mean)
estadd scalar Control_mean = mean[1,1] : incumbent_vote2b
estadd scalar Control_sd = sd[1,1] : incumbent_vote2b

esttab  ///
, keep(*concurrent_mayoral*  *.year ) label se(a2) b(a2) replace star(* 0.1 ** 0.05 *** 0.01)  stats(N N_clust r2_w Control_mean Control_sd, label(N "Clusters" "Within R^{2}" "Control group mean" "Control group SD")) ///
order(*conc* *incumbentv22* *.year) ///
drop() nobaselevels /// 
numbers   nonote 




********************************************************************************
*Table 3
*The effect of CME on party vote shares and turnout depending on party affiliation of the incumbent mayor
********************************************************************************


eststo clear

* SPD vote share ~ incumbency
eststo : xtreg spd_c cme_spd cme_cdu cme_fdpgreen cme_else i.year , fe cluster(gkz)
quietly mean spd_c if concurrent_mayoral==0 
quietly estat sd
 mat sd=r(sd)
 mat mean=r(mean)
estadd scalar Control_mean = mean[1,1] : est1
estadd scalar Control_sd = sd[1,1] : est1

* CDU vote share ~ incumbency
eststo : xtreg cdu_c cme_spd cme_cdu cme_fdpgreen  cme_else i.year , fe cluster(gkz)
quietly mean cdu_c if concurrent_mayoral==0 
quietly estat sd
 mat sd=r(sd)
 mat mean=r(mean)
estadd scalar Control_mean = mean[1,1] : est2
estadd scalar Control_sd = sd[1,1] : est2

* FDP/Green vote share ~ incumbency
eststo : xtreg fdpgreen_c cme_spd cme_cdu cme_fdpgreen cme_else i.year , fe cluster(gkz)
quietly mean fdpgreen_c if concurrent_mayoral==0 
quietly estat sd
 mat sd=r(sd)
 mat mean=r(mean)
estadd scalar Control_mean = mean[1,1] : est3
estadd scalar Control_sd = sd[1,1] : est3

* Turnout ~ CME party incumbency
eststo : xtreg voters_c cme_spd cme_cdu cme_fdpgreen cme_else i.year , fe cluster(gkz)
quietly mean voters_c if concurrent_mayoral==0 
quietly estat sd
 mat sd=r(sd)
 mat mean=r(mean)
estadd scalar Control_mean = mean[1,1] : est4
estadd scalar Control_sd = sd[1,1] : est4


* Table
esttab ///
, keep(cme* *.year) se(a2) b(a2) ///
varwidth(25) ///
stats(N N_clust r2_w Control_mean Control_sd, label(N "Clusters" "Within R^{2}" "Control group mean" "Control group SD")) ///
coeflabels(concurrent_mayoral "CME" cme_spd "CME (SPD Inc.)" ///
	   cme_cdu "CME (CDU Inc.)" cme_fdpgreen "CME (FDP/Green Inc.)" ///
	   cme_else "CME (Indep./No elected Inc.)") ///
replace star(* 0.1 ** 0.05 *** 0.01) ///
order (concurrent_mayoral cme*) ///
nobaselevels ///
mtitles("SPD vote (\%)" "CDU vote (\%)" "Green/FDP vote (\%)" "Turnout (\%)") ///
numbers nonote




********************************************************************************
*Table 4
* The effect of CMEs on the probability of one party having an absolute majority in the
* municipal council (one-party dominance), the effective number of parliamentary parties in the
* municipal council, and the probability of one party commanding both a majority in the council
* and controlling the mayoralty (executive-legislative alignment).
********************************************************************************


eststo clear

foreach x in any_majority enpp alignment {
eststo `x': quietly xtreg `x' concurrent_mayoral i.year , fe cluster(gkz)
quietly mean `x' if concurrent_mayoral==0
quietly estat sd
 mat sd=r(sd)
 mat mean=r(mean)
estadd scalar Control_mean = mean[1,1] : `x'
estadd scalar Control_sd = sd[1,1] : `x'
}


esttab  ///
, keep(*concurrent_mayoral*  *.year ) label se(a2) b(a2) replace star(* 0.1 ** 0.05 *** 0.01)  stats(N N_clust r2_w Control_mean Control_sd, label(N "Clusters" "Within R^{2}" "Control group mean" "Control group SD")) ///
varwidth(31) ///
order(conc* ) ///
drop() nobaselevels /// 
numbers   nonote 



*______________________________________________________________________________________________________________
****************************************************************************************************************************************************************
*TABLES IN APPENDIX
*______________________________________________________________________________________________________________
****************************************************************************************************************************************************************


********************************************************************************
* Appendix Table A.7: 
* Summary statistics reported for full sample and by treatment group for the dependent and independent variables used in the analyses
********************************************************************************

eststo clear
eststo: estpost tabstat voters_c  incumbent_vote major spd_c cdu_c fdp_c gruene_c non_lt_c  spd_c any_majority enpp alignment concurrent_mayoral cme_spd cme_cdu cme_fdpgreen cme_else , by(concurrent_mayoral)  columns(statistics) statistics(mean sd min max n) 

esttab . /// 
, cells("mean(fmt(a2)) sd min max count") stats(N) label unstack replace


********************************************************************************
* Appendix Table Table A.8: 
* Balance in population, geographical, fiscal and economic indicators of municipalities with and without concurrent mayoral elections (CME)
********************************************************************************

eststo clear
eststo full   : estpost ttest eligible_c region? debt_market log_debt_market tax log_tax tax_earn_real log_tax_earn_real population pop_density alo_sh wa, by(concurrent_mayoral) // 
eststo cme2001: estpost ttest eligible_c region? debt_market log_debt_market tax log_tax tax_earn_real log_tax_earn_real population pop_density alo_sh wa if year == 2001, by(concurrent_mayoral) 
eststo cme2006: estpost ttest eligible_c region? debt_market log_debt_market tax log_tax tax_earn_real log_tax_earn_real population pop_density alo_sh wa if year == 2006, by(concurrent_mayoral) 
eststo cme2011: estpost ttest eligible_c region? debt_market log_debt_market tax log_tax tax_earn_real log_tax_earn_real population pop_density alo_sh wa if year == 2011, by(concurrent_mayoral) 

esttab cme2001 cme2006 cme2011 full ///
, mtitles( 2001 2006 2011 Full) replace label compress star(* 0.10 ** 0.05 *** 0.01) ///
cells("mu_1(fmt(%12.2f) label(C)) mu_2(fmt(%12.2f) label(T)) b(fmt(%12.2f) star label(Diff-In-Means)) N_1(fmt(%12.0f) label(N C)) N_2(fmt(%12.0f) label(N T))" "mean mean se(par fmt(2))" ". . .") 


********************************************************************************
* Appendix Table Table A.9: 
* Balance in incumbent characteristics of municipalities with and without concurrent mayoral elections (CME)
********************************************************************************


eststo clear

eststo full: estpost ttest incumbent_spd incumbent_cdu incumbent_timeinoffice incumbent_female if year > 2001, by(concurrent_mayoral)
eststo inc2006: estpost ttest incumbent_spd incumbent_cdu incumbent_timeinoffice incumbent_female if year == 2006, by(concurrent_mayoral)
eststo inc2011: estpost ttest incumbent_spd incumbent_cdu incumbent_timeinoffice incumbent_female if year == 2011, by(concurrent_mayoral)

esttab inc2006 inc2011 full ///
, mtitles( 2006 2011 Full) replace label compress star(* 0.10 ** 0.05 *** 0.01) ///
cells("mu_1(fmt(%12.2f) label(C)) mu_2(fmt(%12.2f) label(T)) b(fmt(%12.2f) star label(Diff-In-Means)) N_1(fmt(%12.0f) label(N C)) N_2(fmt(%12.0f) label(N T))" "mean mean se(par fmt(2))" ". . .")


********************************************************************************
* Appendix Table A.10: 
* Balance Tests between (first-time) CME and non-CME municipalities in 1996, 2001, 2006 and 2011. The third column in 
* each panel gives the differences in means and p-values for t-tests in parentheses. For each election we compare municipalities which hold
* CME for the first time with municipalities which still have not seen any CME.
********************************************************************************

preserve 

append using master_1996.dta, force

gen ags_district = substr(municipality,2,2)
drop ags_region
gen ags_region = substr(municipality,1,1)
destring ags_district ags_region, replace
drop region*
tab ags_region, gen(region)

* 1996: 1996 CME vs 1996-non-CME
eststo clear
eststo cme1996: estpost ttest population eligible_c region? ///
	if year == 1996 ///
	, by(concurrent_mayoral)



* 2001: 2001 first-time CME vs. still non-CME
gen concurrent_mayoral_2001 = 0 if 	year == 2001 & ///
									(cme_sequence_1996 == "0 0 0 0" | ///
									cme_sequence_1996 == "0 0 0 1" | ///
									cme_sequence_1996 == "0 0 1 0" | ///
									cme_sequence_1996 == "0 0 1 1")
replace concurrent_mayoral_2001 = 1 if	year == 2001 & ///
										(cme_sequence_1996 ==  "0 1 0 0" | ///
										cme_sequence_1996 == "0 1 0 1" | ///
										cme_sequence_1996 == "0 1 1 0" | ///
										cme_sequence_1996 == "0 1 1 1")

eststo cme2001: estpost ttest population eligible_c region? ///
	debt_market log_debt_market tax log_tax tax_earn_real log_tax_earn_real ///
	if year == 2001 ///
	, by(concurrent_mayoral_2001)
							
* 2006: 2006 first-time CME vs. still non-CME
cap gen concurrent_mayoral_2006 = 0 if 	year == 2006 & ///
									(cme_sequence_1996 == "0 0 0 0" | ///
									cme_sequence_1996 == "0 0 0 1")

replace concurrent_mayoral_2006 = 1 if 	year == 2006 & ///
										(cme_sequence_1996 == "0 0 1 0" | ///
										cme_sequence_1996 == "0 0 1 1")

eststo cme2006: estpost ttest population eligible_c region? ///
	debt_market log_debt_market tax log_tax tax_earn_real log_tax_earn_real ///
	incumbent_spd incumbent_cdu incumbent_timeinoffice incumbent_female ///
	if year == 2006 ///
	, by(concurrent_mayoral_2006)

* 2011: 1011 first-time CME vs. still non-CME
cap gen concurrent_mayoral_2011 = 0 if year == 2011 & cme_sequence_1996 == "0 0 0 0"

replace concurrent_mayoral_2011 = 1 if year == 2011 & cme_sequence_1996 == "0 0 0 1"

eststo cme2011: estpost ttest population eligible_c region? ///
	debt_market log_debt_market tax log_tax tax_earn_real log_tax_earn_real ///
	incumbent_spd incumbent_cdu incumbent_timeinoffice incumbent_female ///
	if year == 2011 ///
	, by(concurrent_mayoral_2011)

*
restore
	
* Table
esttab cme1996 cme2001 cme2006 cme2011 ///
, mtitles("CME 1996" "CME 2001" "CME 2006" "CME 2011") replace label compress star(* 0.10 ** 0.05 *** 0.01) ///
cells("mu_1(fmt(%12.2f) label(C)) mu_2(fmt(%12.2f) label(T)) b(fmt(%12.2f) star label(Diff-In-Means)) N_1(fmt(%12.0f) label(N C)) N_2(fmt(%12.0f) label(N T))" "mean mean se(par fmt(2))" ". . .")





********************************************************************************
* Appendix Table A.11: 
* Balance in population, geographical, fiscal and economic indicators of municipalities with concurrent mayoral elections (CME)
* and CDU or SPD incumbents.
********************************************************************************

eststo clear

preserve
keep if incumbent_spd==1 | incumbent_cdu==1

eststo full   : estpost ttest eligible_c region? debt_market log_debt_market tax log_tax tax_earn_real log_tax_earn_real population pop_density alo_sh wa if concurrent_mayoral==1, by(incumbent_spd) 
eststo spdcdu2001: estpost ttest eligible_c region? debt_market log_debt_market tax log_tax tax_earn_real log_tax_earn_real population pop_density alo_sh wa if year == 2001 & concurrent_mayoral==1, by(incumbent_spd) 
eststo spdcdu2006: estpost ttest eligible_c region? debt_market log_debt_market tax log_tax tax_earn_real log_tax_earn_real population pop_density alo_sh wa if year == 2006 & concurrent_mayoral==1, by(incumbent_spd) 
eststo spdcdu2011: estpost ttest eligible_c region? debt_market log_debt_market tax log_tax tax_earn_real log_tax_earn_real population pop_density alo_sh wa if year == 2011 & concurrent_mayoral==1, by(incumbent_spd) 

restore

esttab spdcdu2001 spdcdu2006 spdcdu2011 full ///
, mtitles( 2001 2006 2011 Full) replace label compress star(* 0.10 ** 0.05 *** 0.01) ///
cells("mu_1(fmt(%12.2f) label(C)) mu_2(fmt(%12.2f) label(T)) b(fmt(%12.2f) star label(Diff-In-Means)) N_1(fmt(%12.0f) label(N C)) N_2(fmt(%12.0f) label(N T))" "mean mean se(par fmt(2))" ". . .") 

********************************************************************************
* SETUP FOR Appendix Table A.12 and A.13: 
* SPD strongholds and incumbents
********************************************************************************

preserve

rename gkz id
merge 1:n id year using master_placebo.dta, gen(_merge_strongholds)


keep if level != "ep"

sort id year

gen spd_btw = .
replace spd_btw = spd[_n-1] if level == ""
gen cdu_btw = .
replace cdu_btw = cdu[_n-1] if level == ""

gen spd_stronghold = .
replace spd_stronghold = spd_btw >= 40 & spd_btw > cdu_btw if level != "btw"
gen cdu_stronghold = .
replace cdu_stronghold = cdu_btw >= 40 & cdu_btw > spd_btw if level != "btw"


********************************************************************************
* Appendix Table A.12: 
* SPD strongholds and incumbents
********************************************************************************

tab spd_stronghold incumbent_spd, V exp

// the table was then compiled manually based on these results

********************************************************************************
* Appendix Table A.13: 
* CDU strongholds and incumbents
********************************************************************************

tab cdu_stronghold incumbent_cdu, V exp

// the table was then compiled manually based on these results

restore


********************************************************************************
* Appendix Table A.14: 
* Average turnout effect and year-by-year turnout effect of concurrent mayoral elections
********************************************************************************

global time = "i.year##i.ags_region i.year##i.muncipality_type3"
global controls = "ue wa   log_tax  ln_pop density" 


eststo clear

eststo to1: xtreg voters_c concurrent_mayoral i.year , fe cluster(gkz)
eststo to2: xtreg voters_c concurrent_mayoral i.year $time $controls, fe cluster(gkz)
eststo to3: xtreg voters_c csoe?? i.year , fe cluster(gkz)
eststo to4: xtreg voters_c csoe?? i.year $time $controls, fe cluster(gkz)

sum voters_c if concurrent_mayoral==0
estadd scalar control_mean = r(mean) : to1 to2 to3 to4
estadd scalar control_sd = r(sd) : to1 to2 to3 to4

esttab to1 to2 to3 to4 ///
, keep(*concurrent_mayoral* *csoe* *.year ) indicate(Controls = "ue") label se(a2) b(a2) replace star(* 0.1 ** 0.05 *** 0.01)  stats(N N_clust r2_w control_mean control_sd, label(N "Clusters" "Within R^{2}" "Control group mean" "Control group SD")) ///
order(*concurrent_mayoral* *csoe*) /// 
drop() nobaselevels /// 
numbers  

********************************************************************************
* Appendix Table A.15: 
* Vote share effect of concurrent mayoral elections
********************************************************************************

eststo clear

foreach x in spd_c cdu_c fdp_c gruene_c non_lt_c {
eststo `x': quietly xtreg `x' concurrent_mayoral i.year , fe cluster(gkz)
quietly mean `x' if concurrent_mayoral==0
quietly estat sd
 mat sd=r(sd)
 mat mean=r(mean)
estadd scalar Control_mean = mean[1,1] : `x'
estadd scalar Control_sd = sd[1,1] : `x'
}


esttab  ///
, keep(*concurrent_mayoral*  *.year ) label se(a2) b(a2) replace star(* 0.1 ** 0.05 *** 0.01)  stats(N N_clust r2_w Control_mean Control_sd, label(N "Clusters" "Within R^{2}" "Control group mean" "Control group SD")) ///
order(conc* ) ///
drop() nobaselevels /// 
numbers   nonote


*______________________________________________________________________________________________________________
****************************************************************************************************************************************************************
* END
*______________________________________________________________________________________________________________
****************************************************************************************************************************************************************

