##############################################
#REPLICATION MATERIAL FOR 
#Rudolph, L., L. Arndt (2020) 
#"Coattails and Spillover-Effects: Quasi-Experimental Evidence from Concurrent Executive and Legislative Elections", 
#Electoral Studies, forthcoming.
#
#Version 1.0, written 2020-12-01
##############################################
  
##############################################
#This script replicates the results presented in 
#Figure 1 and 
#Figure A.1
#Table A.1
##############################################
  
install.packages('ggplot2') 
install.packages('dplyr') 
install.packages('lubridate') 
install.packages('stringr') 
install.packages('gridExtra') 
install.packages('ggpmisc') 

library(ggplot2)
library(dplyr)
library(lubridate)
library(stringr)
library(gridExtra)
library(ggpmisc)

# rm(list = ls())

##############################################
#set workind directory to folder containing master_timing.csv and mmaster_timing.csv

setwd('')

##############################################
#import data and prep analysis

d <- read.csv('master_timing.csv', stringsAsFactors = F) %>% as_tibble()
k <- read.csv('mayoral_timing.csv', stringsAsFactors = F) %>% as_tibble()


# Join council and mayoral election data ---------------------------------------

ce <- ymd(unique(d$date_c))

d$date_c <- ymd(d$date_c)  # date of council election

# relevant municipalities
gemeindekennziffern <- d$gkz[which(d$year >= 2001)]

# identify distinct groups of concurrency
d <-
d %>% filter(year >= 2001) %>%
  arrange(gkz, year) %>% group_by(gkz) %>%
  mutate(cme = paste(concurrent_mayoral, collapse = ' ')) %>%
  select(gkz, cme) %>% distinct(gkz, .keep_all = T) %>%
  mutate(cme = ordered(cme, levels = c('0 0 0', '1 0 0', '0 1 0', '0 0 1',
                                       '1 0 1', '1 1 0', '0 1 1', '1 1 1')))

# reduce to needed variables (gkz and cme)
# d <- d %>% select(gkz, cme) %>% distinct(gkz, .keep_all = T)

k$gkz <- as.integer(k$gkz)
k$wahltag <- ymd(k$wahltag)
k <- inner_join(k, d, by = 'gkz')

years <- ymd(c('1997-01-01', '1999-01-01', '2001-01-01',
               '2003-01-01', '2005-01-01',
               '2007-01-01', '2009-01-01',
               '2011-01-01', '2013-01-01', '2015-01-01', '2017-01-01'))

##############################################
# Obtain information for Table A.1 in appendix ---------------------------------

# number of municipalities per group
d %>% group_by(cme) %>%
    summarize(n = n()) %>%
    arrange(desc(n))

# number of cme per year (2001, 2006, 2011)
d <-
d %>%
    mutate(cme_in_2001 = substr(cme, 1, 1) == 1,
           cme_in_2006 = substr(cme, 3, 3) == 1,
           cme_in_2011 = substr(cme, 5, 5) == 1)

sum(d$cme_in_2001)
sum(d$cme_in_2006)
sum(d$cme_in_2011)

# Table was then assembled manually based on these numbers


##############################################
# Prepare data for plotting ----------------------------------------------------

get_group_number = function(){
  i = 0
  function(){
    i <<- i+1
    i
  }
}
group_number <- get_group_number()
dfig <- k %>% group_by(cme) %>% mutate(cme_n = n())

levels <- dfig %>% distinct(cme, cme_n) %>% arrange(cme_n) %>% select(cme) %>%
    t %>% as.character()

dfig <-
    dfig %>% ungroup() %>%
    mutate(cme = ordered(cme, levels = levels)) %>%
    group_by(cme, gkz) %>% arrange(cme, gkz) %>%
  mutate(id = group_number()) %>%
  ungroup() %>%
  mutate(#id = -1 * id + max(id) + 1,
          size = ifelse(cme == '0 0 0', 'large', 'small'))

tmp <- dfig %>% group_by(cme) %>%
    filter(id == max(id)) %>%
    select(gkz, cme, id) %>%
    distinct() %>%
  ungroup() %>%
  mutate(lbl = c('2001', 'always', '2006 and 2011', '2001 and 2011',
                   '\u25cb never', '\u25a0 2011', '\u25a1 2006', '\u25c6 2001 and 2006'))

##############################################
## Figure 1 for manuscript -------------------------------------------------------
##############################################

dfig %>% filter(cme %in% c('1 1 0', '0 1 0', '0 0 1', '0 0 0')) %>%
    ggplot(., aes(x = wahltag, y = id, shape = cme, size = size)) +
    geom_vline(xintercept = as.integer(ce), linetype = 2) +
    geom_point(fill = 'black') +
    ylab('Municipalities holding CME in') + xlab('Date of Mayoral Election') +
    scale_y_continuous(breaks = tmp$id, labels = tmp$lbl,
                       expand = c(0, 0)) +
    scale_x_date(labels = year(years[-c(length(years)-1, length(years))]),
                 limits = c(min(k$wahltag) - days(100),
                            max(k$wahltag) + days(100)),
                 breaks = years[-c(length(years)-1, length(years))],
                 expand = c(0, 0)) +
    scale_shape_manual(values = c('0 0 0' = 1,'1 0 0' = 24, '0 1 0' = 0, '0 0 1' = 15,
                                  '1 0 1' = 6, '1 1 0' = 23, '0 1 1' = 25, '1 1 1' = 16),
                       name = 'Concurrency',
                       guide = guide_legend(reverse = TRUE)) +
    scale_size_manual(values = c('large' = 3, 'small' = 2), guide = 'none') +
    theme_bw(base_size = 14) +
    theme(panel.grid.minor = element_blank(),
          axis.title = element_text(size = 12),
          panel.grid.major.x = element_blank(),
          axis.text.y = element_text(angle = 90),
          axis.ticks.y = element_blank(),
          legend.position = 'none')

##############################################
## Figure A.1 for appendix ---------------------------------------------------------
##############################################

# Legend
dlegend <-
  dfig %>% distinct(cme, cme_n) %>%
  arrange(desc(cme_n)) %>%
  mutate(`2001` = str_sub(cme, 1, 1),
         `2006` = str_sub(cme, 3, 3),
         `2011` = str_sub(cme, 5, 5)) %>%
  mutate(`2001` = ifelse(`2001` == 1, '\u2713', '\u2717'),
         `2006` = ifelse(`2006` == 1, '\u2713', '\u2717'),
         `2011` = ifelse(`2011` == 1, '\u2713', '\u2717'),
         labels = c('\u25c6', '\u25a1', '\u25a0', '\u25cb', '\u25bd', '\u25bc',
                    '\u25b2', '\u25cf')) %>%
  as.data.frame()
rownames(dlegend) <- dlegend$labels
dlegend

# Plot
f_mun_timeline <-
    ggplot(dfig, aes(x = wahltag, y = id, shape = cme, size = size)) +
    geom_vline(xintercept = as.integer(ce), linetype = 2) +
    geom_point(fill = 'black') +
    ylab('Municipalities') + xlab('Date of Mayoral Election') +
    scale_y_continuous(breaks = tmp$id, labels = NULL,
                       expand = c(0, 0)) +
    scale_x_date(labels = year(years[-c(length(years)-1, length(years))]),
                 limits = c(min(k$wahltag) - days(100),
                            max(k$wahltag) + days(100)),
                 breaks = years[-c(length(years)-1, length(years))],
                 expand = c(0, 0)) +
    scale_shape_manual(values = c('0 0 0' = 1,'1 0 0' = 24, '0 1 0' = 0, '0 0 1' = 15,
                                  '1 0 1' = 6, '1 1 0' = 23, '0 1 1' = 25, '1 1 1' = 16),
                       name = 'Concurrency',
                       guide = guide_legend(reverse = TRUE)) +
    scale_size_manual(values = c('large' = 3, 'small' = 2), guide = 'none') +
    theme_bw(base_size = 14) +
    theme(panel.grid.minor = element_blank(), panel.grid.major.x = element_blank(),
          axis.title = element_text(size = 12),
          axis.ticks.y = element_blank(),
          legend.position = 'none')


# Legend
theme <- ttheme_minimal()

tb <- dlegend %>%
    select(`2001`:`2011`)
dftb <- tibble(x = 1, y = 1, tb = list(tb))

f_legend <-
    ggplot() +
    xlim(.5, 1.5) + ylim(.5, 1.5) +
    geom_table(data = dftb, aes(x = x, y = y, label = tb),
               table.theme = ttheme_gtminimal(), table.rownames = TRUE) +
    annotate('text', x = 1.08, y = 1.13, label = 'Concurrency in') +
    theme_minimal() +
    theme(panel.grid = element_blank(), axis.title = element_blank(),
          axis.text = element_blank())

# Full plot
grid.arrange(f_mun_timeline, f_legend, nrow = 1, widths = c(3,1))


##############################################
# END
##############################################
