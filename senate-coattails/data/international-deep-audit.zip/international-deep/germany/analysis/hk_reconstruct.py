"""Exploratory reconstruction of general-election incumbency spillover RD.
NOT an exact reproduction of Hainmueller/Kern's unavailable microdata.
Boundary gate: paper's retained election pairs, plus same state, district number,
and normalized district name. A name/number match is NOT proof of unchanged
boundaries. Therefore outputs are provisional, not independently validated causal
estimates. Classical fixed-bandwidth local-linear estimates, not rdrobust CIs.
"""
import csv,json,re,unicodedata
from pathlib import Path
import pandas as pd,numpy as np
from scipy import stats
R=Path(__file__).resolve().parents[1]; out=R/'analysis'
pairs={1961:1957,1969:1965,1972:1969,1983:1980,1987:1983,1990:1987,1994:1990,1998:1994}
states=['SH','HH','NI','HB','NW','HE','RP','BW','BY','SL','BE','BB','MV','SN','ST','TH']
def norm(s):
 s=s.upper().replace('Ä','AE').replace('Ö','OE').replace('Ü','UE').replace('ß','SS')
 return re.sub('[^A-Z0-9]','',s)
def parse(year):
 text=(R/f'raw/btw_kerg/btw{year}_kerg.csv').read_text(encoding='cp1252')
 a=list(csv.reader([s for s in text.splitlines() if s and not s.startswith('#')],delimiter=';'))
 h1,h2=a[:2]; res=[]
 for row in a[2:]:
  if not row or not row[0].isdigit() or not 1<=int(row[0])<=500:continue
  state=row[2]
  if state.isdigit():state=states[int(state)-901]
  if state not in states[:10]:continue
  z=dict(year=year,district=int(row[0]),name=row[1],state=state,normalized_name=norm(row[1]),eligible=int(row[3]),voters=int(row[4]),valid_first=int(row[7]),valid_second=int(row[8]))
  first={};second={}
  for j in range(9,min(len(row),len(h1),len(h2))):
   if not row[j].strip():continue
   party=norm(h1[j]);typ=h2[j];v=int(row[j])
   if typ=='Erststimmen':first[party]=first.get(party,0)+v
   if typ=='Zweitstimmen':second[party]=second.get(party,0)+v
  first['UNION']=first.get('CDU',0)+first.get('CSU',0);second['UNION']=second.get('CDU',0)+second.get('CSU',0)
  for party in ['SPD','UNION']:
   others={k:v for k,v in first.items() if k not in ([party,'CDU','CSU'] if party=='UNION' else [party,'UNION'])}
   z[party+'_first']=first.get(party,0);z[party+'_second']=second.get(party,0);z[party+'_maxother']=max(others.values())
  res.append(z)
 return pd.DataFrame(res)
frames={t:parse(t) for t in sorted(set(pairs)|set(pairs.values()))}
panel=[];aud=[]
for later,earlier in pairs.items():
 a,b=frames[earlier],frames[later]
 merged=a.merge(b,on=['state','district'],suffixes=('_prior','_next'))
 merged['name_match']=merged.normalized_name_prior==merged.normalized_name_next
 aud.append(dict(prior_year=earlier,outcome_year=later,prior_west_districts=len(a),next_west_districts=len(b),number_state_matches=len(merged),also_name_matches=int(merged.name_match.sum()),boundary_verified=False))
 merged.to_csv(out/f'hk_pair_audit_{earlier}_{later}.csv',index=False)
 for _,r in merged[merged.name_match].iterrows():
  for party in ['SPD','UNION']:
   m=100*(r[party+'_first_prior']-r[party+'_maxother_prior'])/r.valid_first_prior
   panel.append(dict(assignment_year=earlier,outcome_year=later,district=r.district,state=r.state,name=r.name_next,cluster=r.state+'_'+r.normalized_name_next,party=party,margin_pp=m,treatment=int(m>0),party_share_next=100*r[party+'_second_next']/r.valid_second_next,party_share_prior=100*r[party+'_second_prior']/r.valid_second_prior,party_votes_per_100_prior_eligible=100*r[party+'_second_next']/r.eligible_prior,turnout_prior=100*r.voters_prior/r.eligible_prior,eligible_prior=r.eligible_prior,eligible_next=r.eligible_next))
pd.DataFrame(aud).to_csv(out/'hk_boundary_audit.csv',index=False)
p=pd.DataFrame(panel);p.to_csv(out/'hk_reconstructed_panel.csv',index=False)
results=[]
def fit(party,y,h,degree=1,yearfe=True,exclude_1994=False):
 d=p[(p.party==party)&(p.margin_pp!=0)].copy()
 if exclude_1994:d=d[d.outcome_year!=1994]
 if h:d=d[d.margin_pp.abs()<h]
 x=d.margin_pp.to_numpy();D=d.treatment.to_numpy();Y=d[y].to_numpy();n=len(d)
 w=np.ones(n) if h is None else 1-np.abs(x)/h
 cols=[np.ones(n),D]
 for k in range(1,degree+1):cols.extend([x**k,D*x**k])
 if yearfe:
  for t in sorted(d.outcome_year.unique())[1:]:cols.append((d.outcome_year==t).astype(float).to_numpy())
 X=np.column_stack(cols);A=X*np.sqrt(w)[:,None];B=Y*np.sqrt(w)
 beta=np.linalg.lstsq(A,B,rcond=None)[0];e=Y-X@beta;bread=np.linalg.inv(A.T@A)
 gu,gi=np.unique(d.cluster,return_inverse=True);G=len(gu);rank=np.linalg.matrix_rank(X)
 sums=np.zeros((G,rank));np.add.at(sums,gi,X*(w*e)[:,None]);V=bread@(sums.T@sums)@bread*(G/(G-1))*(n-1)/(n-rank)
 se=np.sqrt(V[1,1]);qt=stats.t.ppf(.975,G-1)
 z=dict(party=party,outcome=y,bandwidth_pp=h,degree=degree,year_fe=yearfe,exclude_1994=exclude_1994,n=n,n_below=int((D==0).sum()),n_above=int((D==1).sum()),clusters=G,estimate_pp=float(beta[1]),se=float(se),ci95_low=float(beta[1]-qt*se),ci95_high=float(beta[1]+qt*se),p=float(2*stats.t.sf(abs(beta[1]/se),G-1)),status='exploratory; boundary verification incomplete; no robust bias correction')
 results.append(z)
for party in ['SPD','UNION']:
 for h in [2.5,5,10,15]:
  for y in ['party_share_next','party_votes_per_100_prior_eligible','turnout_prior','party_share_prior']:
   fit(party,y,h)
  fit(party,'party_share_next',h,yearfe=False)
 fit(party,'party_share_next',None,degree=3,yearfe=False)
 fit(party,'party_share_next',None,degree=3,yearfe=True)
 for h in [5,10]:fit(party,'party_share_next',h,exclude_1994=True)
(out/'hk_reconstructed_results.json').write_text(json.dumps(results,indent=2)+'\n');pd.DataFrame(results).to_csv(out/'hk_reconstructed_results.csv',index=False)
print(pd.DataFrame(aud).to_string(index=False))
print(pd.DataFrame(results).query('outcome == "party_share_next"').to_string(index=False))
