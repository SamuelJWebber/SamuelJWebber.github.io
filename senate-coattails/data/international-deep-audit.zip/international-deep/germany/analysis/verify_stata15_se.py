"""Numerical external check against Stata15 xtreg manual Example3, p16.
Reference: https://www.stata.com/manuals15/xtxtreg.pdf
Data: https://www.stata-press.com/data/r15/nlswork.dta
"""
from pathlib import Path
import numpy as np,pandas as pd,json
from scipy import linalg
R=Path(__file__).resolve().parents[1]
d=pd.read_stata(R/'raw/nlswork_stata.dta',convert_categoricals=False)
d=d[['ln_wage','idcode','grade','age','ttl_exp','tenure','race','not_smsa','south']].dropna().astype(float)
x=pd.DataFrame({'age':d.age,'age2':d.age**2,'ttl_exp':d.ttl_exp,'ttl_exp2':d.ttl_exp**2,'tenure':d.tenure,'tenure2':d.tenure**2,'not_smsa':d.not_smsa,'south':d.south})
X=(x-x.groupby(d.idcode).transform('mean')).to_numpy();Y=(d.ln_wage-d.groupby('idcode').ln_wage.transform('mean')).to_numpy()
b=np.linalg.lstsq(X,Y,rcond=None)[0];e=Y-X@b;bread=np.linalg.inv(X.T@X)
gu,gi=np.unique(d.idcode,return_inverse=True);G=len(gu);n=len(d);k=X.shape[1]
s=np.zeros((G,k));np.add.at(s,gi,X*e[:,None]);base=bread@(s.T@s)@bread
published=np.array([.0052407,.0000845,.004069,.0001763,.0024683,.0001696,.0137629,.0163366])
rows=[]
for add_const in [False,True]:
 se=np.sqrt(np.diag(base)*(G/(G-1))*(n-1)/(n-k-int(add_const)))
 for name,p,v in zip(x.columns,published,se):rows.append(dict(term=name,counts_constant=add_const,se=float(v),published_se=float(p),matches_7_decimal_rounding=bool(np.round(v,7)==p)))
print('N',n,'G',G,'Kslopes',k)
print(pd.DataFrame(rows).to_string(index=False))
(R/'analysis/stata15_se_validation.json').write_text(json.dumps(dict(reference='Stata15 xtreg Example3 p16',n=n,clusters=G,rank_slopes=k,comparisons=rows),indent=2)+'\n')
assert n==28091 and G==4697
assert all(r['matches_7_decimal_rounding'] for r in rows if r['counts_constant'])
