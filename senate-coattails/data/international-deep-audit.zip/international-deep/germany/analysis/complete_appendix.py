"""Complete finite replication checklist: A1/A7/A12/A13 and all six figures.
Figure data/model definitions follow source code; layout is a fresh rendering.
No new causal estimator is introduced.
"""
from pathlib import Path
import json
import numpy as np,pandas as pd
from scipy import stats
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
R=Path(__file__).resolve().parents[1];O=R/'analysis';F=O/'figures';F.mkdir(exist_ok=True)
d=pd.read_stata(R/'raw/master_treatment.dta',convert_categoricals=False)
p=pd.read_stata(R/'raw/master_placebo.dta',convert_categoricals=False)
checks=[]
def check(name,condition,detail):
 checks.append({'check':name,'passed':bool(condition),'detail':detail});assert condition,name
# A12/A13 mimic source outer merge, retain federal/council rows, preceding federal row.
q=d.rename(columns={'gkz':'id'}).merge(p,on=['id','year'],how='outer',suffixes=('','_using'))
q=q[q.level.ne('ep')].sort_values(['id','year'])
for party in ['spd','cdu']:q['prior_'+party]=q.groupby('id')[party].shift()
q['prior_year']=q.groupby('id').year.shift();q=q[q.level.isna()].copy()
check('Stronghold source prior elections',set(q.prior_year.dropna())=={1998,2005,2009},sorted(q.prior_year.dropna().unique().tolist()))
summary=[];cells=[]
for party,table,expected in [('spd','A12',[[381,137],[224,165]]),('cdu','A13',[[536,204],[57,110]])]:
 q[party+'_stronghold']=((q['prior_'+party]>=40)&(q['prior_'+party]>q['prior_'+('cdu' if party=='spd' else 'spd')])).astype(int)
 ct=pd.crosstab(q[party+'_stronghold'],q['incumbent_'+party]).reindex(index=[0,1],columns=[0,1]);observed=ct.to_numpy();chi,pval,df,exp=stats.chi2_contingency(observed,correction=False);n=int(observed.sum());v=float(np.sqrt(chi/n))
 check(table+' source cell counts',observed.tolist()==expected,{'observed':observed.tolist(),'n':n})
 for i in [0,1]:
  for j in [0,1]:cells.append(dict(table=table,party=party.upper(),stronghold=bool(i),incumbent=bool(j),observed=int(observed[i,j]),expected_under_independence=float(exp[i,j])))
 summary.append(dict(table=table,party=party.upper(),n=n,chi2=float(chi),df=int(df),p=float(pval),cramers_v=v,observed_rows_no_yes_columns_no_yes=observed.tolist(),column_totals_no_yes=observed.sum(axis=0).tolist(),row_totals_no_yes=observed.sum(axis=1).tolist(),source_discrepancy='Manuscript labels both dimensions Yes/No although source output cells are No/Yes.'+(' Printed CDU first column total599 is inconsistent; data total593.' if party=='cdu' else ''),interpretation='Descriptive association only; not an additional coattail effect estimate.'))
pd.DataFrame(cells).to_csv(O/'lower_saxony_A12_A13_cells.csv',index=False)
(O/'lower_saxony_A12_A13.json').write_text(json.dumps(summary,indent=2)+'\n')
q[['id','year','prior_year','prior_spd','prior_cdu','spd_stronghold','cdu_stronghold','incumbent_spd','incumbent_cdu']].to_csv(O/'lower_saxony_stronghold_join.csv',index=False)
# A7 summary stats; duplicate SPD variable in source command printed once.
variables=['voters_c','incumbent_vote','major','spd_c','cdu_c','fdp_c','gruene_c','non_lt_c','any_majority','enpp','alignment','concurrent_mayoral','cme_spd','cme_cdu','cme_fdpgreen','cme_else']
rows=[]
for group in [0,1,'all']:
 a=d if group=='all' else d[d.concurrent_mayoral==group]
 for col in variables:
  b=a[col].dropna();rows.append(dict(treatment_group=group,variable=col,n=len(b),mean=float(b.mean()),sd=float(b.std()),minimum=float(b.min()),maximum=float(b.max())))
pd.DataFrame(rows).to_csv(O/'lower_saxony_A7_summary.csv',index=False)
# A1 and timeline figure data.
t=pd.read_csv(R/'raw/master_timing.csv');k=pd.read_csv(R/'raw/mayoral_timing.csv');ce=pd.to_datetime(t.date_c.unique());t=t[t.year>=2001].sort_values(['gkz','year'])
g=t.groupby('gkz').concurrent_mayoral.apply(lambda a:' '.join(a.astype(int).astype(str))).rename('sequence').reset_index();counts=g.sequence.value_counts().rename_axis('sequence').reset_index(name='municipalities')
counts.to_csv(O/'lower_saxony_A1_counts.csv',index=False);k['gkz']=pd.to_numeric(k.gkz,errors='coerce');tk=k.merge(g,on='gkz',how='inner');tk['wahltag']=pd.to_datetime(tk.wahltag)
order=tk.groupby('sequence').size().sort_values().index.tolist();id_map={};idx=0
for seq in order:
 for id in sorted(tk.loc[tk.sequence==seq,'gkz'].unique()):idx+=1;id_map[id]=idx
tk['display_id']=tk.gkz.map(id_map);tk.to_csv(O/'figure_timing_data.csv',index=False)
check('A1 covers401 municipalities',len(g)==401 and counts.municipalities.sum()==401,counts.to_dict('records'))
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none'})
figure_files=[]
def save(fig,stem):
 for ext in ['png','svg','pdf']:
  path=F/f'{stem}.{ext}';fig.savefig(path,dpi=160,bbox_inches='tight');figure_files.append(str(path.relative_to(R)))
 plt.close(fig)
markers={'0 0 0':'o','1 0 0':'^','0 1 0':'s','0 0 1':'s','1 0 1':'v','1 1 0':'D','0 1 1':'v','1 1 1':'o'}
labels={'0 0 0':'Never concurrent','1 0 0':'2001','0 1 0':'2006','0 0 1':'2011','1 0 1':'2001 and 2011','1 1 0':'2001 and 2006','0 1 1':'2006 and 2011','1 1 1':'All three'}
for stem,subset,title in [('figure_1_timing',['1 1 0','0 1 0','0 0 1','0 0 0'],'Figure 1 · Mayoral-election dates in four principal timing groups'),('figure_A1_timing',order,'Figure A1 · Mayoral-election dates in all timing groups')]:
 fig,ax=plt.subplots(figsize=(11,7));yt=[];yl=[]
 for seq in order:
  if seq not in subset:continue
  a=tk[tk.sequence==seq];filled=seq in ['0 0 1','1 1 0','0 1 1','1 1 1'];ax.scatter(a.wahltag,a.display_id,s=10,marker=markers[seq],facecolors='black' if filled else 'none',edgecolors='black',linewidths=.5,label=labels[seq]+f' (n={a.gkz.nunique()})')
  yt.append((a.display_id.min()+a.display_id.max())/2);yl.append(labels[seq]+f' (n={a.gkz.nunique()})')
 for date in ce:ax.axvline(date,color='#777777',ls='--',lw=.7)
 
 if stem=='figure_A1_timing':
  ax.set_ylabel('Municipality display index');ax.legend(loc='center left',bbox_to_anchor=(1.01,.5),frameon=False,fontsize=9)
 else:ax.set_yticks(yt,yl)
 ax.xaxis.set_major_locator(mdates.YearLocator(2));ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y'));ax.set_xlabel('Date of mayoral election');ax.set_title(title,loc='left',pad=16);fig.text(.02,.01,'Source: released timing files. Dashed lines mark council elections. Content reproduction; layout differs from original.',fontsize=8);fig.tight_layout(rect=[0,.025,1,1]);save(fig,stem)
# Figure A2 same first-election grouping as pretrends.do.
a=pd.read_stata(R/'raw/master_pretrends.dta',convert_categoricals=False);date=pd.to_datetime(a.date,errors='coerce');group=pd.Series(np.nan,index=a.index)
group.loc[date.between('1996-09-15','1996-09-29')|date.between('2001-09-09','2001-09-23')]=1
group.loc[((date>'1996-09-29')&(date<'2001-09-09'))|date.between('2006-09-10','2006-09-24')]=2
group.loc[(date>'2001-09-23')&(date<'2006-09-10')]=3
a['mayoral_group']=group;a['major']=a.spd+a.cdu;a=a[(a.year<1996)&a.mayoral_group.notna()]
means=a.groupby(['year','mayoral_group'])[['to','major','spd','cdu']].mean().reset_index();means.to_csv(O/'figure_A2_data.csv',index=False)
styles={1:('o','-','CME 2001 and 2006'),2:('s','--','CME 2006'),3:('^',':','CME 2011')};ylabs={'to':'Turnout (%)','major':'SPD+CDU share (%)','spd':'SPD share (%)','cdu':'CDU share (%)'}
def panels(data,stem,title,footnote):
 fig,axes=plt.subplots(2,2,figsize=(11,7),sharex=True)
 for ax,y in zip(axes.ravel(),ylabs):
  for group,(marker,line,label) in styles.items():
   b=data[data.mayoral_group==group].sort_values('year');ax.plot(b.year,b[y],marker=marker,linestyle=line,color='black',label=label,markersize=4)
  ax.set_ylabel(ylabs[y]);ax.set_xticks(sorted(data.year.unique()));ax.grid(axis='y',alpha=.15)
 handles,legend=axes[0,0].get_legend_handles_labels();fig.legend(handles,legend,loc='lower center',ncol=3,bbox_to_anchor=(.5,.045));fig.suptitle(title,x=.07,ha='left');fig.text(.02,.01,footnote,fontsize=8);fig.tight_layout(rect=[0,.1,1,.95]);save(fig,stem)
panels(means,'figure_A2_pretrends','Figure A2 · Council-election outcomes before reform','Means from released data; descriptive parallel trends do not prove causal identification.')
for level,num in [('btw',3),('ep',4)]:
 b=p[(p.level==level)&p.mayoral_group.notna()];means=b.groupby(['year','mayoral_group'])[['to','major','spd','cdu']].mean().reset_index();means.to_csv(O/f'figure_A{num}_data.csv',index=False)
 panels(means,f'figure_A{num}_unrelated',f'Figure A{num} · '+('Federal' if level=='btw' else 'European')+' election outcomes by council-concurrency group','Unadjusted source-data means. Some added clustered joint trend tests reject; see VERIFICATION.json.')
# Figure A5: A4 OLS predicted values under CSOE=0; all year/group cells are saturated.
results=json.loads((O/'lower_saxony_results_extended.json').read_text());pred=[]
for year in [1999,2004,2009,2014]:
 for group in [1,2,3]:
  row={'year':year,'mayoral_group':group}
  for y in ylabs:
   coef=next(r for r in results if r['model']=='A4/unrelated_trends/originalOLS' and r['outcome']==y)['coefficients'];row[y]=sum(coef.get(term,{}).get('estimate',0) for term in ['intercept',f'year_{year}' if year!=1999 else '',f'group_{group}' if group!=1 else '',f'year_{year}_group_{group}' if group!=1 and year!=1999 else ''])
  pred.append(row)
pred=pd.DataFrame(pred);pred.to_csv(O/'figure_A5_data.csv',index=False);panels(pred,'figure_A5_adjusted','Figure A5 · European-election predictions with concurrent mayoral election set to zero','Predictions from original A4 OLS specification; model-based adjustment, not new randomized evidence.')
check('Six figure contents rendered',len(figure_files)==18,figure_files)
# check source rounded CramersV irrespective of manuscript cell-label reversals
check('Source CramersV rounded magnitudes',round(summary[0]['cramers_v'],2)==.17 and round(summary[1]['cramers_v'],2)==.31,[r['cramers_v'] for r in summary])
(O/'APPENDIX_COMPLETION.json').write_text(json.dumps({'checks':checks,'tables_completed':['A1','A7','A12','A13'],'figures_completed':['1','A1','A2','A3','A4','A5'],'figure_files':figure_files,'source_table_labels_corrected':True,'new_causal_effect_estimated':False},indent=2)+'\n')
print(json.dumps(summary,indent=2));print('All remaining source tables/figure contents completed; Stata/R graphical facsimile not claimed.')
