"""Verification of reported computations; diagnostic rejections are preserved."""
from pathlib import Path
import json,hashlib
import pandas as pd,numpy as np
R=Path(__file__).resolve().parents[1];checks=[]
def check(name,condition,evidence):
 checks.append(dict(check=name,passed=bool(condition),evidence=evidence))
 if not condition:raise AssertionError(name)
rows=json.loads((R/'analysis/lower_saxony_results_extended.json').read_text())
def row(model,y):return next(x for x in rows if x['model']==model and x['outcome']==y)
for y,e,se,n,g in [('voters_c',3.03,.19,1203,401),('major',1.20,.40,1203,401)]:
 r=row('Main/Tables1,2,4/A15',y);c=r['coefficients']['concurrent_mayoral'];check('source main '+y,round(c['estimate'],2)==e and round(c['se'],2)==se and r['n']==n and r['clusters']==g,c)
r=row('Table2/incumbent party','incumbent_vote');c=r['coefficients']['concurrent_mayoral'];check('source incumbent model',round(c['estimate'],2)==.95 and round(c['se'],2)==.48 and r['n']==624 and r['clusters']==291,c)
for model,y,est,se,precision,n in [('A5/A6/btw/preceding','to',.067,.076,3,2005),('A5/A6/btw/closest','to',.039,.061,3,2005),('A5/A6/ep/closest','to',.19,.18,2,1604),('A5/A6/btw/preceding','major',.036,.118,3,2005),('A5/A6/btw/closest','major',.14,.11,2,2005),('A5/A6/ep/closest','major',-.021,.134,3,1604)]:
 r=row(model,y);c=r['coefficients']['placebo'];check('placebo '+model+' '+y,round(c['estimate'],precision)==est and round(c['se'],precision)==se and r['n']==n,c)
# Source A6 displayed SE .12 and .13; the three-decimal values above are an independent frozen audit, not source precision.
counts=pd.read_csv(R/'analysis/treatment_counts.csv');check('actual treatment counts',counts['sum'].tolist()==[188,273,93] and counts['count'].tolist()==[401]*3,counts.to_dict('records'))
validation=json.loads((R/'analysis/stata15_se_validation.json').read_text());a=[r for r in validation['comparisons'] if r['counts_constant']];check('official Stata15 external SE reference',len(a)==8 and all(r['matches_7_decimal_rounding'] for r in a),{'N':validation['n'],'G':validation['clusters'],'matched':len(a)})
for model,y,n,term,e in [('A2/pretrends/originalOLS','to',1185,'intercept',79.59),('A3/unrelated_trends/originalOLS','to',1605,'year_2002',-2.88),('A4/unrelated_trends/originalOLS','to',1284,'year_2004',-4.87)]:
 r=row(model,y);check('source trend anchor '+model,r['n']==n and round(r['coefficients'][term]['estimate'],2)==e,{'n':r['n'],'coefficient':r['coefficients'][term]})
pdta=pd.read_csv(R/'analysis/hk_reconstructed_panel.csv');check('HK exploratory unique district party year keys',not pdta.duplicated(['state','district','party','outcome_year']).any(),len(pdta));check('HK treatment matches positive margin',(pdta.treatment==(pdta.margin_pp>0)).all(),len(pdta));check('HK reconstructed not original sample',pdta.groupby('party').size().to_dict()=={'SPD':1955,'UNION':1955},pdta.groupby('party').size().to_dict())
audit=pd.read_csv(R/'analysis/hk_boundary_audit.csv');check('HK boundary gate still explicitly incomplete',not audit.boundary_verified.any(),audit.to_dict('records'))
nom=json.loads((R/'public_nomination_rows_expanded.json').read_text());check('nomination outcomes joined and causality disclaimed',len(nom)==3 and all(x['official_archive_outcomes_verified'] and not x['is_causal_estimate'] and x['pretreatment_quality_rank'] is None for x in nom),[{'district':x['district_code'],'party_second_votes':x['party_second_votes']} for x in nom])
pri=json.loads((R/'prior_appeal_fragment.json').read_text());check('one-city prior quality fragment linkage',len(pri)==2 and [r['concurrent_mayoral'] for r in pri]==[1,0] and all(not r['is_causal_estimate'] for r in pri),[{'year':r['outcome_year'],'prior_premium_pp':r['prior_descriptive_personal_minus_council_pp']} for r in pri])
# Finite appendix completion checks are kept separate from scientific diagnostics.
appendix=json.loads((R/'analysis/APPENDIX_COMPLETION.json').read_text())
for item in appendix['checks']:check('Appendix: '+item['check'],item['passed'],item['detail'])
# Research diagnostic findings are NOT represented as unit-test passes.
diagnostics=[]
for r in rows:
 if 'joint_interactions_test' in r:diagnostics.append({'model':r['model'],'outcome':r['outcome'],'n':r['n'],'clusters':r['clusters'],**r['joint_interactions_test'],'reject_5_percent':r['joint_interactions_test']['p']<.05})
result={'execution_status':'all checks completed','checks':checks,'scientific_diagnostics':diagnostics,'warnings':['Some added clustered unrelated-election joint trend tests reject at5%; these are exploratory multiple-outcome tests, not a definitive causal validation/refutation.','HK legal boundary harmonization incomplete; all estimates exploratory.','No identified all-star candidate effect has been estimated.','Python translations only; Stata executable not run.','A10 source references nonexistent municipality variable; region reconstructed from gkz and explicitly labeled repair.']}
(R/'analysis/VERIFICATION.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
