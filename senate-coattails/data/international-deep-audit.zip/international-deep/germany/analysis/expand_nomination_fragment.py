"""Append a public three-aspirant contest and machine-join all outcomes.
This purposive fragment is not a systematic sample and cannot estimate an RD.
"""
import json,csv
from pathlib import Path
import pandas as pd
R=Path(__file__).resolve().parents[1]
rows=json.loads((R/'public_nomination_rows.json').read_text())
new={k:None for k in rows[0]}
new.update(election_year=2021,state_code='08',district_code='277',district_name='Rhein-Neckar',party='CDU',nomination_date='2020-09-25',nominee='Moritz Oppelt',finalist_loser='Georg Hellmuth',nominee_votes=104,loser_votes=29,total_ballots=None,decisive_round=1,original_aspirants=3,nominee_baseline_federal_incumbent=False,pretreatment_quality_rank=None,is_causal_estimate=False,collection_scope='Purposive public-source feasibility fragment; not all contested nominations',nomination_source='https://moritz-oppelt.de/news/lokal/106/Moritz-Oppelt-ist-Bundestagskandidat-im-Wahlkreis-Rhein-Neckar.html',outcome_source='https://www.bundeswahlleiterin.de/bundestagswahlen/2021/ergebnisse/bund-99/land-8/wahlkreis-277.html',list_source='https://upload.wikimedia.org/wikipedia/commons/d/da/Wahlsonderheft_Wahlkreiskandidaten_und_Landeslisten_2021.pdf',qualification='Third aspirant Jens Keienburg received 2 votes. Reported candidate votes total 135; no ballot-total/invalid count verified. This is not a near tie. Pairwise margin is descriptive and does not establish the assignment rule in a multiperson contest. Neither education nor profession establishes talent.')
rows.append(new)
p=pd.read_csv(R/'raw/btw_kerg/btw2021_kerg2.csv',sep=';',skiprows=9)
for row in rows:
 r=p[(p.Gebietsart=='Wahlkreis')&(p.Gebietsnummer==int(row['district_code']))]
 def get(group,vote=None):
  q=r[r.Gruppenname==group]
  if vote is not None:q=q[q.Stimme==vote]
  assert len(q)==1
  return int(q.iloc[0].Anzahl)
 computed=dict(eligible_voters=get('Wahlberechtigte'),voters=get('Wählende'),party_second_votes=get('CDU',2),valid_second_votes=get('Gültige',2),nominee_first_votes=get('CDU',1),valid_first_votes=get('Gültige',1))
 for k,v in computed.items():
  if row.get(k) is not None:assert row[k]==v,(row['district_code'],k,row[k],v)
 row.update(computed)
 row['nominee_minus_loser_pair_margin_pp']=100*(row['nominee_votes']-row['loser_votes'])/(row['nominee_votes']+row['loser_votes'])
 row['party_second_votes_per_100_eligible']=100*row['party_second_votes']/row['eligible_voters']
 row['party_second_valid_share_pp']=100*row['party_second_votes']/row['valid_second_votes']
 row['turnout_pct']=100*row['voters']/row['eligible_voters']
 row['denominator_timing']='Registered electorate at 2021 general election; NOT fixed before nomination'
 row['official_archive_outcomes_verified']=True
 row['nomination_source_availability']='Historical primary report retained in search index; live URL redirects to current ministry biography' if row['district_code']=='277' else 'Live primary party report downloaded'
 row['nomination_source_count_confidence']='indexed primary report only; live-page validation blocked by redirect' if row['district_code']=='277' else 'verified live primary report'
(R/'public_nomination_rows_expanded.json').write_text(json.dumps(rows,indent=2,ensure_ascii=False)+'\n')
with (R/'public_nomination_rows_expanded.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
print('Verified original two outcomes against official CSV; expanded to three contests. Still no assignment-time quality score or systematic risk set.')
