"""Additional source-table translations. Import reruns the main audit first."""
import lower_saxony_reproduction as m
import numpy as np,pandas as pd,json
from scipy import stats
R=m.R;out=m.OUT
# Source A3/A4: original homoskedastic OLS, and separately labeled cluster diagnostics.
for level,acts,table in [('btw',m.actual_btw,'A3'),('ep',m.actual_ep,'A4')]:
 q=m.p[(m.p.level==level)&m.p.mayoral_group.notna()].copy();q['csoe']=0.
 for t,ids in acts.items():q.loc[(q.year==t)&q.id.isin(ids),'csoe']=1
 if level=='ep':q.loc[q.year==2014,'csoe']=q.loc[q.year==2014,'bgm']
 for y in ['to','major','spd','cdu']:
  cols=m.years(q);cols['csoe']=q.csoe;inter=[]
  for g in [2,3]:
   cols[f'group_{g}']=(q.mayoral_group==g).astype(float)
   cols[f'csoe_group_{g}']=cols[f'group_{g}']*q.csoe
   for t in sorted(q.year.unique())[1:]:
    name=f'year_{int(t)}_group_{g}';inter.append(name);cols[name]=((q.mayoral_group==g)&(q.year==t)).astype(float)
  for cl in [None,'id']:
   row,(b,V,names,df)=m.fit(q,y,cols,label=f'{table}/unrelated_trends/'+('originalOLS' if cl is None else 'additional_clustered'),cluster=cl)
   ix=[names.index(z) for z in inter];bb=b[ix];vv=V[np.ix_(ix,ix)];F=float(bb@np.linalg.pinv(vv)@bb/len(ix))
   row['joint_interactions_test']=dict(F=F,numerator_df=len(ix),denominator_df=df,p=float(stats.f.sf(F,len(ix),df)))
(out/'lower_saxony_results_extended.json').write_text(json.dumps(m.results,indent=2)+'\n')
flat=[]
for r in m.results:
 for name,v in r['coefficients'].items():flat.append({**{k:x for k,x in r.items() if k not in ['coefficients','joint_interactions_test']},'term':name,**v})
pd.DataFrame(flat).to_csv(out/'lower_saxony_coefficients_extended.csv',index=False)
# Source balance tables: Stata ttest's equal-variance independent two-sample test.
d=m.d;rows=[]
regions=sorted(c for c in d.columns if len(c)==7 and c.startswith('region'))
econ=['eligible_c']+regions+['debt_market','log_debt_market','tax','log_tax','tax_earn_real','log_tax_earn_real','population','pop_density','alo_sh','wa']
inc=['incumbent_spd','incumbent_cdu','incumbent_timeinoffice','incumbent_female']
def balance(data,cols,by,table,period):
 for col in cols:
  a=data.loc[data[by]==0,col].dropna().astype(float);b=data.loc[data[by]==1,col].dropna().astype(float)
  if min(len(a),len(b))<2:continue
  na,nb=len(a),len(b);v=((na-1)*a.var()+(nb-1)*b.var())/(na+nb-2);se=np.sqrt(v*(1/na+1/nb));diff=a.mean()-b.mean()
  p=2*stats.t.sf(abs(diff/se),na+nb-2) if se else (1. if diff==0 else 0.)
  rows.append(dict(table=table,period=period,variable=col,grouping=by,n0=na,n1=nb,mean0=float(a.mean()),mean1=float(b.mean()),difference_0_minus_1=float(diff),se=float(se),p=float(p)))
for period in ['full',2001,2006,2011]:
 q=d if period=='full' else d[d.year==period]
 balance(q,econ,'concurrent_mayoral','A8',period)
 q=q[(q.concurrent_mayoral==1)&((q.incumbent_spd==1)|(q.incumbent_cdu==1))]
 balance(q,econ,'incumbent_spd','A11',period)
for period in ['full',2006,2011]:
 q=d[d.year>2001] if period=='full' else d[d.year==period]
 balance(q,inc,'concurrent_mayoral','A9',period)
a96=pd.read_stata(R/'raw/master_1996.dta',convert_categoricals=False)
# Archive do-file references nonexistent municipality. Use supplied numeric gkz
# to recover the first of six regional-code digits; this is a declared repair.
z=pd.concat([d,a96],ignore_index=True);reg=np.floor(z.gkz/100000)
regions=[]
for v in sorted(reg.dropna().unique()):
 col=f'region_recomputed_{int(v)}';regions.append(col);z[col]=(reg==v).astype(float)
for period in [1996,2001,2006,2011]:
 q=z[z.year==period].copy();cols=['population','eligible_c']+regions
 if period>1996:
  q['first_concurrent']=np.nan
  allowed={2001:({'0 0 0 0','0 0 0 1','0 0 1 0','0 0 1 1'},{'0 1 0 0','0 1 0 1','0 1 1 0','0 1 1 1'}),2006:({'0 0 0 0','0 0 0 1'},{'0 0 1 0','0 0 1 1'}),2011:({'0 0 0 0'},{'0 0 0 1'})}[period]
  for value,seqs in enumerate(allowed):q.loc[q.cme_sequence_1996.isin(seqs),'first_concurrent']=value
  cols+=['debt_market','log_debt_market','tax','log_tax','tax_earn_real','log_tax_earn_real']
  if period>2001:cols+=inc
 balance(q,cols,'concurrent_mayoral' if period==1996 else 'first_concurrent','A10',period)
pd.DataFrame(rows).to_csv(out/'lower_saxony_balance.csv',index=False)
print('\nADDITIONAL SOURCE TREND TABLES:')
for row in m.results:
 if row['model'].startswith(('A3','A4')):print(row['model'],row['outcome'],row['n'],row['joint_interactions_test'])
print('\nA9 party balance:');print(pd.DataFrame(rows).query('table == "A9"').to_string(index=False))
