"""One-city public-source linkage proof. No estimated causal quality effect."""
from pathlib import Path
import json,csv,hashlib,urllib.request,concurrent.futures
import pandas as pd
R=Path(__file__).resolve().parents[1]
urls={
'braunschweig_mayor_2001.pdf':'https://www.braunschweig.de/politik_verwaltung/politik/wahlen/kw/01_obm2001.pdf',
'braunschweig_mayor_runoff_2001.pdf':'https://www.braunschweig.de/politik_verwaltung/politik/wahlen/kw/obmstichw2001_amtlerg.pdf',
'braunschweig_council_2001_revised2002.pdf':'https://www.braunschweig.de/politik_verwaltung/politik/wahlen/kw/01_rat2001.pdf',
'braunschweig_mayor_2006.pdf':'https://www.braunschweig.de/politik_verwaltung/politik/wahlen/ergebnisse/infoline_w_03_2006.pdf',
'braunschweig_hoffmann_bio.html':'https://www.braunschweig.de/leben/stadtportraet/geschichte/ob-historie/buergermeistergalerie/artikel-ob-galerie/hoffman_gert.php'}
def download(kv):
 name,url=kv
 try:
  with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0'}),timeout=40) as r: data=r.read();final=r.url
  (R/'raw'/name).write_bytes(data)
  return dict(file=name,url=url,final_url=final,bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),status='downloaded')
 except Exception as e:return dict(file=name,url=url,status='failed',error=str(e))
with concurrent.futures.ThreadPoolExecutor(max_workers=5) as pool:manifest=list(pool.map(download,urls.items()))
(R/'raw/prior_appeal_download_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
d=pd.read_stata(R/'raw/master_treatment.dta',convert_categoricals=False);rows=[]
for year in [2006,2011]:
 q=d[(d.gkz==101000)&(d.year==year)];assert len(q)==1;q=q.iloc[0]
 rows.append(dict(municipality='Braunschweig',replication_gkz=101000,official_ags='03101000',candidate='Gert Hoffmann',party='CDU',outcome_year=year,concurrent_mayoral=int(q.concurrent_mayoral),prior_appeal_date='2001-09-09',prior_personal_first_round_votes=44418,prior_personal_valid_votes=92591,prior_personal_share_pp=100*44418/92591,prior_party_council_votes=110169,prior_council_valid_votes=267846,prior_party_council_share_pp=100*110169/267846,prior_descriptive_personal_minus_council_pp=100*(44418/92591-110169/267846),council_series_revision='Council2001 final figures incorporate precinct606 rerun on2002-02-17; different event/eligibility from first-round mayoral ballot',outcome_party_council_share_pp=float(q.cdu_c),outcome_council_turnout_pp=float(q.voters_c),candidate_present_on_mayoral_ballot=year==2006,incumbent_same_person_verified='City biography says mayor2001–2014; candidate identity verified again in2006 official result',is_causal_estimate=False,quality_validation_status='Historical personal vote premium only; not validated all-star measure; not randomly assigned quality',source_personal=urls['braunschweig_mayor_2001.pdf'],source_party=urls['braunschweig_council_2001_revised2002.pdf'],source_2006_identity=urls['braunschweig_mayor_2006.pdf'],source_bio=urls['braunschweig_hoffmann_bio.html']))
(R/'prior_appeal_fragment.json').write_text(json.dumps(rows,indent=2,ensure_ascii=False)+'\n')
with (R/'prior_appeal_fragment.csv').open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
print(json.dumps(manifest,indent=2));print('Prior personal premium pp:',rows[0]['prior_descriptive_personal_minus_council_pp'])
