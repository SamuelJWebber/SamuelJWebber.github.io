"""Python translation of supplied Stata regressions, plus labeled additional audits.
No Stata execution. FE slopes are obtained by group demeaning; clustered CR1 uses
G/(G-1)*(N-1)/(N-K), where K includes an intercept and estimable within slopes.
This is xtreg's nested-FE convention, not the LSDV correction counting all unit FE.
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from scipy import stats,linalg
R=Path(__file__).resolve().parents[1]; OUT=R/'analysis'; results=[]

def fit(data,y,cols,idcol=None,label='',cluster=None,focus=None):
    names=list(cols); d=pd.concat([data[[y]],pd.DataFrame(cols,index=data.index)],axis=1)
    if idcol:d['_id']=data[idcol]
    if cluster:d['_cluster']=data[cluster]
    d=d.dropna(); n=len(d)
    Y=d[y].to_numpy(float); X=d[names].to_numpy(float)
    if idcol:
        Y=Y-d.groupby('_id')[y].transform('mean').to_numpy(float)
        X=X-d.groupby('_id')[names].transform('mean').to_numpy(float)
    else:
        X=np.column_stack([np.ones(n),X]); names=['intercept']+names
    _,rr,piv=linalg.qr(X,mode='economic',pivoting=True)
    rank=int(np.linalg.matrix_rank(X)); use=sorted(piv[:rank]); X=X[:,use]; names=[names[i] for i in use]
    beta=np.linalg.lstsq(X,Y,rcond=None)[0]; e=Y-X@beta; bread=np.linalg.inv(X.T@X)
    g=None
    if cluster:
        gr=d['_cluster'].to_numpy(); gu,gi=np.unique(gr,return_inverse=True); g=len(gu)
        sums=np.zeros((g,rank));np.add.at(sums,gi,X*e[:,None])
        k=rank+(1 if idcol else 0)
        V=bread@(sums.T@sums)@bread*(g/(g-1))*((n-1)/(n-k)); df=g-1
    else:V=bread*(e@e)/(n-rank);df=n-rank
    se=np.sqrt(np.maximum(np.diag(V),0)); ci=stats.t.ppf(.975,df)
    row=dict(model=label,outcome=y,n=n,clusters=g,df=df,rank=rank,correction='CR1 nested-FE convention' if cluster else 'OLS homoskedastic',coefficients={})
    for j,name in enumerate(names):
        if focus is None or name in focus:
            row['coefficients'][name]=dict(estimate=float(beta[j]),se=float(se[j]),ci95_low=float(beta[j]-ci*se[j]),ci95_high=float(beta[j]+ci*se[j]),p=float(2*stats.t.sf(abs(beta[j]/se[j]),df)))
    results.append(row)
    return row,(beta,V,names,df)

def years(d):return {f'year_{int(t)}':(d.year==t).astype(float) for t in sorted(d.year.dropna().unique())[1:]}
def fe(d,y,treats,label):
    cols={t:d[t] for t in treats};cols.update(years(d))
    return fit(d,y,cols,idcol='gkz',cluster='gkz',label=label,focus=treats)[0]

d=pd.read_stata(R/'raw/master_treatment.dta',convert_categoricals=False)
for y in ['voters_c','spd_c','cdu_c','major','fdp_c','gruene_c','non_lt_c','any_majority','enpp','alignment']:
    fe(d,y,['concurrent_mayoral'],'Main/Tables1,2,4/A15')
fe(d[d.incumbent_indep==0], 'incumbent_vote',['concurrent_mayoral'],'Table2/incumbent party')
for y in ['spd_c','cdu_c','fdpgreen_c','voters_c']:
    fe(d,y,['cme_spd','cme_cdu','cme_fdpgreen','cme_else'],'Table3/party heterogeneity')
fe(d,'voters_c',['csoe01','csoe06','csoe11'],'A14/year-specific')
for treats in [['concurrent_mayoral'],['csoe01','csoe06','csoe11']]:
    cov={t:d[t] for t in treats+['ue','wa','log_tax','ln_pop','density']};cov.update(years(d))
    for cat in ['ags_region','muncipality_type3']:
        for t in sorted(d.year.unique())[1:]:
            for v in sorted(d[cat].dropna().unique())[1:]:cov[f'{cat}_{v}_year_{t}']=((d[cat]==v)&(d.year==t)).astype(float)
    fit(d,'voters_c',cov,idcol='gkz',cluster='gkz',label='A14/controls',focus=treats)
counts=d.groupby('year').concurrent_mayoral.agg(['sum','count']).reset_index();counts.to_csv(OUT/'treatment_counts.csv',index=False)
seq=d.pivot(index='gkz',columns='year',values='concurrent_mayoral'); seq.value_counts().to_csv(OUT/'timing_sequences.csv')

# Placebo appendixA5/A6 exactly recreate source's hard-coded simultaneous elections.
p=pd.read_stata(R/'raw/master_placebo.dta',convert_categoricals=False)
p=p[p.csoe_2011.notna()].copy()
actual_btw={1998:[251402,359406,453013,457401,460007,152026,352407,353406,354405,461003],2002:[153002,154013,254014,351012,360404,453012,457018,459013],2005:[153010,154404,351401,353403,455007,460001,155007],2009:[457020,461001],2013:[153005,153007,153008,154404,155007,155011,158404,251041,254021,256030,257009,351010,355403,451008,453003,456403,459008,459404,460001,152001,241001,241014,251040,256406,353031,353403,404000,455007]}
actual_ep={2004:[151009,151406,155008,241016,254003,255405,454019,454054,454401,454404,454408,455015,459015,460005,460009,241012,359028],1999:[153005,156009,158406,359404,361001,459020,152012,154403,352050,452023]}
for lev,acts,variants in [('btw',actual_btw,{'preceding':{1998:2001,2005:2006,2009:2011},'closest':{2002:2001,2005:2006,2009:2011}}),('ep',actual_ep,{'closest':{1999:2001,2004:2006,2009:2011}})]:
    q=p[p.level==lev].copy();q['csoe']=0.
    for t,ids in acts.items():q.loc[(q.year==t)&q.id.isin(ids),'csoe']=1
    if lev=='ep':q.loc[q.year==2014,'csoe']=q.loc[q.year==2014,'bgm']
    for label,mapping in variants.items():
        q['placebo']=0.
        for t,ct in mapping.items():q.loc[q.year==t,'placebo']=q.loc[q.year==t,f'csoe_{ct}']
        for y in ['to','major']:
            cols=dict(placebo=q.placebo,csoe=q.csoe);cols.update(years(q))
            fit(q,y,cols,idcol='id',cluster='id',label=f'A5/A6/{lev}/{label}',focus=['placebo','csoe'])

# Pretrends: same groups/date rules and original OLS; additional cluster-robust joint test.
r=pd.read_stata(R/'raw/master_pretrends.dta',convert_categoricals=False)
date=pd.to_datetime(r.date,errors='coerce');group=pd.Series(np.nan,index=r.index)
group.loc[date.between('1996-09-15','1996-09-29')|date.between('2001-09-09','2001-09-23')]=1
group.loc[((date>'1996-09-29')&(date<'2001-09-09'))|date.between('2006-09-10','2006-09-24')]=2
group.loc[(date>'2001-09-23')&(date<'2006-09-10')]=3
r['mayoral_group']=group;r['major']=r.cdu+r.spd;r=r[(r.year<1996)&r.mayoral_group.notna()].copy()
r.groupby(['year','mayoral_group'])[['to','major','spd','cdu']].agg(['mean','count']).to_csv(OUT/'pretrend_group_means.csv')
for y in ['to','major','spd','cdu']:
    cols=years(r);inter=[]
    for g in [2,3]:
        cols[f'group_{g}']=(r.mayoral_group==g).astype(float)
        for t in [1986,1991]:
            name=f'year_{t}_group_{g}';inter.append(name);cols[name]=((r.mayoral_group==g)&(r.year==t)).astype(float)
    for cl in [None,'id']:
        row,(b,V,names,df)=fit(r,y,cols,label='A2/pretrends/originalOLS' if cl is None else 'Additional/pretrends/clustered',cluster=cl)
        ix=[names.index(z) for z in inter];bb=b[ix]; vv=V[np.ix_(ix,ix)];F=float(bb@np.linalg.pinv(vv)@bb/len(ix))
        row['joint_interactions_test']=dict(F=F,numerator_df=len(ix),denominator_df=df,p=float(stats.f.sf(F,len(ix),df)))

(OUT/'lower_saxony_results.json').write_text(json.dumps(results,indent=2)+'\n')
flat=[]
for row in results:
    for name,c in row['coefficients'].items():flat.append({**{k:v for k,v in row.items() if k not in ['coefficients','joint_interactions_test']},'term':name,**c})
pd.DataFrame(flat).to_csv(OUT/'lower_saxony_coefficients.csv',index=False)
for row in results:
    if row['model'].startswith(('A5','A2','Additional')) or row['outcome'] in ['voters_c','incumbent_vote']:
        print(row['model'],row['outcome'],'n',row['n'],'G',row['clusters'],{k:(round(v['estimate'],6),round(v['se'],6),round(v['p'],6)) for k,v in row['coefficients'].items() if k in ['concurrent_mayoral','placebo','csoe01','csoe06','csoe11']},row.get('joint_interactions_test',''))
