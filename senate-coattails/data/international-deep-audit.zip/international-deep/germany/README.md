# German coattails audit: executed work and remaining limits

This package contains executed Python translations of the Lower Saxony replication, an exploratory reconstruction of German federal incumbency spillovers, three public nomination joins, and a one-city historical candidate-appeal linkage. **It does not estimate a causal all-star candidate effect.** Results and failures are separated below. No restricted GLES microdata, account access, access contract, or outreach was used.

## Lower Saxony: replication and diagnostics actually executed

Source: Rudolph and Leininger (2021), *Coattails and spillover-effects: Quasi-experimental evidence from concurrent executive and legislative elections*, DOI [10.1016/j.electstud.2020.102264](https://doi.org/10.1016/j.electstud.2020.102264). [Public replication archive](https://zenodo.org/records/18230905), original DOI10.7910/DVN/XFUJOO. The mirrored archive metadata specifies CC-BY4.0. The [author manuscript](https://www.lukas-rudolph.com/wp-content/uploads/2021/01/Rudolph-Leininger-2020-Conc-Elections-Authors-Manuscript.pdf) supplies tables for verification.

Executed source specifications: main Tables1–4 and Appendix A1–A15. Source balance comparisons A8–A11 were translated, with the A10 repair declared below. A1 timing counts, A7 summary statistics, and A12/A13 stronghold cross-tabs are now saved separately. All six source figure contents (Figure1 and A1–A5) are rendered as PNG, SVG, and PDF from the source-defined data and models; layout is a fresh rendering, not a graphical facsimile. `analysis/APPENDIX_COMPLETION.json` records these completed checks. `lower_saxony_results_extended.json` contains the regression output. `lower_saxony_balance.csv` contains balance tests.

| Outcome | Estimate | Cluster SE | 95% CI | Rows / municipalities |
|---|---:|---:|---:|---:|
| Council turnout | 3.032787 | 0.191493 | [2.656329, 3.409245] | 1203 / 401 |
| SPD+CDU council vote share | 1.196803 | 0.399834 | [0.410764, 1.982842] | 1203 / 401 |
| Incumbent mayor's party council share | 0.946393 | 0.476175 | [0.009195, 1.883590] | 624 / 291 |
| Council turnout, A14 controls | 3.075965 | 0.186261 | [2.709738, 3.442193] | 1145 / 382 |

Units are percentage points. These compare concurrent mayoral elections with council elections without a concurrent mayoral election, under the timing design assumptions. The incumbent-party result is not a contrast between talented and ordinary nominees. The council system allows three votes per voter: multiplying turnout by council party share does not recover the number of individual party voters.

The six source placebo coefficients are small and individually nonsignificant:

| Placebo election / mapping | Turnout estimate (p) | Major-party share estimate (p) |
|---|---:|---:|
| Federal preceding | 0.067317 (.377767) | 0.036156 (.758774) |
| Federal closest | 0.039179 (.520717) | 0.136880 (.216088) |
| European preceding | 0.189090 (.295127) | −0.020977 (.875866) |

The code's European mapping label is `closest`; its actual year mapping is1999→2001,2004→2006,2009→2011, as in the source's preceding-election definition.

**The diagnostic record is mixed.** The original A2 pre-period models and A3/A4 unrelated-election models use homoskedastic OLS. Their coefficients and sample sizes reproduce. We additionally calculate joint tests of all group-by-year interactions, both using the original covariance and using municipality clustering. These joint tests are new calculations, not published test statistics. Council1981–1991 clustered p-values are turnout.8573, SPD+CDU.9123, SPD.1452, CDU.7479. But the clustered federal unrelated-election tests reject for turnout(.04641), SPD+CDU(.04654), and SPD(.03713); European SPD also rejects(.04088). These are exploratory tests across multiple outcomes, and unrelated elections are not all pretreatment periods. They neither certify nor by themselves refute the design. They must not be summarized as “all diagnostics passed.”

Balance is also imperfect: in2006 SPD incumbents occur in.200 of nonconcurrent municipalities versus.348 of concurrent municipalities(p=.00475); in2011 the corresponding proportions are.365 versus.226(p=.01240). Timing as-if random does not mean candidate party or quality is randomly assigned. Tenure also differs, partly mechanically with election cycles.

The A12/A13 stronghold cross-tabs also reproduce numerically, but their printed labels are reversed. With rows **not a stronghold / stronghold** and columns **not party incumbent / party incumbent**, SPD cells are `[[381,137],[224,165]]` and CDU cells are `[[536,204],[57,110]]`, each N907. Cramer's V is .167697 and .312024, matching the printed .17/.31. The manuscript places those same cells under Yes/No headings in both dimensions. It also prints CDU's first-column total599, although the cells sum to593. Corrected labels and expected counts are saved in `lower_saxony_A12_A13.json` and `lower_saxony_A12_A13_cells.csv`. These are descriptive associations, not additional coattail effects.

### Source and finite-sample discrepancies

- The manuscript narrative reports treated counts188/110/249, while the released data and Appendix A8 give **188/273/93** in2001/2006/2011. There are554 treated and649 untreated municipality-years;401 municipalities,355 switching,41 never treated,5 always treated.
- Appendix A14's caption lists log market debt, but the executable `treatment.do` controls macro contains only `ue wa log_tax ln_pop density`, plus year-by-region/type interactions. We follow the code. The adjusted sample and printed coefficients reproduce.
- Appendix A10 code refers to a nonexistent variable `municipality` in the released files. The initial execution failed at that line. The declared repair derives the regional digit as `floor(gkz/100000)` from the supplied six-digit code; A10 is not an unmodified do-file execution.
- **No Stata executable was run.** We use within-group demeaning and municipality CR1 covariance: `G/(G−1) × (N−1)/(N−K)`, with `K = estimable within slopes +1` for the constant; CIs use t with G−1 degrees of freedom. Unit fixed effects nested in the clusters are not counted separately.
- The earlier project script counted only within slopes and therefore slightly understated SEs (turnout.191413 versus corrected.191493; incumbent share.475792 versus.476175). This convention was resolved with an independent numerical check against [Stata15 manual Example3,p16](https://www.stata.com/manuals15/xtxtreg.pdf): downloading [official nlswork.dta](https://www.stata-press.com/data/r15/nlswork.dta), all eight printed slope SEs match at seven decimals when the constant is counted; four do not when it is excluded. `stata15_se_validation.json` preserves both variants.

## Federal Germany: actual reconstruction, not exact replication

[Hainmueller and Kern paper](https://www.mit.edu/~jhainm/Paper/HK2008Contamination.pdf) and [supplement](https://www.mit.edu/~jhainm/Paper/supp.pdf). Treatment is a party barely winning a constituency in the **previous general election**; outcome is its next-election separate PR ballot share. This is an incumbency spillover estimand. It does not assign an all-star nominee, measure same-election nomination coattails, or rule out resource/officeholding mechanisms.

The original article's main cubic estimates are SPD1.67(SE.60) and CDU/CSU1.36(SE.69), with N1958 per party and published90% CIs. Our reconstruction downloads [official historical constituency results](https://www.bundeswahlleiterin.de/dam/jcr/ce2d2b6a-f211-4355-8eea-355c98cd4e47/btw_kerg.zip). It retains the paper's election pairs and matches West German districts on state, number, and normalized name, yielding **1955 district-periods per party**, not the original1958. Clusters are state+normalized constituency name, not a fully harmonized geographic unit.

| Exploratory estimator | SPD estimate [95% CI] | CDU/CSU estimate [95% CI] |
|---|---:|---:|
| Global interacted cubic, no year effects | 1.715169 [0.380790,3.049549] | 1.397778 [0.075988,2.719569] |
| Local linear,±5pp, triangular weights, year effects | 0.461186 [−1.128246,2.050617] | 0.383870 [−0.737602,1.505343] |
| Local linear,±10pp, triangular weights, year effects | 0.206460 [−0.941878,1.354799] | 0.580789 [−0.204439,1.366017] |

The±5pp models use SPD378 observations/192 clusters and CDU/CSU376/191. Bandwidths2.5/5/10/15, models without year effects, prior-party-share and prior-turnout placebos, and next-party votes per100 prior-election registered voters are in the results. CIs are classical cluster intervals, **not robust bias-corrected RD intervals**. The grid is exploratory, not a preregistered bandwidth selection. Original paper uses a different covariance/sample construction.

**Boundary validation is incomplete and prevents causal certification.** Identical names/numbers do not imply identical boundaries. The [Constitutional Court's1995 decision](https://www.bundesverfassungsgericht.de/SharedDocs/Entscheidungen/DE/1995/01/es19950123_2bve000694.html) documents changes under the1993 law despite unchanged state seat counts. We additionally excluded the1994 outcome period as a sensitivity check; this does not certify the remaining periods. Each pair has a saved audit file, and every estimate is explicitly marked exploratory. Original author microdata/code were not located. The broad cubic result is similar; narrower local results are much less precise and all displayed local CIs include zero. Do not replace the published estimate with this as an exact replication.

## Candidate-quality feasibility: real rows, no claimed effect

`public_nomination_rows_expanded.csv` joins three2021 CDU nomination contests to official general-election returns. Two genuinely close cases are Sabine Buder110 versus Hans-Georg von der Marwitz105(WK59,2020-08-15) and Klaus Wiener96 versus Annette Leonhardt91 in the decisive second round(WK104,2021-04-12). The third, Moritz Oppelt104 versus Georg Hellmuth29 versus Jens Keienburg2(WK277,2020-09-25), is **not close**. It was added to demonstrate that collecting all contested nominations must include wide contests, not to increase the near-tie sample. Oppelt's historical primary report remains in the search index; its live URL now redirects to a ministry biography. Its counts have weaker reproducibility than the two downloaded live party reports and are labeled accordingly.

All general-election vote counts were machine-checked against the official2021 archive. The denominator is **the electorate registered for the2021 general election, not an electorate fixed before nomination**. These are descriptive joined rows; no outcome difference between the three is interpreted causally. No systematic universe/risk set, density test, complete near-tie sample, or assignment-time quality score has been assembled. Buder already had local office/party experience; federal incumbency is not a talent ranking.

The losing aspirant may remain on the party list. The first two losers are absent from the final published candidate inventory, but postnomination list inclusion is a mediator/compliance variable and cannot be used to select an unbiased sample. The design assigns **local constituency nomination**, not necessarily presence anywhere on a party's ballot. Separate second votes measure party-slate spillover, not votes for each other named candidate.

`prior_appeal_fragment.csv` makes a second concrete linkage. Gert Hoffmann's official2001 mayoral first-round result(44,418/92,591) and CDU council result(110,169/267,846) imply a descriptive prior personal-minus-council premium of6.840794pp. The same candidate is verified in the2006 result, and the city biography verifies tenure2001–2014. This links to Braunschweig `gkz=101000` with concurrent mayoral election in2006 and none in2011. **One municipality is a proof of linkage, not an estimate.** The council2001 figures incorporate a precinct606 rerun in February2002; the personal/council ballots are consequently not exactly the same event, and eligibilities differ. Prior performance is before2006 but already reflects earlier party environment and coattails. A quality-by-concurrency interaction would identify timing-effect heterogeneity under additional assumptions, not the causal effect of replacing an ordinary candidate with a talented one.

The state-wide legacy Lower Saxony candidate pages currently redirect to maintenance. Search-index fragments retain some2006 candidates/IDs, but a complete2001/2006/2011 candidate identity/prior vote panel was not recovered. Municipal archives provide a lawful open route, demonstrated by Braunschweig, but do not establish statewide coverage.

The systematic GLES nomination datasets remain a potentially stronger route:2025 ZA10104v2, DOI10.4232/5.ZA10104.2.0.0;2021 ZA7717. The2025 codebook reports2149 aspirant rows but only328 losers,49.1% first-vote-share coverage, and73.1% date coverage; complete paired near-tie count is unknown. Extended microdata are CategoryC/safeguarded with an application/contract, and individual linkage requires coordination. **No restricted access was requested or bypassed.** `n24` office is before the general election, not necessarily before nomination; post-election candidate surveys cannot define same-cycle preassignment stars.

## Reproduce

Python3 with numpy,pandas,scipy,matplotlib; no proprietary software required. Paths are relative to this directory. `download_sources.py` fetches public data and manuals, records hashes, and unpacks the official election archive. Some historical URLs can fail/redirect; recorded failures remain evidence, not successful data collection.

```bash
python download_sources.py
python analysis/lower_saxony_reproduction.py
python analysis/extend_robustness.py
python analysis/verify_stata15_se.py
python analysis/hk_reconstruct.py
python build_public_nomination_rows.py
python analysis/expand_nomination_fragment.py
python analysis/build_prior_appeal_fragment.py
python analysis/complete_appendix.py
python analysis/verify_outputs.py
```

`analysis/VERIFICATION.json` contains computational checks **separately from** scientific diagnostic results and remaining limitations. `FAILURES_AND_REPAIRS.json` preserves recovered failures and unresolved access/boundary issues. `PUBLIC_FILES.json` enumerates deliverables safe for incorporation into the public project; cached third-party manuscripts and the erroneous redirected Oppelt page are excluded. Hash manifests distinguish original source files from derived outputs. Raw third-party PDFs can be fetched from their credited public URLs rather than republished.
