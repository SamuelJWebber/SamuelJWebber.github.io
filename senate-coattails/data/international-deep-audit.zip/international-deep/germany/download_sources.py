import urllib.request,json,concurrent.futures,hashlib,pathlib,time
p=pathlib.Path(__file__).resolve().parent/'raw';p.mkdir(exist_ok=True)
if not (p/'zenodo_record.json').exists():
 with urllib.request.urlopen(urllib.request.Request('https://zenodo.org/api/records/18230905',headers={'User-Agent':'Mozilla/5.0'}),timeout=40) as r:(p/'zenodo_record.json').write_bytes(r.read())
record=json.loads((p/'zenodo_record.json').read_text())
urls={f['key']:f['links']['self'] for f in record['files']}
urls.update({'HK2008Contamination.pdf':'https://www.mit.edu/~jhainm/Paper/HK2008Contamination.pdf','HK2008supp.pdf':'https://www.mit.edu/~jhainm/Paper/supp.pdf','btw_kerg.zip':'https://www.bundeswahlleiterin.de/dam/jcr/ce2d2b6a-f211-4355-8eea-355c98cd4e47/btw_kerg.zip','federal_candidates2021.pdf':'https://upload.wikimedia.org/wikipedia/commons/d/da/Wahlsonderheft_Wahlkreiskandidaten_und_Landeslisten_2021.pdf','RudolphLeininger2020.pdf':'https://www.lukas-rudolph.com/wp-content/uploads/2021/01/Rudolph-Leininger-2020-Conc-Elections-Authors-Manuscript.pdf'})
urls.update({'nlswork_stata.dta':'https://www.stata-press.com/data/r15/nlswork.dta','stata15_xtreg.pdf':'https://www.stata.com/manuals15/xtxtreg.pdf'})
def get(it):
 name,url=it
 try:
  with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0'}),timeout=40) as r:data=r.read();final=r.url
  (p/name).write_bytes(data)
  return dict(file=name,url=url,final_url=final,bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),status='downloaded')
 except Exception as e:return dict(file=name,url=url,status='failed',error=str(e))
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as ex: results=list(ex.map(get,urls.items()))
(p/'download_manifest_latest.json').write_text(json.dumps(results,indent=2))
for r in results:print(r['file'],r['status'],r.get('bytes',r.get('error')))

if (p/'btw_kerg.zip').exists():
 import zipfile
 with zipfile.ZipFile(p/'btw_kerg.zip') as z:z.extractall(p/'btw_kerg')
