# Independent statistical review — 6 November 2026

No fatal arithmetic or outcome-orientation error was found in the reviewed U.S. House and New Zealand analyses. This was a read-only review; the accompanying JSON contains aggregate checks only.

## U.S. House nominees

An independent NumPy implementation reproduced **eight coefficient/SE pairs within1e−9**: both primary±5pp models and all six matched-sample current/prior/change models. The implementation used triangular-weighted least squares, separate slopes, party-year effects and state-cluster CR1 covariance. It did not reuse statsmodels estimation.

Party orientation is correct: an increase means greater presidential support for the nominee's party. The prior outcome lookup is also correct: the t−2 midterm source row contains the t−4 presidential outcome, and both intervening redistricting flags are checked. Stable2014 values exactly match2012;2018 versus2016 has small source differences up to0.051476 percentage point.

The matched money estimates are current−17.6947, prior−16.9898 and change−0.7049 percentage points. This supports the displayed warning that the negative level association predates the nomination. Subtraction does not repair questionable assignment. Few clusters, narrow support, high leverage and local-linear extrapolation remain important; the intervals are conventional cluster-t intervals, not exact or bias-corrected RD inference. Experience is not charisma, and unverified candidate-level report dates keep the money ranking conditional.

## New Zealand lotteries

Independent enumeration of **74,953 within-draw allocations** reproduced all three primary-outcome HT estimates and exact p-values:

| Draw | Eligible / selected | HT estimate | Exact two-sided p |
|---|---:|---:|---:|
| 2009-09-24 | 12 / 1 | −17.456684 | .272727 |
| 2015-03-19 | 34 / 1 | +3.525547 | .697901 |
| 2021-03-11 | 28 / 3 | +1.442485 | .971335 |

The weighted point summary is−0.665163 and conservative global sharp-null p=.818182. Roster sizes, unique MPs and ordinals, selected counts, unique eligible electorates and complete primary outcome joins checked out. Zero contributions for entrants outside the baseline electorate cohort correctly preserve full-roster assignment probabilities without inventing local outcomes.

These are valid sharp-null calculations conditional on the stated lottery design. They are not confidence intervals for the average effect, nor evidence of zero coattails. Only five eligible winners, possible cross-electorate effects, later lottery exposure and an incomplete archive materially limit interpretation. The treatment is a legislative opportunity, not an assigned measure of talent.

## Corrections reported to the integrating agent

1. The dashboard named Klaus Wiener's rival **Martin Leonhardt**. The primary party report and assembled rows identify **Annette Leonhardt**.
2. Saved U.S. JSON retained older optimistic interpretation-status strings while current source code used the more cautious failed/inconclusive-gate labels. Numeric results match. **Resolved:** the quality agent regenerated results, and a fresh read confirmed both cautious labels. Dashboard prose was already appropriately cautious.

The review did not change source analyses, outcomes or published files. Exact numbers and evidence are recorded in `CROSS_COUNTRY_REVIEW.json`.
