#!/usr/bin/env python3
"""Reproduce a feasibility audit, not a causal coattails estimate.

Requirements: Python 3.10+, pandas. Run in this directory:
  python audit_buenos_aires.py
Use --download to obtain fresh official files; hashes may then change.
"""
from pathlib import Path
import argparse
import hashlib
import json
import urllib.request
import pandas as pd

BASE = Path(__file__).resolve().parent
SOURCES = {
    'argentina_paso.csv': 'https://catalogo.datos.gba.gob.ar/dataset/0db2279b-b3d0-44a8-b985-261fc2e1f0dc/resource/b3c81c28-0930-4b33-95cf-27ae39d4106a/download/elecciones-paso-2011-2021.csv',
    'argentina_general.csv': 'https://catalogo.datos.gba.gob.ar/dataset/0db2279b-b3d0-44a8-b985-261fc2e1f0dc/resource/7920d25d-d822-4b19-ae76-45b6379ec143/download/elecciones-generales-2005-2023.csv',
}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--download', action='store_true')
    args = parser.parse_args()
    for name, url in SOURCES.items():
        if args.download or not (BASE / name).exists():
            urllib.request.urlretrieve(url, BASE / name)
    raw = pd.read_csv(BASE / 'argentina_paso.csv')
    general_raw = pd.read_csv(BASE / 'argentina_general.csv', encoding='latin1')
    primary = raw.drop_duplicates().copy()
    general = general_raw.drop_duplicates().copy()
    mayor = primary.loc[(primary.cargo == 'Intendente') & primary.linea_id.notna()].copy()
    keys = ['eleccion', 'distrito_id', 'lista_id', 'linea_id']
    # After exact duplicate removal, each row is one municipal party-list option.
    assert not mayor.duplicated(keys).any(), 'Nonidentical duplicate keys need adjudication'
    assert not mayor.votos.isna().any()
    assert (mayor.votos >= 0).all()
    assert mayor.groupby(['eleccion', 'distrito_id', 'lista_id']).lista.nunique().max() == 1
    events = []
    for (year, district, party), group in mayor.groupby(keys[:3]):
        ordered = group.sort_values(['votos', 'linea_id'], ascending=[False, True])
        if len(ordered) < 2:
            continue
        first, second = ordered.iloc[0], ordered.iloc[1]
        v1, v2, total = int(first.votos), int(second.votos), int(ordered.votos.sum())
        assert v1 + v2 > 0
        events.append({
            'year': int(year), 'municipality_id': int(district), 'municipality': first.distrito,
            'electoral_section_id': int(first.seccion_id), 'coalition_id': int(party),
            'coalition': first.lista, 'number_of_lists': len(ordered),
            'first_list_id': int(first.linea_id), 'first_list': first.linea,
            'second_list_id': int(second.linea_id), 'second_list': second.linea,
            'first_votes': v1, 'second_votes': v2,
            'third_votes': int(ordered.iloc[2].votos) if len(ordered) > 2 else 0,
            'all_list_votes': total,
            'top_two_margin_pp': 100 * (v1-v2)/(v1+v2),
            'all_lists_margin_pp': 100 * (v1-v2)/total,
            'runner_up_third_gap_pp_all': 100 * (v2-int(ordered.iloc[2].votos))/total if len(ordered) > 2 else None,
            'top_tie': bool(v1 == v2),
            'electors_reported': int(first.electores_habilitados),
        })
    contests = pd.DataFrame(events)
    # Exact ID linkage checks only: this does not establish candidate identity or legal eligibility.
    upper = general.loc[general.cargo.isin(['DIPUTADOS PROVINCIALES', 'SENADORES PROVINCIALES'])]
    upper_keys = set(map(tuple, upper[['eleccion','distrito_id','lista_id']].drop_duplicates().values.tolist()))
    contests['general_upper_ticket_id_match'] = [
        (r.year, r.municipality_id, r.coalition_id) in upper_keys for r in contests.itertuples()
    ]
    contests.to_csv(BASE / 'all_contested_mayoral_list_primaries.csv', index=False)
    close = contests[contests.top_two_margin_pp < 5].copy()
    close.to_csv(BASE / 'close_mayoral_list_primaries_under_5pp.csv', index=False)
    by_year = []
    for year, frame in contests.groupby('year'):
        by_year.append({
            'year': int(year), 'contested': len(frame),
            'under_5pp_top_two': int((frame.top_two_margin_pp < 5).sum()),
            'under_10pp_top_two': int((frame.top_two_margin_pp < 10).sum()),
            'under_5pp_all_lists': int((frame.all_lists_margin_pp < 5).sum()),
            'under_10pp_all_lists': int((frame.all_lists_margin_pp < 10).sum()),
            'municipalities_with_mayoral_records': int(mayor[mayor.eleccion == year].distrito_id.nunique()),
        })
    audit = {
        'status': 'Feasibility audit only; no quality classification, eligible RD sample, or causal estimate',
        'source_page': 'https://catalogo.datos.gba.gob.ar/dataset/resultados-electorales-provinciales',
        'retrieved_utc_date': '2026-11-06',
        'sources': [{
            'file': name, 'url': url, 'bytes': (BASE/name).stat().st_size,
            'sha256': hashlib.sha256((BASE/name).read_bytes()).hexdigest(),
        } for name, url in SOURCES.items()],
        'primary_raw_rows': len(raw), 'primary_raw_columns': list(raw.columns),
        'primary_exact_duplicates_removed': int(raw.duplicated().sum()),
        'general_raw_rows': len(general_raw), 'general_raw_columns': list(general_raw.columns),
        'general_exact_duplicates_removed': int(general_raw.duplicated().sum()),
        'candidate_names_present': False,
        'contested_mayoral_list_primaries': len(contests),
        'close_under_5pp_top_two': len(close),
        'close_under_10pp_top_two': int((contests.top_two_margin_pp < 10).sum()),
        'close_under_5pp_all_lists': int((contests.all_lists_margin_pp < 5).sum()),
        'close_under_10pp_all_lists': int((contests.all_lists_margin_pp < 10).sum()),
        'close_under_5pp_exactly_two_lists': int((close.number_of_lists == 2).sum()),
        'close_under_5pp_three_or_more_lists': int((close.number_of_lists > 2).sum()),
        'close_under_5pp_with_second_third_gap_under_5pp_all': int(((close.number_of_lists > 2) & (close.runner_up_third_gap_pp_all < 5)).sum()),
        'top_ties': int(contests.top_tie.sum()),
        'close_under_5pp_general_upper_id_matches': int(close.general_upper_ticket_id_match.sum()),
        'by_year': by_year,
        'running_variable_status': 'Unsigned winning margin only. A causal design requires orienting margin by PRETREATMENT high-quality candidate identity.',
        'top_two_formula': '100 * (first_votes - second_votes)/(first_votes + second_votes)',
        'all_lists_formula': '100 * (first_votes - second_votes)/all_list_votes',
        'warnings': [
            'No candidate names or donor counts in these files; list labels are not individual candidates.',
            '75 is a screening count, not 75 verified random experiments or 75 all-star candidates.',
            'Legal qualification, actual nominee identity, ties, recounts, manipulation and coalition continuity are not adjudicated.',
            '2011 and 2015 source coverage is incomplete relative to 135 municipalities; do not silently impute missing returns.',
            'Mayor and council are one municipal ticket; do not use council votes as an independent coattails outcome.',
            'Mayoral-list selection may alter the entire local slate, faction organization or upper-ticket attachments.',
            'General upper-ticket ID matches do not validate same nominee, list integration or all general-election ballot access rules.',
            'Current-election own-vote surplus cannot be used as pretreatment quality.',
        ],
    }
    (BASE/'audit_summary.json').write_text(json.dumps(audit, ensure_ascii=False, indent=2)+'\n')
    print(json.dumps({k:audit[k] for k in ['contested_mayoral_list_primaries','close_under_5pp_top_two','close_under_10pp_top_two','close_under_5pp_all_lists','close_under_10pp_all_lists','close_under_5pp_exactly_two_lists','close_under_5pp_three_or_more_lists','close_under_5pp_general_upper_id_matches','top_ties','by_year']}, indent=2))

if __name__ == '__main__':
    main()
