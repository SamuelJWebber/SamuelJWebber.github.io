"""Check the constructed data and a few independently traced event examples."""
import csv
import json
from pathlib import Path

B = Path(__file__).resolve().parent
rows = list(csv.DictReader((B / 'close_primary_candidates_outcomes.csv').open()))
by_id = {r['event_id']: r for r in rows}
checks = {
    'event_count': len(rows) == 75,
    'event_ids_unique': len(by_id) == len(rows),
    'no_duplicate_named_opponents': all(
        not r['first_candidate_name'] or r['first_candidate_name'] != r['second_candidate_name']
        for r in rows
    ),
    'denominators_positive': all(float(r['electors_reported']) > 0 for r in rows),
    'vote_bounds': all(
        not r[office + '_general_votes'] or
        0 <= float(r[office + '_general_votes']) <= float(r[office + '_general_ballots_recorded'])
        for r in rows for office in ['governor', 'legislative']
    ),
    'threshold_and_general_positive_match': all(
        r['passes_numeric_1_5pct_municipal_threshold'] == r['general_mayoral_positive_votes_flag']
        for r in rows
    ),
    'governor_legislative_turnout_agree': all(
        r['governor_general_ballots_recorded'] == r['legislative_general_ballots_recorded']
        for r in rows
    ),
    'no_causal_eligibility_claim': all(r['estimation_eligible'] == 'False' for r in rows),
    'barroso_example': (
        by_id['2015-083-135']['first_candidate_name'] == 'Mariano Barroso'
        and int(by_id['2015-083-135']['first_votes']) == 8004
        and int(by_id['2015-083-135']['second_votes']) == 7763
        and int(by_id['2015-083-135']['legislative_general_votes']) == 15338
    ),
    'simioni_example': (
        by_id['2015-063-137']['first_candidate_name'] == 'Luana Simioni'
        and int(by_id['2015-063-137']['first_votes']) == 8391
        and int(by_id['2015-063-137']['second_votes']) == 8351
        and int(by_id['2015-063-137']['legislative_general_votes']) == 23886
    ),
    'tigre_corrected_person': (
        'José Salvador Enríquez' in [by_id['2015-113-137'][s + '_candidate_name'] for s in ['first', 'second']]
        and 'Matías Tomasello' not in [by_id['2015-113-137'][s + '_candidate_name'] for s in ['first', 'second']]
    ),
}
(B / 'validation_checks.json').write_text(json.dumps(checks, indent=2) + '\n')
assert all(checks.values()), checks
print(json.dumps(checks, indent=2))
