"""A restricted, pre-primary trait: winner of the preceding mayoral general election.
Not charisma, all-star status, incumbency at nomination, or causal coattails.
"""
import contextlib,io,json,re,collections
with contextlib.redirect_stdout(io.StringIO()):
 import join_candidates_and_outcomes as j
B=j.B
def names_for(y,did,pid,p,municipality):
 candidates=j.grouped.get((y,j.mun(municipality),p),[])
 official=[r for r in j.prim_groups[(y,did,'Intendente')] if int(r['lista_id'])==pid]
 matches={};methods={}
 for r in official:
  k=j.canon_official(r['linea'],p,y);cs=[c for c in candidates if k is not None and c['faction_key']==k]
  if len(cs)==1:matches[r['linea_id']]=cs[0];methods[r['linea_id']]='explicit_faction_alias'
 unused=[c for c in candidates if id(c) not in {id(x) for x in matches.values()}];remaining=[r for r in official if r['linea_id'] not in matches]
 if len(candidates)==len(official) and len(remaining)==len(unused)==1 and (unused[0]['faction_key'] is None or len(official)==1):
  matches[remaining[0]['linea_id']]=unused[0];methods[remaining[0]['linea_id']]='unique_remaining_roster_candidate_provisional'
 return official,matches,methods
past=[]
for (y,did,cargo),rows in sorted(j.gen_groups.items()):
 if y not in [2011,2015] or cargo!='Intendente':continue
 ordered=sorted([r for r in rows if int(r['lista_id'])<9996],key=lambda r:int(r['votos']),reverse=True)
 if not ordered:continue
 g=ordered[0];p=j.party(g['lista'],y);pid=int(g['lista_id']);official,matches,methods=names_for(y,did,pid,p,g['distrito'])
 rank=sorted(official,key=lambda r:int(r['votos']),reverse=True);name='';method='unresolved'
 if rank and (len(rank)==1 or int(rank[0]['votos'])>int(rank[1]['votos'])):
  match=matches.get(rank[0]['linea_id'])
  if match:name=match['name_raw'];method=methods[rank[0]['linea_id']]
 extra=''
 if y==2015 and did==55 and name=='E. Campana':
  name='Eduardo Campana';extra='https://www.latecla.info/78028-pase-intendente-que-jugo-con-la-ucr-salto-al-pro';method+='; explicit_full_name_corroboration_before_2019_primary'
 complete=bool(name) and not re.search(r'(?:^|\s)[A-ZÁÉÍÓÚÑ]\.',name)
 past.append({'prior_year':y,'municipality_id':did,'municipality':g['distrito'],'winning_coalition_id':pid,'winning_coalition':g['lista'],'general_winning_votes':int(g['votos']),'prior_winner_name':name,'name_complete_enough_for_exact_comparison':complete,'identity_method':method,'additional_name_source':extra})
j.writecsv('past_mayoral_winner_name_audit.csv',past)
index={(x['prior_year'],x['municipality_id']):x for x in past}
trait=[]
for e in j.out:
 e=dict(e);y=int(e['year']);prev=index.get((y-4,int(e['municipality_id'])));e['prior_winner_definition']='person who won mayoral general election four years earlier; not active incumbency or all-star quality'
 e['prior_winner_name']=prev['prior_winner_name'] if prev else '';e['prior_winner_identity_available']=bool(prev and prev['name_complete_enough_for_exact_comparison'])
 e['first_won_previous_mayoral_general']='';e['second_won_previous_mayoral_general']=''
 for side in ['first','second']:
  n=e[side+'_candidate_name']
  if prev and prev['name_complete_enough_for_exact_comparison'] and n and not re.search(r'(?:^|\s)[A-ZÁÉÍÓÚÑ]\.',n):
   current=j.norm(n);previous=j.norm(prev['prior_winner_name'])
   if current==previous:
    e[side+'_won_previous_mayoral_general']=1
   elif current.split()[-1]!=previous.split()[-1]:
    e[side+'_won_previous_mayoral_general']=0
   # A shared surname but different given names may reflect an abbreviated
   # name or a relative; leave unknown until checked, never force a nonmatch.
 a=e['first_won_previous_mayoral_general'];b=e['second_won_previous_mayoral_general'];discordant=isinstance(a,int) and isinstance(b,int) and a!=b
 e['prior_winner_trait_discordant_pair']=discordant
 e['prior_winner_oriented_margin_pp']=float(e['top_two_margin_pp'])*(1 if a==1 else -1) if discordant else ''
 e['prior_winner_nominated']=a if discordant else ''
 e['prior_winner_trait_analysis_status']='insufficient_design_and_support; no_effect_estimated'
 trait.append(e)
j.writecsv('close_primaries_with_prior_winner_trait.csv',trait)
summary={'trait':'previous mayoral general-election winner','not_measured':['charisma','all-star candidate quality','active incumbency on primary day'],'prior_winner_names_recovered_by_year':{y:sum(x['prior_year']==y and bool(x['prior_winner_name']) for x in past) for y in [2011,2015]},'exact_name_comparison_available_by_event_year':{y:sum(int(e['year'])==y and isinstance(e['first_won_previous_mayoral_general'],int) and isinstance(e['second_won_previous_mayoral_general'],int) for e in trait) for y in [2011,2015,2019]},'discordant_near_tie_pairs':[{k:e[k] for k in ['event_id','first_candidate_name','second_candidate_name','prior_winner_name','prior_winner_oriented_margin_pp','prior_winner_nominated','legislative_general_votes_per_100_primary_electors']} for e in trait if e['prior_winner_trait_discordant_pair']],'effect_estimated':False,'reason':'The available previous-winner trait is a narrow pretreatment attribute, not general candidate quality. Too few discordant close pairs and unresolved ballot/slate exclusions prevent causal inference. Prior outcomes are not counted as evidence of causal coattails.'}
(B/'prior_winner_trait_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');print(json.dumps(summary,ensure_ascii=False,indent=2))
