# Buenos Aires candidate identities and coattails feasibility

Audit date: 2026-11-06. This package contains an executed data construction, not a causal coattails estimate. All 75 screened events remain ineligible for an all-star coattails estimate. Candidate-name recovery and outcome construction are substantially completed; treatment validation and identification are not.

## What was actually built

| Election | Close mayoral-list primary events | Both top candidates named | Named candidate slots |
| --- | ---: | ---: | ---: |
| 2011 | 12 | 4 | 8 / 24 |
| 2015 | 35 | 35 | 70 / 70 |
| 2019 | 28 | 28 | 56 / 56 |
| Total | 75 | 67 | 134 / 150 |

The original official-return audit found 630 contested municipal party primaries. The screen selects top-two margins below 5 percentage points: `100 × (winner votes − runner-up votes) / (winner votes + runner-up votes)`. Forty-four events have two lists and 31 have more. This is a feasibility screen, not an RD bandwidth choice or an eligible experimental sample. The original return coverage is 120, 133 and 135 municipalities in 2011, 2015 and 2019 respectively.

The join constructed governor and provincial-legislature outcomes for 71 events using the same-year municipality and coalition IDs. Seventy-one coalitions pass the arithmetic 1.5% municipal positive-vote threshold and have positive general-election mayoral votes. Sixty-three events have both candidate names and positive general mayoral votes. These facts do not certify ballot access or upper-ticket attachment.

Name matching uses explicit municipality, party and faction aliases, with no fuzzy person matching: 121 candidate slots use a unique faction match, three use a sole remaining blank faction, and ten use separately sourced corrections. Sixteen remain unresolved. Every name is still flagged as provisional pending certified nomination records.

## Outcomes and denominator

The principal constructed outcome is same-coalition provincial-legislative general-election votes per 100 **primary registered electors**, with governor votes as a second outcome. Positive-vote shares, recorded ballots, blank votes and null votes are also retained. The fixed pre-primary roll avoids conditioning the denominator on later turnout. It can capture turnout and persuasion together, but these aggregates cannot identify the two mechanisms separately.

The reported primary elector count agrees across mayoral, gubernatorial and provincial-legislative categories in all 75 events. General-election rolls can differ: La Plata 2015 reports 552,590 primary versus 552,298 general electors. No missing rolls or returns were imputed. Foreign residents may vote for these provincial/local offices under [Law 11700](https://www.argentina.gob.ar/normativa/provincial/ley-11700-123456789-0abc-defg-007-1100bvorpyel/actualizacion); this denominator must not be transferred uncritically to national offices. Mayor/council votes are not an independent coattails outcome because they share the municipal ticket.

Examples of observed outcomes, **not lift estimates**:

| Municipality, primary | Nominee and runner-up | Primary votes | Legislative general votes | Per 100 primary electors |
| --- | --- | --- | ---: | ---: |
| Nueve de Julio, Cambiemos 2015 | Mariano Barroso; Walter Battistella | 8,004; 7,763 | 15,338 | 37.973806 |
| La Plata, FIT 2015 | Luana Simioni; Amelia García | 8,391; 8,351 | 23,886 | 4.322554 |

## A pretreatment trait was constructed, with very limited support

The implemented trait is **the person who won the preceding mayoral general election four years earlier**. It is not charisma, all-star quality, or active incumbency on primary day. The script identifies the previous general-election winning coalition, maps its primary-winning list to a person, and compares that name with both current contenders. It recovered 55 prior-winner names in 2011 and 122 in 2015. Complete exact-name comparison is available in 12 of the 35 close 2015 events and 20 of the 28 close 2019 events.

Missing or abbreviated identities stay unknown. A normalized exact match is coded 1; complete names with different surnames are coded 0 for this narrow trait. A shared surname but different given names remains unknown. Eduardo Campana's abbreviated 2015 roster name is expanded using a [2016 report](https://www.latecla.info/78028-pase-intendente-que-jugo-con-la-ucr-salto-al-pro), published before the 2019 primary.

Only three pairs have one prior winner and one other candidate:

| Event | Municipality | Prior winner | Other candidate | Prior winner's signed primary margin, pp | Prior winner nominated | Legislative votes / 100 primary electors |
| --- | --- | --- | --- | ---: | ---: | ---: |
| 2015-083-135 | Nueve de Julio | Walter Battistella | Mariano Barroso | −1.528508911 | 0 | 37.973806046 |
| 2015-087-135 | Pergamino | Héctor Gutiérrez | Javier Martínez | −1.595904848 | 0 | 36.202384745 |
| 2019-055-135 | General Villegas | Eduardo Campana | Gilberto Alegre | +3.323988787 | 1 | 40.473542031 |

There is only one treated event across these years, and no control event within 2019. No effect was estimated. Pooling the three observations would confound year and coalition context and provide no useful local discontinuity estimate.

A previous win does not establish that a candidate caused earlier party success. In a sufficiently supported close-primary design, the identifying comparison would be whether the predesignated candidate narrowly wins or narrowly loses the nomination; prior party strength would be a balance/placebo variable. Treating prior party overperformance itself as new-election coattails would not solve the user's confounding objection. The present three-case result is a support check, not such a causal comparison.

## Requirements ledger

| Requirement | What is completed | Remaining limitation / disposition |
| --- | --- | --- |
| Official municipal primary and general returns | Existing official CSVs read; exact duplicates removed; 75-event screen reused and hashed | Missing municipalities in 2011/2015 are retained as coverage limitations |
| Person-level candidates | 3,357 factual roster rows extracted; 134 candidate slots joined; targeted Tigre error corrected | Eight 2011 pairs unresolved; no complete certified nominee validation |
| Signed treatment margin | Constructed for the three prior-winner-discordant pairs | No independent general all-star ranking; no usable support for narrow-trait RD |
| General outcomes | Governor and independently voted provincial legislature constructed for 71 same-ID matches | Same ID is not proof of actual ballot attachment |
| Population denominator | Primary registered electorate checked across offices; fixed-denominator outcomes computed | National-office electorate differs; primary/general registration can change |
| Primary winner and qualification law | Plurality nomination and 1.5% rule verified in Law 14086 | Individual judicial exceptions and final access records are not adjudicated |
| Cross-party ballot attachment | 2011/2015 versus 2019 decree change verified | Actual approved ballots/agreements missing for all events |
| Slate integration | Law delegates it to party/alliance rules; documented local candidate bundles | Complete coalition-by-year charter and final merged-slate audit missing |
| Pretreatment quality | Prior-general-winner trait executed; three discordant cases found | Historical candidate-specific unique-donor breadth, rally attendance and frozen digital reach not recovered as comparable panel variables |
| Close-election validity | Exact counts, near-tie fields and multi-list flags retained; recount/dispute sources flagged | Density, balance, recount and interference validation not established; no arbitrary statistical fit substitutes for missing treatment |
| Personal candidate effect | Estimand distinguished from nomination package | A close mayoral-list win also changes faction/council slate/campaign. Even full data may identify a nomination-package spillover, not isolated personal appeal |
| Replication | Portable standard-library joins, input hashes, validation checks and public manifest prepared | Roster extraction was human-assisted; public factual crosswalk is the frozen reproducible input, not a claim that newspaper parsing is fully automated |

## Institutional evidence

[Law 14086](https://www.argentina.gob.ar/normativa/provincial/ley-14086-123456789-0abc-defg-680-4100bvorpyel/actualizacion), articles 10, 13 and 14, provides the municipal qualification threshold, plurality mayoral nomination and party/alliance-specific legislative/council integration. Article 10 also bars primary losers from running in the general election and bars nominees from changing grouping. Article 1 fixes registration before the primary. The linked consolidated text contains later amendments; the central nomination/threshold rules are distinguished from the gender provisions changed in 2016. The [original 2009 scan](https://normas.gba.gob.ar/documentos/VNREpU6V.pdf) is a historical verification route, not a newly transcribed complete legal record.

[Decree 332/2011](https://normas.gba.gob.ar/documentos/B1W7JYt4.html), articles 18 and 24, permitted regulated within-party attachments and general-election cross-group attachment agreements subject to stated conditions. The official HTML heading mistakenly says 332/19; its date and [official landing page](https://normas.gba.gob.ar/ar-b/decreto/2011/332/173680) identify the 2011 decree. It governs the 2011/2015 regime.

[Decree 267/2019](https://normas.gba.gob.ar/documentos/BjbWL4Fy.html) repeals that decree. Article 23 prohibits cross-group ballot-attachment pacts in both primary and general elections, while article 18 retains within-group attachment procedures. This makes 2019 more promising for coalition continuity, without eliminating nominee/slate/faction bundling. Neither decree validates a particular event's actual ballots.

Coalition integration thresholds reported in [2019 contemporary journalism](https://www.letrap.com.ar/nota/2019-6-28-15-29-0-la-formula-de-cada-frente-para-integrar-las-listas-despues-de-las-paso) vary by front. They are not substituted for official year-specific charters. A Cambiemos charter surfaced in search for 2015 belongs to San Juan and was rejected for this Buenos Aires analysis. A 2011 official-gazette minority-allocation rule belongs to a local movement, not a province-wide universal rule, and was also not generalized.

## Identity ambiguities and source corrections

The raw 2011 La Tecla source has 1,210 candidate rows, 135 printed sections but only 134 unique municipalities: General Lavalle is repeated and General Rodríguez is absent. The 2015 extraction has 1,256 rows although its headline says 1,255; punctuation anomalies are retained. The 2019 extraction has 891 rows across 135 municipalities although the article says 892; no extra candidate was invented. Both 2019 PDF parts were actually read and parsed, with no remaining unparsed candidate row in the extracted text. A zero parser-error count does not certify newspaper completeness or correctness.

Three blank-faction matches are explicitly provisional: Simón Barraza (Carmen de Areco 2015), José Molina (Pilar 2015), and Pedro Elizalde (Pinamar 2015). They use one remaining unmatched roster candidate and one remaining official list with equal full-party counts.

Tigre 2015 demonstrates why newspaper matching needs validation: La Tecla labels Matías Tomasello as the FIT mayoral candidate, but [El Comercio](https://www.elcomercioonline.com.ar/articulos/50068638-Todos-los-pre-candidatos-que-competiran-en-Tigre-en-las-elecciones-Primarias-2015.html) and [Que Pasa](https://www.quepasaweb.com.ar/todas-la-listas-todos-los-candidatos-de-tigre/) distinguish mayoral candidate José Salvador Enríquez from first councillor Tomasello. The explicit correction is in `identity_overrides.json`, with sources and notes.

General Alvarado 2011 reporting pairs Viviana Farías with list A and Martín Cevedio with B, but gives Cevedio 653 votes while the official provincial CSV gives 655. The mapping is retained and the count discrepancy flagged, not silently reconciled. Berazategui and Chacabuco reports include contested preliminary results; final official votes are used. Conflicting Hurlingham election-night winners are not used to force an identity match.

Unresolved events: General San Martín/Frente Popular; San Miguel/UDeSo; La Plata/UDeSo; Navarro/UDeSo; Quilmes/Coalición Cívica; Quilmes/Frente Popular; San Fernando/Frente Popular; Hurlingham/UDeSo, all 2011. The audit CSV preserves the candidate pools and official faction labels for follow-up.

## Additional data routes checked

The [Lucardi, Vallejo and Feierherd study](https://www.cambridge.org/core/journals/british-journal-of-political-science/article/three-is-a-crowd-information-and-electoral-coordination-in-argentina/01B7AA0F7A2980E7012336D6445E01CC) and [replication DOI](https://doi.org/10.7910/DVN/XPKHC0) provide a stronger route to broader municipal and precinct returns. Its design concerns between-party finishing rank and coordination; it is not an estimate of a better nominee's coattails. The authors explicitly report lacking losing-candidate names. This audit located the replication but did not execute that replication package.

[CIPPEC's 2017 financing analysis](https://oear.cippec.org/wp-content/uploads/2018/07/187-DPP-IP-Quien-como-y-en-que-recomendaciones-para-desarrollar-un-regimen-de-financiamiento-en-la-politica-en-PBA.pdf) and [Law 9889, article 45](https://www.argentina.gob.ar/normativa/provincial/ley-9889-123456789-0abc-defg-988-9029bvorpyel/actualizacion) establish filing/record obligations. They do not supply a standardized historical municipal candidate-level unique-donor panel. National public-funding totals and annual party balances are not candidate donor breadth. This is a non-recovery finding, not a claim that underlying records never existed. No outreach was sent.

## Reproduce

Python 3.10+ suffices for the added joins and checks; the original official-data audit uses pandas. No private workspace path is embedded in the scripts.

1. Obtain `argentina_paso.csv`, `argentina_general.csv`, and `close_mayoral_list_primaries_under_5pp.csv` from the original Argentina audit directory. To reconstruct them, run its `audit_buenos_aires.py --download` (requires pandas). Download URLs and exact snapshot hashes appear below.
2. Put this package beside those files, in their immediate subdirectory, or set `ARGENTINA_SOURCE_DIR` to their directory.
3. Run `python prior_winner_trait.py`. It also runs the identity/outcome join and regenerates all derived panels and summary JSON files.
4. Run `python validate_completion.py`. Eleven data consistency/example checks must pass.

The input `candidate_rosters_all_years.csv` is intentionally included: the three original newspaper extracts are not required to run the published calculation. It contains names, municipality, faction/party and source-location facts only. To audit extraction, consult [2011 La Tecla](https://www.latecla.info/46590-aqui-estan-los-mas-de-1200-candidatos-a-intendente), [2015 La Tecla](https://www.latecla.info/69872-0), and [2019 La Tecla](https://www.latecla.info/103095-0). The 2019 article links [PDF part 1](https://drive.google.com/file/d/1laLfz6Irwu8TDcaGaJCh61ndXOf_ua_S/view) and [part 2](https://drive.google.com/file/d/1d8EF703w_EwqPWR4Sh34jzHMtt9B6OZD/view). Article line references are retrieval-specific audit hints, not permanent anchors. Exact factual crosswalk and override hashes identify this snapshot; a source refresh should be versioned and revalidated.

Official [catalog](https://catalogo.datos.gba.gob.ar/dataset/resultados-electorales-provinciales) download endpoints:

- Primary: https://catalogo.datos.gba.gob.ar/dataset/0db2279b-b3d0-44a8-b985-261fc2e1f0dc/resource/b3c81c28-0930-4b33-95cf-27ae39d4106a/download/elecciones-paso-2011-2021.csv
- General: https://catalogo.datos.gba.gob.ar/dataset/0db2279b-b3d0-44a8-b985-261fc2e1f0dc/resource/7920d25d-d822-4b19-ae76-45b6379ec143/download/elecciones-generales-2005-2023.csv

| Snapshot input | SHA-256 |
| --- | --- |
| argentina_paso.csv | `2cbabc60744135470bedbc8c56c12b285e14763e9f829e7223f4179684a4f2a9` |
| argentina_general.csv | `c85789bffc1221992d6ff5bf8e66732afa2b395738e11b8536f8a1ab4612a0e3` |
| close_mayoral_list_primaries_under_5pp.csv | `0e3bfbe20b3eaaf0b027886eadad4b91f82eed6a38b644c6798a4d20f1918cea` |
| candidate_rosters_all_years.csv | `3356985e3a6ebd28480a9f85223854e2cbe6e81accc980b5fec9cc0302967916` |

## Public distribution

Use `PUBLIC_FILES.json` as the explicit allowlist. The derived factual crosswalk, event panels, summaries, scripts and this report can accompany the existing official-data audit. Do not publish newspaper HTML, PDF files, extracted newspaper text, private Page exports, or the intermediate raw roster JSON files. Source links are supplied instead. No article prose or page images are required by the public analysis. The public bundle was rerun using only allowlisted files plus the three official-audit inputs.
