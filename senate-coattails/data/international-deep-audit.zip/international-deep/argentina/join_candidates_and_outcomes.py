"""Identity and outcome construction only. No quality scores or causal estimates.

Uses explicit municipality/party/faction aliases; never fuzzy name matching.
All roster-based names remain provisional until certified nomination validation.
"""
import csv,json,re,pathlib,unicodedata,hashlib,collections,os
B=pathlib.Path(__file__).resolve().parent
# Portable: place the official files beside this script (or in its parent), or
# set ARGENTINA_SOURCE_DIR explicitly. No prior workspace path is required.
required_sources=['argentina_paso.csv','argentina_general.csv','close_mayoral_list_primaries_under_5pp.csv']
source_candidates=([pathlib.Path(os.environ['ARGENTINA_SOURCE_DIR'])] if os.environ.get('ARGENTINA_SOURCE_DIR') else [B,B.parent])
S=next((p for p in source_candidates if all((p/f).is_file() for f in required_sources)),None)
if S is None:
 raise FileNotFoundError('Official inputs missing. See README_ARGENTINA.md; set ARGENTINA_SOURCE_DIR to their directory.')
def norm(s):return ' '.join(''.join(c for c in unicodedata.normalize('NFD',str(s)) if not unicodedata.combining(c)).upper().split())
def mun(s):
 s=norm(s)
 return {'AMIRANTE BROWN':'ALMIRANTE BROWN','HURLINGHAN':'HURLINGHAM','DEL PILAR':'PILAR','PARTIDO DE PINAMAR':'PINAMAR','PARTIDO DE LA COSTA':'LA COSTA','EXALT. DE LA CRUZ':'EXALTACION DE LA CRUZ','ADOLFO GONZALES CHAVES':'GONZALES CHAVES','25 DE MAYO':'VEINTICINCO DE MAYO'}.get(s,s)
def party(s,y):
 s=norm(s).replace('ALIANZA ','').strip()
 if s.endswith(')') and s.count(')')>s.count('('):s=s[:-1]
 aliases={'FPV':'FRENTE PARA LA VICTORIA','CAMBIEMOS':'CAMBIEMOS BUENOS AIRES','UNA':'UNIDOS POR UNA NUEVA ALTERNATIVA (UNA)','FIT':'FRENTE DE IZQUIERDA Y LOS TRABAJADORES','PROG.':'PROGRESISTAS','COMP. FED.':'COMPROMISO FEDERAL','COMP. FEDERAL':'COMPROMISO FEDERAL','COM. FED.':'COMPROMISO FEDERAL','F. POPULAR':'FRENTE POPULAR','JXC':'JUNTOS POR EL CAMBIO','JCC':'JUNTOS POR EL CAMBIO','FDT':'FRENTE DE TODOS','NOS':'FRENTE NOS','C. FED.':'CONSENSO FEDERAL','C. FED':'CONSENSO FEDERAL','C.FED.':'CONSENSO FEDERAL','D. POP.':'PARTIDO DIGNIDAD POPULAR','D.POP.':'PARTIDO DIGNIDAD POPULAR','D. POP':'PARTIDO DIGNIDAD POPULAR','DIG. POP':'PARTIDO DIGNIDAD POPULAR','UDESO':'UNION PARA EL DESARROLLO SOCIAL','UP':'FRENTE POPULAR','CC':'COALICION CIVICA - AFIRMACION PARA UNA REPUBLICA IGUALITARIA (A.R.I.)'}
 return aliases.get(s,s)
def canon_official(label,p,y):
 s=norm(label)
 if p in ['CAMBIEMOS BUENOS AIRES','JUNTOS POR EL CAMBIO']:
  m=re.search(r'^LISTA\s+(.+?)\s*(?:-\s*)?(?:AMARILLO|ROJO|VERDE|AZUL)\b',s);return re.sub(r'[\s-]','',m.group(1)) if m else None
 if p in ['FRENTE PARA LA VICTORIA','FRENTE DE TODOS']:
  m=re.search(r'(\d+)\s*$',s);return m.group(1) if m else None
 if p=='FRENTE DE IZQUIERDA Y LOS TRABAJADORES':return '2U' if '2U' in s else ('RYF' if 'RENOVAR Y FORTALECER' in s else None)
 d={'LISTA IGUALDAD Y DECENCIA MS':'IYD','LISTA SOCIALISMO Y PARTICIPACION SP':'SYP','LISTA CREO A':'CREO','LISTA B CORRIENTE RENOVADORA':'CR','LISTA C LINEA RENOVADORA':'LR','LISTA D MOVIMIENTO RENOVADOR':'MR','LISTA B AHORA EL PUEBLO':'AP','LISTA C CON TERNURA VENCEREMOS':'TV','LISTA P':'UP','LISTA M':'MIJD','LISTA E':'EP','HAY CONSENSO':'HC','GENTE PROGRESISTA':'GP','CONSENSO FEDERAL 2030':'CF2030','CONSENSO ROJO Y BLANCO':'RYB','ALTERNATIVA':'A','LINEA UNICA':'U','LISTA 3C - ACCION VECINAL':'AV','LISTA 2B - LIBERACION NACIONAL':'LN','LISTA 1A - POR LA VIDA':'PV'}
 return d.get(s)
def canon_roster(r):
 f=norm(r.get('faction_raw',''));p=party(r['party_raw'],r['year'])
 if p=='FRENTE DE TODOS':f=re.sub(r'^CY\s*B\s*','',f)
 if p=='FRENTE PARA LA VICTORIA':f=f.lstrip('K ')
 return re.sub(r'\s','',f).strip('()') or None
def readcsv(path,encoding='utf8'):
 return list(csv.DictReader(open(path,encoding=encoding)))
def dedup(rows):return list({tuple(r.items()):r for r in rows}.values())
paso=dedup(readcsv(S/'argentina_paso.csv'));general=dedup(readcsv(S/'argentina_general.csv','latin1'))
close=readcsv(S/'close_mayoral_list_primaries_under_5pp.csv')
if (B/'candidate_rosters_all_years.csv').is_file():
 roster=readcsv(B/'candidate_rosters_all_years.csv')
 for r in roster:r['year']=int(r['year'])
else:
 roster=sum([json.loads((B/f'roster{y}.json').read_text()) for y in [2011,2015,2019]],[])
for r in roster:r['municipality_key']=mun(r['municipality_raw']);r['party_key']=party(r['party_raw'],r['year']);r['faction_key']=canon_roster(r)
grouped=collections.defaultdict(list)
for r in roster:grouped[(r['year'],r['municipality_key'],r['party_key'])].append(r)
prim_groups=collections.defaultdict(list);gen_groups=collections.defaultdict(list)
for r in paso:prim_groups[(int(r['eleccion']),int(r['distrito_id']),r['cargo'])].append(r)
for r in general:gen_groups[(int(r['eleccion']),int(r['distrito_id']),r['cargo'])].append(r)
out=[];links=[]
overrides={(r['event_id'],norm(r['list'])):r for r in json.loads((B/'identity_overrides.json').read_text())}
for e in close:
 y=int(e['year']);did=int(e['municipality_id']);pid=int(e['coalition_id']);p=party(e['coalition'],y);ek=f'{y}-{did:03d}-{pid}'
 candidates=grouped.get((y,mun(e['municipality']),p),[])
 official=[r for r in prim_groups[(y,did,'Intendente')] if int(r['lista_id'])==pid and r['linea_id']]
 matches={};methods={}
 for r in official:
  k=canon_official(r['linea'],p,y);cand=[c for c in candidates if k is not None and c['faction_key']==k]
  if len(cand)==1:matches[r['linea_id']]=cand[0];methods[r['linea_id']]='unique_explicit_faction_alias'
 # Only resolve a sole blank roster faction by elimination if all other lists
 # match one-to-one and the two complete party rosters have equal counts.
 remaining=[r for r in official if r['linea_id'] not in matches]
 used={id(x) for x in matches.values()};unused=[c for c in candidates if id(c) not in used]
 if y>2011 and len(candidates)==len(official) and len(remaining)==len(unused)==1 and unused[0]['faction_key'] is None:
  matches[remaining[0]['linea_id']]=unused[0];methods[remaining[0]['linea_id']]='unique_blank_faction_elimination_provisional'
 e=dict(e);e['event_id']=ek;e['roster_candidate_pool_size']=len(candidates);e['roster_candidate_pool']='; '.join(c['name_raw'] for c in candidates)
 for side in ['first','second']:
  ident=e[side+'_list_id'];c=matches.get(ident)
  override=overrides.get((ek,norm(e[side+'_list'])))
  if override:
   c={'name_raw':override['name'],'source_line':'','source_part':''};methods[ident]='explicit_additional_source_mapping'
  e[side+'_identity_source_url']=override['source'] if override else ('https://www.latecla.info/69872-0' if y==2015 else ('https://www.latecla.info/103095-0' if y==2019 else 'https://www.latecla.info/46590-aqui-estan-los-mas-de-1200-candidatos-a-intendente'))
  e[side+'_identity_note']=override['note'] if override else ''
  e[side+'_candidate_name']=c['name_raw'] if c else ''
  e[side+'_identity_method']=methods.get(ident,'unresolved')
  e[side+'_identity_source_line']=c['source_line'] if c else ''
  e[side+'_identity_source_part']=c.get('source_part','') if c else ''
  links.append({'event_id':ek,'year':y,'municipality':e['municipality'],'coalition':e['coalition'],'position':side,'official_list_id':ident,'official_list':e[side+'_list'],'candidate_name':c['name_raw'] if c else '', 'method':methods.get(ident,'unresolved'),'roster_pool':e['roster_candidate_pool'],'source_line':c['source_line'] if c else '', 'source_part':c.get('source_part','') if c else '', 'source_url':e[side+'_identity_source_url'],'identity_note':e[side+'_identity_note']})
 e['both_candidate_names_matched']=bool(e['first_candidate_name'] and e['second_candidate_name'])
 e['identity_validation']='journalistic_names_plus_official_list_results; certified_nomination_validation_pending'
 e['quality_pre_primary']='';e['quality_status']='missing_independent_pretreatment_measure'
 roll=int(e['electors_reported']);pr=prim_groups[(y,did,'Intendente')]
 positive=sum(int(r['votos']) for r in pr if int(r['lista_id'])<9996)
 e['primary_mayoral_positive_votes']=positive
 e['coalition_primary_positive_share_pct']=100*int(e['all_list_votes'])/positive
 e['passes_numeric_1_5pct_municipal_threshold']=e['coalition_primary_positive_share_pct']>=1.5
 e['general_mayoral_party_row_present']=any(int(r['lista_id'])==pid for r in gen_groups[(y,did,'Intendente')])
 e['general_mayoral_party_votes']=sum(int(r['votos']) for r in gen_groups[(y,did,'Intendente')] if int(r['lista_id'])==pid) if e['general_mayoral_party_row_present'] else ''
 e['general_mayoral_positive_votes_flag']=isinstance(e['general_mayoral_party_votes'],int) and e['general_mayoral_party_votes']>0
 for label,cargos in [('governor',['Gobernador']),('legislative',['DIPUTADOS PROVINCIALES','SENADORES PROVINCIALES'])]:
  gr=[r for cargo in cargos for r in gen_groups[(y,did,cargo)]];target=[r for r in gr if int(r['lista_id'])==pid]
  e[label+'_outcome_same_year_party_id_match']=bool(target)
  e[label+'_office']='; '.join(sorted({r['cargo'] for r in target}))
  e[label+'_general_votes']=sum(int(r['votos']) for r in target) if target else ''
  e[label+'_general_votes_per_100_primary_electors']=100*e[label+'_general_votes']/roll if target else ''
  e[label+'_general_positive_vote_share_pct']=100*e[label+'_general_votes']/sum(int(r['votos']) for r in gr if int(r['lista_id'])<9996) if target else ''
  e[label+'_general_ballots_recorded']=sum(int(r['votos']) for r in gr)
  e[label+'_general_blank_votes']=sum(int(r['votos']) for r in gr if int(r['lista_id'])==9996)
  e[label+'_general_null_votes']=sum(int(r['votos']) for r in gr if int(r['lista_id'])==9997)
  e[label+'_general_total_ballots_per_100_primary_electors']=100*e[label+'_general_ballots_recorded']/roll if gr else ''
  e[label+'_general_elector_counts']=';'.join(sorted({r['votantes_habilitados'] for r in gr}))
  prup=[r for cargo in cargos for r in prim_groups[(y,did,cargo)]]
  e[label+'_primary_elector_counts']=';'.join(sorted({r['electores_habilitados'] for r in prup}))
  e[label+'_fixed_roll_office_check']=bool(prup) and {int(r['electores_habilitados']) for r in prup}=={roll}
 e['upper_ticket_attachment_validation']='pending_actual_ballot_and_coalition_agreements'
 e['slate_integration_validation']='pending_coalition_year_charter_and_final_candidate_lists'
 e['estimation_eligible']=False
 out.append(e)
def writecsv(name,rows):
 with open(B/name,'w') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
writecsv('close_primary_candidates_outcomes.csv',out);writecsv('identity_match_audit.csv',links)
writecsv('candidate_rosters_all_years.csv',[{k:r.get(k,'') for k in ['year','municipality_raw','name_raw','party_raw','faction_raw','affiliation_raw','source_part','source_line','parse_note','municipality_key','party_key','faction_key']} for r in roster])
summary={'status':'constructed descriptive event panel only; no validated all-star quality or causal effect','near_tie_screen_events':len(out),'roster_rows_by_year':{y:sum(r['year']==y for r in roster) for y in [2011,2015,2019]},'both_names_matched':sum(e['both_candidate_names_matched'] for e in out),'candidate_slots_matched':sum(bool(r['candidate_name']) for r in links),'match_methods':dict(collections.Counter(r['method'] for r in links)),'by_year':[{'year':y,'events':sum(int(e['year'])==y for e in out),'both_names_matched':sum(int(e['year'])==y and e['both_candidate_names_matched'] for e in out),'candidate_slots_matched':sum(r['year']==y and bool(r['candidate_name']) for r in links)} for y in [2011,2015,2019]],'governor_outcomes_matched':sum(e['governor_outcome_same_year_party_id_match'] for e in out),'legislative_outcomes_matched':sum(e['legislative_outcome_same_year_party_id_match'] for e in out),'numerical_municipal_threshold_pass':sum(e['passes_numeric_1_5pct_municipal_threshold'] for e in out),'general_mayoral_positive_votes':sum(e['general_mayoral_positive_votes_flag'] for e in out),'both_names_and_positive_general_mayoral_votes':sum(e['both_candidate_names_matched'] and e['general_mayoral_positive_votes_flag'] for e in out),'fixed_roll_office_check_failures':[e['event_id'] for e in out if not(e['governor_fixed_roll_office_check'] and e['legislative_fixed_roll_office_check'])],'missing_quality_events':len(out),'estimation_eligible_events':0,'sources':[{ 'file':f,'sha256':hashlib.sha256((S/f).read_bytes()).hexdigest()} for f in ['argentina_paso.csv','argentina_general.csv','close_mayoral_list_primaries_under_5pp.csv']]}
(B/'join_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');print(json.dumps(summary,ensure_ascii=False,indent=2))
