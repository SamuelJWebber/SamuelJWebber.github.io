"""Checks independent reproduction against published rounded coefficients and source totals."""
from pathlib import Path
import json,pandas as pd,numpy as np
r=Path(__file__).parent
expected={('support_population','baseline','reduced_form','other_ban'):-.00667,('support_population','adjusted_pretrends','reduced_form','other_ban'):-.00809,('support_population','baseline','2SLS','coattail_ratio'):.274,('support_population','adjusted_pretrends','2SLS','coattail_ratio'):.315,('support_voters','baseline','2SLS','coattail_ratio'):.256,('support_voters','adjusted_pretrends','2SLS','coattail_ratio'):.267}
checks=[]
for folder,ex in [('spain_results',expected),('spain_results_entropy',{('support_population','baseline','2SLS','coattail_ratio'):.397,('support_population','adjusted_pretrends','2SLS','coattail_ratio'):.401}),('spain_results_municipal',{('support_population','baseline','2SLS','coattail_ratio'):.257,('support_population','adjusted_pretrends','2SLS','coattail_ratio'):.302,('support_voters','baseline','2SLS','coattail_ratio'):.237,('support_voters','adjusted_pretrends','2SLS','coattail_ratio'):.264})]:
 d=pd.read_csv(r/folder/'table1_python.csv').set_index(['outcome','specification','estimator','term'])
 for key,value in ex.items():
  v=float(d.loc[key,'coefficient']);tol=.0005 if key[2]=='2SLS' else .000005
  rec={'folder':folder,'key':list(key),'published_rounded':value,'reproduced':v,'absolute_difference':abs(value-v),'rounding_tolerance':tol,'passes':abs(value-v)<tol};checks.append(rec)
  assert rec['passes'],rec
base=pd.read_csv(r/'spain_results/table1_python.csv');rob=pd.read_csv(r/'spain_results_cluster_municipal/table1_python.csv')
assert len(base)==len(rob) and max(abs(base.coefficient-rob.coefficient))<1e-10
assert set(base['n'])=={3360} and set(rob.clusters)=={182}
# Verify the saved files, not just in-memory estimator sample labels.
panels=[]
for folder,n in [('spain_results',3360),('spain_results_cluster_municipal',3360),('spain_results_municipal',2184),('spain_results_entropy',3360)]:
 panel=pd.read_csv(r/folder/'analysis_panel.csv')
 assert len(panel)==n and (panel.groupby('group_type').size()==6).all(),folder
 panels.append({'folder':folder,'rows':len(panel),'all_unit_office_pairs_have_six_elections':True})
py_event=pd.read_csv(r/'spain_results/event_study_python.csv')
coef_checks=[]
for outcome in ['turnout','support_voters','support_population']:
 rv=pd.read_csv(r/'spain_results_honestdid'/f'{outcome}_event_study_R.csv')
 assert len(rv)==5
 for row in rv.itertuples():
  year=row.term.split('::')[1].split(':')[0]
  pv=py_event.loc[(py_event.outcome==outcome)&(py_event.term==year),'coefficient']
  assert len(pv)==1
  diff=abs(float(pv.iloc[0])-row.coefficient)
  assert diff<1e-8,(outcome,year,diff)
  coef_checks.append({'outcome':outcome,'year':int(year),'python_coefficient':float(pv.iloc[0]),'R_coefficient':row.coefficient,'absolute_difference':diff})
assert len(coef_checks)==15
bounds=pd.read_csv(r/'spain_results_honestdid/all_relative_magnitude_bounds.csv')
assert len(bounds)==45 and np.isfinite(bounds[['lb','ub','Mbar']]).all().all()
assert (bounds.lb<=bounds.ub).all() and set(bounds.method)=={'C-LF'}
for outcome,d in bounds.groupby('outcome'):
 assert len(d)==15 and np.allclose(sorted(d.Mbar),np.arange(1,16)/10)
 assert np.all(np.diff(d.sort_values('Mbar').lb)<=1e-8)
 assert np.all(np.diff(d.sort_values('Mbar').ub)>=-1e-8)
 assert ((r/'spain_results_honestdid'/f'{outcome}_relative_magnitude.csv').exists())
 assert np.allclose(pd.read_csv(r/'spain_results_honestdid'/f'{outcome}_relative_magnitude.csv')[['lb','ub','Mbar']],d[['lb','ub','Mbar']])
diag=pd.read_csv(r/'spain_results_honestdid/event_study_diagnostics.csv')
assert len(diag)==3 and set(diag.n)=={3360} and set(diag.precinct_clusters)=={280}
orig=pd.read_csv(r/'spain_results_honestdid/original_confidence_sets.csv')
assert len(orig)==3 and np.isfinite(orig[['lb','ub']]).all().all()
honest_validation={'passes':True,'all_event_study_coefficients_checked':15,'maximum_R_Python_absolute_difference':max(x['absolute_difference'] for x in coef_checks),'comparison_tolerance':1e-8,'coefficient_checks':coef_checks,'sensitivity_intervals_checked':45,'all_intervals_finite_ordered_and_widening':True,'saved_panels_checked':panels,'R_model_N':3360,'R_clusters':280,'note':'R covariance and independent Python CR1 covariance use slightly different degrees-of-freedom corrections; coefficient checks do not impose identical SEs.'}
(r/'spain_results_honestdid/honestdid_validation.json').write_text(json.dumps(honest_validation,indent=2)+'\n')
b=json.loads((r/'brazil_prepared/validation.json').read_text())
assert b['nominal_reconciliation_nonzero_rows']==0 and b['eligible_missing_rows']==0
assert b['seat_vacancy_difference_municipalities_with_outcomes']==0
c=json.loads((r/'brazil_prepared/cgu_roster_validation.json').read_text())
assert c['draw_records']==676 and c['unique_matched_municipalities']==670
(r/'replication_verification.json').write_text(json.dumps({'all_numerical_replication_checks_pass':True,'checks':checks,'saved_panel_checks':panels,'honestdid_validation':honest_validation,'standard_error_note':'Independent CR1 cluster covariance with explicit nested-FE degrees-of-freedom correction; coefficients reproduce published rounding. Tiny SE differences from original Stata are retained rather than overwritten.','additional_checks':['Municipality clustering leaves point estimates unchanged','Brazil candidate and party nominal votes reconcile in all 56948 rows','Brazil seats match vacancies for all municipalities with outcomes','All 15 R event-study coefficients match independent Python within 1e-8','All 45 HonestDiD intervals are finite, ordered and widen with Mbar'],'brazil_causal_readiness_gate':'FAILED: reconstructed 670 municipalities vs published 669; report dates, risk sets, corruption severity and pre-audit party unresolved. No Brazil causal estimate.'},indent=2))
print('PASS: 12 published coefficient rounding checks; all 15 cross-language event-study coefficients; all 45 sensitivity intervals; saved panels; cluster invariance; Brazil outcome accounting.')
print('BRAZIL CAUSAL READINESS GATE: NOT PASSED. No causal estimate.')
