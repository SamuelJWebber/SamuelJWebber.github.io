



clear all
capture cd $datapath

/*Glossary
codi_prov = province code
codi_mun = municipality code
nom_muni = municipality name
validos = valid votes
distrito = precinct identifier
censo = number of registered voters
votantes = number of voters who turned out to vote
nulos = number of voters who cast invalid votes
validos = number of voters who cast valid votes (votoscand or blancos)
votoscand = number of voters who vote for parties
blancos = number of voters who cast a blank vote
*/

*Open and clean each file (one file per year and election type), and harmonize them
*data_X_ZY.dta
*X=year
*Z= j (provincial) or m (local/municipal)
*Y = mes (precinct)


****************************************1987************************************

***********************************Provincial***********************************
clear
import delimited MesJ87_c.csv

rename th codi_pro
rename codmunicipio codi_mun
rename ambito nom_muni
rename válidos validos
rename sección seccion

keep codi_pro codi_mun seccion mesa distrito nom_muni /*
*/ censo votantes nulos validos blancos votoscand abstenciones hb 

*Batasuna brand in 1987 is hb
gen batasuna=hb
gen year=1987
sort  codi_pro codi_mun year
save data_1987_jmes.dta, replace

*************************************Local**************************************

clear
import delimited MesM87_c.csv

rename th codi_pro
rename codmunicipio codi_mun
rename ambito nom_muni
rename válidos validos
rename sección seccion

keep codi_pro codi_mun seccion mesa distrito nom_muni /*
*/ censo votantes nulos validos blancos votoscand abstenciones hb 

*Batasuna brand in 1987 is hb
gen batasuna=hb
gen year=1987
sort  codi_pro codi_mun year
save data_1987_mmes.dta, replace

**************************************1991**************************************

***********************************Provincial***********************************

clear
import delimited MesJ91_c.csv

rename th codi_pro
rename codmunicipio codi_mun
rename ambito nom_muni
rename válidos validos
rename sección seccion

keep codi_pro codi_mun seccion mesa distrito nom_muni /*
*/ censo votantes nulos validos blancos votoscand abstenciones hb 

*Batasuna brand in 1991 is hb
gen batasuna=hb
gen year=1991
sort  codi_pro codi_mun year
save data_1991_jmes.dta, replace

*************************************Local**************************************

clear
import delimited MesM91_c.csv

rename th codi_pro
rename codmunicipio codi_mun
rename ambito nom_muni
rename válidos validos
rename sección seccion

keep codi_pro codi_mun seccion mesa distrito nom_muni /*
*/ censo votantes nulos validos blancos votoscand abstenciones hb 

*Batasuna brand in 1991 is hb
gen batasuna=hb
gen year=1991
sort  codi_pro codi_mun year
save data_1991_mmes.dta, replace

**************************************1995**************************************

***********************************Provincial***********************************

clear
import delimited MesJ95_c.csv

rename th codi_pro
rename codmunicipio codi_mun
rename ambito nom_muni
rename válidos validos
rename sección seccion

keep codi_pro codi_mun seccion mesa distrito nom_muni /*
*/ censo votantes nulos validos blancos votoscand abstenciones hb 

*Batasuna brand in 1995 is hb
gen batasuna=hb
gen year=1995
sort  codi_pro codi_mun year
save data_1995_jmes.dta, replace

*************************************Local**************************************

clear
import delimited MesM95_c.csv

rename th codi_pro
rename codmunicipio codi_mun
rename ambito nom_muni
rename válidos validos
rename sección seccion

keep codi_pro codi_mun seccion mesa distrito nom_muni /*
*/ censo votantes nulos validos blancos votoscand abstenciones hb 

*Batasuna brand in 1995 is hb
gen batasuna=hb
gen year=1995
sort  codi_pro codi_mun year
save data_1995_mmes.dta, replace

**************************************1999**************************************

***********************************Provincial***********************************

clear
import delimited MesJ99_c.csv

rename th codi_pro
rename codmunicipio codi_mun
rename ambito nom_muni
rename válidos validos
rename sección seccion

*Batasuna brand in 1999 is eh
keep codi_pro codi_mun seccion mesa distrito nom_muni /*
*/ censo votantes nulos validos blancos votoscand abstenciones eh 

gen batasuna=eh
gen year=1999
sort  codi_pro codi_mun year
save data_1999_jmes.dta, replace

*************************************Local**************************************

clear
import delimited MesM99_c.csv

rename th codi_pro
rename codmunicipio codi_mun
rename ambito nom_muni
rename válidos validos
rename sección seccion

keep codi_pro codi_mun seccion mesa distrito nom_muni /*
*/ censo votantes nulos validos blancos votoscand abstenciones eh

*Batasuna brand in 1999 is eh
gen batasuna=eh
gen year=1999
sort  codi_pro codi_mun year
save data_1999_mmes.dta, replace

**************************************2003**************************************

***********************************Provincial***********************************

clear
import delimited MesJ03_c.csv

rename th codi_pro
rename codmunicipio codi_mun
rename ambito nom_muni
rename válidos validos
rename sección seccion

keep codi_pro codi_mun seccion mesa distrito nom_muni /*
*/ censo votantes nulos validos blancos votoscand abstenciones 

*Batasuna is fully banned in 2003
gen batasuna=.
gen year=2003
sort  codi_pro codi_mun year
save data_2003_jmes.dta, replace

*************************************Local**************************************

clear
import delimited MesM03_c.csv

rename th codi_pro
rename codmunicipio codi_mun
rename ambito nom_muni
rename válidos validos
rename sección seccion

keep codi_pro codi_mun seccion mesa distrito nom_muni /*
*/ censo votantes nulos validos blancos votoscand abstenciones 

*Batasuna is fully banned in 2003
gen batasuna=.
gen year=2003
sort  codi_pro codi_mun year
save data_2003_mmes.dta, replace

**************************************2007**************************************

***********************************Provincial***********************************
clear
import delimited MesJ07_c.csv

rename th codi_pro
rename codmunicipio codi_mun
rename ambito nom_muni
rename válidos validos
rename sección seccion

keep codi_pro codi_mun seccion mesa distrito nom_muni /*
*/ censo votantes nulos validos blancos votoscand abstenciones eaeanv

*Batasuna brand is eaeanv in 2007
gen batasuna=eaeanv
gen year=2007
sort  codi_pro codi_mun year
save data_2007_jmes.dta, replace

*************************************Local**************************************

clear
import delimited MesM07_c.csv

rename th codi_pro
rename codmunicipio codi_mun
rename ambito nom_muni
rename válidos validos
rename sección seccion

keep codi_pro codi_mun seccion mesa distrito nom_muni /*
*/ censo votantes nulos validos blancos votoscand abstenciones eaeanv

*Batasuna brand is eaeanv in 2007
gen batasuna=eaeanv
gen year=2007
sort  codi_pro codi_mun year
save data_2007_mmes.dta, replace

********************************************************************************
********************************************************************************


