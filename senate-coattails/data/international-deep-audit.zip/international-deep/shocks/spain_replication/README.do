
********************************************************************************
*Replication package for "Coattail effects and turnout: evidence from a quasi-experiment"
*Author: Andreu Arenas - andreu.arenas@ub.edu
*Date: January 10th, 2024

*This runs all codes in the right order, producing everything from scratch to the final output 

*See below a sketch of what every do file does

*Before starting, create a replication folder, with the following sub-folders
*Place all the do-files and R script in a Replicaton/Code folder
*Place all the raw data in a Replication/Data folder
*Create a Replication/Paper/Output/Figures anda Replication/Paper/Output/Tables folder 
*Running the code will automatically store the figures and tables in the corresponding folder

********************************************************************************


********************************************************************************
********************************CODE RUNNING************************************
********************************************************************************

*1) set CD (here just add an identical line below excepct for your Dropbox path)
*Need to set the CD to the right dropbox

clear all
global dfpath "C:/Users/andreu.arenas/Dropbox/Coattails/Replication/Code"
global datapath "C:/Users/andreu.arenas/Dropbox/Coattails/Replication/Data"

*Replace by your path

*2) Download data from https://www.euskadi.eus/informacion/descargas-de-ficheros-de-resultados-de-elecciones/web01-a2haukon/es/
****Files starting with J have provincial elections data
****Files starting with M have local elections data
****Every file name also indicates the year (i.e., J07_CSV indicates provincial elections in 2007)
****Download every file starting with J and with M, from 1987 to 2007 (i.e., 87, 91, 95, 99, 03, 07)
****Save it in a Data Folder

*3) Check if word wrap and ebalance installed
****If word wrap not installed, follow the following lines:
*net from https://mloeffler.github.io/stata/
*net install wordwrap
****If not available online, there's a copy in the package

****If ebalance not installed, follow the following lines:
*ssc install ebalance
****If not available online, there's a copy in the package

*3) Run do-files:

/*00*/
*takes the raw data at the electoral precinct-level, cleans it, and saves a stata 
*file for each year and election type
do ${dfpath}/00_data_cleaning.do


/*01*/ 
*produces all the results except for table A3 and figure A2
*also creates data_final_stata.dta 
do ${dfpath}/01_analysis.do


/*02*/ 
*uses R to do the honest trend analysis (figure A2)
*Open R, load data_final_stata.dta, run the analysis

/*03*/ 
*produces table A3
do ${dfpath}/03_analysis_municipalities.do

