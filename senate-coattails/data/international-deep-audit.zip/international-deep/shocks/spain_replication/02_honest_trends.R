
#clear all
rm(list = ls())
## Installation
 
# Install remotes package if not installed
#install.packages("remotes") 

# Turn off warning-error-conversion, because the tiniest warning stops installation
Sys.setenv("R_REMOTES_NO_ERRORS_FROM_WARNINGS" = "true")

# install from github
#remotes::install_github("asheshrambachan/HonestDiD")


library(here)
library(dplyr)
library(did)
library(haven)
library(ggplot2)
library(fixest)
library(HonestDiD)

setwd("C:/Users/andreu.arenas/Dropbox/Coattails/Replication/")
#write your working directory

df <-   read_dta("Data/data_final_stata.dta")

head(df,5)
 

df <- df %>%
  mutate(mine_ban_aux = ifelse(year == 2007, mine_ban, NA)) %>%
  group_by(group_type) %>%
  mutate(mine_ban_2007 = max(mine_ban_aux, na.rm = TRUE)) %>%
  ungroup() %>%
  select(-mine_ban_aux)

df <- df %>%
  mutate(other_ban_aux = ifelse(year == 2007, other_ban, NA)) %>%
  group_by(group_type) %>%
  mutate(other_ban_2007 = max(other_ban_aux, na.rm = TRUE)) %>%
  ungroup() %>%
  select(-other_ban_aux)




################################################################################
##############################TURNOUT###########################################
################################################################################

twfe_results <- fixest::feols(turnout ~ i(year, other_ban_2007, ref = 2003) |  group_type + year + year*type +year*codi_prov + mine_ban, 
                             cluster = "group",
                            data = df,
                            weights=df$meancenso)




betahat <- summary(twfe_results)$coefficients #save the coefficients
sigma <- summary(twfe_results)$cov.scaled #save the covariance matrix


fixest::iplot(twfe_results)
#https://lrberge.github.io/fixest/reference/coefplot.html

delta_rm_results <- 
  HonestDiD::createSensitivityResults_relativeMagnitudes(
    betahat = betahat, #coefficients
    sigma = sigma, #covariance matrix
    numPrePeriods = 4, #num. of pre-treatment coefs
    numPostPeriods = 1, #num. of post-treatment coefs
    Mbarvec = seq(0.1,1.5,by=0.1) #values of Mbar
  )

delta_rm_results


originalResults <- HonestDiD::constructOriginalCS(betahat = betahat,
                                                  sigma = sigma,
                                                  numPrePeriods = 4,
                                                  numPostPeriods = 1)


HonestDiD::createSensitivityPlot_relativeMagnitudes(delta_rm_results, originalResults)

 
png(filename = "Paper/Output/Figures/honest_turnout.png", width = 800, height = 600, units = "px", res = 100)
HonestDiD::createSensitivityPlot_relativeMagnitudes(delta_rm_results, originalResults)
dev.off()


 



################################################################################
##############################BAT_CALL_SHARE_T##################################
################################################################################

twfe_results <- fixest::feols(bat_call_share_t ~ i(year, other_ban_2007, ref = 2003) |  group_type + year + year*type +year*codi_prov + mine_ban, 
                              cluster = "group",
                              data = df,
                              weights=df$meancenso)

 


betahat <- summary(twfe_results)$coefficients #save the coefficients
sigma <- summary(twfe_results)$cov.scaled #save the covariance matrix


fixest::iplot(twfe_results)
#https://lrberge.github.io/fixest/reference/coefplot.html

delta_rm_results <- 
  HonestDiD::createSensitivityResults_relativeMagnitudes(
    betahat = betahat, #coefficients
    sigma = sigma, #covariance matrix
    numPrePeriods = 4, #num. of pre-treatment coefs
    numPostPeriods = 1, #num. of post-treatment coefs
    Mbarvec = seq(0.1,1.5,by=0.1) #values of Mbar
  )

delta_rm_results


originalResults <- HonestDiD::constructOriginalCS(betahat = betahat,
                                                  sigma = sigma,
                                                  numPrePeriods = 4,
                                                  numPostPeriods = 1)


HonestDiD::createSensitivityPlot_relativeMagnitudes(delta_rm_results, originalResults)


png(filename = "Paper/Output/Figures/honest_bat_call_share_t.png", width = 800, height = 600, units = "px", res = 100)
HonestDiD::createSensitivityPlot_relativeMagnitudes(delta_rm_results, originalResults)
dev.off()









################################################################################
##############################BAT_CALL_SHARE_C##################################
################################################################################

twfe_results <- fixest::feols(bat_call_share_c ~ i(year, other_ban_2007, ref = 2003) |  group_type + year + year*type +year*codi_prov + mine_ban, 
                              cluster = "group",
                              data = df,
                              weights=df$meancenso)

#You can interact a numeric variable with a "factor-like" variable by using
#i(factor_var, continuous_var, ref), where continuous_var will be interacted
#with each value of factor_var and the argument ref is a value of factor_var taken as a reference (optional).


betahat <- summary(twfe_results)$coefficients #save the coefficients
sigma <- summary(twfe_results)$cov.scaled #save the covariance matrix


fixest::iplot(twfe_results)
#https://lrberge.github.io/fixest/reference/coefplot.html

delta_rm_results <- 
  HonestDiD::createSensitivityResults_relativeMagnitudes(
    betahat = betahat, #coefficients
    sigma = sigma, #covariance matrix
    numPrePeriods = 4, #num. of pre-treatment coefs
    numPostPeriods = 1, #num. of post-treatment coefs
    Mbarvec = seq(0.1,1.5,by=0.1) #values of Mbar
  )

delta_rm_results


originalResults <- HonestDiD::constructOriginalCS(betahat = betahat,
                                                  sigma = sigma,
                                                  numPrePeriods = 4,
                                                  numPostPeriods = 1)


HonestDiD::createSensitivityPlot_relativeMagnitudes(delta_rm_results, originalResults)


png(filename = "Paper/Output/Figures/honest_bat_call_share_c.png", width = 800, height = 600, units = "px", res = 100)
HonestDiD::createSensitivityPlot_relativeMagnitudes(delta_rm_results, originalResults)
dev.off()




