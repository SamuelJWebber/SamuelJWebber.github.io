clear all


capture cd $datapath

********************************************************************************
**************************FURTHER DATA CLEANING*********************************
********************************************************************************


********************Import/append provincial elections data*********************
forval z=1987(4)2007{
append using data_`z'_jmes.dta
}
gen type=1
gen type_string="juntas"

*********************Import/append local elections data*************************
forval z=1987(4)2007{
append using data_`z'_mmes.dta
}

replace type=2 if type==.
replace type_string="munis" if type_string==""

***********************Harmonize Batasuna's vote shares ************************
foreach var in hb eh eaeanv batasuna{
replace `var'=0 if `var'==.
}
drop hb eh eaeanv

********************Collapse data at the electoral district level***************
unique codi_mun codi_pro type year distrito seccion mesa
*every municipality has 1 or more districts
*every district has sections
*every section has mesas

*There is a lot of remerging and attrition in mesas and sections
*we collapse the data at the electoral district (precinct) level
ds codi_pro codi_mun nom_muni distrito seccion mesa year type type_string, not

bysort codi_pro codi_mun: replace nom_muni =nom_muni[_N]

*By district
collapse (sum) `r(varlist)', by(codi_pro codi_mun nom_muni distrito year type type_string)
global analysis_level codi_pro codi_mun distrito
global analysis_string district



gen locale=(type==2)
gen provincial=type==1 
***************Create identifiers of presence at the local level****************
 
forval z=1979(4)2007{
gen bat_present_`z'_aux=(batasuna>0) if year==`z'
egen bat_present_`z'=max(bat_present_`z'_aux), by(codi_mun codi_pro type)
drop bat_present_`z'_aux
gen bat_present_`z'muniaux=bat_present_`z' if type==2
egen bat_present_`z'muni =max(bat_present_`z'muniaux), by(codi_mun codi_pro)
gen bat_present_`z'juntaux=bat_present_`z' if type==1
egen bat_present_`z'junt =max(bat_present_`z'juntaux), by(codi_mun codi_pro)
drop bat_present_`z'muniaux bat_present_`z'juntaux
}

*******************Create identifiers for fixed effects*************************
 
egen group=group($analysis_level)
egen ident=group(codi_mun codi_pro)
egen group_type=group(group type)
egen ident_type=group(ident type)
egen group_year=group(group year)
egen ident_year=group(ident year)
egen type_year=group(type year)
egen codi_prov=group(codi_pro)
 
*****************************Create key variables*******************************
*Population share variables divide by registered voters (censo)
*Turnout share variables divide by the number of voters (votantes)
gen bat_share_c=batasuna/censo
gen bat_share_t=batasuna/votantes
gen nuls_share_c=nulos/censo
gen nuls_share_t=nulos/votantes
gen bat_call_share_c=(batasuna+nulos)/censo
gen bat_call_share_t=(batasuna+nulos)/votantes
gen turnout=votantes/censo

*********Create key variables in concurrent election (variable_other)***********
foreach var in bat_share_c bat_share_t bat_call_share_c bat_call_share_t turnout votantes blancos validos nulos censo{
gen aux=`var' if type==1
egen maux=max(aux), by(group_year)
gen `var'_other=maux if type==2
drop aux maux
gen aux=`var' if type==2
egen maux=max(aux), by(group_year)
replace `var'_other=maux if type==1
drop aux maux
}

gen bat_legal_2007_aux=(batasuna>0)*(year==2007)
egen bat_legal_2007=max(bat_legal_2007_aux), by(ident_type)
gen bat_ban_2007=1-bat_legal_2007
drop bat_legal_2007_aux


foreach var in bat_legal_2007 bat_ban_2007{
gen aux_`var'=`var' if type==1
egen maux_`var'=max(aux_`var'), by(ident)
gen `var'_other=maux_`var' if type==2
drop aux_`var' maux_`var'

gen aux_`var'=`var' if type==2
egen maux_`var'=max(aux_`var'), by(ident)
replace `var'_other=maux_`var' if type==1
drop aux_`var' maux_`var'
}


***********************Create treatment variables******************************
gen mine_ban=year==2003
gen other_ban=year==2003
replace mine_ban=(bat_ban_2007==1) if year==2007
replace other_ban=(bat_ban_2007_other==1) if year==2007

gen mine_legal=(year<=1999)
replace mine_legal=(bat_legal_2007==1) if year==2007
gen other_legal=(year<=1999)
replace other_legal=(bat_legal_2007_other==1) if year==2007



*********Measure otucomes in the different years, to compute trends later*******
foreach var in bat_call_share_t bat_call_share_c turnout bat_call_share_t_other bat_call_share_c_other turnout_other{
forval z=1987(4)2007{
gen `var'`z'aux=`var' if year==`z'
egen `var'`z'=max(`var'`z'aux), by(group_type)
drop `var'`z'aux
}
}

**********************Drop if didn't exist pre-treatment************************
drop if bat_call_share_t1999==. | bat_call_share_t1995==. | bat_call_share_t1991==. | bat_call_share_t1987==.


*******Keep municipalities where Batasuna used to contest local elections********
gen strong_presence=(bat_present_1995muni==1 & bat_present_1999muni==1)
keep if strong_presence==1



****Compute unit-specific pre-trends, for crucial own and concurrent outcomes***

forval z=1991(4)2003{
local w=`z'-4
gen dbat_call_share_c`z'=bat_call_share_c`z'-bat_call_share_c`w'
gen dbat_call_share_t`z'=bat_call_share_t`z'-bat_call_share_t`w'
gen dturnout`z'=turnout`z'-turnout`w'

gen dbat_call_share_c_other`z'=bat_call_share_c_other`z'-bat_call_share_c_other`w'
gen dbat_call_share_t_other`z'=bat_call_share_t_other`z'-bat_call_share_t_other`w'
gen dturnout_other`z'=turnout_other`z'-turnout_other`w'
}


global trends_bat_call_share_c c.dbat_call_share_c2003 c.dbat_call_share_c1999 c.dbat_call_share_c1995 c.dbat_call_share_c1991
global trends_bat_call_share_c_other c.dbat_call_share_c_other2003 c.dbat_call_share_c_other1999 c.dbat_call_share_c_other1995 c.dbat_call_share_c_other1991
global trends_bat_call_share_c_all  $trends_bat_call_share_c $trends_bat_call_share_c_other

global trends_bat_call_share_t  c.dbat_call_share_t2003 c.dbat_call_share_t1999 c.dbat_call_share_t1995 c.dbat_call_share_t1991
global trends_bat_call_share_t_other  c.dbat_call_share_t_other2003 c.dbat_call_share_t_other1999 c.dbat_call_share_t_other1995 c.dbat_call_share_t_other1991
global trends_bat_call_share_t_all   $trends_bat_call_share_t $trends_bat_call_share_t_other

global trends_turnout c.dturnout2003 c.dturnout1999 c.dturnout1995 c.dturnout1991
global trends_turnout_other c.dturnout_other2003 c.dturnout_other1999 c.dturnout_other1995 c.dturnout_other1991
global trends_turnout_all $trends_turnout $trends_turnout_other



***********************Municipality and district size variables*****************

gen meancenso=censo
egen cens_muni1=sum(censo), by(codi_mun codi_pro year type)




********************************************************************************
*********************ANALYSIS AND PAPER OUTPUT*********************************
********************************************************************************



set scheme plotplain 
********************************************************************************
************FIGURE 1: VALIDATING NULL VOTES AS A MEASURE OF SUPPORT*************
********************************************************************************
binscatter bat_share_c nuls_share_c year [aweight=meancenso], by(bat_legal_2007) linetype(connect)   xlabel(1987(4)2007, angle(45) nogrid)  /*
*/ xtitle("Election")  ytitle("Batasuna Votes and Null Votes") legend(position(6) rows(2) label(1 "Batasuna Votes, Ban in 2003 and 2007") label(2 "Null Votes, Ban in 2003 and 2007 ") label(3 "Batasuna Votes, Ban in 2003, Legal in 2007") label(4 "Null Votes, Ban in 2003, Legal in 2007")) name(g0, replace) note("Note: Batasuna and null votes as a fraction of eligible voters", size(vsmall) pos(6))  colors(gs0 gs3 gs6 gs9)

quietly graph export ../Paper/Output/Figures/g0.png , as(png) width(1250) replace
quietly graph export ../Paper/Output/Figures/g0.eps , as(eps) replace
quietly graph export ../Paper/Output/Figures/g0.pdf , as(pdf) replace


 
********************************************************************************
************FIGURE 2: D-I-D OF OTHER_BAN ON BAT SUPPORT AND SUPPORT OTHER*******
********************************************************************************
local ytitle_bat_call_share_c "Batasuna support (fraction of population)"
local ytitle_bat_call_share_t "Batasuna support (fraction of turnout)"
local ytitle_turnout "Turnout"  

local ylabel_bat_call_share_c 0(0.05).15

foreach outcome in bat_call_share_c{
binscatter `outcome'  year [aweight=meancenso], by(bat_ban_2007_other)  linetype(connect) ylabel(`ylabel_`outcome'') xlabel(1987(4)2007 , angle(45) nogrid) /*
*/ xtitle("Election") ytitle( `ytitle_`outcome'') legend(position(6) ring(0) label(1 "Legal in the concurrent 2007 election") label(2 "Banned in the concurrent 2007 election") size(medium)) name(g1_`outcome', replace)  colors(gs0 gs10)
quietly graph export ../Paper/Output/Figures/g1`outcome'.png , as(png) width(1250) replace
quietly graph export ../Paper/Output/Figures/g1`outcome'.eps , as(eps)   replace
quietly graph export ../Paper/Output/Figures/g1`outcome'.pdf , as(pdf)   replace

binscatter `outcome'_other  year [aweight=meancenso], by(bat_ban_2007_other)  linetype(connect) ylabel(`ylabel_`outcome'') xlabel(1987(4)2007, angle(45) nogrid) /*
*/ xtitle("Election") ytitle( `ytitle_`outcome'') legend(position(6) ring(0) label(1 "Legal in the 2007 election") label(2 "Banned in the 2007 election")  size(medium)) name(g1_`outcome'_other, replace)  colors(gs0 gs10)
quietly graph export ../Paper/Output/Figures/g1`outcome'_other.png , as(png) width(1250) replace
quietly graph export ../Paper/Output/Figures/g1`outcome'_other.eps , as(eps) replace
quietly graph export ../Paper/Output/Figures/g1`outcome'_other.pdf , as(pdf) replace
}



********************************************************************************
*FIGURE 3 & FIGURE A1: EVENT STUDY COATTAIL (SUPPORT AND SUPPORT IN CONCURRENT)*
*******************    WITH AND WITHOUT TREND ADJUSTMENT    ********************
********************************************************************************

global clustervar group
**************************Create event-study set-up*****************************
forval z=1987(4)2007{
gen bat_ban_2007_other_`z'=bat_ban_2007_other*(year==`z')
gen bat_ban_2007_other_mb`z'=bat_ban_2007_other*(year==`z')*bat_ban_2007
gen bat_ban_2007_other_ml`z'=bat_ban_2007_other*(year==`z')*bat_legal_2007
gen bat_ban_2007`z'=bat_ban_2007*(year==`z')
}


capture gen zero=0
global eventstudy  bat_ban_2007_other_1987 bat_ban_2007_other_1991 bat_ban_2007_other_1995 bat_ban_2007_other_1999 zero  bat_ban_2007_other_2007  
global othercontrols_simple  mine_ban i.year i.group_type year#type year#codi_prov  
global othercontrols_trends  mine_ban i.year i.group_type year#type year#codi_prov  
 
foreach outcome in bat_call_share_c bat_call_share_t turnout{
quietly reg  `outcome'         $eventstudy $othercontrols_simple [aweight=meancenso], cluster($clustervar) 
estimates store g2`outcome'
quietly reg `outcome'_other   $eventstudy $othercontrols_simple [aweight=meancenso], cluster($clustervar)  
estimates store g2`outcome'_other

quietly reg `outcome'         $eventstudy $othercontrols_trends year#(${trends_`outcome'_all}) [aweight=meancenso], cluster($clustervar)  
estimates store g2`outcome't
quietly reg `outcome'_other   $eventstudy $othercontrols_trends year#(${trends_`outcome'_all}) [aweight=meancenso], cluster($clustervar)   
estimates store g2`outcome'_othert
} 
 
local bat_call_share_c_label Dep. Var: Bat Support (pop. share)
local bat_call_share_c_label2 Dependent Variable: Batasuna Support (pop. share)
local bat_call_share_c_note  "Note: Baseline: 2003. 95% confidence intervals based on standard errors clustered by electoral precinct"

local bat_call_share_t_label Dep. Var: Bat Support (turnout share)
local bat_call_share_t_label2 Dependent Variable: Batasuna Support (turnout share)
local bat_call_share_t_note  "Note: Baseline: 2003. 95% confidence intervals based on standard errors clustered by electoral precinct"

local turnout_label Dep. Var: Turnout
local turnout_label2 Dependent Variable: Turnout
local turnout_note           "Note: Baseline: 2003. 95% confidence intervals based on standard errors clustered by electoral precinct"

 
foreach outcome in bat_call_share_c bat_call_share_t turnout{
local text = "``outcome'_note'"
wordwrap "`text'", l(50)
coefplot (g2`outcome', label(``outcome'_label2' )) (g2`outcome'_other, label("``outcome'_label2', concurrent election")), levels(95) omitted keep($eventstudy ) graphregion(color(white))  vertical yline(0) xlabel( 1 "1987" 2 "1991" 3 "1995" 4 "1999" 5 "2003" 6 "2007", angle(45) )   xlabel(,labsize(medsmall)) ylabel(-0.06(0.02)0.02 ,labsize(medsmall))  ytitle(""  , size(medsmall))  name(g2`outcome'noy2, replace) legend(pos(6) rows(2) size(medsmall))


local text = "``outcome'_note'"
wordwrap "`text'", l(50)
coefplot (g2`outcome't, label(``outcome'_label' )) (g2`outcome'_othert, label("``outcome'_label'," "concurrent election")), levels(95) omitted keep($eventstudy ) graphregion(color(white))  vertical yline(0) xlabel( 1 "1987" 2 "1991" 3 "1995" 4 "1999" 5 "2003" 6 "2007", angle(45) )   xlabel(,labsize(medsmall)) ylabel(-0.06(0.02)0.02 ,labsize(medsmall))  ytitle(""  , size(medsmall))  name(g2`outcome'_trendsnoy, replace) legend(pos(6) rows(2) size(vsmall))


local text = "``outcome'_note'"
wordwrap "`text'", l(80)
grc1leg g2`outcome'noy2 g2`outcome'_trendsnoy, ycommon xcommon span name(g2`outcome'non2)  

quietly graph export ../Paper/Output/Figures/g2`outcome'_trends_combinednon2.png , as(png) width(1250) replace
quietly graph export ../Paper/Output/Figures/g2`outcome'_trends_combinednon2.eps , as(eps) replace
quietly graph export ../Paper/Output/Figures/g2`outcome'_trends_combinednon2.pdf , as(pdf) replace

} 





 
**************************COATTAIL EFFECTS TABLES*******************************
 

*TABLE 1 AND TABLE A5
eststo clear
global fixedeffects year group_type year#type year#codi_prov 

capture gen outcome_other=.

local i=0
foreach outcome in bat_call_share_c bat_call_share_t turnout{

local i=`i'+1

replace outcome_other=`outcome'_other

******OLS (COL 1, 4, 7)
eststo ols_`i': reghdfe `outcome' outcome_other  [aweight=meancenso], absorb($fixedeffects) cluster($clustervar)
quietly estadd ysumm 
estadd local group_fe "$\checkmark$"
estadd local year_fe "$\checkmark$"

******BETA COATTAIL (COLS 2, 5, 8)
eststo p2_`i'ivbase: ivreghdfe `outcome' mine_ban   (outcome_other=other_ban) [aweight=meancenso], absorb($fixedeffects) cluster($clustervar)
local iv_beta= _b[outcome_other] 
local se_beta=_se[outcome_other] 

local t=`iv_beta'/`se_beta'
local p=2*ttail(e(df_r),abs(`t'))
local iv_beta=round(`iv_beta', 0.001)
local se_beta=round(`se_beta', 0.001)

local iv_beta_orig=`iv_beta'

if `p'<=0.1 local iv_beta="0`iv_beta'\sym{*}"
if `p'<=0.05 local iv_beta="0`iv_beta_orig'\sym{**} "
if `p'<=0.01 local iv_beta="0`iv_beta_orig'\sym{***} "
local se_beta="(0`se_beta')"

if `i'==3 local iv_beta=""
if `i'==3 local se_beta=""

*****REDUCED FORM (COLS 2, 5, 8)
eststo p2_`i'base: reghdfe `outcome' mine_ban other_ban   [aweight=meancenso], absorb($fixedeffects) cluster($clustervar)
estadd local iv_beta="`iv_beta'"
estadd local iv_se="`se_beta'"
estadd ysumm 
estadd local group_fe "$\checkmark$"
estadd local year_fe "$\checkmark$"

*****REDUCED FORM DISTINGUISHING LOCAL-PROVINCIAL (FOR TABLE A5)
eststo p2_`i'baselocal: reghdfe `outcome' c.mine_ban#c.provincial c.other_ban#c.locale c.mine_ban#c.locale c.other_ban#c.provincial    [aweight=meancenso], absorb($fixedeffects) cluster($clustervar)
estadd local iv_beta="`iv_beta'"
estadd local iv_se="`se_beta'"
estadd ysumm 
estadd local group_fe "$\checkmark$"
estadd local year_fe "$\checkmark$"

******BETA COATTAIL WITH TRENDS (COLS 3, 6, 9)
eststo p2_`i'ivtrends: ivreghdfe `outcome' mine_ban  (outcome_other=other_ban)  year#(${trends_`outcome'_all}) [aweight=meancenso], absorb($fixedeffects) cluster($clustervar)
local iv_beta= _b[outcome_other] 
local se_beta=_se[outcome_other] 

local t=`iv_beta'/`se_beta'
local p=2*ttail(e(df_r),abs(`t'))
local iv_beta=round(`iv_beta', .001)
local se_beta=round(`se_beta', 0.001)

local iv_beta_orig=`iv_beta'

if `p'<=0.1 local iv_beta="0`iv_beta'\sym{*}"
if `p'<=0.05 local iv_beta="0`iv_beta_orig'\sym{**} "
if `p'<=0.01 local iv_beta="0`iv_beta_orig'\sym{***} "
local se_beta="(0`se_beta')"

if `i'==3 local iv_beta=""
if `i'==3 local se_beta=""

*****REDUCED FORM WITH TRENDS (COLS 3, 6, 8)
eststo p2_`i'trends: reghdfe `outcome' mine_ban other_ban  year#(${trends_`outcome'_all}) [aweight=meancenso], absorb($fixedeffects) cluster($clustervar)
estadd local iv_beta="`iv_beta'"
estadd local iv_se="`se_beta'"
estadd ysumm 
estadd local group_fe "$\checkmark$"
estadd local year_fe "$\checkmark$"
estadd local trends "$\checkmark$"

*****REDUCED FORM DISTINGUISHING LOCAL-PROVINCIAL (FOR TABLE A5)
eststo p2_`i'trendslocal: reghdfe `outcome' c.mine_ban#c.provincial c.other_ban#c.locale c.mine_ban#c.locale c.other_ban#c.provincial  year#(${trends_`outcome'_all}) [aweight=meancenso], absorb($fixedeffects) cluster($clustervar)
estadd local iv_beta="`iv_beta'"
estadd local iv_se="`se_beta'"
estadd ysumm 
estadd local group_fe "$\checkmark$"
estadd local year_fe "$\checkmark$"
estadd local trends "$\checkmark$"
}



*Table 1
esttab ols_1 p2_1base p2_1trends ols_2 p2_2base p2_2trends ols_3 p2_3base p2_3trends using ../Paper/Output/Tables/coattail.tex , replace keep(other_ban mine_ban outcome_other ) se star(* 0.10 ** 0.05 *** 0.01) stats( group_fe year_fe trends   ymean N iv_beta   iv_se, labels("\shortstack{ \\   \hspace{-.65cm} Precinct by \hspace{1em} \\ election type FE}" "Year FE\$\dagger$" "Pre-trends"   "Mean Dep. Var" "N" "\hline $\beta^{Coattail}$" " "))  ///
nomtitle collabels(none) mgroups("Bat. Support (pop. share)\$_{pjt}$" "Bat. Support (turnout share)\$_{pjt}$" "Turnout (pop. share)\$_{pjt}$", pattern(1 0 0 1 0 0 1 0 0 )  ///
prefix(\multicolumn{@span}{c}{) suffix(}) span erepeat(\cmidrule(lr){@span})) ///
coeflabels (other_ban "Ban\$_{p-jt}$" mine_ban "Ban\$_{pjt}$" outcome_other "Dep. Var\$_{p-jt}$" ) tex   nonotes  ///
addnotes("\footnotesize  Standard errors clustered by electoral precinct. \sym{*} \(p<0.10\), \sym{**} \(p<0.05\), \sym{***} \(p<0.01\). Observations weighted by the number of eligible voters. \$\dagger\$Year-by-election type FE and Year-by-province FE. Pre-trends specifications include year FE interacted with \$\Delta y_{pjk,pjk-4}$ and by \$\Delta y_{p-jk,p-jk-4}$, for k=1991, ..., 2003. \$\beta^{Coattail}$ estimated with 2SLS, instrumenting Bat. Support\$_{p-jt}$ with Ban\$_{p-jt}$ as an excluded instrument." ) substitute(\_ _ \begin{tabular} \setlength{\linewidth}{.1cm}\newcommand{\contents}{\begin{tabular}           \end{tabular} \end{tabular}}\setbox0=\hbox{\contents}\setlength{\linewidth}{\wd0-2\tabcolsep-.25em}\contents           {l}{\footnotesize {p{\linewidth}}{\footnotesize )


*Table A5
esttab  p2_1baselocal p2_1trendslocal  p2_2baselocal p2_2trendslocal   p2_3baselocal p2_3trendslocal using ../Paper/Output/Tables/coattail_local.tex , replace keep(c.mine_ban#c.provincial c.other_ban#c.locale c.mine_ban#c.locale c.other_ban#c.provincial  ) se star(* 0.10 ** 0.05 *** 0.01) stats( group_fe year_fe trends   ymean N , labels("\shortstack{ \\   \hspace{-.65cm} Precinct by \hspace{1em} \\ election type FE}" "Year FE\$\dagger$" "Pre-trends"   "Mean Dep. Var" "N"  " "))  ///
nomtitle collabels(none) mgroups("Bat. Support (pop. share)\$_{pjt}$" "Bat. Support (turnout share)\$_{pjt}$" "Turnout (pop. share)\$_{pjt}$", pattern(1 0 1 0 1 0 )  ///
prefix(\multicolumn{@span}{c}{) suffix(}) span erepeat(\cmidrule(lr){@span})) ///
coeflabels (c.mine_ban#c.provincial  "Ban\$_{pjt}\times Provincial $" c.other_ban#c.locale "Ban\$_{p-jt}\times Local$" c.mine_ban#c.locale  "Ban\$_{pjt}\times Local $" c.other_ban#c.provincial  "Ban\$_{p-jt}\times Provincial$") tex   nonotes  ///
addnotes("\footnotesize  Standard errors clustered by electoral precinct. \sym{*} \(p<0.10\), \sym{**} \(p<0.05\), \sym{***} \(p<0.01\). Observations weighted by the number of eligible voters. \$\dagger\$Year-by-election type FE and Year-by-province FE. Pre-trends specifications include year FE interacted with \$\Delta y_{pjk,pjk-4}$ and by \$\Delta y_{p-jk,p-jk-4}$, for k=1991, ..., 2003." ) substitute(\_ _ \begin{tabular} \setlength{\linewidth}{.1cm}\newcommand{\contents}{\begin{tabular}           \end{tabular} \end{tabular}}\setbox0=\hbox{\contents}\setlength{\linewidth}{\wd0-2\tabcolsep-.25em}\contents           {l}{\footnotesize {p{\linewidth}}{\footnotesize )



 

*for some strange reason, when doing the post tabular command, it looks like it
* doesn't close the loop, although it actually does
 
********************************************************************************
********************************************************************************


  







********************************************************************************
******************************DESCRIPTIVES**************************************
********************************************************************************

***********************TABLE A1: BY CONCURRENT BAN******************************

gen alava=codi_prov==1
gen bizkaia=codi_prov==2
gen gipuzkoa=codi_prov==3
gen post=year==2007
global sumvars bat_share_c nuls_share_c bat_call_share_c turnout bat_share_t nuls_share_t bat_call_share_t bat_ban_2007 meancenso cens_muni1 local alava bizkaia gipuzkoa

label variable bat_share_c "\\ Batasuna votes (pop. share)"
label variable nuls_share_c " [1em] Null votes (pop. share)"
label variable bat_call_share_c " [1em] Batasuna Support (pop. share)"
label variable turnout " [1em] Turnout"
label variable bat_share_t " [1em] Batasuna votes (turnout share)"
label variable nuls_share_t " [1em] Null votes (turnout share)"
label variable bat_call_share_t " [1em] Batasuna support (turnout share)"
label variable bat_ban_2007 " [1em] Ban\$_{pj2007}$"
label variable meancenso  " [1em] Precinct size"
label variable cens_muni1 " [1em] Municipality size"
label variable local " [1em] Local elections dummy"
label variable alava  " [1em] Araba province"
label variable bizkaia  " [1em] Bizkaia province"
label variable gipuzkoa  " [1em] Gipuzkoa province"

xtset group_type
estpost tabstat	 $sumvars if bat_ban_2007_other==0 & post==0 [aweight=meancenso],  ///
statistics(mean sd) columns(statistics) listwise
est store A
distinct group_type if bat_ban_2007_other==0 & post==0
estadd local clusters_group_type `r(ndistinct)' , replace
distinct ident if bat_ban_2007_other==0 & post==0
estadd local clusters_ident `r(ndistinct)' , replace

estpost tabstat	 $sumvars if bat_ban_2007_other==0 & post==1 [aweight=meancenso],  ///
statistics(mean sd) columns(statistics) listwise
est store B 
distinct group_type if bat_ban_2007_other==0 & post==1
estadd local clusters_group_type `r(ndistinct)' , replace
distinct ident if bat_ban_2007_other==0 & post==1
estadd local clusters_ident `r(ndistinct)' , replace

estpost tabstat	 $sumvars if bat_ban_2007_other==1 & post==0 [aweight=meancenso],  ///
statistics(mean sd) columns(statistics) listwise
est store C
distinct group_type if bat_ban_2007_other==1 & post==0
estadd local clusters_group_type `r(ndistinct)' , replace
distinct ident if bat_ban_2007_other==1 & post==0
estadd local clusters_ident `r(ndistinct)' , replace

estpost tabstat	 $sumvars if bat_ban_2007_other==1 & post==1 [aweight=meancenso],  ///
statistics(mean sd) columns(statistics) listwise
est store D  
distinct group_type if bat_ban_2007_other==1 & post==1
estadd local clusters_group_type `r(ndistinct)' , replace
distinct ident if bat_ban_2007_other==1 & post==1
estadd local clusters_ident `r(ndistinct)' , replace 
  
estpost tabstat	 $sumvars if  post==0 [aweight=meancenso],  ///
statistics(mean sd) columns(statistics) listwise
est store E
distinct group_type if   post==0
estadd local clusters_group_type `r(ndistinct)' , replace
distinct ident if post==0
estadd local clusters_ident `r(ndistinct)' , replace  

estpost tabstat	 $sumvars if   post==1 [aweight=meancenso],  ///
statistics(mean sd) columns(statistics) listwise
est store F   
distinct group_type if  post==1
estadd local clusters_group_type `r(ndistinct)' , replace
distinct ident if post==1
estadd local clusters_ident `r(ndistinct)' , replace  


esttab A B C D E F  using ../Paper/Output/Tables/desc.tex,  main(mean) aux(sd) unstack  nostar   label   /*
*/ tex nogaps  nonumbers nomtitles  /*
*/ s(clusters_group_type clusters_ident  N,  label("\hline \addlinespace[1ex] Electoral Precincts" "Municipalities" "N" )) /* 
*/ prehead("{" "\def\sym#1{\ifmmode^{#1}\else\(^{#1}\)\fi}" "\begin{tabular}{l*{7}{c}}"	"\hline\hline" /*
*/ "Variable Name	&	\multicolumn{2}{c}{Ban\$_{p-j2007}$=1}	& \multicolumn{2}{c}{Ban\$_{p-j2007}$=0}&	\multicolumn{2}{c}{Total}\\" /*	
*/ "\cmidrule(lr){2-3} \cmidrule(lr){4-5} \cmidrule(lr){6-7}" 	"&	Pre	&	Post	&	Pre	&	Post	&	Pre & Post		\\ \hline"  ) /*
*/   nonotes postfoot(\hline\hline \multicolumn{7}{l}{\footnotesize  Standard deviations in parentheses. Observations weigthed by the number of eligible voters by precinct and election type.} \\ \multicolumn{7}{l}{\footnotesize Batasuna support is the sum of Batasuna votes and Null votes.  } /*	
*/ \end{tabular}} ) replace substitute(\_ _)


********************************************************************************
*Here we save the dataset that we use in R for figure A2
save data_final_stata.dta, replace
********************************************************************************





****************************BALANCE TABLE (Table A2)****************************
  
gen delta=1 if bat_ban_2007_other==1 & post==0 
replace delta=0 if bat_ban_2007_other==0 & post==0 
 
global sumvars bat_share_c nuls_share_c bat_call_share_c turnout bat_share_t nuls_share_t bat_call_share_t bat_ban_2007 meancenso cens_muni1 local alava bizkaia gipuzkoa
global balancevars $sumvars  

 
balancetable (mean if delta==1) (mean if delta==0) (diff delta if post==0)  $balancevars using ../Paper/Output/Tables/balance.tex   [aweight=meancenso], vce( cluster $clustervar) replace ctitles(" Ban$_{p-j2007}$=1" "Ban$^{p-j2007}$=0" "Difference") varlabels   groups("Means" "Difference", pattern(1 0 1) end("\cmidrule(lr){2-3} \cmidrule(lr){3-4}" )) postfoot(\hline \multicolumn{4}{p{.825\linewidth}}{Standard deviations clustered by electoral precinct in parentheses. Observations weigthed by the number of eligible voters by precinct and election type.  \sym{*} \(p<0.10\), \sym{**} \(p<0.05\), \sym{***} \(p<0.01\)}  /*
*/ "\end{tabular}"  )  starlevels(* 0.1 ** 0.05 *** 0.01)



**********************ENTROPY BALANCING ESTIMATES (Table A4)********************

egen bat_call_share_cpre=rmean(bat_call_share_c2003 bat_call_share_c1999 bat_call_share_c1995 bat_call_share_c1991 bat_call_share_c1987)
egen bat_call_share_tpre=rmean(bat_call_share_t2003 bat_call_share_t1999 bat_call_share_t1995 bat_call_share_t1991 bat_call_share_t1987)
egen turnoutpre=rmean(turnout2003 turnout1999 turnout1995 turnout1991 turnout1987)


ebalance bat_ban_2007_other  bat_ban_2007  /*
*/ bat_call_share_c2003  bat_call_share_t2003 turnout2003 /*
*/ cens_muni1 local  if year==2007, g(w) tar(1)

egen new_w=max(w), by(group_type)


eststo clear
drop outcome_other
gen outcome_other=.
local i=0
foreach outcome in bat_call_share_c bat_call_share_t turnout{

local i=`i'+1

replace outcome_other=`outcome'_other

eststo ols_`i': reghdfe `outcome' outcome_other  [aweight=new_w], absorb($fixedeffects) cluster($clustervar)
quietly estadd ysumm 
estadd local group_fe "$\checkmark$"
estadd local year_fe "$\checkmark$"

eststo p2_`i'ivbase: ivreghdfe `outcome' mine_ban   (outcome_other=other_ban)  [aweight=new_w], absorb($fixedeffects) cluster($clustervar)
local iv_beta= _b[outcome_other] 
local se_beta=_se[outcome_other] 

local t=`iv_beta'/`se_beta'
local p=2*ttail(e(df_r),abs(`t'))
local iv_beta=round(`iv_beta', 0.001)
local se_beta=round(`se_beta', 0.001)

local iv_beta_orig=`iv_beta'

if `p'<=0.1 local iv_beta="0`iv_beta'\sym{*}"
if `p'<=0.05 local iv_beta="0`iv_beta_orig'\sym{**} "
if `p'<=0.01 local iv_beta="0`iv_beta_orig'\sym{***} "
local se_beta="(0`se_beta')"

if `i'==3 local iv_beta=""
if `i'==3 local se_beta=""

eststo p2_`i'base: reghdfe `outcome' mine_ban other_ban    [aweight=new_w], absorb($fixedeffects) cluster($clustervar)
estadd local iv_beta="`iv_beta'"
estadd local iv_se="`se_beta'"
estadd ysumm 
estadd local group_fe "$\checkmark$"
estadd local year_fe "$\checkmark$"



eststo p2_`i'ivtrends: ivreghdfe `outcome' mine_ban  (outcome_other=other_ban)  year#(${trends_`outcome'_all})  [aweight=new_w], absorb($fixedeffects) cluster($clustervar)
local iv_beta= _b[outcome_other] 
local se_beta=_se[outcome_other] 

local t=`iv_beta'/`se_beta'
local p=2*ttail(e(df_r),abs(`t'))
local iv_beta=round(`iv_beta', .001)
local se_beta=round(`se_beta', 0.001)

local iv_beta_orig=`iv_beta'


if `p'<=0.1 local iv_beta="0`iv_beta'\sym{*}"
if `p'<=0.05 local iv_beta="0`iv_beta_orig'\sym{**} "
if `p'<=0.01 local iv_beta="0`iv_beta_orig'\sym{***} "
local se_beta="(0`se_beta')"

if `i'==3 local iv_beta=""
if `i'==3 local se_beta=""

eststo p2_`i'trends: reghdfe `outcome' mine_ban other_ban  year#(${trends_`outcome'_all})  [aweight=new_w], absorb($fixedeffects) cluster($clustervar)
estadd local iv_beta="`iv_beta'"
estadd local iv_se="`se_beta'"
estadd ysumm 
estadd local group_fe "$\checkmark$"
estadd local year_fe "$\checkmark$"
estadd local trends "$\checkmark$"

 
}



esttab ols_1 p2_1base p2_1trends ols_2 p2_2base p2_2trends ols_3 p2_3base p2_3trends using ../Paper/Output/Tables/coattail_eb.tex , replace keep(other_ban mine_ban outcome_other ) se star(* 0.10 ** 0.05 *** 0.01) stats( group_fe year_fe trends   ymean N iv_beta   iv_se, labels("\shortstack{ \\   \hspace{-.65cm} Precinct by \hspace{1em} \\ election type FE}" "Year FE\$\dagger$" "Pre-trends"   "Mean Dep. Var" "N" "\hline $\beta^{Coattail}$" " "))  ///
nomtitle collabels(none) mgroups("Bat. Support (pop. share)\$_{pjt}$" "Bat. Support (turnout share)\$_{pjt}$" "Turnout (pop. share)\$_{pjt}$", pattern(1 0 0 1 0 0 1 0 0 )  ///
prefix(\multicolumn{@span}{c}{) suffix(}) span erepeat(\cmidrule(lr){@span})) ///
coeflabels (other_ban "Ban\$_{p-jt}$" mine_ban "Ban\$_{pjt}$" outcome_other "Dep. Var\$_{p-jt}$" ) tex   nonotes  ///
addnotes("\footnotesize  Standard errors clustered by electoral precinct. \sym{*} \(p<0.10\), \sym{**} \(p<0.05\), \sym{***} \(p<0.01\). \$\dagger\$Year-by-election type FE and Year-by-province FE. Pre-trends specifications include year FE interacted with \$\Delta y_{pjk,pjk-4}$ and by \$\Delta y_{p-jk,p-jk-4}$, for k=1991, ..., 2003. \$\beta^{Coattail}$ estimated with 2SLS, instrumenting Bat. Support\$_{p-jt}$ with Ban\$_{p-jt}$ as an excluded instrument. Observations reweighted with entropy balance weights such that those with and without a ban in a concurrent 2007 election feature the same average municipality size, precinct size, ban in the 2007 election, support for Batasuna (both measures) and turnout in 2003." ) substitute(\_ _ \begin{tabular} \setlength{\linewidth}{.1cm}\newcommand{\contents}{\begin{tabular}           \end{tabular} \end{tabular}}\setbox0=\hbox{\contents}\setlength{\linewidth}{\wd0-2\tabcolsep-.25em}\contents           {l}{\footnotesize {p{\linewidth}}{\footnotesize )






