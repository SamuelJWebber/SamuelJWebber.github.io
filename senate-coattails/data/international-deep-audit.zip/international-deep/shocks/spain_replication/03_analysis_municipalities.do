


*Similar to as 02_analysis.do but with results at the municipality level

clear all
capture cd $datapath


clear all

forval z=1987(4)2007{
append using data_`z'_jmes.dta
}

gen type=1
gen type_string="juntas"

forval z=1987(4)2007{
append using data_`z'_mmes.dta
}

replace type=2 if type==.
replace type_string="munis" if type_string==""

foreach var in hb eh eaeanv batasuna{
replace `var'=0 if `var'==.
}
drop hb eh eaeanv

*First collapse to district, then to municipality
ds codi_pro codi_mun nom_muni distrito seccion mesa year type type_string, not
bysort codi_pro codi_mun: replace nom_muni =nom_muni[_N]

*By district
collapse (sum) `r(varlist)', by(codi_pro codi_mun nom_muni distrito year type type_string)
*By municipality
ds codi_pro codi_mun nom_muni distrito year type type_string, not
collapse (sum) `r(varlist)', by(codi_pro codi_mun nom_muni year type type_string)
global analysis_level codi_pro codi_mun  
global analysis_string codi_mun codi_pro


 

forval z=1987(4)2007{
gen bat_present_`z'_aux=(batasuna>0) if year==`z'
egen bat_present_`z'=max(bat_present_`z'_aux), by(codi_mun codi_pro type)
drop bat_present_`z'_aux
gen bat_present_`z'muniaux=bat_present_`z' if type==2
egen bat_present_`z'muni =max(bat_present_`z'muniaux), by(codi_mun codi_pro)
gen bat_present_`z'juntaux=bat_present_`z' if type==1
egen bat_present_`z'junt =max(bat_present_`z'juntaux), by(codi_mun codi_pro)
drop bat_present_`z'muniaux bat_present_`z'juntaux
}




gen strong_presence=(bat_present_1995muni==1 & bat_present_1999muni==1)
 
egen group=group($analysis_level)
egen ident=group(codi_mun codi_pro)
egen group_type=group(group type)
egen ident_type=group(ident type)
egen group_year=group(group year)
egen ident_year=group(ident year)
egen type_year=group(type year)
egen codi_prov=group(codi_pro)
 

gen bat_share_c=batasuna/censo
gen bat_share_t=batasuna/votantes
gen bat_call_share_c=(batasuna+nulos)/censo
gen bat_call_share_t=(batasuna+nulos)/votantes
gen turnout=votantes/censo

foreach var in bat_share_c bat_share_t bat_call_share_c bat_call_share_t turnout votantes blancos validos nulos censo{
gen aux=`var' if type==1
egen maux=max(aux), by(group_year)
gen `var'_other=maux if type==2
drop aux maux
gen aux=`var' if type==2
egen maux=max(aux), by(group_year)
replace `var'_other=maux if type==1
drop aux maux
}

gen bat_legal_2007_aux=(batasuna>0)*(year==2007)
egen bat_legal_2007=max(bat_legal_2007_aux), by(ident_type)
gen bat_ban_2007=1-bat_legal_2007
drop bat_legal_2007_aux


foreach var in bat_legal_2007 bat_ban_2007{
gen aux_`var'=`var' if type==1
egen maux_`var'=max(aux_`var'), by(ident)
gen `var'_other=maux_`var' if type==2
drop aux_`var' maux_`var'

gen aux_`var'=`var' if type==2
egen maux_`var'=max(aux_`var'), by(ident)
replace `var'_other=maux_`var' if type==1
drop aux_`var' maux_`var'
}


gen mine_ban=year==2003
gen other_ban=year==2003
replace mine_ban=(bat_ban_2007==1) if year==2007
replace other_ban=(bat_ban_2007_other==1) if year==2007

gen mine_legal=(year<=1999)
replace mine_legal=(bat_legal_2007==1) if year==2007
gen other_legal=(year<=1999)
replace other_legal=(bat_legal_2007_other==1) if year==2007



*Support in the different years
foreach var in bat_call_share_t bat_call_share_c turnout bat_call_share_t_other bat_call_share_c_other turnout_other{
forval z=1987(4)2007{
gen `var'`z'aux=`var' if year==`z'
egen `var'`z'=max(`var'`z'aux), by(group_type)
drop `var'`z'aux
}
}
drop if bat_call_share_t1999==. | bat_call_share_t1995==. | bat_call_share_t1991==. | bat_call_share_t1987==.
keep if strong_presence==1






forval z=1991(4)2003{
local w=`z'-4
gen dbat_call_share_c`z'=bat_call_share_c`z'-bat_call_share_c`w'
gen dbat_call_share_t`z'=bat_call_share_t`z'-bat_call_share_t`w'
gen dturnout`z'=turnout`z'-turnout`w'

gen dbat_call_share_c_other`z'=bat_call_share_c_other`z'-bat_call_share_c_other`w'
gen dbat_call_share_t_other`z'=bat_call_share_t_other`z'-bat_call_share_t_other`w'
gen dturnout_other`z'=turnout_other`z'-turnout_other`w'
}


global trends_bat_call_share_c c.dbat_call_share_c2003 c.dbat_call_share_c1999 c.dbat_call_share_c1995 c.dbat_call_share_c1991
global trends_bat_call_share_c_other c.dbat_call_share_c_other2003 c.dbat_call_share_c_other1999 c.dbat_call_share_c_other1995 c.dbat_call_share_c_other1991
global trends_bat_call_share_c_all  $trends_bat_call_share_c $trends_bat_call_share_c_other

global trends_bat_call_share_t  c.dbat_call_share_t2003 c.dbat_call_share_t1999 c.dbat_call_share_t1995 c.dbat_call_share_t1991
global trends_bat_call_share_t_other  c.dbat_call_share_t_other2003 c.dbat_call_share_t_other1999 c.dbat_call_share_t_other1995 c.dbat_call_share_t_other1991
global trends_bat_call_share_t_all   $trends_bat_call_share_t $trends_bat_call_share_t_other

global trends_turnout c.dturnout2003 c.dturnout1999 c.dturnout1995 c.dturnout1991
global trends_turnout_other c.dturnout_other2003 c.dturnout_other1999 c.dturnout_other1995 c.dturnout_other1991
global trends_turnout_all $trends_turnout $trends_turnout_other

global trends_all $trends_bat_call_share_c_all $trends_bat_call_share_t_all $trends_turnout_all

gen meancenso=censo

 
******************************************************************************** 
********************************TABLE A3****************************************
********************************************************************************



eststo clear
global fixedeffects year group_type year#type year#codi_prov 
global clustervar group  

capture gen outcome_other=.

local i=0
foreach outcome in bat_call_share_c bat_call_share_t turnout{

local i=`i'+1

replace outcome_other=`outcome'_other

*****OLS
eststo ols_`i': reghdfe `outcome' outcome_other  [aweight=meancenso], absorb($fixedeffects) cluster($clustervar)
quietly estadd ysumm 
estadd local group_fe "$\checkmark$"
estadd local year_fe "$\checkmark$"
*****IV (compute coattail effect)
eststo p2_`i'ivbase: ivreghdfe `outcome' mine_ban  (outcome_other=other_ban) [aweight=meancenso], absorb($fixedeffects) cluster($clustervar)
local iv_beta= _b[outcome_other] 
local se_beta=_se[outcome_other] 

local t=`iv_beta'/`se_beta'
local p=2*ttail(e(df_r),abs(`t'))
local iv_beta=round(`iv_beta', 0.001)
local se_beta=round(`se_beta', 0.001)

local iv_beta_orig=`iv_beta'

if `p'<=0.1 local iv_beta="0`iv_beta'\sym{*}"
if `p'<=0.05 local iv_beta="0`iv_beta_orig'\sym{**} "
if `p'<=0.01 local iv_beta="0`iv_beta_orig'\sym{***} "
local se_beta="(0`se_beta')"

if `i'==3 local iv_beta=""
if `i'==3 local se_beta=""

*****Reduced form
eststo p2_`i'base: reghdfe `outcome' mine_ban other_ban  [aweight=meancenso], absorb($fixedeffects) cluster($clustervar)
estadd local iv_beta="`iv_beta'"
estadd local iv_se="`se_beta'"
estadd ysumm 
estadd local group_fe "$\checkmark$"
estadd local year_fe "$\checkmark$"

*****Coattail effects with trends
eststo p2_`i'ivtrends: ivreghdfe `outcome' mine_ban  (outcome_other=other_ban)  year#(${trends_`outcome'_all}) [aweight=meancenso], absorb($fixedeffects) cluster($clustervar)
local iv_beta= _b[outcome_other] 
local se_beta=_se[outcome_other] 

local t=`iv_beta'/`se_beta'
local p=2*ttail(e(df_r),abs(`t'))
local iv_beta=round(`iv_beta', .001)
local se_beta=round(`se_beta', 0.001)



local iv_beta_orig=`iv_beta'


if `p'<=0.1 local iv_beta="0`iv_beta'\sym{*}"
if `p'<=0.05 local iv_beta="0`iv_beta_orig'\sym{**} "
if `p'<=0.01 local iv_beta="0`iv_beta_orig'\sym{***} "
local se_beta="(0`se_beta')"

if `i'==3 local iv_beta=""
if `i'==3 local se_beta=""

*****Reduced form with trends
eststo p2_`i'trends: reghdfe `outcome' mine_ban other_ban  year#(${trends_`outcome'_all}) [aweight=meancenso], absorb($fixedeffects) cluster($clustervar)
estadd local iv_beta="`iv_beta'"
estadd local iv_se="`se_beta'"
estadd ysumm 
estadd local group_fe "$\checkmark$"
estadd local year_fe "$\checkmark$"
estadd local trends "$\checkmark$"
}



esttab ols_1 p2_1base p2_1trends ols_2 p2_2base p2_2trends ols_3 p2_3base p2_3trends using ../Paper/Output/Tables/coattail_mun.tex , replace keep(other_ban mine_ban outcome_other ) se star(* 0.10 ** 0.05 *** 0.01) stats( group_fe year_fe trends  ymean N iv_beta   iv_se, labels("\shortstack{ \\ \hspace{-1em} Municipality by\\election type FE}" "Year FE\$\dagger$" "Pre-trends"  "Mean Dep. Var" "N" "\hline $\beta^{Coattail}$" " "))  ///
nomtitle collabels(none) mgroups("Bat. Support (pop. share)\$_{mjt}$" "Bat. Support (turnout share)\$_{mjt}$" "Turnout\$_{mjt}$", pattern(1 0 0 1 0 0 1 0 0 )  ///
prefix(\multicolumn{@span}{c}{) suffix(}) span erepeat(\cmidrule(lr){@span})) ///
coeflabels (other_ban "Ban\$_{m-jt}$" mine_ban "Ban\$_{mjt}$" outcome_other "Dep. Var\$_{m-jt}$" ) tex   nonotes  ///
addnotes("\footnotesize  Standard errors clustered by municipality. \sym{*} \(p<0.10\), \sym{**} \(p<0.05\), \sym{***} \(p<0.01\). Observations weighted by the number of eligible voters. \$\dagger$ Year-by-election type FE and Year-by-province FE. Pre-trends specifications include year FE interacted with \$\Delta y_{mjk,mjk-4}$ and by \$\Delta y_{m-jk,m-jk-4}$, for k=1991, ..., 2003. $\beta^{Coattail}$ estimated with 2SLS, instrumenting Bat. Support\$_{m-jt}$ with Ban\$_{m-jt}$ as an excluded instrument." ) substitute(\_ _ \begin{tabular} \setlength{\linewidth}{.1cm}\newcommand{\contents}{\begin{tabular}           \end{tabular} \end{tabular}}\setbox0=\hbox{\contents}\setlength{\linewidth}{\wd0-2\tabcolsep-.25em}\contents           {l}{\footnotesize {p{\linewidth}}{\footnotesize )


