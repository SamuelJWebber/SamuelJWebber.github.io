# Spain/Brazil execution report

Execution date: 2026-11-06. This folder contains actual downloaded public data and executed calculations, not simulated observations. The Spain estimates reproduce an existing party-ban study; they are not a new estimate of all-star candidate quality.

## Executed Spain replication

Source: Andreu Arenas (2024), *Coattail effects and turnout: Evidence from a quasi-experiment*, Research & Politics, https://doi.org/10.1177/20531680241229930. Official replication: https://doi.org/10.7910/DVN/JEJPVM.

All 21 deposited files were downloaded through documented Harvard Dataverse APIs. `spain_download_manifest.json` records original-file endpoints, byte sizes and SHA-256 hashes. The original CSVs returned by `?format=original` sometimes retain the Dataverse `.tab` filename in our local archive; their content is comma-separated Latin-1. `spain_dataset_metadata.json` records version 1 and CC0-1.0, with no additional restrictions.

`replicate_spain.py` independently translates the authors' cleaning and main Table 1 estimator to Python. It uses weighted least squares and just-identified 2SLS after projecting out fixed effects; cluster covariances are computed explicitly. No Stata execution is claimed. The separate sensitivity analysis below was executed with the actual R packages. Coefficients reproduce the paper's rounded entries. Small standard-error differences from original Stata degrees-of-freedom conventions are retained and disclosed.

| Population-support result | Published-style precinct clustering | Additional municipality clustering |
|---|---:|---:|
| Baseline concurrent-ban effect | -0.006667 (SE 0.002043) | -0.006667 (SE 0.003348) |
| Adjusted concurrent-ban effect | -0.008091 (SE 0.001616) | -0.008091 (SE 0.002847) |
| Baseline coattail ratio | 0.273861 (SE 0.062556) | 0.273861 (SE 0.101105) |
| Adjusted coattail ratio | 0.314530 (SE 0.045621) | 0.314530 (SE 0.078134) |

The first two effects are proportions: -0.006667 means -0.667 percentage points. The coattail ratio is percentage points per percentage point. The precinct panel has 3,360 rows, 280 precincts, 182 municipalities and six elections, 1987–2007. The distinct municipality-aggregated robustness uses 2,184 rows; its population-support ratios are 0.256591 and 0.302409. Twelve published-coefficient rounding checks passed in `replication_verification.json`.

Outputs include the complete analysis panels, 2007 treatment rosters, main reduced-form/IV tables, baseline event-study estimates, sample checks, and `spain_dashboard.json`.

Interpretation matters: support is party votes plus invalid ballots, divided by registered voters (or, in a separate specification, voters who turned out). The authors' code infers a 2007 ban from zero party votes within municipality×office; the deposit does not provide an independent court-decision roster. The identifying shock changes party-list availability. It is not a measure of candidate charisma. The design needs appropriate parallel trends; the IV ratio also needs the ban's cross-election effect to operate through the modeled support channel. The municipality-cluster robustness uses the same precinct observations and treats municipalities as clusters; it is different from aggregating outcomes to municipality level.

The entropy-balancing Table A4 robustness was executed by translating the deposited `ebalance.ado` Newton algorithm, including its default tolerance and stopping convention. Population-support IV ratios are 0.397418 and 0.401144; voter-support ratios are 0.304038 and 0.290605. The six moments follow the deposited command: own-office ban, 2003 population/voter support, 2003 turnout, municipality electorate, and local-office indicator. The paper's table note also mentions precinct size, which is absent from that command. Treated units retain weight one; controls are calibrated to the treated moment targets, without an additional electorate-weight multiplier. The default algorithm's maximum standardized moment discrepancy is 0.000669. A separately solved strict convex optimum has discrepancy below 4e-10; its solver reports a numerical improvement warning, so the published-style outputs use the original default algorithm. Both diagnostics are preserved.

`honest_spain.R` executed all three outcomes with R 4.4.3, fixest 0.14.2 and HonestDiD 0.2.6. All 15 event-study coefficients were checked against the independent Python estimates, and all 45 C-LF sensitivity intervals were validated. Input and fitted samples are both 3,360 rows. The R package covariance is used for the sensitivity analysis; minor differences from Python's independent cluster correction remain visible.

The sensitivity parameter Mbar bounds the absolute **change** in the untreated treated-control gap from 2003 to 2007, relative to the largest absolute change between consecutive pretreatment elections. It concerns first differences, not gap levels or second differences. At Mbar = 1, the post-treatment counterfactual gap may drift as much as the largest pretreatment adjacent-election drift. Confidence intervals account for uncertainty in estimated pre-trends. See the authors' official method documentation: https://github.com/asheshrambachan/HonestDiD#background and the exact formula in `spain_results_honestdid/honestdid_summary.json`.

| Reduced-form outcome | 95% interval at Mbar = 1 (percentage points) | First tested Mbar whose interval includes zero |
|---|---:|---:|
| Support / registered voters | [-1.444, 0.139] | 0.8 |
| Support / voters | [-2.358, 0.361] | 0.4 |
| Turnout | [-4.355, -0.207] | 1.2 |

The grid runs from 0.1 to 1.5 in steps of 0.1. These crossings are grid summaries, not exact breakdown values. These are **reduced-form ban spillover intervals**, not sensitivity intervals for the IV ratio. PDFs were rendered and visually checked. An incomplete preliminary panel was caught by the sample checks, regenerated atomically, and the R analysis rerun; that invalid preliminary run is excluded from public files.

Reproduction commands (Python with pandas, numpy and scipy):

```sh
python download_spain.py
OPENBLAS_NUM_THREADS=1 python replicate_spain.py
OPENBLAS_NUM_THREADS=1 python replicate_spain.py --municipal
OPENBLAS_NUM_THREADS=1 python replicate_spain.py --cluster-municipal
OPENBLAS_NUM_THREADS=1 python replicate_spain.py --entropy
# Install fixest and HonestDiD in an R environment; see recorded package versions.
OPENBLAS_NUM_THREADS=1 Rscript honest_spain.R .
python verify_outputs.py
```

## Executed Brazil data preparation

Official sources: https://dadosabertos.tse.jus.br/dataset/resultados-2004 and https://dadosabertos.tse.jus.br/dataset/candidatos-2004 . `download_brazil.py` lists direct official ZIP endpoints. The TSE portals specify Creative Commons Attribution. `prepare_brazil_outcomes.py` reads the national BRASIL files once; it does not concatenate duplicate state copies.

Prepared 56,948 municipality×party council outcomes across 5,560 municipalities. Party nominal votes reconcile exactly with independently aggregated candidate nominal votes in every row. Party votes equal nominal plus party-label votes. No turnout denominator is missing, and none exceeds one.

The historic status `MÉDIA` must count as elected along with `ELEITO`. This yields 51,811 seats and matches official vacancies in every municipality with observed council outcomes. The vacancy file has 51,838 seats: Campos/RJ (18) and Vassouras/RJ (9) lack council outcomes in both the national and corresponding state files. Missing outcomes are not zeros. The 2004 eligible-voter denominator is contemporaneous, not a frozen pre-audit electorate.

The downloaded candidate-registration ZIP contains personal identifier/contact columns. Those fields are not used in calculations and the ZIP must not be copied to public deliverables. Public-ready derived outputs contain only municipality/party aggregates and public institutional labels.

## Brazil audit roster: concrete progress, failed replication gate

Downloaded official CGU lottery pages and parsed all 676 selections in official draws 2–14. Draw 1 is a separate five-town pilot. The published Ferraz–Finan (2008) paper describes 376 selections with reports disclosed before the October election and 300 after: these counts match draws 2–9 (26 + 7×50) and 10–14 (5×60). Draws 10–12 occurred before election day even though their reports belong to the paper's later-disclosure cohort, so using draw date as publication date is wrong.

Twelve explicit spelling/historical-name aliases are recorded in `manual_name_crosswalk.csv`; all 676 records now match a TSE municipality ID. Primary rename checks include IBGE's Serra Caiada/Presidente Juscelino history, https://www.ibge.gov.br/en/statistics/full-list-statistics/18448-population-estimates.html?edicao=18450 , and Piçarras/Balneário Piçarras history, https://biblioteca.ibge.gov.br/visualizacao/dtb/santacatarina/balneariopicarras.pdf .

However, the official reconstructed roster has **670 distinct municipalities and six repeats**, while the paper reports 669 and seven repeats. This discrepancy is unresolved. One of our roster municipalities, Vassouras, lacks the 2004 council outcome. Its exclusion would happen to produce 669 observations; that coincidence does not validate the original paper's sample. The provisional CSV preserves the discrepancy and every excluded/missing row.

Individual report-publication dates, the original corruption-severity coding, lottery-specific eligible risk sets, pre-audit incumbent party, and original mayor-term eligibility are not reconstructed. Changes in lottery population eligibility must be resolved before treating timing as randomized in this new sample. The original paper's mayor-reelection sample is 373, with 205 pre-election and 168 post-election cases; its Figure I caption reverses these numbers, while Table I and the main text agree.

**No Brazilian causal council effect has been estimated.** The prepared council outcomes and provisional roster make the remaining requirements explicit; they do not establish an all-star or scandal effect.

The 2008 exact replication package was not found. A different 2011 AER package is publicly listed at https://www.openicpsr.org/openicpsr/project/112431/version/V1/view, but downloading led to an ICPSR sign-in page. No login or terms acceptance occurred. The different 2018 JPE archive returned HTTP403. Muço's 2025 JEBO paper, https://doi.org/10.1016/j.jebo.2025.106897, already studies audit-related party-network spillovers; its publisher states that data are available on request. No outreach occurred.

Brazil reconstruction commands additionally require BeautifulSoup:

```sh
python download_brazil.py
python prepare_brazil_outcomes.py
python download_cgu_roster.py
python prepare_cgu_roster.py
```

## Public integration

Use the explicit `PUBLIC_FILES.json` whitelist. It includes code, source provenance, Spain deposited data (CC0), aggregate outputs and provisional institutional rosters. It excludes the entire `brazil_sources/` directory, candidate registration data, publisher PDFs/HTML, login pages and redundant scratch downloads, compiled runtimes, and all preliminary runs under `robustness_setup/`. Source URLs and attribution remain in the accompanying files. `spain_dashboard.json` is the compact dashboard import; Brazil outputs must remain labeled prepared/provisional, with no causal estimate.
