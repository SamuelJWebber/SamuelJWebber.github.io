import urllib.request, json, pathlib, concurrent.futures, hashlib, time
root=pathlib.Path(__file__).parent
out=root/'spain_replication';out.mkdir(exist_ok=True)
metadata_urls={'spain_dataset_metadata.json':'https://dataverse.harvard.edu/api/datasets/export?exporter=dataverse_json&persistentId=doi:10.7910/DVN/JEJPVM','spain_file_list.json':'https://dataverse.harvard.edu/api/datasets/:persistentId/versions/:latest/files?persistentId=doi:10.7910/DVN/JEJPVM'}
for name,url in metadata_urls.items():
 if not (root/name).exists():
  data=urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0'}),timeout=45).read();(root/name).write_bytes(data)
files=json.loads((root/'spain_file_list.json').read_text())['data']
def grab(x):
 f=x['dataFile']; target=out/f['filename'];url=f"https://dataverse.harvard.edu/api/access/datafile/{f['id']}?format=original"
 for k in range(3):
  try:
   data=urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0'}),timeout=40).read();target.write_bytes(data)
   return {'file':f['filename'],'id':f['id'],'url':url,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
  except Exception as e:
   if k==2:return {'file':f['filename'],'error':str(e)}
with concurrent.futures.ThreadPoolExecutor(max_workers=5) as ex:
 results=list(ex.map(grab,files))
(root/'spain_download_manifest.json').write_text(json.dumps(results,indent=2))
for r in results:print(r['file'],r.get('bytes',r.get('error')),flush=True)
