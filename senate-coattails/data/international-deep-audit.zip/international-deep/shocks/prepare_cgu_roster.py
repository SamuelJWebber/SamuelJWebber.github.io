from pathlib import Path
import pandas as pd,json,re,unicodedata,difflib,zipfile
root=Path(__file__).parent;rows=[];fail=[]
for d in json.loads((root/'brazil_sources/cgu_roster/source_rosters.json').read_text()):
 if not 2<=d['draw']<=14:continue
 date=re.search(r'\d{2}/\d{2}/\d{4}',d['description'])[0]
 for line in d['text'].splitlines():
  if not re.match(r'^\d+[º°]',line):continue
  m=re.match(r'^(\d+)[º°]\s*-\s*(.*?)\s*(?:-\s*|/\s*)([A-Z]{2})(?:\s*-?\s*\(.*\))?\s*$',line)
  if not m:fail.append({'draw':d['draw'],'line':line});continue
  rows.append({'draw':d['draw'],'draw_date':date,'rank':int(m[1]),'municipality_as_printed':m[2].strip(),'SG_UF':m[3],'source_url':d['url'],'disclosure_pre_election_inferred_cohort':int(d['draw']<=9),'classification_basis':'Paper Figure II: first8 of13 study lotteries published pre-election; mapped to official draws2-9 after five-town pilot. Individual report dates not retrieved.'})
def norm(x):return re.sub('[^A-Z0-9]','',unicodedata.normalize('NFKD',str(x).upper()).encode('ascii','ignore').decode())
r=pd.DataFrame(rows);r['name_key']=r.municipality_as_printed.map(norm)
aliases={('PE','ILHADEITAMARACA'):'ITAMARACA',('SP','IPAUSSU'):'IPAUCU',('GO','GOIANOPOLIS'):'GOIANAPOLIS',('RO','ALVORADADOESTE'):'ALVORADADOOESTE',('MS','BATAYPORA'):'BATAIPORA',('RN','PRESIDENTEJUSCELINO'):'SERRACAIADA',('SC','PICARRAS'):'BALNEARIOPICARRAS',('RJ','SAOJOAODOMERITI'):'SAOJOAODEMERITI',('RS','SAOLUIZGONZAGA'):'SAOLUISGONZAGA',('PR','CONSELHEIROMAIRINCK'):'CONSELHEIROMAYRINCK',('SP','FLORINIA'):'FLORINEA',('MS','JUTI'):'JUTY'}
r['original_name_key']=r.name_key
r['name_key']=[aliases.get((uf,k),k) for uf,k in zip(r.SG_UF,r.name_key)]
r['manual_alias_applied']=r.name_key.ne(r.original_name_key)
pd.DataFrame([{'SG_UF':uf,'cgu_normalized_name':a,'tse_normalized_name':b,'basis':'Explicit spelling or historical-name crosswalk; see README for primary IBGE rename sources'} for (uf,a),b in aliases.items()]).to_csv(root/'brazil_prepared/manual_name_crosswalk.csv',index=False)
mun=pd.read_csv(root/'brazil_prepared/council_party_outcomes_2004.csv',dtype={'CD_MUNICIPIO':str})[['SG_UF','CD_MUNICIPIO','NM_MUNICIPIO']].drop_duplicates();mun['name_key']=mun.NM_MUNICIPIO.map(norm)
# Add vacancies dictionary so missing election outcomes do not erase municipalities.
with zipfile.ZipFile(root/'brazil_sources/vacancies_2004.zip') as z:
 f=next(x for x in z.namelist() if x.endswith('BRASIL.csv'))
 names=pd.read_csv(z.open(f),sep=';',encoding='latin1',usecols=['SG_UF','SG_UE','NM_UE'],dtype={'SG_UE':str}).rename(columns={'SG_UE':'CD_MUNICIPIO','NM_UE':'NM_MUNICIPIO'}).drop_duplicates()
names['name_key']=names.NM_MUNICIPIO.map(norm)
mun=pd.concat([mun,names]).drop_duplicates(['SG_UF','CD_MUNICIPIO','name_key'])
mun=mun.drop_duplicates(['SG_UF','name_key'])
r=r.merge(mun,on=['SG_UF','name_key'],how='left',validate='many_to_one')
for _,x in r[r.CD_MUNICIPIO.isna()].iterrows():
 cand=mun[mun.SG_UF==x.SG_UF];matches=difflib.get_close_matches(x.name_key,cand.name_key.tolist(),n=2,cutoff=.65)
 print('UNMATCHED',x['draw'],x.municipality_as_printed,x.SG_UF,[(q,cand[cand.name_key==q].NM_MUNICIPIO.tolist()) for q in matches])
r.to_csv(root/'brazil_prepared/cgu_draw_roster_provisional.csv',index=False)
unique=r.sort_values('draw').drop_duplicates(['SG_UF','CD_MUNICIPIO']).copy()
outcome_keys=pd.read_csv(root/'brazil_prepared/council_party_outcomes_2004.csv',usecols=['SG_UF','CD_MUNICIPIO'],dtype={'CD_MUNICIPIO':str}).drop_duplicates();outcome_keys['council_outcomes_present']=True
unique=unique.merge(outcome_keys,on=['SG_UF','CD_MUNICIPIO'],how='left',validate='one_to_one');unique['council_outcomes_present']=unique.council_outcomes_present.fillna(False)
unique.to_csv(root/'brazil_prepared/cgu_municipality_roster_provisional.csv',index=False)
print('Repeated municipalities',r[r.duplicated(['SG_UF','CD_MUNICIPIO'],keep=False)][['draw','SG_UF','CD_MUNICIPIO','NM_MUNICIPIO']].to_string(index=False))
check={'draw_records':len(r),'draw_counts':r.groupby('draw').size().to_dict(),'unique_state_normalized_names':len(r[['SG_UF','name_key']].drop_duplicates()),'matched_records':int(r.CD_MUNICIPIO.notna().sum()),'unique_matched_municipalities':len(r[r.CD_MUNICIPIO.notna()][['SG_UF','CD_MUNICIPIO']].drop_duplicates()),'pre_election_draw_records':int(r.disclosure_pre_election_inferred_cohort.sum()),'post_election_draw_records':int((1-r.disclosure_pre_election_inferred_cohort).sum()),'unique_early_disclosure_municipalities':int(unique.disclosure_pre_election_inferred_cohort.sum()),'unique_late_disclosure_municipalities':int((1-unique.disclosure_pre_election_inferred_cohort).sum()),'missing_council_outcome_municipalities':unique.loc[~unique.council_outcomes_present,['SG_UF','CD_MUNICIPIO','NM_MUNICIPIO']].to_dict('records'),'unparsed_lines':fail,'treatment_status':'PROVISIONAL: count-match to paper; individual report dates and lottery-specific eligibility unresolved'}
(root/'brazil_prepared/cgu_roster_validation.json').write_text(json.dumps(check,indent=2));print(json.dumps(check,indent=2))
