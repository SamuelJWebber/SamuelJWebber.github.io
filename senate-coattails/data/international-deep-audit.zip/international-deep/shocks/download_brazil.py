import urllib.request,pathlib,concurrent.futures,zipfile,json,hashlib
root=pathlib.Path(__file__).parent/'brazil_sources';root.mkdir(exist_ok=True)
urls={
'candidate_votes_2004.zip':'https://cdn.tse.jus.br/estatistica/sead/odsele/votacao_candidato_munzona/votacao_candidato_munzona_2004.zip',
'party_votes_2004.zip':'https://cdn.tse.jus.br/estatistica/sead/odsele/votacao_partido_munzona/votacao_partido_munzona_2004.zip',
'voting_details_2004.zip':'https://cdn.tse.jus.br/estatistica/sead/odsele/detalhe_votacao_munzona/detalhe_votacao_munzona_2004.zip',
'coalitions_2004.zip':'https://cdn.tse.jus.br/estatistica/sead/odsele/consulta_coligacao/consulta_coligacao_2004.zip',
'vacancies_2004.zip':'https://cdn.tse.jus.br/estatistica/sead/odsele/consulta_vagas/consulta_vagas_2004.zip',
'jpe2018_replication.zip':'https://www.journals.uchicago.edu/doi/suppl/10.1086/699209/suppl_file/2016532data.zip',
'aer2011_replication.html':'https://www.openicpsr.org/openicpsr/project/112431/version/V1/view',
'finan_home.html':'https://berkeley-econ.github.io/ffinan-site/'
}
def grab(item):
 name,url=item
 try:
  d=urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0'}),timeout=60).read();(root/name).write_bytes(d)
  out={'name':name,'url':url,'bytes':len(d),'sha256':hashlib.sha256(d).hexdigest()}
  if name.endswith('.zip'):
   with zipfile.ZipFile(root/name) as z:out['members']=z.namelist()
 except Exception as e:out={'name':name,'url':url,'error':str(e)}
 print(name,out.get('bytes',out.get('error')),flush=True);return out
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:res=list(ex.map(grab,urls.items()))
(root/'manifest.json').write_text(json.dumps(res,indent=2))
