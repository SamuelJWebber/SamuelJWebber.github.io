# Reconstruct Arenas (2024) appendix sensitivity analysis using actual R packages.
# This uses the same cleaned raw-election panel as the independent Python replication.
args <- commandArgs(trailingOnly=TRUE)
root <- if(length(args)) normalizePath(args[[1]]) else getwd()
out <- file.path(root,"spain_results_honestdid")
dir.create(out,recursive=TRUE,showWarnings=FALSE)
suppressPackageStartupMessages(library(fixest))
suppressPackageStartupMessages(library(HonestDiD))
df <- read.csv(file.path(root,"spain_results","analysis_panel.csv"))
stopifnot(nrow(df)==3360,all(table(df$group_type)==6))
df$codi_prov <- as.integer(factor(df$province))
df$other_ban_2007 <- df$ban_2007_other
set.seed(20261106)
all_results <- list(); original_results <- list(); diagnostic <- list()
for(outcome in c("turnout","support_voters","support_population")) {
  cat("Starting",outcome,"\n");flush.console()
  form <- as.formula(paste0(outcome," ~ i(year, other_ban_2007, ref=2003) | group_type + year + year*type + year*codi_prov + mine_ban"))
  fit <- fixest::feols(form,cluster="group",data=df,weights=df$eligible)
  stopifnot(nobs(fit)==3360)
  beta <- summary(fit)$coefficients
  sigma <- summary(fit)$cov.scaled
  stopifnot(length(beta)==5)
  write.csv(data.frame(term=names(beta),coefficient=as.numeric(beta),standard_error=sqrt(diag(sigma))),file.path(out,paste0(outcome,"_event_study_R.csv")),row.names=FALSE)
  write.csv(sigma,file.path(out,paste0(outcome,"_covariance_R.csv")))
  original <- HonestDiD::constructOriginalCS(betahat=beta,sigma=sigma,numPrePeriods=4,numPostPeriods=1)
  original$outcome <- outcome
  original_results[[outcome]] <- original
  sens <- HonestDiD::createSensitivityResults_relativeMagnitudes(betahat=beta,sigma=sigma,numPrePeriods=4,numPostPeriods=1,Mbarvec=seq(.1,1.5,by=.1))
  sens$outcome <- outcome
  all_results[[outcome]] <- sens
  write.csv(sens,file.path(out,paste0(outcome,"_relative_magnitude.csv")),row.names=FALSE)
  print(sens)
  # Save vector scientific figures in addition to machine-readable bounds.
  p <- HonestDiD::createSensitivityPlot_relativeMagnitudes(sens,original)
  ggplot2::ggsave(file.path(out,paste0(outcome,"_sensitivity.pdf")),p,width=8,height=6)
  diagnostic[[outcome]] <- data.frame(outcome=outcome,n=nobs(fit),precinct_clusters=length(unique(df$group)),post_coefficient=as.numeric(beta[5]),post_se=sqrt(sigma[5,5]))
}
write.csv(do.call(rbind,all_results),file.path(out,"all_relative_magnitude_bounds.csv"),row.names=FALSE)
write.csv(do.call(rbind,original_results),file.path(out,"original_confidence_sets.csv"),row.names=FALSE)
write.csv(do.call(rbind,diagnostic),file.path(out,"event_study_diagnostics.csv"),row.names=FALSE)
capture.output(sessionInfo(),file=file.path(out,"R_session_info.txt"))
cat("Completed all three outcomes and fifteen sensitivity values each.\n")
