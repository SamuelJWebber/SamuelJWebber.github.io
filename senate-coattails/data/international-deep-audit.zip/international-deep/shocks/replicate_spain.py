"""Independent Python reconstruction of Arenas (2024), main Table 1.
Sources: doi:10.7910/DVN/JEJPVM; translations of 00_data_cleaning.do/01_analysis.do.
No Stata/R execution is claimed. Requires pandas, numpy, scipy.
"""
from pathlib import Path
import json, argparse
import pandas as pd
import numpy as np
from scipy.linalg import qr
from scipy.stats import t as tdist
ROOT=Path(__file__).parent
RAW=ROOT/'spain_replication'
parser=argparse.ArgumentParser();parser.add_argument('--municipal',action='store_true');parser.add_argument('--cluster-municipal',action='store_true');parser.add_argument('--entropy',action='store_true');args=parser.parse_args()
OUT=ROOT/('spain_results_entropy' if args.entropy else ('spain_results_municipal' if args.municipal else ('spain_results_cluster_municipal' if args.cluster_municipal else 'spain_results')));OUT.mkdir(exist_ok=True)
YEARS=list(range(1987,2008,4))
frames=[]
rename={'TH':'province','Cod.Municipio':'municipality','AMBITO':'name','Distrito':'district','Censo':'eligible','Votantes':'voters','Nulos':'invalid','Válidos':'valid','Blancos':'blank','Votos Cand.':'party_votes','Abstenciones':'abstentions'}
for typ,letter in [(1,'J'),(2,'M')]:
 for year in YEARS:
  f=next(RAW.glob(f'Mes{letter}{str(year)[2:]}_c.*'))
  d=pd.read_csv(f,encoding='latin1').rename(columns=rename)
  d['batasuna']=0 if year==2003 else d[{1987:'HB',1991:'HB',1995:'HB',1999:'EH',2007:'EAE / ANV'}[year]].fillna(0)
  d['year']=year;d['type']=typ
  if args.municipal:d['district']=1
  numeric=['eligible','voters','invalid','valid','blank','party_votes','abstentions','batasuna']
  d[numeric]=d[numeric].apply(pd.to_numeric,errors='raise')
  d=d.groupby(['province','municipality','district','year','type'],dropna=False)[numeric].sum().reset_index()
  frames.append(d)
d=pd.concat(frames,ignore_index=True)
mun=['province','municipality']; unit=mun+['district']; ut=unit+['type']
for year in [1995,1999,2007]:
 pres=d.loc[(d.year==year)&(d.type==2)].groupby(mun).batasuna.max().gt(0).rename('present_'+str(year))
 d=d.join(pres,on=mun)
for v, num, den in [('support_population',d.batasuna+d.invalid,d.eligible),('support_voters',d.batasuna+d.invalid,d.voters),('turnout',d.voters,d.eligible)]:d[v]=num/den
outcomes=['support_population','support_voters','turnout']
# Concurrent outcomes are captured before balanced-sample restrictions, as in Stata.
other=d[unit+['year','type']+outcomes].copy();other['type']=3-other.type
other=other.rename(columns={x:x+'_other' for x in outcomes})
d=d.merge(other,on=unit+['year','type'],how='left',validate='one_to_one')
legal=d.loc[d.year==2007].groupby(mun+['type']).batasuna.max().gt(0).rename('legal_2007')
d=d.join(legal,on=mun+['type']);d['ban_2007']=1-d.legal_2007.astype(int)
otherban=legal.reset_index();otherban['type']=3-otherban.type;otherban=otherban.rename(columns={'legal_2007':'legal_2007_other'})
d=d.merge(otherban,on=mun+['type'],how='left',validate='many_to_one')
d['ban_2007_other']=1-d.legal_2007_other.astype(int)
d['mine_ban']=np.where(d.year==2003,1,np.where(d.year==2007,d.ban_2007,0))
d['other_ban']=np.where(d.year==2003,1,np.where(d.year==2007,d.ban_2007_other,0))
# Unit-specific lagged outcomes and differences; include both offices.
for o in outcomes+[x+'_other' for x in outcomes]:
 for year in YEARS:
  lag=d.loc[d.year==year].set_index(ut)[o].rename(f'{o}_{year}')
  d=d.join(lag,on=ut)
 for year in YEARS[1:-1]:d[f'd_{o}_{year}']=d[f'{o}_{year}']-d[f'{o}_{year-4}']
d=d[d[[f'support_voters_{y}' for y in YEARS[:4]]].notna().all(axis=1)&d.present_1995&d.present_1999].copy().reset_index(drop=True)
for key,cols in [('group',unit),('group_type',ut),('type_year',['type','year']),('province_year',['province','year'])]:d[key]=pd.factorize(pd.MultiIndex.from_frame(d[cols]),sort=True)[0]
panel_tmp=OUT/'analysis_panel.tmp.csv'
d.to_csv(panel_tmp,index=False);panel_tmp.replace(OUT/'analysis_panel.csv')
assert len(pd.read_csv(OUT/'analysis_panel.csv'))==len(d), 'Saved panel row count mismatch'
d.loc[d.year==2007,unit+['type','ban_2007','ban_2007_other','eligible','voters','batasuna','invalid']].to_csv(OUT/'treatment_roster_2007.csv',index=False)
# Full dummy span matches absorb(year group_type year#type year#province).
F=np.column_stack([pd.get_dummies(d[x],dtype=float).to_numpy() for x in ['group_type','type_year','province_year']])
weight=d.eligible.to_numpy(float)
if args.entropy:
 from scipy.optimize import minimize
 from scipy.special import logsumexp
 d['municipality_eligible']=d.groupby(mun+['year','type']).eligible.transform('sum')
 d['local']=(d.type==2).astype(int)
 cross=d[d.year==2007].copy();treated=cross.ban_2007_other.eq(1).to_numpy()
 columns=['ban_2007','support_population_2003','support_voters_2003','turnout_2003','municipality_eligible','local']
 values=cross[columns].to_numpy(float);target=values[treated].mean(axis=0);scale=values.std(axis=0)
 centered=(values[~treated]-target)/scale
 def objective(lam):
  z=centered@lam; prob=np.exp(z-logsumexp(z));grad=prob@centered
  return logsumexp(z),grad
 def hess(lam):
  z=centered@lam;prob=np.exp(z-logsumexp(z));mean=prob@centered
  return (centered.T*prob)@centered-np.outer(mean,mean)
 sol=minimize(objective,np.zeros(len(columns)),jac=True,hess=hess,method='trust-exact',options={'gtol':1e-10,'maxiter':1000})
 z=centered@sol.x;strict_cw=np.exp(z-logsumexp(z))*treated.sum()
 # Reproduce deposited ebalance.ado v1.5.4, including default tolerance .015
 # and its stored pre-Newton-update weights. This differs slightly from the
 # converged convex optimum; both moment discrepancies are recorded.
 moments=np.r_[1.,target]
 mags=np.where(moments!=0,10.**np.trunc(np.log10(np.abs(moments))),1.)
 mm=moments/mags;cx=np.column_stack([np.ones((~treated).sum()),values[~treated]])/mags
 coefs=np.zeros(cx.shape[1]);maxdiff=1.015;iteration=1
 while maxdiff>.015 and iteration<=20:
  ww=np.exp(cx@coefs);gradient=ww@cx-mm;H=(cx.T*ww)@cx
  nstep=np.linalg.solve(H,gradient);old=coefs.copy();coefs=old-nstep
  loss=lambda coef:np.max(np.abs(np.exp(cx@coef)@cx-mm))
  if loss(old)<=loss(coefs):
   ss=min([1.,.5,1/3,.25,.2],key=lambda a:loss(old-a*nstep));coefs=old-ss*nstep
  maxdiff=np.max(np.abs(gradient))/mm[0];iteration+=1
 cw=ww*treated.sum()/ww.sum()
 balanced=np.average(values[~treated],axis=0,weights=cw)
 assert maxdiff<=.015
 strict_balanced=np.average(values[~treated],axis=0,weights=strict_cw)
 assert np.max(np.abs((strict_balanced-target)/scale))<1e-7
 cross['entropy_weight']=1.;cross.loc[~treated,'entropy_weight']=cw
 weights=cross.set_index('group_type').entropy_weight
 d['entropy_weight']=d.group_type.map(weights);weight=d.entropy_weight.to_numpy()
 cross[unit+['type','group_type','ban_2007_other','entropy_weight']+columns].to_csv(OUT/'entropy_weights_2007.csv',index=False)
 pd.DataFrame({'variable':columns,'treated_mean':target,'unweighted_control_mean':values[~treated].mean(axis=0),'weighted_control_mean':balanced,'standardized_discrepancy':(balanced-target)/scale,'strict_optimum_control_mean':strict_balanced}).to_csv(OUT/'entropy_moment_balance.csv',index=False)
 (OUT/'entropy_solver.json').write_text(json.dumps({'algorithm':'Translated deposited ebalance.ado v1.5.4 Newton iteration; default .015 tolerance; strict convex solution separately checked','ado_iterations':iteration-1,'ado_scaled_gradient_error':float(maxdiff),'strict_optimum_maximum_standardized_moment_error':float(np.max(np.abs((strict_balanced-target)/scale))),'solver_success':bool(maxdiff<=.015),'solver_message':'ADO default convergence criterion satisfied','strict_optimizer_reported_success':bool(sol.success),'strict_optimizer_message':str(sol.message),'strict_optimizer_iterations':int(sol.nit),'maximum_standardized_moment_error':float(np.max(np.abs((balanced-target)/scale))),'treated_units':int(treated.sum()),'control_units':int((~treated).sum()),'control_weight_sum':float(cw.sum()),'minimum_control_weight':float(cw.min()),'maximum_control_weight':float(cw.max()),'code_note':'Follows six moments in original ebalance command. It includes municipality size and local-office indicator; paper table note also mentions precinct size, absent from code.'},indent=2))
w=np.sqrt(weight);clusters=(pd.factorize(pd.MultiIndex.from_frame(d[mun]),sort=True)[0] if args.cluster_municipal else d.group.to_numpy());G=len(np.unique(clusters));n=len(d)

def projection(A):
 q,r,p=qr(A,mode='economic',pivoting=True)
 rank=int(np.sum(np.abs(np.diag(r))>1e-10*np.abs(r[0,0])))
 return q[:,:rank],rank

def fit(y,X,Z,controls,labels,iv=False):
 Q,rank=projection(controls*w[:,None])
 residual=lambda a:(a*w[:,None])-Q@(Q.T@(a*w[:,None]))
 yy=residual(y[:,None]).ravel();xx=residual(X);zz=residual(Z)
 if iv:
  zzi=np.linalg.inv(zz.T@zz);proj=xx.T@zz@zzi
  bread=np.linalg.inv(proj@zz.T@xx);beta=bread@proj@zz.T@yy
  scorematrix=(zz@(proj.T))
 else:
  bread=np.linalg.inv(xx.T@xx);beta=bread@xx.T@yy;scorematrix=xx
 error=yy-xx@beta
 sums=np.zeros((G,X.shape[1]));np.add.at(sums,clusters,scorematrix*error[:,None])
 cov0=bread@(sums.T@sums)@bread
 # reghdfe excludes absorbed group_type FE nested within precinct clusters
 # from small-sample degrees-of-freedom; report this explicit correction.
 effective_k=X.shape[1]+rank-d.group_type.nunique()
 correction=G/(G-1)*(n-1)/(n-effective_k)
 cov=cov0*correction;se=np.sqrt(np.diag(cov))
 return [{'term':lab,'coefficient':float(b),'standard_error':float(s),'ci95_low':float(b-tdist.ppf(.975,G-1)*s),'ci95_high':float(b+tdist.ppf(.975,G-1)*s),'n':n,'clusters':G,'absorbed_rank':rank,'effective_k':effective_k,'covariance':('municipality' if args.municipal or args.cluster_municipal else 'precinct')+'-cluster CR1; nested fixed effects excluded from df'} for lab,b,s in zip(labels,beta,se)]
results=[]
for o in outcomes:
 y=d[o].to_numpy(float)
 for trends in [False,True]:
  C=F
  if trends:
   trendcols=[f'd_{oo}_{year}' for oo in [o,o+'_other'] for year in YEARS[1:-1]]
   C=np.column_stack([F]+[d[trendcols].to_numpy()*np.asarray(d.year==year)[:,None] for year in YEARS])
  X=d[['mine_ban','other_ban']].to_numpy(float)
  for row in fit(y,X,X,C,['mine_ban','other_ban']):row.update(outcome=o,specification='adjusted_pretrends' if trends else 'baseline',estimator='reduced_form');results.append(row)
  if o!='turnout':
   X=d[['mine_ban',o+'_other']].to_numpy(float);Z=d[['mine_ban','other_ban']].to_numpy(float)
   for row in fit(y,X,Z,C,['mine_ban','coattail_ratio'],iv=True):row.update(outcome=o,specification='adjusted_pretrends' if trends else 'baseline',estimator='2SLS');results.append(row)

# Event-study reduced forms, reference election 2003.
events=[]
for o in outcomes:
 evyears=[1987,1991,1995,1999,2007]
 X=np.column_stack([d.mine_ban.to_numpy()]+[(d.ban_2007_other*(d.year==yr)).to_numpy() for yr in evyears])
 for rr in fit(d[o].to_numpy(float),X,X,F,['mine_ban']+[str(x) for x in evyears]):
  rr.update(outcome=o,estimator='event_study',specification='baseline_reference_2003');events.append(rr)
pd.DataFrame(events).to_csv(OUT/'event_study_python.csv',index=False)
res=pd.DataFrame(results);res.to_csv(OUT/'table1_python.csv',index=False)
(OUT/'results.json').write_text(json.dumps(results,indent=2))
checks={'rows':len(d),'municipalities':len(d[mun].drop_duplicates()),'precincts':int(d.group.nunique()),'clusters':G,'cluster_unit':'municipality' if args.municipal or args.cluster_municipal else 'precinct','analysis_unit':'municipality' if args.municipal else 'precinct','precinct_office_pairs':d.group_type.nunique(),'years':sorted(d.year.unique().tolist()),'rows_each_year':{str(int(k)):int(v) for k,v in d.groupby('year').size().items()},'outcome':'(Batasuna candidate/list votes + invalid ballots)/eligible voters; invalid ballots are a support proxy under party ban','design':'selective bans on a concurrent party list; not candidate quality','pretrends_definition':'year interactions with own and other-office outcome changes 1987-1991,1991-1995,1995-1999,1999-2003'}
(OUT/'sample_checks.json').write_text(json.dumps(checks,indent=2))
print(checks)
print(res[['outcome','specification','estimator','term','coefficient','standard_error']].to_string(index=False))
