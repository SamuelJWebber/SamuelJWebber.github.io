"""Prepare public municipality/party outcomes; does NOT estimate an audit effect.
Reads official 2004 TSE aggregates. Personal-registration fields are not used.
"""
from pathlib import Path
import pandas as pd, zipfile,json
ROOT=Path(__file__).parent;RAW=ROOT/'brazil_sources';OUT=ROOT/'brazil_prepared';OUT.mkdir(exist_ok=True)
KEY=['SG_UF','CD_MUNICIPIO','NM_MUNICIPIO','NR_PARTIDO','SG_PARTIDO']
def readz(stem,cols):
 with zipfile.ZipFile(RAW/(stem+'.zip')) as z:
  f=next(x for x in z.namelist() if x.endswith('BRASIL.csv'))
  with z.open(f) as fh:return pd.read_csv(fh,sep=';',encoding='latin1',usecols=cols,dtype={'CD_MUNICIPIO':str,'SG_UE':str},low_memory=False)
p=readz('party_votes_2004',KEY+['NR_TURNO','CD_CARGO','NR_ZONA','QT_VOTOS_NOMINAIS','QT_VOTOS_LEGENDA','SQ_COLIGACAO','NM_COLIGACAO','DS_COMPOSICAO_COLIGACAO'])
p=p[(p.NR_TURNO==1)&(p.CD_CARGO==13)].copy()
assert not p.duplicated(KEY+['NR_ZONA']).any()
a=p.groupby(KEY)[['QT_VOTOS_NOMINAIS','QT_VOTOS_LEGENDA']].sum().reset_index()
a['council_party_votes']=a.QT_VOTOS_NOMINAIS+a.QT_VOTOS_LEGENDA
v=readz('voting_details_2004',['SG_UF','CD_MUNICIPIO','NR_TURNO','CD_CARGO','NR_ZONA','QT_APTOS','QT_COMPARECIMENTO','QT_ABSTENCOES','QT_VOTOS_BRANCOS','QT_VOTOS_NULOS','QT_TOTAL_VOTOS_VALIDOS'])
v=v[(v.NR_TURNO==1)&(v.CD_CARGO==13)].copy()
assert not v.duplicated(['SG_UF','CD_MUNICIPIO','NR_ZONA']).any()
v=v.groupby(['SG_UF','CD_MUNICIPIO'])[['QT_APTOS','QT_COMPARECIMENTO','QT_ABSTENCOES','QT_VOTOS_BRANCOS','QT_VOTOS_NULOS','QT_TOTAL_VOTOS_VALIDOS']].sum().reset_index()
a=a.merge(v,on=['SG_UF','CD_MUNICIPIO'],how='left',validate='many_to_one')
a['council_party_votes_per_eligible']=a.council_party_votes/a.QT_APTOS
a['council_party_votes_per_voter']=a.council_party_votes/a.QT_COMPARECIMENTO
a['turnout']=a.QT_COMPARECIMENTO/a.QT_APTOS
c=readz('candidate_votes_2004',KEY+['NR_TURNO','CD_CARGO','NR_ZONA','SQ_CANDIDATO','DS_SIT_TOT_TURNO','QT_VOTOS_NOMINAIS'])
c=c[(c.NR_TURNO==1)&(c.CD_CARGO==13)].copy()
cs=c.groupby(KEY).QT_VOTOS_NOMINAIS.sum().rename('candidate_nominal_sum').reset_index()
a=a.merge(cs,on=KEY,how='left',validate='one_to_one')
a['nominal_reconciliation_difference']=a.QT_VOTOS_NOMINAIS-a.candidate_nominal_sum.fillna(0)
seats=c[c.DS_SIT_TOT_TURNO.str.startswith('ELEITO')|c.DS_SIT_TOT_TURNO.eq('MÉDIA')].drop_duplicates(KEY+['SQ_CANDIDATO']).groupby(KEY).size().rename('council_seats').reset_index()
a=a.merge(seats,on=KEY,how='left',validate='one_to_one');a['council_seats']=a.council_seats.fillna(0).astype(int)
vac=readz('vacancies_2004',['SG_UF','SG_UE','CD_CARGO','QT_VAGAS'])
vac=vac[vac.CD_CARGO==13].rename(columns={'SG_UE':'CD_MUNICIPIO'}).groupby(['SG_UF','CD_MUNICIPIO']).QT_VAGAS.max()
seatcheck=a.groupby(['SG_UF','CD_MUNICIPIO']).council_seats.sum().to_frame().join(vac,how='outer')
seatcheck['difference']=seatcheck.council_seats-seatcheck.QT_VAGAS
seatcheck.to_csv(OUT/'council_seat_validation_2004.csv')
coal=p[KEY+['SQ_COLIGACAO','NM_COLIGACAO','DS_COMPOSICAO_COLIGACAO']].drop_duplicates()
coal.to_csv(OUT/'council_party_coalitions_2004.csv',index=False)
a.to_csv(OUT/'council_party_outcomes_2004.csv',index=False)
checks={'party_municipality_rows':len(a),'municipalities':len(a[['SG_UF','CD_MUNICIPIO']].drop_duplicates()),'total_council_party_votes':int(a.council_party_votes.sum()),'total_council_seats':int(a.council_seats.sum()),'official_council_vacancies':int(vac.sum()),'seat_vacancy_difference_municipalities_with_outcomes':int((seatcheck.loc[seatcheck.council_seats.notna(),'difference']!=0).sum()),'municipalities_with_vacancies_but_no_outcomes':int(seatcheck.council_seats.isna().sum()),'vacancies_in_observed_outcome_municipalities':int(seatcheck.loc[seatcheck.council_seats.notna(),'QT_VAGAS'].sum()),'seat_status_rule':'Historical 2004 ELEITO or MÉDIA; latter denotes seats filled by averages','nominal_reconciliation_nonzero_rows':int((a.nominal_reconciliation_difference!=0).sum()),'max_absolute_nominal_reconciliation_difference':float(a.nominal_reconciliation_difference.abs().max()),'eligible_missing_rows':int(a.QT_APTOS.isna().sum()),'turnout_over_one_rows':int((a.turnout>1).sum()),'treatment_join_status':'NOT JOINED: no validated Ferraz-Finan treatment/severity roster','estimate_status':'No causal effect estimated','turnout_denominator':'2004 registered voters (QT_APTOS), not a frozen pre-audit electorate','party_vote_definition':'QT_VOTOS_NOMINAIS + QT_VOTOS_LEGENDA; candidate nominal sums independently reconciled','source_paths':'Official TSE 2004 candidate/party/turnout ZIPs; national BRASIL CSV only (do not also concatenate state copies)'}
(OUT/'validation.json').write_text(json.dumps(checks,indent=2))
print(json.dumps(checks,indent=2))
