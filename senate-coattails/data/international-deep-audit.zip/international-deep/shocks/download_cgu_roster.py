from pathlib import Path
import concurrent.futures, urllib.request, json
from bs4 import BeautifulSoup
root=Path(__file__).parent/'brazil_sources'/'cgu_roster';root.mkdir(exist_ok=True)
def grab(i):
 suffix='deg' if i in [1,10,11,12] else 'o'
 u=f'https://www.gov.br/cgu/pt-br/assuntos/auditoria-e-fiscalizacao/programa-de-fiscalizacao-em-entes-federativos/edicoes-anteriores/municipios/{i}{suffix}-sorteio'
 try:
  raw=urllib.request.urlopen(urllib.request.Request(u,headers={'User-Agent':'Mozilla/5.0'}),timeout=30).read();(root/f'draw_{i:02}.html').write_bytes(raw)
  s=BeautifulSoup(raw,'html.parser');c=s.select_one('#content-core') or s
  desc=s.select_one('.documentDescription')
  obj={'draw':i,'url':u,'description':desc.get_text(' ',strip=True) if desc else '', 'text':c.get_text('\n',strip=True)}
 except Exception as e:obj={'draw':i,'url':u,'error':str(e)}
 print(i,len(obj.get('text','')),obj.get('description','')[:180],obj.get('error',''),flush=True);return obj
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:r=list(ex.map(grab,range(1,15)))
(root/'source_rosters.json').write_text(json.dumps(r,indent=2,ensure_ascii=False))
