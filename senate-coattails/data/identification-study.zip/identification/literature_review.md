# Candidate coattails: identification search, 5 November 2026

## Recommendation

Use a **close-primary nomination regression discontinuity**, orienting the running variable toward whichever of the two top contenders had the stronger **pre-primary** grassroots base. Count distinct disclosed individual donors at a fixed cutoff before the primary (prefer the last report publicly filed before primary day), not donation transactions and not general-election fundraising. Comparing candidates in the same primary is especially useful: population, state/party climate, and the eventual general election's underlying competitiveness are shared. A within-primary donor ratio does not need a population denominator. Exclude runoff/top-two complications unless the decisive nomination round is correctly represented.

Treatment: the party narrowly nominates the predesignated broader-support contender, rather than that contender's actual rival. Outcomes: party teammates' vote shares, votes per eligible resident, turnout and rolloff. Candidate's own general-election performance is a separate validation outcome; do not select the proxy/bandwidth because teammate effects are large. Report whole-candidate-package local effects, not a causal effect of donations or charisma alone. Cluster at the assignment level, inspect balance in BOTH contenders' pretreatment characteristics, and report power before effects. Close primary assignment is substantively different from controlling for last election's party margin.

This remains preferable to prior close-general-election winners: the latter changes governing party, policy, incumbency and balancing before the next outcome. It does not simply change which talented candidate appears contemporaneously on the ballot.

## Primary sources that sharpen this recommendation

### Bertoli and Hazlett (2025), Seeing Like a District
https://www.cambridge.org/core/journals/political-analysis/article/seeing-like-a-district-understanding-what-closeelection-designs-for-leader-characteristics-can-and-cannot-tell-us/77782269233D983FD37019E7A82189CB
DOI10.1017/pan.2025.5, Political Analysis33(4):393–411. Read full text.

The design identifies the effect of electing/nominating candidate type A rather than the actual type B alternative among close contests. It does not isolate a single candidate attribute. Both candidates' pre-election traits can and should be checked for balance across the victory threshold. Gradient PCRDs are directly relevant to ranking finalists by donor breadth. This is a positive justification of the useful whole-candidate-package estimand, not a reason to abandon the design.

### McCrary (October2,2026 draft), Leveraging an October Surprise to Estimate Coattail Effects
https://kjmccrary.github.io/coattails/draft.pdf
https://www.kayleigh-mccrary.com/research
Author page calls this second-round R&R at AEJ: Economic Policy; not yet final peer-reviewed publication. Shock agent is scrutinizing replication.

Uses the unexpected October28,2016 Comey letter and pre-existing variation in states' early-voting availability. Difference2012–2016 in states/counties without no-excuse early voting before letter vs those with it. Reports +3.2pp Republican presidential first stage and .79pp average downballot Republican share per1pp own presidential share. Also six-state early/day comparisons and daily NC turnout by registration. This is a genuine new, candidate-specific shock strategy capable of reflecting turnout and persuasion. Risks: early voting law selection, state-level assignment despite county observations, parallel trends, and party-brand direct pathways. It is not a reusable all-star estimate for Senate candidates.

Potential statewide extensions with early voting underway: Mourdock2012Oct23 remark; Stevens2008Oct27 conviction; Walker2022Oct26 second allegation; Fetterman2022Oct25 debate. Dates and data need audit. Do not compare all early vs ElectionDay as if random; early categories contain post-shock ballots and voter composition differs. Mourdock official county result link with vote modes:
https://secure2.hamiltoncounty.in.gov/Elections/2012G/results/ElectionSummary.htm

### DeLuca, Moskowitz, Schneer (2025/2026), A Drag on the Ticket?
https://onlinelibrary.wiley.com/doi/full/10.1111/ajps.70025
DOI10.1111/ajps.70025; replication10.7910/DVN/J6C26T. Read full text.

Large adjusted observational comparisons, not a nomination natural experiment. Authors explicitly say their endorsement quality measure principally captures governing quality rather than campaigning quality. They examine experience/scandals/incumbency too and get near-zero statewide spillover. Same-pair House candidate matchups help hold peer identity constant, but top candidate selection/state-specific political shocks remain observational. Should not be described as resolving the user's grassroots-charisma hypothesis. Their own discussion recognizes controlling House quality can remove an indirect candidate-entry channel, though appendices suggest it is not important.

### Erikson, Folke, Snyder (2015), A Gubernatorial Helping Hand?
https://www.journals.uchicago.edu/doi/10.1086/680186
Published result3–4pp presidential vote penalty for own-party governor, using close gubernatorial elections before presidential elections. Genuine control assignment leverage; fundamentally governing-party/balancing effect, not contemporaneous on-ballot candidate quality. Early drafts report2–3pp; use published number if citing.

Replication reliability review:
https://www.econstor.eu/bitstream/10419/269243/1/I4R-DP022.pdf
Stommes/Aronow/Savje2023 received original author files and got close but not exact reproduction; AppendixS6. Their general lesson is RD identification does not guarantee statistical precision, and conventional SEs often understate uncertainty. Do not transform tiny primary sample into apparent precision by treating every precinct as independent treatment.

## Credible comparative proof of coattails, not the exact US talent effect

### Arenas (2024), Coattail effects and turnout: Evidence from a quasi-experiment
https://journals.sagepub.com/doi/10.1177/20531680241229930
Institutional PDF:
https://diposit.ub.edu/server/api/core/bitstreams/642a4bf7-8c6e-44fa-ad68-6a42aa0accff/content

Batasuna legal in only one of simultaneous provincial/local elections in some Basque municipalities. DiD in 2007 relative earlier elections estimates around .25pp concurrent-election loss per1pp direct support loss, with lower turnout. Ban status can be correlated with local prior candidate links to banned party; author uses precinct×election-type, election-type×year, province×year FE and pretrends. Support under a ban includes coordinated null ballots. It proves an external one-ballot change can affect another and turnout, but party-list bans differ from nominee quality.

### Rudolph and Leininger (2021), Coattails and Spillover-Effects
https://www.lukas-rudolph.com/wp-content/uploads/2021/01/Rudolph-Leininger-2020-Conc-Elections-Authors-Manuscript.pdf
DOI10.1016/j.electstud.2020.102264
Open replication:10.7910/DVN/XFUJOO or https://zenodo.org/records/18230905
Downloaded in this folder: master_treatment.dta, treatment.do, README.txt, author PDF.

German local election schedule changes cause quasi-random concurrency of mayoral and council elections.1203municipality-years/401municipalities. Turnout+3.03pp(SE.19), incumbent mayor's party councilshare+.95pp(SE.48;624observations/291municipalities). Identifies concurrence of a mayoral election/party incumbency, not superior vs mediocre mayor. Timing derives from1996reform preserving prior12yearterms plus2005switch from5to8yearterms. They audit timing selection and pretrends.

## Rejected shortcuts

- General-election close-win RD used contemporaneously: win/loss is determined by the very general election whose teammates we measure; cannot cause ballots already cast.
- Prior close-win RD: estimates incumbency/governing/balancing as well as subsequent candidate presence.
- Ballot-order randomized exposure: useful persuasion perturbation but cannot alone recover mobilization before voters reach the ballot; shared alphabetical lottery may directly move teammates' positions.
- Term limits: forced departure changes incumbency, accumulated governing performance and candidate recruitment; time trends/term-selection remain. Potential complement, not clean all-star causal instrument.
- Hometown IV: authentic local appeal effect but transport to statewide nomination effect needs additional homogeneity assumptions.
- Future presidency: post-treatment selection and unavailable ex ante.
