"""Pretreatment diagnostics only; never loads any current general-election outcome."""
from pathlib import Path
import hashlib,json
import numpy as np
import pandas as pd
from scipy import stats

HERE=Path(__file__).resolve().parent
PAIR=HERE.parent/'primary/primary_pair_audit.csv'
RAW=HERE/'presidential_raw.csv'
SHA='9936410a6dd4ecc8be7fe202c6dff5b5f8fee59d88f35ab542ed12879941dcb7'
assert hashlib.sha256(RAW.read_bytes()).hexdigest()==SHA
pair=pd.read_csv(PAIR)
excluded={'AL','AR','GA','MS','NC','OK','SC','SD','TX'}
p=pair.loc[(pair.status=='eligible')&~pair.state.isin(excluded)&pair.fundraising_rv.notna()].copy()
p['margin_pp']=200*p.fundraising_rv
p['higher_money_won']=(p.margin_pp>0).astype(int)
assert np.all(p.higher_money_won==p.fundraising_high_won)
raw=pd.read_csv(RAW)
print('presidential columns',raw.columns.tolist())
# Identify the major-party nominee by their largest major-party ballot line,
# then include that same candidate's fusion-party lines in the vote total.
party_col='party_detailed' if 'party_detailed' in raw else 'party'
raw['candidate_key']=raw.candidate.fillna('').str.strip().str.upper()
major=raw.loc[raw[party_col].isin(['DEMOCRAT','REPUBLICAN'])].copy()
major=major.loc[major.groupby(['state_po','year',party_col]).candidatevotes.idxmax()]
nominee_keys=major[['state_po','year','candidate_key',party_col]].rename(columns={party_col:'nominee_party'})
joined=raw.merge(nominee_keys,on=['state_po','year','candidate_key'],validate='many_to_one')
group=joined.groupby(['state_po','year','nominee_party'],as_index=False).candidatevotes.sum().rename(columns={'nominee_party':party_col})
q=group.pivot(index=['state_po','year'],columns=party_col,values='candidatevotes').reset_index()
q['dem_share']=q.DEMOCRAT/(q.DEMOCRAT+q.REPUBLICAN)
q.to_csv(HERE/'presidential_state_baselines.csv',index=False)
for i,row in p.iterrows():
 b=q.loc[(q.state_po==row.state)&(q.year<row.year)].sort_values('year')
 if len(b):
  b=b.iloc[-1];p.loc[i,'baseline_presidential_year']=b.year
  p.loc[i,'prior_presidential_party_pp']=100*(b.dem_share if row.party=='dem' else 1-b.dem_share)
p['democratic_party']=100*(p.party=='dem').astype(int)
assert (p.baseline_presidential_year<p.year).all()
# Use only bounded nomination columns and the newly reconstructed prior outcome.
keep=['myers_row','state','year','party','name0','name1','margin_pp','higher_money_won',
      'fundraising_high_share','fundraising_low_share','fundraising_ratio',
      'baseline_presidential_year','prior_presidential_party_pp','democratic_party']
p[keep].to_csv(HERE/'eligible_pretreatment_panel.csv',index=False)

def fit(sample,y,h,method):
 m=sample.margin_pp.to_numpy();d=sample.higher_money_won.to_numpy()
 if method=='mean_difference':
  X=np.column_stack([np.ones(len(m)),d]);w=np.ones(len(m))
 else:
  X=np.column_stack([np.ones(len(m)),d,m,d*m]);w=1-np.abs(m)/h
 assert np.linalg.matrix_rank(X)==X.shape[1]
 inv=np.linalg.inv(X.T@(w[:,None]*X))
 A=inv@(X.T*w)
 beta=A@y;res=y-X@beta
 scores=X*(w*res)[:,None]
 states=sample.state.to_numpy();unique=np.unique(states);G=len(unique);n=len(m);k=X.shape[1]
 meat=sum(np.outer(scores[states==g].sum(0),scores[states==g].sum(0)) for g in unique)
 cov=inv@meat@inv*(G/(G-1))*((n-1)/(n-k))
 se=np.sqrt(max(0,cov[1,1]));crit=stats.t.ppf(.975,G-1)
 ess=float(w.sum()**2/(w@w))
 ess_side={str(side):float(w[d==side].sum()**2/(w[d==side]@w[d==side])) for side in [0,1]}
 result={'window_margin_pp':h,'estimator':method,'n':n,'higher_money_wins':int(d.sum()),
 'higher_money_losses':int((1-d).sum()),'states':G,'state_years':len(sample[['state','year']].drop_duplicates()),
 'weight_ess':ess,'ess_control':ess_side['0'],'ess_treated':ess_side['1'],'rank':k,
 'effect_pp':float(beta[1]),'state_cluster_se_pp':float(se),'ci95_low':float(beta[1]-crit*se),
 'ci95_high':float(beta[1]+crit*se),'p_value':float(2*stats.t.sf(abs(beta[1]/se),G-1)),
 'mean_prior_control':float(np.mean(y[d==0])),'mean_prior_treated':float(np.mean(y[d==1]))}
 powers=[]
 for rho in [0,.25]:
  C=(1-rho)*np.eye(n)+rho*(states[:,None]==states[None,:])
  scale=float(np.sqrt((A@C@A.T)[1,1]))
  for sigma in [3.,5.]:
   scenario_se=sigma*scale
   powers.append({'window_margin_pp':h,'estimator':method,'n':n,'states':G,
    'residual_sd_pp':sigma,'assumed_within_state_error_correlation':rho,
    'scenario_se_pp':scenario_se,'approx_80pct_mde_pp':float((crit+stats.norm.ppf(.8))*scenario_se),
    'scenario_95pct_halfwidth_pp':float(crit*scenario_se),
    'interpretation':'Hypothetical fixed-design planning calculation; not empirical achieved power.'})
 return result,powers

balances=[];powers=[];counts=[]
for h,method in [(2,'mean_difference'),(5,'local_linear_triangular'),(10,'local_linear_triangular')]:
 s=p.loc[p.margin_pp.abs()<h].copy()
 assert len(s)=={2:15,5:33,10:65}[h],(h,len(s))
 for outcome in ['prior_presidential_party_pp','democratic_party']:
  ss=s.loc[s[outcome].notna()].copy()
  result,scenario=fit(ss,ss[outcome].to_numpy(),h,method)
  result['outcome']=outcome;balances.append(result)
  if outcome=='prior_presidential_party_pp': powers.extend(scenario)
pd.DataFrame(balances).to_csv(HERE/'balance_results.csv',index=False)
pd.DataFrame(powers).to_csv(HERE/'power_scenarios.csv',index=False)
manifest={'source_url':'https://dataverse.harvard.edu/api/access/datafile/13887042','presidential_sha256':SHA,
 'candidate_pair_sha256':hashlib.sha256(PAIR.read_bytes()).hexdigest(),
 'analysis':'Pretreatment balance and hypothetical precision only. No contemporaneous election outcome fitted.',
 'exclusions':'Noneligible source rows, missing pre-primary money contrast, and entire historical runoff-state list pending nomination-round validation.',
 'runoff_states_excluded':sorted(excluded),'baseline_rule':'Latest presidential election strictly before nomination cycle, party-oriented major-party nominee share including same-name fusion lines.',
 'windows':[2,5,10],'treatment':'Nomination of finalist with larger pre-primary fundraising dollar share.',
 'results':balances,'scenario_power':powers}
(HERE/'summary.json').write_text(json.dumps(manifest,indent=2))
print(pd.DataFrame(balances).to_string(index=False))
print(pd.DataFrame(powers).to_string(index=False))
