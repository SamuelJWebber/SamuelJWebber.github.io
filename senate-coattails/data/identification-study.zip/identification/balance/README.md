# Pretreatment balance audit and hypothetical precision

This module analyzes **no current Senate, House, governor, or turnout outcome**. Its result is a diagnostic of whether the available money-primary pilot resembles a credible nomination experiment. It is not a coattail estimate.

## Frozen sample and calculation

Input: the provisional matched primary-finalist audit, with observed pre-primary money on both sides. Exclude source rows not marked eligible and all observations from AL, AR, GA, MS, NC, OK, SC, SD, and TX while their historical runoff rules and nomination-determining rounds remain unresolved. This broad quarantine sacrifices some valid no-runoff observations rather than accidentally use first-round margins.

The running variable is the higher-money finalist's top-two vote-share margin: `200 * fundraising_rv`, in percentage points. The candidate labels and nomination orientation come from the independent pair audit; this module has not independently certified every primary result or funding window.

Windows are fixed at strictly less than 2, 5, and 10 percentage points of margin. The narrow window uses a difference in means. The main five-point and wider ten-point windows use local linear fits with separate side slopes and triangular weights. Standard errors cluster by state, with G/(G-1)*(N-1)/(N-rank) correction and a t interval on G-1 degrees of freedom. These intervals condition on the local-linear specification; they are not robust bias-corrected nonparametric RD intervals.

The main five-point sample has 33 primaries in 20 states (32 distinct state-years), with 19 higher-money wins and 14 losses. The triangular-weight effective sample size is 25.36 overall, 16.33 on the winning side, and 9.11 on the losing side.

## Reconstructed prior presidential support

Download MIT's state presidential returns from:

https://dataverse.harvard.edu/api/access/datafile/13887042

SHA256: `9936410a6dd4ecc8be7fe202c6dff5b5f8fee59d88f35ab542ed12879941dcb7`.

Identify each major party's nominee from its largest major-party ballot line, then sum all same-candidate fusion lines within that state and presidential year. Compute the nominee's share of the two major nominees' votes. For every primary, choose the **latest presidential election strictly before** its election year and orient the share to the primary's party. Current-year presidential outcomes are never used. The downloaded snapshot runs through 2020, which supplies the appropriate prior baseline for the final 2022 primary observations.

| Top-two margin window | Estimator | Cases | Prior-presidential discontinuity | 95% state-cluster interval |
|---|---|---:|---:|---:|
| Under 2 points | Difference in means | 15 | -5.26 points | -11.03 to +0.51 |
| Under 5 points | Local linear, triangular | 33 | -10.90 points | -19.21 to -2.59 |
| Under 10 points | Local linear, triangular | 65 | -3.51 points | -9.08 to +2.06 |

The current nomination cannot cause this change in votes cast in a previous election. The main-window estimate exposes substantial prior partisan imbalance in this small, provisional sample. It undermines a causal interpretation of any subsequent money-primary coattail estimate from this specification. It is not evidence that richer candidates harm their parties. A wider or narrower interval crossing zero does not prove balance, and does not justify selecting that specification after seeing this failure.

Democratic-party identity also differs substantially across sides. This additional diagnostic is included in `balance_results.csv`; its local-linear probability contrast is unconstrained and can have intervals outside -100 to +100 points. It is an exploratory composition diagnostic, not an election outcome. The two diagnostics should not be presented as two independent causal discoveries.

## Source variables quarantined

The Myers codebook labels `lag_vote_share_g` as lagged legislative vote share, but the Senate subset has repeated identical values for both parties and values incompatible with an ordinary party's preceding Senate share. Its precise construction could not be established from the supplied replication analysis code. It is not analyzed or presented as verified prior electoral support.

The source `lag_pres_twoparty_vote_share` is party-oriented, but does not consistently represent the most recent presidential election. For example, the WV 2018 value matches the 2012 result rather than the 2016 result. The main audit therefore reconstructs the baseline from MIT returns instead of relying on that field.

## Hypothetical precision, not achieved power

`power_scenarios.csv` applies the actual fixed design matrix to hypothetical residual standard deviations of 3 and 5 vote-share points, with assumed within-state error correlation of either 0 or 0.25. It uses no estimated current outcome variance and no current treatment effect.

For a linear estimator A*y, the scenario variance is sigma^2*A*C*A', where C has unit diagonals and the specified within-state off-diagonal correlation. The approximate two-sided 5%-test, 80%-power detectable effect is (t_0.975,G-1 + z_0.8)*SE. This is a normal-shift planning approximation with a small-cluster critical value, not a simulation or a claim that the study has validated power.

For the main five-point local-linear design, hypothetical residual SD 3 points gives a detectable difference of about **7.13 points** with independent errors, or **7.17 points** at within-state correlation 0.25. Residual SD 5 points gives about **11.89** or **11.96 points**, respectively. These exceed an optimistic balanced-mean benchmark because this actual design has separate fitted slopes and uneven, kernel-weighted support near the cutoff. This small pilot cannot promise to detect one-point coattails.

## Reproduction

Python dependencies: NumPy, pandas, SciPy. Place the verified MIT file at `presidential_raw.csv` and preserve the relative primary audit path (or adjust the explicit constants), then run `python audit_balance.py`.

Outputs: `eligible_pretreatment_panel.csv`, `presidential_state_baselines.csv`, `balance_results.csv`, `power_scenarios.csv`, and `summary.json`. The summary records source hashes and the full frozen specification. No current general-election outcome is loaded by the script.

