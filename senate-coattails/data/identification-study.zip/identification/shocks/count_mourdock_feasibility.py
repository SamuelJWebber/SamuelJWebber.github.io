"""Feasibility only; never computes vote shares, contrasts, or treatment effects."""
from pathlib import Path
import pandas as pd,json
p=Path(__file__).parent
d=pd.read_csv(p/'CCES12_Common_VV.tab',sep='\t',low_memory=False,na_values=['__NA__'])
start=pd.to_datetime(d.starttime,format='mixed',errors='coerce');end=pd.to_datetime(d.endtime,format='mixed',errors='coerce')
d['date']=start.dt.normalize();d['enddate']=end.dt.normalize()
d['self_registered']=d.votereg.eq(1)
d['early_vote_report']=d.CC354.eq(3)
d['validation_observed']=d.e2012g.notna()
d['matched']=d.catalist_match.astype(str).eq('1')
shock=pd.Timestamp('2012-10-23'); rows=[]
for state in ['IN','ALL_NON_IN']:
 sub=d[d.StateAbbr.eq('IN') if state=='IN' else ~d.StateAbbr.eq('IN')]
 for pop in ['all_respondents','self_registered']:
  q=sub if pop=='all_respondents' else sub[sub.self_registered]
  for window in [7,14,28]:
   for side in ['before','after']:
    if side=='before':mask=(q.date>=shock-pd.Timedelta(days=window))&(q.enddate<shock)
    else:mask=(q.date>shock)&(q.date<=shock+pd.Timedelta(days=window))
    z=q[mask]
    row={'population':pop,'geography':state,'window_days':window,'period':side,'n':len(z),'already_voted':int(z.early_vote_report.sum()),'turnout_intention_answered':int(z.CC354.isin([1,2,3,4,5,6]).sum()),'validated_turnout_known':int(z.validation_observed.sum()),'matched_catalist':int(z.matched.sum()),'postwave_respondents':int(z.starttime_post.notna().sum())}
    for office, pref,voted,post in [('senate','CC355b','CC355','CC410b'),('governor','CC356b','CC356','CC411'),('house','CC390b','CC390','CC412')]:
     row[office+'_preference_nonmissing']=int(z[pref].notna().sum())
     row[office+'_preference_or_already_cast_nonmissing']=int((z[pref].notna()|z[voted].notna()).sum())
     row[office+'_postvote_nonmissing']=int(z[post].notna().sum())
    rows.append(row)
out=pd.DataFrame(rows);out.to_csv(p/'mourdock_feasibility_counts.csv',index=False)
inall=d[d.StateAbbr.eq('IN')]
daily=inall.groupby('date').agg(n=('V101','size'),registered=('self_registered','sum'),already_voted=('early_vote_report','sum'),validation_known=('validation_observed','sum')).reset_index()
daily.to_csv(p/'indiana_interview_daily_counts.csv',index=False)
info={'n_all':len(d),'n_indiana':len(inall),'n_indiana_registered':int(inall.self_registered.sum()),'indiana_first_start':str(inall.date.min()),'indiana_last_start':str(inall.date.max()),'indiana_last_end':str(inall.enddate.max()),'indiana_event_date_or_spanning_event':int(((inall.date<=shock)&(inall.enddate>=shock)).sum()),'indiana_missing_start':int(inall.date.isna().sum()),'indiana_missing_end':int(inall.enddate.isna().sum()),'scope':'Feasibility counts only; no outcome means, group contrasts or effect estimates calculated.','date_rule':'Before: start >= Oct23-window and end <Oct23. After: start>Oct23 and <=Oct23+window. Whole shock date excluded; preinterviews spanning event date excluded.','registration':'votereg=1; self-reported, not a validated registration requirement.','choice_counts':'Nonmissing measures contain undecided/no-one/other responses; not solely named-candidate choices. DDI labels independently verified. Prewave 7=Other,8=Unsure,9=Noone; skipped/notasked are archived as missing. PDF guide has inconsistent codes.','turnout':'e2012g nonmissing includes MatchedNoVote and actual voting modes. Missing records not silently coded as nonvoters.'}
(p/'mourdock_feasibility_summary.json').write_text(json.dumps(info,indent=2))
print(json.dumps(info,indent=2));print(out[(out.geography=='IN')&(out.population=='self_registered')].to_string(index=False))
