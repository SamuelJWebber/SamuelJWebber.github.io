# Mourdock 2012: actual survey-data feasibility audit

We downloaded the official CCES2012 common-content data with Catalist vote validation: DOI10.7910/DVN/HQEVPK, public file2500154,54,535 respondents,490 columns. SHA256 recorded in cces2012_download_manifest.json. No effect estimates or outcome means were calculated.

Indiana has1,020 respondents,931 reporting registration. Their pre-election interviews start October1–November4; the last finishes November5. Every respondent has start/end timestamps. We exclude the entire October23 event date and interviews crossing that day (26 Indiana respondents overall).

| Window around Oct23 | Registered before | Registered after | Governor response before/after | House response before/after | Validated turnout observed before/after |
|---|---:|---:|---:|---:|---:|
| ±7 days |224|34|223/34|224/34|183/31|
| ±14 days |459|74|457/74|458/74|388/66|
| ±28 days |836|74|833/74|834/74|740/66|

Governor/House coverage combines pre-election preferences with already-cast self-reports. Undecided, no-one and other responses remain observed outcomes; these are not counts only of major-party supporters. Authoritative Dataverse DDI labels were checked: pre-wave codes7/8/9 mean Other/Unsure/Noone;98/99 are skipped/notasked and already missing in the archived table. Some printed PDF guide codes are inconsistent with this file; use cces2012_relevant_variable_labels.json.

Only60 of the74 registered respondents interviewed after the event completed the post-election wave;59 have each peer-office vote-response field. Among all836 registered before-event respondents, only24 report having already voted.

**Important identification limit:** interview timing changes when we *measure* preferences. It does not randomly assign eventual exposure to the news. Respondents interviewed before October23 can still hear the story before ElectionDay. Therefore eventual validated turnout cannot be interpreted as an outcome of exposure simply by comparing interview-before versus interview-after groups. It could validate measurement or describe later behavior; a separate actual-exposure design is needed for a causal mobilization estimate.

The snapshot comparison could estimate a discontinuity in contemporaneous intended support, with comparable non-Indiana respondents absorbing national campaign changes, compositional balance checks and a frozen time-window protocol. However, the post-event Indiana sample is small. With74 after and459 before, a simple independent binary-outcome calculation at50% baseline gives a95% half-width near12.3 percentage points and an80%-power MDE near17.6points, before survey weights, comparison-state uncertainty, clustering or design concerns. This is not a standalone design for1–2point coattails.

Reproduce:

    python download_cces2012.py
    python count_mourdock_feasibility.py

Outputs:
- mourdock_feasibility_counts.csv: Indiana and all other states, all respondents and self-registered,±7/14/28 windows, all requested availability counts.
- indiana_interview_daily_counts.csv: aggregate daily counts only.
- mourdock_feasibility_summary.json: sample/date-rule provenance.
- cces2012_download_manifest.json: exact source URLs, size and SHA256.

The raw survey remains a reproducible intermediate. No identifying respondent fields or individual political choices are included in the aggregate outputs.
