import urllib.request,pathlib,hashlib,json,concurrent.futures
root=pathlib.Path(__file__).parent
files=[(2500154,'CCES12_Common_VV.tab'),(2688939,'cces_guide_2012.pdf'),(3036513,'vote-validation-guide-2012.pdf')]
def get(x):
 fid,name=x;p=root/name;u=f'https://dataverse.harvard.edu/api/access/datafile/{fid}'
 if not p.exists():
  req=urllib.request.Request(u,headers={'User-Agent':'Mozilla/5.0'})
  with urllib.request.urlopen(req,timeout=120) as r,p.open('wb') as f:
   while b:=r.read(1048576):f.write(b)
 d={'url':u,'file':name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()};print(json.dumps(d),flush=True);return d
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:out=list(pool.map(get,files))
(root/'cces2012_download_manifest.json').write_text(json.dumps({'doi':'10.7910/DVN/HQEVPK','files':out},indent=2))

# Machine-readable labels (printed guide codes differ for some fields).
u='https://dataverse.harvard.edu/api/datasets/export?exporter=ddi&persistentId=doi:10.7910/DVN/HQEVPK'
req=urllib.request.Request(u,headers={'User-Agent':'Mozilla/5.0'})
(root/'cces2012_ddi.xml').write_bytes(urllib.request.urlopen(req,timeout=60).read())
