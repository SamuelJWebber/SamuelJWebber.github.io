# Governor primary augmentation: verified feasibility audit

The larger governor design is not ready. We found evidence that relevant source data exist, but no verified downloadable set of governor primary vote margins plus pre-primary candidate quality. Do not infer the number of usable close contests from counts of all primaries.

## Actual DIME download inspected

Downloaded the official DIME v4.0 full candidate/recipient file linked at https://data.stanford.edu/dime (46,920,897 compressed bytes; 910,156 rows). Exact public download URLs are in governor_feasibility_manifest.json. Filtered the exact office label `state:governor` (excluding lieutenant governor):

- 5,744 candidate-cycle rows, 1986–2024.
- 0 nonmissing primary vote shares (`prim.vote.pct`).
- 0 nonmissing primary-winner indicators (`pwinner`).
- 3,884 nonmissing cycle donor counts (`num.givers`).
- 1,900 nonmissing NIMSP status descriptions (e.g. won, lost primary, lost general, not up for election).

Thus this file cannot identify any primary margin or support an actual close-primary count. Status descriptions cannot substitute for vote shares. Candidate-cycle rows include non-election cycles and are not a count of actual candidates appearing on ballots. Cycle donor counts are not locked before the primary, so using them to rank candidates would leak post-nomination treatment into the treatment definition.

The official page also links an itemized governor contributions file, but states that public itemized files exclude records originating in the Center for Responsive Politics/NIMSP database. It was not downloaded. Availability of an itemized file therefore does not establish comprehensive coverage or comparable pre-primary donor counting across states/years.

## Verified historical paper pool

Hirano and Snyder, *Primary Elections and the Quality of Elected Officials* (QJPS 2014), DOI 10.1561/100.00013096. Working author PDF, migrated from the supplied old Harvard URL: https://jsnyder.scholars.harvard.edu/file_url/119 .

Table 2 reports 1,917 open-seat governor and Senate primaries, 1952–2012 (1,914 with winner-quality classification; 1,896 for fraction-quality metric). Table 3 includes 575 experience-mixed races (171 with two candidates; 404 with three to five). Their governor experience indicator is previous elected statewide executive office or mayor of a large city; Senate indicator is previous service in the US House or Senate. These are not counts of close primaries, and experience is not the proposed grassroots appeal measure.

Searched the migrated Harvard publication page, current Snyder papers and books sites, Hirano's papers site, publisher page, and web-indexed replication results. No downloadable raw replication located. Harvard Dataverse API search returned 403. This is a retrieval finding, not evidence that the authors lack data or could not share it. No author contacted.

## Other candidate source, not acquired

Alana Jeydel and William R. Wilkerson, *Why aren't more women on the gubernatorial ballot?* (2024), DOI 10.1080/21565503.2024.2333353. Primary publisher page: https://www.tandfonline.com/doi/full/10.1080/21565503.2024.2333353 . The article reports all 1,224 major-party gubernatorial primaries/conventions in 1978–2022, with 1,210 analysis observations. Its outcome is the count of women candidates. No raw download or evidence of complete primary vote margins was established, so this is a lead, not an analysis-ready dataset.

Harbridge-Yong and Hutchinson's 2024 working paper, *The Plurality Problem*, studies House/Senate/governor partisan primaries 2010–2022 with at least three candidates: https://www.ipr.northwestern.edu/documents/working-papers/2024/wp-24-07.pdf . It excludes two-candidate races by design and is not itself an identified coattail design. No replication download acquired within this audit.

## Honest next-step dependency

First obtain and verify a primary-returns source containing winners and runners-up, nomination rules/runoffs, dates, and exact vote shares. Only then count close governor primaries and join pre-primary donor records. Neither DIME's recipient table nor published all-primary sample sizes establishes that a larger causal sample will pass the balance and power checks that the 33-contest Senate pilot failed.
