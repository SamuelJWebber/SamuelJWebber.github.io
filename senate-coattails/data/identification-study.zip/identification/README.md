# Candidate coattails: nomination and information-shock designs

Prepared November 5, 2026, for Samuel Webber's Senate Coattails dashboard.

This release contains a concrete identification protocol, a primary-data audit, and an executed **pretreatment** diagnostic. It does not contain a new causal coattail estimate.

## What changed

The proposed intervention is the nomination of the contender with broader support before a close primary, instead of that contender's actual rival. Teammates' subsequent votes are the outcome. Prior party success is a comparability check, rather than the treatment. Turnout and persuasion are both allowed pathways.

The currently available pilot uses itemized contribution **dollars**, not unique donor counts or validated political talent. The desired donor-breadth extraction is a distinct unfinished measurement task. A relatively stronger contender need not be a nationally exceptional all-star.

## Actual findings of this audit

- 436 Senate primary records in the research source; conservative institutional exclusions and a funding join leave 33 provisional comparisons within a five-point top-two vote margin.
- 25 of these 33 have independently checked official FEC primary votes and winners. Eight older comparisons remain provisional. The exact funding cutoff and treatment of self-financing remain unverified.
- Corrected interpretation of the source margin: five points of top-two vote margin corresponds to 0.025 of top-two share above/below 0.5. Candidate-name slots cannot safely be inferred from the source's ideology-treatment flag. Runoff states are quarantined because some records describe the first round, not the nomination-determining round.
- The specified five-point, separately sloped, triangular-weight local-linear comparison has a **−10.8988-point discontinuity in strictly prior presidential party vote**, with a state-cluster 95% interval of **[−19.2061, −2.5915]**. N=33, 20 states; weight effective sample size=25.36. This is a serious comparability warning, not negative coattails. No current teammate outcomes were fitted.
- The two-point mean comparison and ten-point local-linear comparison are reported alongside it. A nonsignificant balance test in another window is not proof that the design is valid. This release does not switch specifications to obtain a preferred result.
- Fixed-design planning scenarios imply roughly 7–12-point minimum detectable effects in the main pilot for assumed residual SDs of 3–5 points. These are hypothetical precision calculations, not achieved power or estimates of the actual coattail.
- A separate feasibility check downloaded the actual 2012 CCES: a ±14-day window around Mourdock's October 23 statement has 459 registered Indiana respondents interviewed before and 74 after. Interview timing measures opinions at different times; it does not randomize eventual exposure or identify actual-turnout effects. This is not a ready substitute for the full-ballot question.

## Reproduction

Python 3.10+; install `pandas`, `numpy`, `scipy`, `openpyxl` and `xlrd`. The primary-data downloader and verification scripts also document PDF handling in `primary/README.md`.

The public archive includes derived candidate comparisons and the small MIT presidential input used by the balance audit. It excludes individual donor identities, individual CCES respondent records, and full author-source candidate tables.

To reproduce the central diagnostic from the included files:

```sh
python balance/audit_balance.py
```

To reacquire the candidate and official primary sources and rebuild the join:

```sh
python primary/acquire.py
python primary/audit_primary_pairs.py
python primary/verify_fec.py
python primary/finalize_audit.py
```

See `primary/README.md` for source details and `acquisition_manifest.json` for URLs and hashes. Acquisition writes raw source inputs locally; these are intentionally absent from this public bundle. The independent vote audit includes explicitly transcribed official older returns with citations. To reproduce survey feasibility counts, run `shocks/download_cces2012.py` followed by `shocks/count_mourdock_feasibility.py` (approximately 116 MB of survey data plus documentation).

`PROTOCOL.md` was written before the new outcome specifications were fitted; this is retrospective exploratory research, not external preregistration. Its optimistic mean-comparison power illustration is supplemented by the more realistic executed design calculations in `balance/power_scenarios.csv`.

## A newly located executed design

Kayleigh McCrary's October 2026 working paper uses the Comey letter and predetermined early-voting availability to study presidential coattails. Its author reports 0.79 points of down-ballot movement per point of presidential movement and examines turnout. That estimate is conditional on the study's assumptions, applies to its particular shock, and has not been independently replicated here.

Paper: https://kjmccrary.github.io/coattails/draft.pdf

The two relevant research routes are nomination changes and candidate-specific information shocks. Neither an adjusted association nor a failed placebo should be promoted to a causal answer. Completing the grassroots version requires pre-primary unique-donor measures, official nomination-round reconstruction, and a larger suitable pool of statewide nominations. More districts within the same state do not create more independent nominations.
