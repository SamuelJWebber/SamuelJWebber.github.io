# Candidate shocks and same-ballot coattails: identification audit

Prepared 2026-11-05. This is a design/feasibility audit, not a newly estimated causal result.

## Best new executed U.S. template

Kayleigh McCrary, *Leveraging an October Surprise to Estimate Coattail Effects*, current author draft dated October 2, 2026. Author research page lists second-round R&R at AEJ: Economic Policy; it is not yet a published journal article.

- Author PDF: https://kjmccrary.github.io/coattails/draft.pdf
- Research page: https://www.kayleigh-mccrary.com/research
- Shock: Comey letter, October 28, 2016.
- Design: counties in states with no no-excuse early voting, or early voting beginning after the letter, versus counties in states offering early voting before the letter; compare 2012 to 2016. States changing convenience-voting rules excluded. Treatment assigned at state level; cluster there.
- Outcomes: own presidential share; average party share across House, Senate and governor contests; total turnout. N=5,782 county-years for president/turnout, 5,400 for down-ballot (2,700 pairs), not 5,400 independent experiments.
- Author reports IV-DID ratio of 0.79 percentage point additional down-ballot Republican share per 1pp presidential Republican share. This is a context-specific presidential shock response, not a universal quality coefficient.
- Complement: early-vote versus Election-Day DDD in six states (Arkansas, Georgia, Iowa, Louisiana, Maryland, North Carolina); N=2,072 for president, 1,814 for down-ballot. Treatment dose varies at state level, so only six treatment clusters. Weighted inference weaker with state clustering.
- Turnout channel: daily party-registration early-vote composition in NC, weekly NV; pre/post survey turnout intentions. Hence design permits mobilization and persuasion.
- Caveats: parallel trends across states; early voters differ from Election-Day voters; letter may have shifted party reputation directly; late information in comparison year; candidate effect does not mean stable charisma. The prediction-market placebo description appears to conflate win prices with vote-share forecasts, so do not lean on this test.
- No public replication package found on author page or in PDF. Main election returns sourced from Dave Leip; can reconstruct with official state returns if pursuing, but not yet done.

## Statewide event feasibility

| Event | Timing / actual records | Decision |
|---|---|---|
| Cal Cunningham, NC2020, sexual texts acknowledged Oct2 | NCSBE mail voting began Sept4. Official files contain request/return dates, status, method and registration party. CES2020 began Sept29, so only ~3 days of pre-event surveys. Thom Tillis and Donald Trump announced COVID diagnoses on the same date; Senate debate Oct1. | Data-rich turnout case, but mixed shock. Cannot call clean Cunningham effect. Individual administrative history has no candidate choices. |
| Mark Robinson, NC2024, Sept19 story | Official NCSBE release: UOCAVA ballots sent Sept20, ordinary absentee ballots Sept24, in-person early voting Oct17. | Reject before/after-voting design: no real pre-event ballots. |
| Herschel Walker, GA2022, first allegation Oct3 | Official SOS says ordinary ballots could not mail before Oct10; in-person early voting Oct17. | Reject main before/after-voting design for first allegation. |
| Herschel Walker, second allegation Oct26,2022 | AP reports second accuser Oct26, after Oct17 in-person opening. Official absentee histories offer turnout dates. Current official CVRs are scrambled/redacted; no verified ballot-choice-by-cast-day series. | Plausible marginal second-shock design, not total candidate quality. Need verified anonymous aggregate day-by-office outcomes; do not derive individual choices. |
| Richard Mourdock, IN2012, debate remark Oct23 | Early voting started Oct9 (literature agent verifying official source). Hamilton County official results distinguish machine/absentee/provisional, including Senate/governor/House. No verified subdivision of absentee results before vs after Oct23 yet. | Most promising single statewide candidate-specific shock. Survey interviews straddle event; precise aggregate early/late ballots not yet verified. |
| Paul Wellstone, MN2002, death Oct25 | Official Minnesota precinct XLS includes all major-party office votes and counts of absentee ballots accepted, but does not promise candidate votes by return date. GAO confirms replacement-ballot litigation, including voters who had already voted. | Unexpected event, but substitution/sympathy and altered ballot procedures are treatment bundle; public current data inadequate for clean voting-time comparison. |
| Todd Akin, MO2012, Aug19 remark | Before normal early ballots; no useful locked-in comparison in requested design. | Reject timing. |
| Roy Moore, AL2017, Nov9 allegations | Senate special; absence of suitable concurrent statewide/House contests. | Reject for same-ballot peer outcome. |

### Concrete statewide design worth implementing after primary RD

Mourdock2012 offers the clearest event to explore. Pre-specify the shock date without inspecting peer outcomes. Use 2012 CES interviews around Oct23 for Indiana versus comparable states; add 2008/2016 interview-date seasonality as checks, rather than simple early-vs-late comparisons. Primary target is change in *other* Republican candidates' intended/actual support plus eventual validated turnout, not Mourdock vote share residual. Preserve respondents who do not turn out; do not condition on post-shock turnout. Pre-interview composition balance and placebo dates required. Survey sample size/power likely limits small coattails; exact Indiana N and pre/post N must be counted from actual CES data before claiming readiness. Regional and national shocks around the Oct22 presidential debate must be controlled using non-Indiana respondents. This estimates the effect of this negative information shock, not a generic superstar replacement.

For an aggregate-ballot validation, obtain anonymous office-by-day totals from counties if such day-separated tabulation exists. Published 'absentee' totals pool votes before and after Oct23 and do not give an untreated group. Receipt date is not marking date, and scan timestamps are not necessarily voting dates. Never infer individual vote choices by joining voter identities to CVRs.

## International proof-of-concept

Andreu Arenas (2024), *Coattail effects and turnout: Evidence from a quasi-experiment*, Research & Politics.

- https://journals.sagepub.com/doi/10.1177/20531680241229930
- Replication DOI: https://doi.org/10.7910/DVN/JEJPVM
- Basque Country 2007: Batasuna legal in some local contests but banned in concurrent provincial contests, or vice versa. 251 municipalities; 11 provincial electoral districts; local legal status ~40%; of municipalities normally fielding the party, 4.4% legal in both, 52.75% in one, 42.85% neither.
- 1987–2007 electoral-precinct panel; DID with precinct×office, office×year and province×year effects. Reports ~0.25pp concurrent spillover per1pp own-support loss; turnout declines in both contests.
- Ban is not randomized: candidate-list continuity drove legal criteria; parallel-trend sensitivity explicitly tested. This is ballot availability, not personal candidate talent. It supports the existence of a mechanism and an executable causal template, but cannot be relabeled Ossoff quality.
- Harvard API/download attempt returned403; metadata not downloaded. Author paper links supplementary appendix; exact replication files not inspected.

## Primary/official data sources

- NC 2020 mail start: https://www.ncsbe.gov/news/events/mailing-absentee-ballots
- NC2024 dates: https://www.ncsbe.gov/news/press-releases/2024/09/13/absentee-ballots-go-out-military-and-overseas-voters-sept-20-all-other-voters-who-requested-them
- NC2024 Sept19 release: https://www.ncsbe.gov/news/press-releases/2024/09/19/nc-absentee-voting-begins-friday-2024-general-election
- NC retrospective absentee files: https://www.ncsbe.gov/results-data/absentee-and-provisional-data
- NC2020 actual ZIP linked by official page: https://s3.amazonaws.com/dl.ncsbe.gov/ENRS/2020_11_03/absentee_20201103.zip
- NC2020 daily aggregate PDF folder: https://dl.ncsbe.gov/?prefix=Press/2020+General/NC+Absentee+Stats+for+2020+General+Election/
- GA2022 official mail dates: https://sos.ga.gov/news/georgias-absentee-ballot-request-window-now-open
- GA2022 calendar: https://sos.ga.gov/sites/default/files/2022-01/2022_State_Short_Calendar10.pdf
- GA official CVRs: https://sos.ga.gov/page/cast-vote-records
- CES2020 full dataset: https://doi.org/10.7910/DVN/E9N6PH (61,000 respondents; CC0; two waves and turnout validation)
- CES study design: https://cces.gov.harvard.edu/book/study-design
- MN2002 official precinct data description: https://sos.mn.gov/elections-voting/election-results/2002/2002-general-election-results/2002-precinct-results-spreadsheet/
- GAO2002 replacement-ballot report: https://www.gao.gov/assets/a92886.html
- Hamilton County2012 actual output: https://secure2.hamiltoncounty.in.gov/Elections/2012G/results/ElectionSummary.htm

## Web references for root to reopen if citing

McCrary PDF turn6461782view0; author page turn6461782view1.
Arenas paper turn6461782view2.
NC dates turn1100001search1, turn1100001search6/7.
GA dates turn1100001search8/9.
NC files turn3526372view0.
CES primary metadata turn3526372search6; design turn3526372search4.
MN2002 official turn3880197search4; GAO turn3526372search7.
Walker second accusation AP syndication turn6620267search7/8.
GA current CVR page turn6620267search0.
