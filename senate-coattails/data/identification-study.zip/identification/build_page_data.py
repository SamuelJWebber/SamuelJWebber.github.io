"""Build the public, aggregate-only identification audit and downloadable package."""
from pathlib import Path
import csv, json, math, shutil, zipfile

ROOT = Path(__file__).resolve().parent
DIST = ROOT.parents[1] / 'dist'
rows = list(csv.DictReader((ROOT/'primary/nonrunoff_fundraising_cohort.csv').open()))
cases = []
for r in rows:
    margin = float(r['margin_corrected_pp'])
    if margin > 10:
        continue
    high = int(float(r['fundraising_high_slot']))
    ratio = float(r['fundraising_ratio'])
    cases.append(dict(year=int(r['year']), state=r['state'], party=r['party'],
        high=r[f'name{high}'].title(), low=r[f'name{1-high}'].title(),
        margin=margin, ratio=ratio if math.isfinite(ratio) else None,
        zero_low_money=not math.isfinite(ratio), high_won=int(float(r['fundraising_high_won'])),
        verification='FEC votes verified; funding timing pending' if r['official_status']=='verified'
        else 'Research-source match; official votes pending'))
cohorts=[]
for band in [2,5,10]:
    s=[r for r in cases if r['margin'] < band]
    cohorts.append(dict(band=band,n=len(s),states=len(set(r['state'] for r in s)),
        high_wins=sum(r['high_won'] for r in s),
        twofold=sum(r['zero_low_money'] or r['ratio']>=2 for r in s)))
balance=json.loads((ROOT/'balance/summary.json').read_text())
data=dict(updated='November 5, 2026', status='Pilot has serious pretreatment imbalance; no new coattail estimate.',
    measurement='Pre-primary itemized contribution dollars; not unique donor counts.',
    cohorts=cohorts,cases=cases,
    balance=[r for r in balance['results'] if r['outcome']=='prior_presidential_party_pp'],
    sources=['https://doi.org/10.7910/DVN/PCPPHI','https://calgara.github.io/senate_candidate_quality.html',
             'https://dataverse.harvard.edu/api/access/datafile/13887042'])
(DIST/'data/identification-audit.json').write_text(json.dumps(data,indent=2,allow_nan=False)+'\n')
with zipfile.ZipFile(DIST/'data/identification-study.zip','w',zipfile.ZIP_DEFLATED) as z:
    for f in sorted(ROOT.rglob('*')):
        if f.is_file() and '__pycache__' not in f.parts:
            z.write(f,'identification/'+str(f.relative_to(ROOT)))
print(json.dumps({'cohorts':cohorts,'cases':len(cases),'archive_bytes':(DIST/'data/identification-study.zip').stat().st_size}))
