# Close nominations and same-ballot coattails

Prepared November 5, 2026, before fitting the new coattail outcome specifications. This is a fixed analysis protocol for an exploratory historical study, not a claim of external preregistration or an untouched research program.

## The causal contrast

Among Senate party primaries decided by a near tie, what happens to the party's contemporaneous House candidates when the finalist with greater **pre-primary fundraising** narrowly becomes the nominee instead of the other finalist?

This is the effect of choosing one real candidate and campaign over another. It includes their fundraising, ideology, networks, competence, enthusiasm, turnout, persuasion, and campaign coordination. It does not isolate the effect of giving the same person extra money, and it does not assume fundraising is charisma.

## Two distinct treatment lanes

**Lane A: executable money pilot.** Use the audited author-file pre-primary fundraising dollar share for each finalist. This tests nominating the better-funded finalist. It is not a test of unique-donor breadth and will never be relabeled as one. The current pilot excludes runoffs because discovered source margins refer to first rounds in some cases; they can enter a later version only after the actual nomination round and pre-primary money window have been validated.

**Lane B: requested grassroots-support test.** Construct distinct disclosed individual donors for both finalists from filings available before the primary, using a common cutoff and an explicitly documented name/address deduplication rule. In-state and national breadth are separate pre-specified measures, with national breadth designated first. Do not count repeat transactions as different donors. Do not reuse the money pilot's effect to choose which donor definition becomes primary. This lane is currently unmeasured: its results must remain blank until the donor extraction and timing audit are complete.

Within each state-party-primary, population and the broad general-election environment are the same for the two contenders. Therefore dividing both donor counts by the state's population cannot change which finalist has more donors. Per-capita normalization remains useful for cross-state star labels, but is unnecessary to identify the within-primary contrast. A close primary can be between two ordinary candidates; the treatment label must reflect this.

The main result is the reduced-form discontinuity in teammates' outcomes. The nomination comparison can be causally useful even if pre-primary fundraising is not a validated general-election quality score. A separate discontinuity in the nominee's own general-election vote tests whether this candidate type actually gains votes in this setting. Report both regardless of sign or significance. Do not select the sample on realized own-race performance or retain a proxy only when its coattails look favorable.

Calling the treatment an "all-star" requires more than having more money than an opponent. Do not call the richer finalist a star in public results. A pre-specified tail contrast can eventually ask whether a nationally exceptional, independently validated candidate narrowly wins, but cannot be manufactured from the close-primary sample after observing the results.

## Why this addresses the prior-election objection

The identifying comparison is the discontinuous change in the current nominee at a tied primary. It is not a regression of this year's teammate improvement on last election's candidate performance. Prior party support, including any older coattails, should change smoothly through the current primary's zero margin. Historical outcomes diagnose that condition and improve precision; they do not supply the treatment.

This identifies the consequence of the current nomination decision, conditional on the world that existed beforehand. It does not identify an incumbent's entire cumulative effect since entering politics. An incumbent barely renominated versus barely replaced is a valid nomination contrast but a different substantive treatment from selecting between two newcomers; describe both candidates' prior status and report the composition.

## Cohort construction, before outcomes

1. Use one row per state, party, Senate seat, election cycle, and nomination-determining round. Resolve special and regular races separately.
2. Use official winners and vote totals to map the two finalists. Audit author-file name slots instead of trusting that names line up with an ideology treatment flag. Exact state-year-party is insufficient when two Senate seats are contested.
3. For majority systems, use the nomination-determining runoff, not an earlier round which merely sends both candidates onward. Exclude top-two/top-four nonpartisan systems from this party-nomination analysis. Treat RCV or convention decisions separately unless a correct assignment rule can be documented.
4. Both finalists must have an observed, comparably measured pre-primary funding measure. Unknown is not zero. The current immediately available measure is pre-primary fundraising dollar share from the candidate data. Distinct donor breadth is a separate future treatment requiring new extraction.
5. Confirm the funding cutoff precedes nomination. Prefer the same cutoff before the first nomination round for runoff contenders, and document the actual source window. Final election-cycle receipts and eventual general-election totals are forbidden.
6. Raw transaction dates do not recreate the historical information set: later cumulative itemization and amendments can expose earlier gifts. A donor-breadth extension should use filings available before nomination, or explicitly quantify and label the remaining retrospective reporting risk. Do not silently reuse June 30 when a primary occurred earlier.
7. Label the finalist with higher pre-primary funding H, the other L. Exclude exact ties in the treatment-defining funding measure. Do not tune a minimum funding-gap threshold using outcomes. Keep all nonzero gaps for the main contrast; show their distribution.
8. Define the signed top-two vote margin as m = 100*(votes_H-votes_L)/(votes_H+votes_L), in percentage points. The treatment is D=1[m>0]. A 51% versus 49% top-two result is m=+2, not +1. If the existing source rv is H's top-two share minus 0.5, m=200*rv, after correct orientation.
9. Record candidate membership, money, prior elected experience, incumbency, field size, runoff status, and primary date before merging general outcomes. Publish the eligibility/exclusion ledger. If official votes cannot resolve a source inconsistency, quarantine it as unresolved rather than select the mapping that gives a preferred result.

## Outcomes

The main outcome is the party's contemporaneous House two-party vote share, summarized once per state election, with a documented aggregation rule and completeness checks. Use the same public outcome definition across treatment groups; do not weight a state by how many House districts it contains. Missing party votes are not automatically zero. If the existing district source cannot produce a complete state aggregation, use a pre-declared comparable-district average and report the resulting narrower estimand and coverage. Do not substitute an outcome definition after inspecting treatment effects.

Secondary outcomes are (a) the Senate nominee's own general-election vote share; (b) the same-party governor's share when there is a concurrent gubernatorial election; (c) House votes for that party per voting-eligible resident, if a defensible denominator exists; (d) total turnout. If only resident population is available, label it votes per resident, not turnout. The vote-share endpoint combines persuasion and differential turnout. Vote counts and turnout preserve effects in which both parties mobilize, but do not by themselves identify individual vote switching.

The primary model does not control for current turnout, the nominee's current general-election vote, current spending, or current presidential results. These can be affected by the nomination. All mechanisms following nomination belong to the total treatment effect.

## Fixed estimates

Main window: |m| < 5 percentage points of the **top-two margin**, not five points from a 50% share. Main estimator: local linear regression with separate slopes on each side and triangular weights w=1-|m|/5. Estimate the jump at zero.

Report the unadjusted specification and a precision-adjusted specification with only the party's lagged House share, strictly prior presidential share, and a Democratic-party indicator. The adjusted specification is the designated main precision estimate; unadjusted results remain prominent. Center covariates consistently and fit their common slopes. Never add controls in response to the coefficient's sign or p-value. The tiny sample does not support a saturated state-by-year fixed-effect model.

The narrow sensitivity is |m|<2 with an unweighted difference in means, clearly labeled as requiring local randomization throughout that entire window. The wide sensitivity is the same local linear model at |m|<10. Do not choose the bandwidth after seeing which produces significance. Show all three side by side.

For each result, report observations per side, distinct states and state-years, weight-based effective sample size, degrees of freedom, and the treatment interval. Cluster uncertainty by state, because multiple party primaries, seats, and cycles within a state are not independent. Use a small-sample correction and state-cluster t critical values. If feasible, include a wild-cluster bootstrap as an inference sensitivity. Weighted least-squares intervals condition on the selected local linear form; they are not automatically bias-corrected nonparametric RD intervals. An rdrobust calculation can be a separately specified robustness check, with the actual bandwidth and effective observations shown.

The coefficient is measured in teammate vote-share points per nomination of H instead of L. A large state's districts are repeated outcomes of one nomination, not hundreds of independent natural experiments. Governor results have fewer eligible nomination experiments than House results.

## Diagnostics and interpretation

Before interpreting a causal effect, display the same discontinuity estimates for lagged House share, lagged presidential share, and earlier changes in those outcomes. Add the number of incumbents, prior offices, prior donations, and prior electoral histories of **both named finalists**. Winner-only characteristics change mechanically when treatment switches and are not ordinary pretreatment balance tests.

Inspect density of margins and recount/administrative treatment. Test the joint behavior of the core predetermined political variables; do not demand that every isolated p-value exceed 0.05. Lack of significance is not proof of balance in a small sample. Consider whether imbalances are substantively comparable to the claimed coattail effect.

Do not drop imbalanced races, add controls, or widen the bandwidth until the design looks favorable. If balance is poor, report the failed diagnostic and retain the full result with a weakened causal interpretation. Fixed diagnostic reporting avoids converting validity checks into outcome-dependent sample selection.

A present-day nomination cannot cause a jump in election results from before the primary. Such a placebo jump is direct evidence that the intended comparison is not separating the current nominee from prior partisan conditions in this realized sample.

## What the sample can detect

The raw Senate source contains 48 primaries within a five-point top-two vote margin before the funding join and audit. The provisional non-runoff money pilot has 33 cases in 20 states, including 19 higher-money winners; 19 of the 33 have at least a twofold money gap. The two-point window has 15 cases and the ten-point window has 65. These are provisional eligibility counts, not results, and may shrink after official nominee and funding-window verification. Districts within these states do not create additional nomination experiments.

As an optimistic benchmark for a balanced, unweighted randomized comparison, the 80%-power, two-sided 5%-test minimum detectable effect is approximately 5.6*sigma/sqrt(N). This is only a planning calculation, not an empirical power result for the RD.

| Total independent cases | Residual outcome SD | Optimistic detectable difference |
|---:|---:|---:|
| 33 | 3 percentage points | 2.92 percentage points |
| 33 | 5 percentage points | 4.87 percentage points |
| 48 | 3 percentage points | 2.43 percentage points |
| 48 | 5 percentage points | 4.04 percentage points |
| 100 | 3 percentage points | 1.68 percentage points |
| 100 | 5 percentage points | 2.80 percentage points |

Slope estimation, triangular weighting, imbalanced treatment counts, and clustering generally worsen this comparison. Detecting a one-point coattail with residual SD 3 points would need roughly 283 independent cases even under this optimistic benchmark; with SD 5 it needs roughly 784. A nonsignificant 40-case result cannot establish that coattails smaller than several points do not exist.

For actual design-based precision, compute the standard error implied by the frozen design matrix and a pre-treatment residual variance estimate, without using the observed treatment coefficient to select the design. Show the attainable interval width beside the effect.

## Do not turn the own-vote effect into an automatic coattail multiplier

If H's nomination causes +a points for H's own party Senate vote and +b points for House candidates, report the pair (a,b). The ratio b/a may be a descriptive ratio of two effects of the same candidate-selection intervention, if the denominator is well separated from zero. It is not automatically the causal effect of an extra Senate vote on House votes.

Instrumenting own Senate vote with H's nomination requires the nomination to affect House votes only through the scalar Senate vote share. That excludes direct coordinated canvassing, fundraising transfers, party-brand effects, persuasion affecting House but not Senate, and shared turnout—precisely mechanisms in the user's question. Do not impose that exclusion restriction. If a ratio is shown, label it intervention-specific, use weak-denominator-robust uncertainty, and never extrapolate it to Ossoff or Obama.

## Extensions that preserve the question

Gubernatorial primaries can add genuinely new statewide nomination decisions. Keep Senate and governor treatments separately estimated first, and then report a pre-specified pooled estimate with office interactions. For odd-year gubernatorial elections, use concurrent state legislative or other statewide executive races; they cannot contribute to the same-year U.S. House outcome. A larger municipal sample identifies municipal coattails, not the statewide effect the user requested.

A randomized survey offering alternate real Senate nominees while keeping the rest of the ballot fixed would directly test stated full-ballot choices and turnout intentions. It can define candidate appeal before the election, but it is not an experiment on actual turnout or votes. It is best used to improve prospective candidate scoring, not represented as an actual-election substitute.

Late candidate-specific shocks with ballots already cast can triangulate a mechanism. Before/after or early/election-day voters are not randomly interchangeable; their partisan composition and trends require explicit controls and comparison elections. Such a design estimates the effect of that information shock, not the nominee's full contribution.

## Primary methodological references

- Hall and Thompson, March 6, 2025 correction: https://www.andrewbenjaminhall.com/pdfs/hall_thompson_revised.pdf . Their earlier close-primary estimates had a large lagged-presidential imbalance. This is why prior outcomes must be shown, not treated as a routine box-check.
- de la Cuesta and Imai, 2016, Misunderstandings About the Regression Discontinuity Design in the Study of Close Elections: https://imai.fas.harvard.edu/research/files/RD.pdf . Distinguishes continuity-based local linear RD from stronger local-randomization comparisons and emphasizes local interpretation.
- Bertoli and Hazlett, 2025, Seeing Like a District: https://doi.org/10.1017/pan.2025.5 . A characteristic-based close-election design identifies selecting a candidate of one type over the opponent; it does not isolate that attribute from the candidate's other features. The within-race gradient design is meaningful when interpreted correctly.
- Myers replication: https://doi.org/10.7910/DVN/PCPPHI . Primary margins and pre-primary ideological measures; its general-election fundraising outcomes must not be mistaken for pretreatment funding.

