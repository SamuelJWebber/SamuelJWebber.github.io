"""Download source data and build local analysis inputs. No effect estimates.
Usage: python -m pip install -r requirements.txt; python acquire.py
"""
from pathlib import Path
import urllib.request,zipfile,io,json,hashlib,re,concurrent.futures
import pandas as pd
P=Path(__file__).resolve().parent
F=P/'fec';F.mkdir(exist_ok=True)
SOURCES={
 'quality.html':'https://calgara.github.io/senate_candidate_quality.html',
 'myers_replication.zip':'https://dataverse.harvard.edu/api/access/datafile/12110235',
 'fec/1984.pdf':'https://www.fec.gov/documents/1548/federalelections84.pdf',
 'fec/1988.pdf':'https://www.fec.gov/documents/1550/federalelections88.pdf',
 'fec/1992.pdf':'https://www.fec.gov/documents/1552/federalelections92.pdf',
 'fec/1994.pdf':'https://www.fec.gov/documents/1553/federalelections94.pdf',
 'fec/1996.xlsx':'https://www.fec.gov/documents/1722/FederalElections96_1996Senate.xlsx',
 'fec/1998.pdf':'https://www.fec.gov/documents/1727/FederalElections98_SenateResults.pdf',
 'fec/2000.pdf':'https://www.fec.gov/documents/1556/federalelections00.pdf',
 'fec/2002.xls':'https://www.fec.gov/documents/1620/2002fedresults.xls',
 'fec/2006.xls':'https://www.fec.gov/documents/1642/federalelections2006.xls',
 'fec/2008.xls':'https://www.fec.gov/documents/1666/federalelections2008.xls',
 'fec/2010.xls':'https://www.fec.gov/documents/1675/federalelections2010.xls',
 'fec/2012.xls':'https://www.fec.gov/documents/1691/federalelections2012.xls',
 'fec/2014.xls':'https://www.fec.gov/documents/1700/federalelections2014.xls',
 'fec/2016.xlsx':'https://www.fec.gov/documents/1890/federalelections2016.xlsx',
 'fec/2018.xlsx':'https://www.fec.gov/documents/2706/federalelections2018.xlsx',
 'fec/2022_federalelections2022.xlsx':'https://www.fec.gov/documents/5676/federalelections2022.xlsx',
}
def get(item):
 name,url=item;p=P/name
 if not p.exists():
  req=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0 (public academic research)'})
  p.write_bytes(urllib.request.urlopen(req,timeout=120).read())
 b=p.read_bytes()
 return name,dict(url=url,bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
with concurrent.futures.ThreadPoolExecutor(max_workers=6)as pool:manifest=dict(pool.map(get,SOURCES.items()))
(P/'acquisition_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
s=(P/'quality.html').read_text()
for n in ['cand','elec','races','codebook']:
 m=re.search(r'<script type="text/plain" id="csv_'+n+r'">(.*?)</script>',s,re.S)
 if not m:raise ValueError('Author page no longer contains '+n)
 (P/(n+'.csv')).write_text(m.group(1))
z=zipfile.ZipFile(P/'myers_replication.zip')
n=next(n for n in z.namelist()if n.endswith('/MoneyRD_hs_primary.dta'))
d=pd.read_stata(io.BytesIO(z.read(n)));d=d[(d.office=='S')&(d.level=='congress')]
assert len(d)==436,'Myers source version changed; review before proceeding'
d.to_csv(P/'myers_senate.csv',index=False)
for name in SOURCES:
 p=P/name
 if p.suffix not in ['.xls','.xlsx']or p.name.startswith('1996'):continue
 x=pd.ExcelFile(p)
 sh=next((s for s in x.sheet_names if ('House'in s or'Senate'in s)and('Result'in s or'Resut'in s)),None)
 if sh is None:raise ValueError('FEC sheet name changed: '+name)
 pd.read_excel(p,sheet_name=sh).to_csv(p.with_suffix('.csv'),index=False)
print('Sources acquired; next run audit_primary_pairs.py, verify_fec.py, finalize_audit.py')
