"""Audit close, nonrunoff pairs against downloaded official FEC tables."""
import sys,pathlib,re
import pandas as pd,numpy as np
P=pathlib.Path(__file__).resolve().parent
D=pd.read_csv(P/'primary_pair_audit.csv')
D=D[(D.status=='eligible')&D.fundraising_rv.notna()&(D.two_candidate_margin_pp<=5)&~D.state.isin({'AL','AR','GA','MS','NC','OK','SC','TX','SD'})]
def norm(x):return re.sub('[^A-Z]','',str(x).upper())
rows=[]
for yr in sorted(D.year.unique()):
 if yr<2002:continue
 files=[x for x in (P/'fec').glob(f'{yr}*.csv')if 'append'not in str(x)and'tables'not in str(x)]
 if not files:continue
 f=pd.read_csv(files[0]);f.columns=[str(x).strip().upper()for x in f.columns]
 sc='STATE ABBREVIATION' if 'STATE ABBREVIATION'in f else 'STATE'
 dc=next(x for x in ['DISTRICT','D']if x in f)
 lc=next(x for x in f if(x=='LAST NAME'or'(LAST)'in x))
 pc=next(x for x in ['PRIMARY VOTES','PRIMARY RESULTS','PRIMARY']if x in f)
 rc=next(x for x in ['RUNOFF VOTES','RUNOFF RESULTS','RUNOFF']if x in f)
 f=f[f[dc].astype(str).str.strip().str.upper().isin(['S','SENATE'])].copy();f['last_norm']=f[lc].map(norm)
 for r in D[D.year==yr].itertuples():
  z=f[(f[sc]==r.state)&(f.PARTY.str[:1]==r.party[0].upper())]
  ms=[z[z.last_norm==norm(getattr(r,'name'+str(i)).split(',')[0])]for i in[0,1]]
  rec={'myers_row':r.myers_row,'state':r.state,'year':yr,'party':r.party,'source_file':str(files[0]),'source_margin_pp':r.two_candidate_margin_pp}
  if any(len(q)!=1 for q in ms):rec['official_status']='match_unresolved';rec['matches']=str([len(q)for q in ms]);rows.append(rec);continue
  a,b=[q.iloc[0] for q in ms];v=pd.to_numeric(pd.Series([a[pc],b[pc]]),errors='coerce');rv=pd.to_numeric(pd.Series([a[rc],b[rc]]),errors='coerce')
  rec.update({'votes0':v[0],'votes1':v[1],'runoff0':rv[0],'runoff1':rv[1],'fec_primary_margin_pp':100*abs(v[0]-v[1])/sum(v),'fec_winner_slot':int(v[1]>v[0]),'algara_winner_slot':r.winner_slot})
  rec['official_status']='verified' if abs(rec['fec_primary_margin_pp']-rec['source_margin_pp'])<.01 and rec['fec_winner_slot']==rec['algara_winner_slot'] and rv.isna().all() else'discrepancy'
  rows.append(rec)
pd.DataFrame(rows).to_csv(P/'official_fec_audit.csv',index=False)
print('Modern FEC pairs',len(rows))
