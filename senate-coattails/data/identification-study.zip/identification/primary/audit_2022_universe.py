"""Count conventional Senate nominations, using final runoff where reported."""
from pathlib import Path
import pandas as pd
P=Path(__file__).resolve().parent
D=pd.read_csv(P/'fec/2022_federalelections2022.csv')
D=D[D['CANDIDATE NAME (Last)'].notna()&D.PARTY.astype(str).str.match(r'^[DR]($|[/\*])')].copy()
D['party_normalized']=D.PARTY.str[0];D['DISTRICT']=D.DISTRICT.str.strip();rows=[]
for (state,district,party),a in D.groupby(['STATE ABBREVIATION','DISTRICT','party_normalized']):
 if state in ['AK','CA','WA','LA']:continue
 col='RUNOFF VOTES'if pd.to_numeric(a['RUNOFF VOTES'],errors='coerce').notna().any()else'PRIMARY VOTES'
 a=a.copy();a['v']=pd.to_numeric(a[col],errors='coerce');a=a[a.v>0].sort_values('v',ascending=False)
 if len(a)<2:continue
 z=a.iloc[:2];gap=100*(z.v.iloc[0]-z.v.iloc[1])/sum(z.v)
 rows.append(dict(state=state,district=district,party=party,margin_pp=gap,winner=z['CANDIDATE NAME'].iloc[0],runnerup=z['CANDIDATE NAME'].iloc[1],round=col))
X=pd.DataFrame(rows);X.to_csv(P/'fec_2022_all_contested.csv',index=False)
print(dict(contested=len(X),within_5pp=int(sum(X.margin_pp<=5)),within_10pp=int(sum(X.margin_pp<=10))))
