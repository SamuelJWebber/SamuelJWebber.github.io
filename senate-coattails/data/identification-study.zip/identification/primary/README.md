# Close Senate nominations: concrete feasibility audit

Date: 2026-11-05. No concurrent Senate or teammate outcome was inspected for effect estimation during this audit. Source election files contain general results, but the audit uses only primary counts and winner status. The selection rule below is based on nomination data and pretreatment candidate attributes only.

## Executable design

Compare nomination of the candidate who had the larger author-described pre-primary itemized contribution share with nomination of the smaller fundraiser, among very close same-party Senate nomination contests. The running variable is the higher fundraiser's top-two primary share minus 0.5. The treatment is nomination of the higher fundraiser. This is a candidate-nomination package, not an intervention on money and not intrinsic charisma. Secondary, separately labeled contrast: prior elected experience versus no prior elected experience.

The direct outcome should be teammates' same-ballot party votes per eligible population, plus two-party vote share. Do not control for current turnout, current candidate spending, or the Senate vote, because those can be consequences/mediators. Adjusting only for lagged teammate/presidential outcomes may improve precision, but random assignment near the threshold—not lag adjustment—is the identification argument. Test pretreatment balance and density and show raw variation before any causal interpretation. Cluster by state or at least primary/state-election; many House districts do not create many independent assignments. Report the nominee's own general-election result as an independent relevance check; a near-zero own-race effect means this particular fundraising contrast has not established an all-star contrast.

## Sources and counts

- Myers, *Do Donors Punish Extremist Primary Nominees?*, APSR, DOI 10.1017/S000305542510138X, replication DOI 10.7910/DVN/PCPPHI, direct ZIP https://dataverse.harvard.edu/api/access/datafile/12110235 . Source is CC0. MoneyRD_hs_primary.dta has 436 Senate primary-party rows, 1980–2022. These are selected contests with ideology data, not the universe.
- Algara et al., *The Rise of Amateur Candidate Pipelines…*, author CSV embedded at https://calgara.github.io/senate_candidate_quality.html . 6,595 candidate rows, primary winners and top-two status, prior elected experience, and pre-primary itemized contribution shares. Archive DOI10.7910/DVN/52OFMP could not be retrieved today; author page accessible. License displayed as proposed CC BY4.0; raw source not suitable for treating as an independently verified license grant.
- FEC official federal-election publications validate primary vote totals and winners. 25 of the 33 conventional nonrunoff pairs within a five-point top-two winning margin independently match FEC primary counts and nomination winners (19 states,24 state-years;14 larger-fundraiser winners). Eight older 1980–1992 pairs remain unaudited; older FEC PDFs retrieved do not provide usable primary tables. The candidate list is in final_audit_summary.json.

Mechanically, 417 of436 Myers rows join to both Algara top-two contestants in a conventional primary,334 have different nonmissing pre-primary money shares,273 remain after quarantining all runoff-rule states. Within actual top-two margin ≤5pp,41 money pairs before runoff quarantine and33 afterward; at≤2pp,15 afterward;at≤10pp,65 afterward. Nineteen of the33 have at least2× contribution contrast. These are feasibility windows, not selected analytical bandwidths.

## Material source errors discovered

1. **Margin units:** Myers rv is share minus0.5, so displayed winner-minus-runner-up margin is 200*abs(rv). The earlier count of93 cases atabs(rv)<0.05 corresponds to top-two winning margins<10pp, not5pp. There are48 raw rows atabs(rv)<.025.
2. **Name slots:** codebook calls cand_last0 moderate and cand_last1 extremist. Among417 matched conventional pairs,403 disagree with inferring the winner directly from treat and those name labels. This audit uses the independent Algara winner flag and the magnitude of rv, not those labels.
3. **Runoff error:** paper says the nomination-determining runoff is used, but TX2002 Kirk/Morales rv=.0007866 matches the first-round difference316052vs317048. FEC final nomination runoff was370878vs249423 (59.79–40.21). AL2020,MS2018,SC2022 similarly look falsely close from first-round margins. We quarantine all AL,AR,GA,MS,NC,OK,SC,TX,SD observations pending final-round repair rather than treating a close first round as randomized nomination. Some actual close runoff pairs can later be restored after independent final-round audit.
4. **Nonpartisan formats:** exclude LA and CA2012+,WA2008+,AK2022+; a close first-vs-second place finish where both advance does not assign nomination.
5. **Wrong pair:** six source rows fail independent winner membership; three NY primaries identify the second/third pair rather than the nominee. These are excluded. One MO2018pair is not independent top-two verified. A remaining ambiguous candidate mapping is quarantined. Routine surname aliases are explicit in code; duplicate surnames resolved only when independently flagged top-two.

## What the money measure means

The author codebook describes pre_contributions_as_prop_of_race as the candidate's share of **pre-primary itemized contributions** in the party's primary. It is a dollar share, NOT number of donors, NOT donations per capita, and NOT all receipts. The trimmed public data does not expose transaction types or precise cutoff dates; we have not independently established whether candidate contributions/self-funding are excluded or how loans are handled. Do not assert self-funding is excluded. Rebuilding individual-donor breadth with receipt dates before the relevant nomination election would address the user's specific grassroots-support proxy; this author variable is an immediately available alternative requiring separate validation.

## Latest-cycle universe check

FEC2022 official Senate sheet yields48 contested conventional major-party nominations (excluding CA,WA,AK,LA; use final runoff where reported and preserve fusion labels such as R/CON). Only3 have top-two margin≤5pp: NHRepublican,ORRepublican,PARepublican; all3 are already in the cohort. At≤10pp there are7: addCORepublican,ILRepublican,MODemocratic,VTRepublican. Thus broadening the universe is correct but will not magically yield hundreds of very close statewide nominations.

## Files

- audit_primary_pairs.py: reproducible candidate matching and preliminary eligibility.
- primary_pair_audit.csv:436-row inclusion/exclusion audit.
- officially_verified_close_cohort.csv:25 independently checked≤5pp nonrunoff pairs, no general-election outcomes.
- nonrunoff_fundraising_cohort.csv:273 matched nonrunoff pairs, with independent audit status.
- official_fec_audit.csv:25 FEC vote comparisons, exact counts, signed nominee checks.
- final_audit_summary.json: counts and eight older pairs requiring verification.
- fec_2022_all_contested.csv:48 nomination contests and correct-round margins.
- source_manifest.json: source files and SHA256 hashes.

## Prior literature warning

Hall and Thompson's March2025 correction (https://www.andrewbenjaminhall.com/pdfs/hall_thompson_revised.pdf) retracts reliance on their original large turnout estimates because baseline presidential support differed around the threshold. Use this as a mandatory reminder that close nominations alone do not establish balance. A well-designed, low-powered RD is more credible than a large confounded panel, but its interval may still be wide. The estimand is local to closely decided nominations between the observed candidate types; it cannot by itself assign an exact Ossoff/Obama statewide contribution.

## Reproduce the audit

Install requirements.txt, then run in order: `python acquire.py`; `python audit_primary_pairs.py`; `python verify_fec.py`; `python finalize_audit.py`. The ten older FEC comparisons are transparent manual transcriptions embedded in finalize_audit.py; source URLs accompany each. The first fifteen are machine matched from official spreadsheets. finalize_audit.py is idempotent and asserts unique primary IDs. Do not include the downloaded author raw CSV files in the distribution; acquisition code and source hashes preserve reproducibility.
