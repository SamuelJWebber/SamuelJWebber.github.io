import sys, re, pathlib, json
import pandas as pd, numpy as np
P=pathlib.Path(__file__).resolve().parent
c=pd.read_csv(P/'cand.csv',keep_default_na=False)
m=pd.read_csv(P/'myers_senate.csv')
def norm(x): return re.sub('[^A-Z]','',str(x).upper())
c['last']=c['name'].str.split(',').str[0].map(norm)
c['shortparty']=c.party.map({'Democratic':'dem','Republican':'rep'})
ALIASES={'VANZSCHAU':'ZSCHAU','VALENTINE':'BUSCHVALENTINE','MANCHIN':'MANCHINIII','DAVID':'BENDAVID'}
rows=[]
for j,r in m.iterrows():
 z=c[(c.fecyear==r.year)&(c.state==r.state)&(c.shortparty==r.party)]
 matches=[z[z['last']==ALIASES.get(norm(r[f'cand_last{i}']),norm(r[f'cand_last{i}']))] for i in (0,1)]
 matches=[q[q.win_primary_top_two.astype(str).isin(['0','1'])] if len(q)>1 else q for q in matches]
 o={'myers_row':j,'state':r.state,'year':int(r.year),'party':r.party,'name0':r.cand_last0,'name1':r.cand_last1,'source_rv':r.rv,'two_candidate_margin_pp':200*abs(r.rv),'source_treat':r.treat,'match0_n':len(matches[0]),'match1_n':len(matches[1])}
 if any(len(q)!=1 for q in matches):o['status']='ambiguous_or_missing_name';rows.append(o);continue
 a,b=[q.iloc[0] for q in matches]
 for i,k in enumerate([a,b]):
  for col in ['name','primary_id','win_primary','win_primary_top_two','political_experience','quality_candidate','pre_contributions_as_prop_of_race','candidate_in_primary','special_election']:
   o[f'{col}{i}']=k[col]
 if a.primary_id!=b.primary_id:o['status']='different_primary';rows.append(o);continue
 if {str(a.win_primary),str(b.win_primary)}!={'0','1'}:o['status']='uncertain_nomination_winner';rows.append(o);continue
 if {str(a.win_primary_top_two),str(b.win_primary_top_two)}!={'0','1'}:o['status']='not_verified_top_two';rows.append(o);continue
 o['winner_slot']=int(str(b.win_primary)=='1')
 o['codebook_name_slots_agree_with_treat']=int(o['winner_slot']==r.treat)
 o['conventional_primary']=not (r.state=='LA' or (r.state=='CA' and r.year>=2012) or(r.state=='WA' and r.year>=2008) or(r.state=='AK' and r.year>=2022))
 o['status']='eligible' if o['conventional_primary'] else 'nonpartisan_primary'
 fs=pd.to_numeric(pd.Series([a.pre_contributions_as_prop_of_race,b.pre_contributions_as_prop_of_race]),errors='coerce')
 qs=pd.to_numeric(pd.Series([a.quality_candidate,b.quality_candidate]),errors='coerce')
 if fs.notna().all() and fs.max()>0 and fs[0]!=fs[1]:
  high=int(fs[1]>fs[0]);o['fundraising_high_slot']=high;o['fundraising_high_won']=int(high==o['winner_slot']);o['fundraising_high_share']=max(fs);o['fundraising_low_share']=min(fs);o['fundraising_ratio']=float(max(fs)/min(fs)) if min(fs)>0 else float('inf');o['fundraising_gap']=max(fs)-min(fs);o['fundraising_rv']=abs(r.rv)*(1 if o['fundraising_high_won'] else -1)
 if qs.notna().all() and qs[0]!=qs[1]:
  high=int(qs[1]>qs[0]);o['experienced_high_won']=int(high==o['winner_slot']);o['experience_rv']=abs(r.rv)*(1 if o['experienced_high_won'] else -1)
 rows.append(o)
d=pd.DataFrame(rows);d.to_csv(P/'primary_pair_audit.csv',index=False)
e=d[d.status=='eligible'];f=e[e.fundraising_rv.notna()];q=e[e.experience_rv.notna()]
summary={'all_source_rows':len(m),'status_counts':d.status.value_counts().to_dict(),'eligible':len(e),'fundraising_available':len(f),'experience_contrast':len(q),'codebook_slot_agreement':e.codebook_name_slots_agree_with_treat.value_counts().to_dict(),'windows':[]}
for band in [2,5,10,20]:
 for label,x in [('all_eligible',e),('pre_primary_money',f),('money_at_least_2x',f[f.fundraising_ratio>=2]),('experience_contrast',q)]:
  a=x[x.two_candidate_margin_pp<=band];v='experienced_high_won' if label=='experience_contrast' else 'fundraising_high_won'
  summary['windows'].append({'max_top_two_margin_pp':band,'cohort':label,'n':len(a),'states':a.state.nunique(),'state_years':len(a[['state','year']].drop_duplicates()),'higher_wins':None if label=='all_eligible' else int(a[v].sum())})
(P/'primary_pair_summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2))
print('\nMAPPING EXCLUSIONS\n',d[d.status!='eligible'][['state','year','party','name0','name1','status']].to_string(index=False))
print('\nCLOSE FUNDS\n',f[f.two_candidate_margin_pp<=5][['state','year','party','name0','name1','two_candidate_margin_pp','fundraising_ratio','fundraising_high_won']].to_string(index=False))
