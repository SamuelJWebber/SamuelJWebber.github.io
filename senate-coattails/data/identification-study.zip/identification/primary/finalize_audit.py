import sys, pathlib,json,hashlib
import pandas as pd,numpy as np
P=pathlib.Path(__file__).resolve().parent
a=pd.read_csv(P/'official_fec_audit.csv');d=pd.read_csv(P/'primary_pair_audit.csv')
manual=[(124,377141,342935,'https://www.fec.gov/documents/1722/FederalElections96_1996Senate.xlsx'),(194,355583,326835,'https://www.fec.gov/documents/1722/FederalElections96_1996Senate.xlsx'),(432,24918,27056,'https://www.fec.gov/documents/1722/FederalElections96_1996Senate.xlsx'),(125,372916,346606,'https://www.fec.gov/documents/1727/FederalElections98_SenateResults.pdf'),(136,131327,138960,'https://www.fec.gov/documents/1727/FederalElections98_SenateResults.pdf'),(192,151323,157585,'https://www.fec.gov/documents/1553/federalelections94.pdf'),(193,270304,292399,'https://www.fec.gov/documents/1553/federalelections94.pdf'),(208,215171,200937,'https://www.fec.gov/documents/1553/federalelections94.pdf'),(298,415853,432361,'https://www.fec.gov/documents/1553/federalelections94.pdf'),(397,16444,17440,'https://www.fec.gov/documents/1556/federalelections00.pdf')]
rs=[]
for row,v0,v1,url in manual:
 r=d.set_index('myers_row').loc[row];margin=100*abs(v0-v1)/(v0+v1)
 rs.append({'myers_row':row,'state':r.state,'year':r.year,'party':r.party,'source_file':url,'source_margin_pp':r.two_candidate_margin_pp,'votes0':v0,'votes1':v1,'fec_primary_margin_pp':margin,'fec_winner_slot':int(v1>v0),'algara_winner_slot':r.winner_slot,'official_status':'verified'if abs(margin-r.two_candidate_margin_pp)<.01 and int(v1>v0)==r.winner_slot else 'discrepancy'})
a=a[~a.myers_row.isin([r[0] for r in manual])]
a=pd.concat([a,pd.DataFrame(rs)],ignore_index=True)
assert a.myers_row.is_unique,'Duplicate primary audits'
a.to_csv(P/'official_fec_audit.csv',index=False)
nonrunoff=d[(d.status=='eligible')&d.fundraising_rv.notna()&~d.state.isin({'AL','AR','GA','MS','NC','OK','SC','TX','SD'})].copy()
nonrunoff=nonrunoff.merge(a[['myers_row','official_status','fec_primary_margin_pp','votes0','votes1']],on='myers_row',how='left')
nonrunoff['margin_corrected_pp']=nonrunoff.fec_primary_margin_pp.combine_first(nonrunoff.two_candidate_margin_pp)
nonrunoff['running_variable']=np.where(nonrunoff.fundraising_high_won==1,1,-1)*nonrunoff.margin_corrected_pp/200
nonrunoff['official_status']=nonrunoff.official_status.fillna('not_yet_independently_verified')
nonrunoff.to_csv(P/'nonrunoff_fundraising_cohort.csv',index=False)
verified=nonrunoff[(nonrunoff.official_status=='verified')&(nonrunoff.margin_corrected_pp<=5)]
verified.to_csv(P/'officially_verified_close_cohort.csv',index=False)
summary={'source_pairs':len(d),'nonrunoff_cohort':len(nonrunoff),'n_close_5pp':sum(nonrunoff.margin_corrected_pp<=5),'officially_verified_5pp':len(verified),'officially_verified_treatment_wins':int(verified.fundraising_high_won.sum()),'officially_verified_states':verified.state.nunique(),'officially_verified_state_years':len(verified[['state','year']].drop_duplicates()),'remaining_5pp_to_verify':nonrunoff[(nonrunoff.margin_corrected_pp<=5)&(nonrunoff.official_status!='verified')][['state','year','party','name0','name1']].to_dict('records'),'no_outcomes_examined':True}
(P/'final_audit_summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
files={str(f.relative_to(P)):{'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()}for f in P.rglob('*')if f.is_file() and f.name!='source_manifest.json'}
(P/'source_manifest.json').write_text(json.dumps({'download_date_utc':'2026-11-05','source_urls':{'algara':'https://calgara.github.io/senate_candidate_quality.html','myers_zip':'https://dataverse.harvard.edu/api/access/datafile/12110235','myers_dataset':'https://doi.org/10.7910/DVN/PCPPHI'},'acquisition_manifest_file':'acquisition_manifest.json','files':files},indent=2))
