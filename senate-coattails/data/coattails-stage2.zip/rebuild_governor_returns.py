"""Rebuild the statewide governor file from the public CC0 Algara/Amlani county returns."""
from pathlib import Path
import argparse, hashlib, urllib.request

import pandas as pd
import pyreadr

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "governor/input"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--fetch', action='store_true')
    args = parser.parse_args()
    raw = DATA / 'governor_county_returns.Rdata'
    if args.fetch:
        urllib.request.urlretrieve('https://dataverse.harvard.edu/api/access/datafile/5028535', raw)
    expected = '437bb3e821b897ec8664a181a4541f93a6caa7e70f510f89756a6828e0676a49'
    assert hashlib.sha256(raw.read_bytes()).hexdigest() == expected
    county = pyreadr.read_r(str(DATA / "governor_county_returns.Rdata"))["gov_elections_release"]
    county = county[county.election_year.ge(1950)].copy()
    vote_fields = ["democratic_raw_votes", "republican_raw_votes", "raw_county_vote_totals"]
    county["missing"] = county[vote_fields].isna().any(axis=1)
    state = (county.groupby(["state", "election_year"], as_index=False)
             .agg(dem_votes=("democratic_raw_votes", "sum"), rep_votes=("republican_raw_votes", "sum"),
                  total_votes=("raw_county_vote_totals", "sum"), counties=("fips", "size"),
                  missing_counties=("missing", "sum"), election_type=("election_type", "first"),
                  seat_status=("seat_status", "first"), dem_nominee=("dem_nominee", "first"),
                  rep_nominee=("rep_nominee", "first"))
             .rename(columns={"state": "state_abbrev", "election_year": "year"}))
    state["year"] = state.year.astype(int)
    major = state.dem_votes + state.rep_votes
    state["share"] = state.dem_votes / major
    state["major_party_fraction"] = major / state.total_votes
    state.to_csv(DATA / "governor_state_returns.csv", index=False)


if __name__ == "__main__":
    main()
