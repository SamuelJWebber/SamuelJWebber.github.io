"""Check published key estimates, held-out errors and sparse-tail counts."""
from pathlib import Path
import json
import numpy as np
import pandas as pd

P = Path(__file__).resolve().parent
H = pd.read_csv(P/'house/association_estimates.csv')
G = pd.read_csv(P/'governor/results/association_estimates.csv')
HM = pd.read_csv(P/'house/forecast_metrics.csv')
GM = pd.read_csv(P/'governor/results/forecast_metrics.csv')
checks = {
    'House full association': (H.query("period=='all_period' and predictor=='prior_candidate_advantage'").estimate_pp.iloc[0], -.013275),
    'House recent association': (H.query("period=='test_period' and predictor=='prior_candidate_advantage'").estimate_pp.iloc[0], 2.863381),
    'Governor full association': (G.query("term=='quality_10pp'").estimate_pp.iloc[0], .439727),
    'House test baseline MAE': (HM.query("stage=='test' and model=='baseline'").mae_pp.iloc[0], 4.946009),
    'House test quality MAE': (HM.query("stage=='test' and model=='continuous_prior_quality'").mae_pp.iloc[0], 5.051551),
    'Governor test baseline MAE': (GM.query("split=='test' and model=='baseline'").mae_pp.iloc[0], 5.511736),
    'Governor test quality MAE': (GM.query("split=='test' and model=='continuous'").mae_pp.iloc[0], 5.545243),
}
for label, (actual, expected) in checks.items():
    assert np.isclose(actual, expected, rtol=0, atol=2e-6), (label, actual, expected)
assert H.query("period=='all_period'").district_races.eq(3389).all()
assert H.query("period=='all_period'").state_elections.eq(499).all()
assert G.n_races.eq(285).all()
assert pd.read_csv(P/'house/strength_counts.csv').query("period=='test'").top_decile.sum()==2
assert pd.read_csv(P/'governor/results/sample_counts.csv').query("split=='test'").any_star_races.iloc[0]==0
assert pd.read_csv(P/'house/coverage_by_year.csv').query('year==2022').district_races.iloc[0]==1
assert json.loads((P/'governor/results/thresholds.json').read_text())['n']==371
print(f'Verified {len(checks)} key estimates/errors, sample counts, thresholds and sparse test tails.')
