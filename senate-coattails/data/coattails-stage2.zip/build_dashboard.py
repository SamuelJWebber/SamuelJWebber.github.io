from pathlib import Path
import pandas as pd,json,sys
P=Path(__file__).resolve().parent
H=pd.read_csv(P/'house/association_estimates.csv');G=pd.read_csv(P/'governor/results/association_estimates.csv')
HM=pd.read_csv(P/'house/forecast_metrics.csv');GM=pd.read_csv(P/'governor/results/forecast_metrics.csv')
def hr(term):
 r=H[(H.period=='all_period')&(H.predictor==term)].iloc[0]
 return dict(office='House',estimate=r.estimate_pp,low=r.low95,high=r.high95,races=int(r.district_races),state_elections=int(r.state_elections),years='1982–2022*')
def gr(term):
 r=G[G.term==term].iloc[0]
 return dict(office='Governor',estimate=r.estimate_pp,low=r.ci_low_pp,high=r.ci_high_pp,races=int(r.n_races),state_elections=int(r.n_races),years='1982–2020')
def forecast(office,m,kind,base='baseline'):
 if office=='House':
  a=m[(m.stage=='test')&(m.model==kind)].iloc[0];b=m[(m.stage=='test')&(m.model==base)].iloc[0]
  return dict(office=office,sample='595 district races / 90 state elections · 2016–2022*',baseline=b.mae_pp,augmented=a.mae_pp,low=a.mae_gain_low95,high=a.mae_gain_high95)
 a=m[(m.split=='test')&(m.model==kind)].iloc[0];b=m[(m.split=='test')&(m.model==base)].iloc[0]
 return dict(office=office,sample='32 governor races / 30 states · 2016–2020',baseline=b.mae_pp,augmented=a.mae_pp,low=a.gain_ci_low_pp,high=a.gain_ci_high_pp)
coverage='House: 3,389 districts across 499 state elections and 49 states, each state election weighted equally. Governor: 285 races in 43 states. *Only one matched House district contributes in2022 because most boundaries changed. Coefficient intervals allow correlation within states.'
d=dict(models={
 'star':dict(description='One party has a top-decile historical Senate candidate relative to its opponent. The lower decile and known-history indicators enter separately. Both-party star presence cancels in this relative comparison.',reading='The historical star estimates are imprecise and include zero. There are36 top-decile nominee appearances in the full House sample and23 in the governor sample. Recent held-out samples contain only2 House star cases and0 governor star cases, so they cannot establish a reliable modern all-star effect.',coverage=coverage,rows=[hr('high_quality_difference'),gr('star_difference')]),
 'continuous':dict(description='Each10-point increase in the Democratic-versus-Republican Senate historical-performance advantage. The outcome is the Democratic vote share in the other office. This continuous comparison is the primary statistical test.',reading='Across the full history, both estimates include zero. A separate House model refitted only on2016–2022 is positive (+2.86 points), so the relationship is sensitive to the period. The fixed historical model does not improve held-out teammate forecasts. This does not establish a stable causal spillover.',coverage=coverage,rows=[hr('prior_candidate_advantage'),gr('quality_10pp')])},forecasts=[forecast('House',HM,'continuous_prior_quality'),forecast('Governor',GM,'continuous')],forecast_note='MAE is percentage points; positive improvement means less error. House fits through2014 before its test; governor keeps its fit through2008. These are within-office comparisons, not a ranking across offices. The predictor is continuous strength. Only2 top-decile House cases and no top-decile governor cases occur in these test samples, so this is not an out-of-time validation of exceptional candidates specifically.',periods=[])
for period,label in [('all_period','1982–2022 · full sample'),('since_2000','2000–2022 · refitted'),('test_period','2016–2022 · refitted diagnostic')]:
 r=H[(H.period==period)&(H.predictor=='prior_candidate_advantage')].iloc[0]
 d['periods'].append(dict(label=label,estimate=r.estimate_pp,low=r.low95,high=r.high95,state_elections=int(r.state_elections)))
def clean(x):
 import re
 if isinstance(x,dict):return {k:clean(v) for k,v in x.items()}
 if isinstance(x,list):return [clean(v) for v in x]
 if isinstance(x,str):return re.sub(r'(?<=[A-Za-z])(?=\d)',' ',x)
 return x
out=Path(sys.argv[1]) if len(sys.argv)>1 else P/'dashboard.json';out.write_text(json.dumps(clean(d),indent=2,allow_nan=False));print(out)
