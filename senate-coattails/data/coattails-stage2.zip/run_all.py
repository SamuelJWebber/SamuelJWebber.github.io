"""Reproduce both offices, the declared sensitivity, and aggregate dashboard data."""
import argparse
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def run(*args):
    env = dict(os.environ, OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1')
    subprocess.run([sys.executable, *map(str,args)], cwd=ROOT, env=env, check=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input-dir', type=Path, default=ROOT/'_work/inputs')
    parser.add_argument('--fetch', action='store_true', help='Download and hash-verify three source files')
    args = parser.parse_args()
    inputs = args.input_dir.resolve()
    prepare = ['prepare_inputs.py', '--input-dir', inputs]
    if args.fetch:
        prepare += ['--fetch']
    run(*prepare)
    run('house/analyze_house.py', '--house-data', inputs/'house_districts.csv',
        '--senate-data', ROOT/'governor/input/senate_sample.csv', '--output-dir', ROOT/'house')
    run('governor/governor_stage2.py', '--input', ROOT/'governor/input', '--output', ROOT/'governor/results')
    run('incumbency_sensitivity.py')
    run('build_dashboard.py', ROOT/'dashboard.json')
    run('verify_results.py')
