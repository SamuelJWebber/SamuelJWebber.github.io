# Governor outcome benchmark using frozen prior Senate performance

This is an exploratory **observational** extension of the Senate candidate-quality prediction benchmark. It asks whether a quality measure selected without governor outcomes improves forecasts of the party's actual concurrent governor vote share. It is not a natural experiment or an estimate of Ossoff's personal causal effect.

## Reproduce

With Python, pandas, NumPy and SciPy installed, run:

```sh
OPENBLAS_NUM_THREADS=1 python governor_stage2.py --input input --output results
```

For the distributed package, run `python run_all.py --fetch` from the package root first. It rebuilds `input/senate_sample.csv` with the frozen stage-one constructor and derives `input/house_governor_incumbency.csv` from the separately downloaded district source. Those licensed-source derivatives are intentionally not distributed. The public `input/governor_state_returns.csv` aggregate is included. Input SHA-256 fingerprints appear in `results/summary.json`. The command above works after this preparation. All row-level audits and predictions described below are generated locally; aggregate tables are bundled.

## Frozen measure and comparison

The score uses only each nominee's **most recent earlier comparable Senate race**. In that old race, the Democratic two-party result is adjusted for the state's presidential lean and the median Senate performance in the old election year. The nominee receives that old excess performance with their own party's orientation. The current score is prior Democratic-nominee performance minus prior Republican-nominee performance. This is historical electoral performance, not a direct observation of charisma: past opponents, environments and measurement error remain in the score. No current Senate result enters the predictor.

An unobserved history is represented by a zero placeholder and a separate party-specific observed-history indicator. The D and R history indicators enter **both** the baseline and augmented models, isolating the additional value of the numerical score. The continuous score is scaled so one unit means ten percentage points of D-minus-R prior performance.

Secondary tail indicators use the complete Senate training population before any governor join: **371 observed-history nominee appearances through 2008**, retaining repeat appearances. The 90th percentile is **+19.45173590766114 points** and the 10th percentile is **−3.65778847380102 points**, using linear quantiles. A star has an observed score at least the 90th percentile; the lower tail has an observed score at most the 10th percentile. Missing histories are in neither group. `star_difference = star_D − star_R`; the lower-tail difference is defined analogously. Both tail terms enter together. The lower tail means historically low performance in this distribution, not an assessment of personal worth or a universally bad candidate.

## Sample and source audit

The initial join contains 293 concurrent Senate/governor state elections. The primary sample contains **285 regular elections in 43 states, 1982–2020**. Every race has one equal weight.

| Partition | Years | Races | States | Star races | D / R star appearances |
|---|---|---:|---:|---:|---:|
| Training | 1982–2008 | 203 | 43 | 20 | 11 / 9 |
| Development | 2010–2014 | 50 | 41 | 3 | 0 / 3 |
| Test | 2016–2020 | 32 | 30 | 0 | 0 / 0 |
| All | 1982–2020 | 285 | 43 | 23 | 11 / 12 |

There are 26 lower-tail races overall (13 D and 13 R appearances), including four test races. No race contains two star nominees. **The held-out governor test has no stars under the frozen cutoff**, so it cannot directly validate star-specific governor predictions. Continuous-score prediction still has variation and is the primary benchmark.

All 999 governor source records, covering 49 states, receive explicit predecessor and gap fields in `all_governor_lag_audit.csv`; Alaska is absent from this source. The script chooses the immediately preceding **regular state election**, including biennial terms, not a universal four-year lag. It never silently substitutes an older usable race when the immediately preceding regular race is invalid. In the final sample, 255 predecessor gaps are four years and 30 are two years. The observed-year gap for Arizona 1994 is three years because the previous regular contest finished in 1991; its regular-election cycle gap is four years.

- Oregon 2016 filled the unexpired final two years of the governor's term. Its generic source label `G` does not make it a regular election. It is excluded both as a target and as a regular-election predecessor; Oregon 2018 therefore points back to 2014. The Oregon Secretary of State explicitly documents the two-year completion term: <https://apps.oregon.gov/oregon-newsroom/OR/SOS/Posts/Post/constitutional-eight-year-term-limit-for-governor-42500>.
- Arizona's source row labeled 1991 is the runoff completing the 1990 regular contest. It can be the known prior return for 1994; it is not joined to the November 1990 Senate election as a concurrent outcome. The Arizona Secretary of State documents that the 1990 runoff became final in March 1991: <https://azsos.gov/about-secretary/rose-mofford>.
- California's 2003 recall and the Utah 2010 and West Virginia 2011 special contests are absent from this governor-return file. The last regular predecessors, rather than these specials, are appropriate for the stated baseline.
- Seven joined Hawaii races have county-completeness flags on current or previous returns: 1982, 1986, 1994, 1998, 2006, 2010 and 2018. They are excluded by a uniform conservative completeness rule. A flag is **not proof that statewide votes are incomplete**: the 2018 totals exactly match Hawaii's certified statewide report (244,934 D; 131,719 R). Full historical reconciliation was not completed. <https://files.hawaii.gov/elections/files/results/2018/general/histatewide.pdf>.
- Nebraska 2014 is incorrectly coded `incumbency_G = −1` in the district metadata. It is corrected to zero: Pete Ricketts first took office on January 8, 2015. <https://www.nga.org/governor/pete-ricketts/>.
- Minnesota 1982 is incorrectly coded `incumbency_G = +1`. It is corrected to zero: Rudy Perpich was a former governor returning to office; Al Quie held office until January 1983. <https://www.lrl.mn.gov/mngov/gov>.
- Florida 1998 remains open (`incumbency_G = 0`) despite the governor file's conflicting incumbent description. Buddy MacKay took office on December 12, after the November election. <https://dos.fl.gov/florida-facts/florida-history/florida-governors/kenneth-hood-mackay-jr/>.
- Minnesota 1998 has zero Democratic votes in this source although Humphrey ran. This is flagged as an invalid two-party return. It is neither a current nor a previous return in the final matched sample, so it does not affect these estimates. No zero-party current or previous return is accepted.
- The historical transitions to longer governor terms are respected: Arkansas changed to four-year terms beginning with 1986, and Rhode Island beginning with 1994. Relevant official sources: <https://www.sos.arkansas.gov/uploads/education/Governors_booklet_1-2025.pdf> and <https://rilegislature.gov/riconstitution/Constitution/C04.aspx>.

The audit flags and corrections are explicit and reproducible, but this is not an exhaustive re-canvass of every historical vote or every candidate biography.

## Forecast specifications and results

The outcome is actual Democratic governor votes divided by Democratic plus Republican governor votes, **not** a residual using the current presidential result. Both models are unweighted OLS fitted only through 2008, with an intercept and:

1. Previous regular governor Democratic two-party share.
2. State Democratic presidential lean relative to the national two-party share, from the strictly previous presidential election.
3. Current governor nominee incumbency (D +1, R −1, neither 0), with the audited corrections above.
4. The president's party (D +1, R −1) and its interaction with the midterm indicator, both known before voting.
5. Separate indicators for observed D and R Senate histories.

The primary augmented model adds only the continuous prior Senate score. The secondary model instead adds the two fixed tail differences. There are no current-year indicators, current presidential returns, current Senate returns, current turnout, spending, or post-election quality measures. Predictions are not clipped. Development results are displayed but did not select or tune the governor specification. Coefficients are not refitted after 2008 for the test comparison.

| Comparison | Baseline MAE | Continuous-score MAE | MAE improvement | 95% interval |
|---|---:|---:|---:|---:|
| Development, 50 races | 5.899 | 5.925 | −0.026 | −0.067 to +0.021 |
| Test, 32 races | 5.512 | 5.545 | −0.034 | −0.074 to +0.008 |

All units are governor vote-share percentage points. Positive improvement means lower error after adding quality. The intervals resample test/development **states** with replacement 10,000 times, keeping all races of each sampled state together; they condition on the fitted training models. They do not incorporate training-model uncertainty, distribution shifts, or uncertainty about the measurement itself. Only three election cycles are in each evaluation period, so these intervals should not imply certainty about future national cycles. This is a chronological holdout, not a holdout of entirely unseen states.

The continuous score does not improve the governor forecast in this test. That is a predictive result and cannot establish absence of a causal coattail effect.

## Conditional association

Separate retrospective regressions use all 285 races and add state and election-year fixed effects, controlling for previous regular governor share, strictly previous presidential lean, governor incumbency and the two history indicators. Year effects replace the White House variables, which are constant within year. The continuous and tail models are separate prespecified specifications.

| Term | Governor-share association | 95% state-cluster interval |
|---|---:|---:|
| Ten points of D-minus-R prior Senate performance | +0.440 | −1.253 to +2.133 |
| D star versus R star difference | −3.436 | −9.336 to +2.464 |
| D lower-tail versus R lower-tail difference | −0.988 | −4.974 to +2.998 |

The star and lower-tail terms are estimated jointly. A one-unit star-difference change represents adding a D star or removing an R star, holding the rest of the specification fixed; moving from an R star to a D star is a two-unit change. It imposes party-reversal symmetry. All figures are vote-share points. Intervals use a state-clustered sandwich covariance with the correction G/(G−1) × (N−1)/(N−rank) and t critical values with G−1 degrees of freedom. All design matrices are full rank. These are individual, unadjusted intervals, not multiplicity-adjusted evidence across a broad search.

Controlling prior governor results absorbs persistent party strength and potentially earlier coattails from the same senator. These models therefore describe **incremental current association**, not all lasting effects of electing the senator. State/year effects do not remove candidate recruitment, opponent quality, local trends or common campaign shocks. The score itself contains such factors and selects nominees with observed histories. The wide star interval supports no confident conclusion about the sign of the star association.

Two-party share can move through turnout and persuasion. This model neither separates those channels nor measures total extra voters, all-party votes, turnout effects, or effects on independent candidates. It cannot furnish a credible candidate-specific causal number for Ossoff or anyone else.

## Underlying data provenance

The Senate sample comes from the accompanying prediction benchmark's audited MIT Senate/presidential return processing. The governor aggregate was prepared from Algara and Amlani's county-level gubernatorial returns, Harvard Dataverse, DOI <https://doi.org/10.7910/DVN/DGUMFI>, file 5028535 (`dataverse_shareable_gubernatorial_county_returns_1865_2020.Rdata`), retaining the study's 1950–2020 extract. Governor incumbency comes from the district data in DeLuca, Moskowitz and Schneer's replication archive, DOI <https://doi.org/10.7910/DVN/J6C26T>. These source datasets are reused for a new benchmark, not a reproduction of their authors' reported models.

`forecast_predictions.csv` contains every evaluation prediction; `forecast_metrics.csv` contains matched-row errors; `association_estimates.csv` contains the three central observational estimates; `star_races.csv` lists every included star race. Full coefficients, sample rows, all-state lag audit, exclusions and thresholds are also included.
