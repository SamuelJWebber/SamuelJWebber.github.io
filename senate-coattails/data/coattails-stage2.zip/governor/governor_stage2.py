#!/usr/bin/env python3
"""Frozen Senate-history predictor, independent governor outcome benchmark.

Run: python governor_stage2.py --input input --output results
Inputs and outputs are portable. House input may be the full district CSV or
its state-year collapse, provided all districts agree on incumbency_G.
"""
from pathlib import Path
import argparse, hashlib, json
import numpy as np
import pandas as pd
from scipy.stats import t

FLAGS = ['prior_D_observed', 'prior_R_observed']
BASE = ['prior_gov_share', 'prior_pres_lean', 'gov_incumbency',
        'white_house_party', 'midterm_white_house'] + FLAGS
QUALITY = 'quality_10pp'
TAILS = ['star_difference', 'low_difference']


def matrix(d, cols, fe=False):
    x = pd.DataFrame({'intercept': np.ones(len(d))}, index=d.index)
    x = pd.concat([x, d[cols].astype(float)], axis=1)
    if fe:
        for col in ['state_abbrev', 'year']:
            x = pd.concat([x, pd.get_dummies(d[col].astype(str), prefix=col,
                                           drop_first=True, dtype=float)], axis=1)
    return x


def ols(d, cols, fe=False):
    x = matrix(d, cols, fe)
    a = x.to_numpy(); y = d.gov_share.to_numpy()
    b = np.linalg.lstsq(a, y, rcond=None)[0]
    r = y-a@b; rank = np.linalg.matrix_rank(a)
    groups = d.state_abbrev.to_numpy(); unique = np.unique(groups)
    meat = np.zeros((a.shape[1], a.shape[1]))
    for g in unique:
        z = a[groups == g].T@r[groups == g]
        meat += np.outer(z, z)
    bread = np.linalg.pinv(a.T@a)
    cov = bread@meat@bread * len(unique)/(len(unique)-1) * (len(d)-1)/(len(d)-rank)
    se = np.sqrt(np.maximum(np.diag(cov), 0)); critical = t.ppf(.975, len(unique)-1)
    tab = pd.DataFrame({'term':x.columns, 'estimate_pp':b*100, 'se_pp':se*100,
                        'ci_low_pp':(b-critical*se)*100, 'ci_high_pp':(b+critical*se)*100})
    tab['n_races'] = len(d); tab['n_states'] = len(unique); tab['rank'] = rank
    assert rank == a.shape[1], f'Rank deficiency: {rank}/{a.shape[1]}'
    return b, tab


def pair_bootstrap(d, base, aug, draws=10000):
    # Conditional on the already fitted training models; resample test states.
    delta = (abs(d.gov_share.to_numpy()-base)-abs(d.gov_share.to_numpy()-aug))*100
    parts = [delta[d.state_abbrev.to_numpy()==g] for g in sorted(d.state_abbrev.unique())]
    sums=np.array([p.sum() for p in parts]); counts=np.array([len(p) for p in parts])
    rng=np.random.default_rng(190707); ids=rng.integers(0,len(parts),(draws,len(parts)))
    boot=sums[ids].sum(axis=1)/counts[ids].sum(axis=1)
    return float(delta.mean()), *map(float, np.quantile(boot,[.025,.975]))


def build(inp, out):
    s=pd.read_csv(inp/'senate_sample.csv')
    g=pd.read_csv(inp/'governor_state_returns.csv').sort_values(['state_abbrev','year'])
    inc=pd.read_csv(inp/'house_governor_incumbency.csv')
    assert inc.groupby(['state_abbrev','year']).incumbency_G.nunique().max()<=1
    inc=inc.groupby(['state_abbrev','year'],as_index=False).incumbency_G.first()
    assert not g.duplicated(['state_abbrev','year']).any()
    assert not s.duplicated(['state_abbrev','year']).any()

    # Threshold population is frozen BEFORE the governor join and uses only
    # observed nominee histories in all Senate training races. Repeats count.
    train=s[s.year<=2008]
    q=pd.concat([train.loc[train.prior_D_observed==1,'prior_D_advantage'],
                 train.loc[train.prior_R_observed==1,'prior_R_advantage']])
    p10,p90=q.quantile([.1,.9]).to_numpy()
    threshold={'population':'Observed-history nominee appearances in all Senate training rows through 2008; repeats retained',
               'n':len(q),'p10':p10,'p90':p90,'quantile_method':'pandas linear',
               'missing_history':'zero placeholder plus separate D/R observed flags; never classified as a star or low-tail nominee'}
    (out/'thresholds.json').write_text(json.dumps(threshold,indent=2)+'\n')
    for party in ['D','R']:
        obs=s[f'prior_{party}_observed'].eq(1)
        s[f'star_{party}']=(obs & s[f'prior_{party}_advantage'].ge(p90)).astype(int)
        s[f'low_{party}']=(obs & s[f'prior_{party}_advantage'].le(p10)).astype(int)
        assert (s.loc[obs,f'prior_{party}_year']<s.loc[obs,'year']).all()
    s[QUALITY]=(s.prior_D_advantage-s.prior_R_advantage)/.1
    s['star_difference']=s.star_D-s.star_R
    s['low_difference']=s.low_D-s.low_R
    assert (s.pres_previous_year<s.year).all()

    # G means general election in the source, not necessarily regular cycle.
    g['is_special']=(g.state_abbrev.eq('OR') & g.year.eq(2016))
    g['cycle_year']=g.year
    g.loc[g.state_abbrev.eq('AZ') & g.year.eq(1991),'cycle_year']=1990
    g['audit_note']=''
    g.loc[g.is_special,'audit_note']='Oregon 2016 filled an unexpired two-year term; exclude as regular target/lag.'
    g.loc[g.state_abbrev.eq('AZ') & g.year.eq(1991),'audit_note']='1990 regular election completed by February 1991 runoff; available as a prior return in 1994, not a concurrent 1990 outcome.'
    # Prior return is the immediately preceding REGULAR election. Never skip
    # an unusable regular outcome in favor of a more distant usable result.
    lag_fields=['year','cycle_year','share','dem_votes','rep_votes','missing_counties']
    rows=[]
    for state, part in g.groupby('state_abbrev',sort=True):
        prev=None
        for _,r in part.sort_values('year').iterrows():
            d=r.to_dict()
            for f in lag_fields: d['prior_gov_'+f]=(prev[f] if prev is not None else np.nan)
            rows.append(d)
            if not r.is_special: prev=r
    g=pd.DataFrame(rows)
    g['previous_regular_gap']=g.cycle_year-g.prior_gov_cycle_year
    g['previous_observation_gap']=g.year-g.prior_gov_year
    g['current_two_party_valid']=g.dem_votes.gt(0)&g.rep_votes.gt(0)
    g['prior_two_party_valid']=g.prior_gov_dem_votes.gt(0)&g.prior_gov_rep_votes.gt(0)
    g['counties_flagged']=g.missing_counties.gt(0)|g.prior_gov_missing_counties.gt(0)
    g.to_csv(out/'all_governor_lag_audit.csv',index=False)
    # Merge gov columns explicitly to avoid confusing Senate and gov shares.
    g=g.rename(columns={'share':'gov_share'})
    d=s.merge(g,on=['state_abbrev','year'],how='inner',validate='one_to_one')
    d=d.merge(inc,on=['state_abbrev','year'],how='left',validate='one_to_one')
    d['gov_incumbency']=d.incumbency_G
    # Pre-election status corrections backed by official historical rosters.
    d.loc[d.state_abbrev.eq('NE') & d.year.eq(2014),'gov_incumbency']=0
    d.loc[d.state_abbrev.eq('MN') & d.year.eq(1982),'gov_incumbency']=0
    # Florida 1998 is correctly open in district metadata: MacKay only took
    # office in December, after losing November's election.
    d['stage2_split']=np.select([d.year.le(2008),d.year.between(2010,2014),d.year.between(2016,2020)],
                               ['train','development','test'],default='outside')
    d['exclusion_reason']=''
    for mask,reason in [
        (d.is_special,'special governor election'),
        (~d.current_two_party_valid,'no valid current two-party return'),
        (~d.prior_two_party_valid,'no valid previous regular two-party return'),
        (d.counties_flagged,'current or previous return has county-completeness flag'),
        (~d.previous_regular_gap.isin([2,4]),'unresolved regular-election gap'),
        (d[BASE+[QUALITY,'gov_share']].isna().any(axis=1),'missing required variable'),
        (d.stage2_split.eq('outside'),'outside fixed benchmark years')]:
        d.loc[mask,'exclusion_reason']+=reason+'; '
    d['included_primary']=d.exclusion_reason.eq('')
    d.to_csv(out/'joined_race_audit.csv',index=False)
    d.loc[d.included_primary].to_csv(out/'governor_sample.csv',index=False)
    absent=s.merge(g[['state_abbrev','year']],on=['state_abbrev','year'],how='left',indicator=True)
    absent=absent[absent._merge.eq('left_only')][['state_abbrev','year']]
    absent['reason']='No same-year governor return in source (usually no concurrent governor election; source lacks Alaska entirely).'
    absent.loc[absent.state_abbrev.eq('AZ')&absent.year.eq(1990),'reason']='Source stores final governor runoff in 1991, not November 1990 first round.'
    absent.to_csv(out/'senate_rows_without_governor_return.csv',index=False)
    return d[d.included_primary].copy(), d


def forecast(d,out):
    tr=d[d.stage2_split.eq('train')]
    models={'baseline':BASE,'continuous':BASE+[QUALITY], 'tails_secondary':BASE+TAILS}
    coeffs=[]; predictions=[]; metrics=[]
    fitted={}
    for name,cols in models.items():
        b,tab=ols(tr,cols);tab['model']=name;coeffs.append(tab);fitted[name]=(b,cols)
    for split in ['development','test']:
        a=d[d.stage2_split.eq(split)].copy();preds={}
        for name,(b,cols) in fitted.items():
            preds[name]=matrix(a,cols).to_numpy()@b
            err=preds[name]-a.gov_share.to_numpy()
            gain,lo,hi=pair_bootstrap(a,preds['baseline'],preds[name])
            metrics.append({'split':split,'model':name,'n_races':len(a),'n_states':a.state_abbrev.nunique(),
                            'training_n':len(tr),'training_end_year':2008,'mae_pp':abs(err).mean()*100,
                            'rmse_pp':np.sqrt((err**2).mean())*100,'mae_gain_pp':gain,
                            'gain_ci_low_pp':lo,'gain_ci_high_pp':hi})
            for (_,r),pr in zip(a.iterrows(),preds[name]):
                predictions.append({'state_abbrev':r.state_abbrev,'year':r.year,'split':split,'model':name,
                                    'actual_D_gov_share':r.gov_share,'predicted_D_gov_share':pr,
                                    'absolute_error_pp':abs(pr-r.gov_share)*100})
    pd.concat(coeffs,ignore_index=True).to_csv(out/'forecast_coefficients.csv',index=False)
    pd.DataFrame(metrics).to_csv(out/'forecast_metrics.csv',index=False)
    pd.DataFrame(predictions).to_csv(out/'forecast_predictions.csv',index=False)
    return metrics


def association(d, out):
    # Year FE replace the perfectly collinear White House/midterm controls.
    controls=['prior_gov_share','prior_pres_lean','gov_incumbency']+FLAGS
    tabs=[]
    for name,extra in [('continuous', [QUALITY]), ('tails_secondary', TAILS)]:
        _,tab=ols(d,controls+extra,fe=True);tab['model']=name
        tab['state_fixed_effects']=True;tab['year_fixed_effects']=True
        tabs.append(tab)
    a=pd.concat(tabs,ignore_index=True);a.to_csv(out/'association_coefficients.csv',index=False)
    key=a[a.term.isin([QUALITY]+TAILS)];key.to_csv(out/'association_estimates.csv',index=False)
    return key.to_dict(orient='records')


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--input',type=Path,default=Path(__file__).parent/'input')
    ap.add_argument('--output',type=Path,default=Path(__file__).parent/'results');args=ap.parse_args()
    args.output.mkdir(parents=True,exist_ok=True)
    d, joined=build(args.input,args.output)
    counts=[]
    for split,a in [('all',d)]+[(k,x) for k,x in d.groupby('stage2_split')]:
        counts.append({'split':split,'n_races':len(a),'n_states':a.state_abbrev.nunique(),
                       'first_year':int(a.year.min()),'last_year':int(a.year.max()),
                       'D_star_appearances':int(a.star_D.sum()),'R_star_appearances':int(a.star_R.sum()),
                       'any_star_races':int((a.star_D+a.star_R).gt(0).sum()),
                       'both_star_races':int((a.star_D+a.star_R).eq(2).sum()),
                       'D_low_appearances':int(a.low_D.sum()),'R_low_appearances':int(a.low_R.sum()),
                       'any_low_races':int((a.low_D+a.low_R).gt(0).sum()),
                       'D_observed':int(a.prior_D_observed.sum()),'R_observed':int(a.prior_R_observed.sum())})
    pd.DataFrame(counts).to_csv(args.output/'sample_counts.csv',index=False)
    d[d.star_D.eq(1)|d.star_R.eq(1)][['state_abbrev','year','stage2_split','candidate_DEMOCRAT',
      'candidate_REPUBLICAN','star_D','star_R','prior_D_advantage','prior_R_advantage']].to_csv(args.output/'star_races.csv',index=False)
    metrics=forecast(d,args.output);assoc=association(d,args.output)
    files={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(args.input.glob('*.csv'))}
    summary={'inputs_sha256':files,'joined_races':len(joined),'included_races':len(d),'counts':counts,
             'forecast':metrics,'association':assoc,
             'interpretation':'Exploratory observational benchmark. Forecasts use only pre-election variables; fixed-effects associations are not causal.'}
    (args.output/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps({'counts':counts,'forecast':metrics,'association':assoc},indent=2))


if __name__=='__main__': main()
