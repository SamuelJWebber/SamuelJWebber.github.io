# Frozen Senate strength and same-ballot House/governor results

**These are conditional associations and historical prediction checks, not causal coattail estimates.** State and year controls do not remove changing state-party shocks or candidate selection. Earlier Senate performance can contain old coattails, opponent weakness and local conditions. Adjusting for the previous House/governor vote measures an incremental current association beyond established support, potentially absorbing lasting contributions of the senator.

The full-period House association is near zero, but the recent-period refit is positive. Both belong in the interpretation. Neither office's fixed historical model improves the held-out forecast when continuous Senate strength is added.

| Outcome and model | Estimate per 10 points of prior Senate advantage | 95% interval |
|---|---:|---:|
| House, full 1982–2022 sample | −0.013 pp | −0.524 to +0.497 |
| House, refitted on 2016–2022 | +2.863 pp | +1.365 to +4.362 |
| Governor, full 1982–2020 sample | +0.440 pp | −1.253 to +2.133 |

| Held-out forecast | Baseline MAE | With continuous strength | Model-fitting cutoff |
|---|---:|---:|---|
| House, 2016–2022 | 4.946 pp | 5.052 pp | Refit through 2014 |
| Governor, 2016–2020 | 5.512 pp | 5.545 pp | Kept at 2008 |

The recent House coefficient is a **refitted association**, not the held-out forecast. The House sample has 3,389 district races / 499 state elections / 49 states; its test contains 595 districts / 90 state elections. Only one district contributes in 2022 because comparable boundaries are required. The governor sample has 285 races / 43 states; its test contains 32 races / 30 states. Office-specific forecast protocols differ, so compare baseline versus augmented models within each office.

The frozen top decile uses 371 observed candidate-history appearances in Senate training years through 2008, before either outcome merge. Its cutoff is +19.4517 points; the bottom-decile cutoff is −3.6578. Repeated nominees contribute repeated appearances. Missing histories are separate from observed middle and tail values. **Only two top-decile House candidate appearances and zero governor star appearances occur in the test periods.** The continuous check cannot establish a reliable modern all-star effect.

## Reproduce

From this directory, with Python 3.10 or newer:

```sh
python -m pip install -r requirements.txt
OPENBLAS_NUM_THREADS=1 python run_all.py --fetch
```

This downloads and SHA-256 verifies the MIT Senate/presidential returns and the authors' district source, reconstructs the exact frozen Senate sample, creates both outcome inputs, runs both main analyses, runs the Senate-incumbency sensitivity, rebuilds `dashboard.json`, and verifies the key numerical results. Internet access to Harvard Dataverse is needed for the first command with `--fetch`.

If the three inputs already exist locally:

```sh
OPENBLAS_NUM_THREADS=1 python run_all.py --input-dir /path/to/source-inputs
```

That directory must contain `mit_senate.tsv`, `mit_president.csv`, and `house_districts.csv`. Source URLs and exact hashes are in [sources.json](sources.json). The included [stage-one constructor](stage1/benchmark.py) is the frozen code used to form histories; this package calls its preparation function without rerunning the larger proxy competition.

The public statewide governor-return aggregate is included. Its optional raw county aggregation can be reproduced with:

```sh
python rebuild_governor_returns.py --fetch
```

This optional step requires `pyreadr` and downloads the public CC0 county data. The main `run_all.py` command uses the included state aggregate.

## Contents and provenance

* [Design and estimands](DESIGN.md), [final analytical audit](FINAL_AUDIT.md), and [Senate-incumbency sensitivity](incumbency_sensitivity.py).
* [House methods](house/README.md), [association estimates](house/association_estimates.csv), [forecast metrics](house/forecast_metrics.csv), [year coverage](house/coverage_by_year.csv), and [tail counts](house/strength_counts.csv).
* [Governor methods and source corrections](governor/README.md), [association estimates](governor/results/association_estimates.csv), [forecast metrics](governor/results/forecast_metrics.csv), and [sample counts](governor/results/sample_counts.csv).
* [Source manifest](sources.json), [numeric verification](verify_results.py), [machine-readable aggregate display data](dashboard.json), and package checksums in `SHA256.json`.

The package distributes code and aggregate estimates. It excludes the DeLuca–Moskowitz–Schneer district source, district samples/predictions, the licensed-source incumbency collapse, and merged Senate/governor rows. The scripts reconstruct these working files locally. The `.gitignore` file lists them; users should respect the source's terms before sharing generated row-level derivatives. No donor records, private account data, credentials, or personal communications are included.

The primary sources are MIT Election Data and Science Lab Senate and presidential returns; DeLuca, Moskowitz and Schneer's [replication archive](https://doi.org/10.7910/DVN/J6C26T); and Algara and Amlani's [county governor returns](https://doi.org/10.7910/DVN/DGUMFI). MIT and Algara/Amlani data are CC0. The district archive carries restricted reuse terms; public download availability is not a redistribution license. The newly generated modeling code and aggregate results do not change any upstream rights.

Association intervals cluster by state. Forecast intervals resample states conditional on fitted predictions. Neither addresses all model-selection uncertainty, changing political conditions, or the sparse star tails. Two-party vote share does not identify additional total voters or separate turnout from persuasion. The design was written after earlier historical exploration; it is not a preregistered natural experiment.

Study author: Samuel Webber. See `VERIFICATION.json` for the package reproduction checks.
