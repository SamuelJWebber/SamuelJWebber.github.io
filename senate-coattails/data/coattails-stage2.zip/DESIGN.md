# Stage 2: frozen candidate strength and other candidates' results

Date: 2026-11-05. This document fixes a proposed historical analysis before a new round of coattail estimates. The historical outcomes have already been inspected in earlier analyses, so this is not a preregistered or genuinely untouched prospective test.

## Question and scope

The ultimate question is how much nominating a stronger Senate candidate changes the votes received by other candidates of that party on the same ballot, through turnout, persuasion, fundraising, recruitment, and organization. Own-Senate-vote prediction is only the first measurement check. A proxy must be selected and constructed without using House or governor results, and must not be replaced because another proxy gives larger coattails.

The current records support an improved observational association. They do not supply random or plausibly random nomination of a star, and cannot by themselves identify the causal effect of an Ossoff or Obama nomination.

## Freeze the score before merging other offices

Use the final prior-performance construction in `stage1/benchmark.py`, whose relative D-minus-R historical score predicted later own-Senate results in temporal holdouts. Each nominee receives the latest observed earlier regular Senate performance relative to that earlier state's presidential lean and that earlier national Senate cycle. Reverse the sign for Republicans. All inputs precede the election being studied.

This is demonstrated historical electoral appeal, not a pure personal talent estimate. It contains the previous opponent's weakness and state-specific political circumstances. Validation of a race-level D-minus-R differential does not separately establish intrinsic talent for each nominee.

Freeze the candidate keys, feature construction, treatment of missing histories, training years, threshold population, primary coefficient, outcomes, and sample rules in a manifest. Save the score table and manifest before merging House or governor outcomes. Do not recompute thresholds after an outcome-data merge, by party, by test year, or after seeing effect sizes.

- **Primary:** a continuous score, reported per 10 percentage points of earlier performance. For a D-share outcome, the broad benchmark's exposure is `prior_D_advantage - prior_R_advantage`, with separate D/R history-availability indicators. This imposes equal and opposite effects of the two parties' scores; a separately prespecified two-coefficient model can check that assumption. Zero-filled unknown scores are a modeling convention, not a classification of candidate weakness. Report support separately for one known history and two known histories.
- **Secondary:** individual top-decile and bottom-decile labels, using only observed nominee-history appearances in training years 1982–2008. In the current final file there are 371 such appearances; the 90th percentile is +19.4517359 points and the 10th percentile is −3.6577885 points. These are candidate-election appearances, so a repeat nominee can contribute more than once. Fix that population explicitly. A unique-person threshold would be a different, separately specified measure.
- **Unknown:** nominees with no comparable historical result remain unknown. They are never assigned to the low-quality or middle-quality category merely because their numeric feature is zero. Special-election veterans may lack a comparable regular-election record.
- **Asymmetry:** the lower decile of this selected population is not a mirror image of the upper decile. Calling it an 'awful candidate' category would overstate what the measure establishes. Use 'lower observed historical performance.'
- **Legacy result:** the returning-incumbent study's +15-point threshold is a different, already explored definition. Retain it only as a labeled legacy sensitivity; do not describe it as the new training top decile.

For individual-star secondary analyses, code D-star and R-star indicators separately (or use their signed difference with that constraint stated), and adjust for the opponent's observed score and history status. Compare with observed non-star histories, not a pooled group that silently treats unknown candidates as ordinary. Two stars can coexist; a signed difference then measures relative advantage, not the absence of two individually strong nominees. An individual-party model with co-party outcomes can describe that case, but D/R observations of the same election are not independent.

## Outcomes and denominator

Two-party House/governor vote share is currently feasible, but it does not measure all turnout contributions. A star could increase both parties' votes while leaving the share unchanged. Do not claim a total vote effect from share alone.

The eventual primary total-effect outcomes should include (a) the party's other-candidate votes per pre-election voting-eligible population and (b) D-minus-R votes per that same fixed denominator. Report turnout and two-party share alongside them. A fixed pre-election denominator prevents turnout itself from being used to normalize away mobilization. Census voting-age population is an acceptable separately labeled fallback when district-level eligible population is unavailable; registered voters are a different population. Aggregate vote totals alone cannot separate persuasion from mobilization.

Current governor returns contain D/R votes and total votes, but no eligible-population denominator. House source vote totals also require boundary-compatible population data. The full total-vote estimand therefore requires additional denominator acquisition; it is not completed by the existing share regressions.

## Feasible historical models

House primary specification: current D two-party share on frozen relative Senate score, previous comparable House share, strictly preceding presidential partisan lean, pre-election House incumbency, Senate incumbency, history indicators, state effects, and election-year effects. Use a flexible but fixed representation of previous share/lean, such as a prespecified quadratic, with the linear form as a declared sensitivity. Freeze transformations before seeing stage-2 effects. State-by-year effects cannot be used because Senate exposure varies at state-year level and would be absorbed.

Use the same-boundary/redistricting-era identifier when joining the previous House election. District number alone is not a valid geographic match across redistricting. Compare baseline and lag-adjusted specifications on exactly the same eligible rows so that a coefficient change is not caused by a different sample. A boundary-harmonized statewide House vote aggregate is an alternative, but seat contestation must be addressed because uncontested districts change observed party totals.

Governor specification: current D share on the same frozen score, the most recent earlier gubernatorial D share, strictly preceding presidential lean, pre-election gubernatorial and Senate incumbency, history indicators, state effects, and year effects. Join the previous governor election from the full state returns, not a fixed four-year lag: terms and timing differ across states. Record how many years have elapsed. Validate actual same-ballot timing and runoff rounds rather than equating calendar years.

The lagged outcome addresses persistent local party strength. It does not remove new state-specific swings, candidate selection in response to political opportunities, or contemporaneous quality/mobilization shared across offices. Year effects remove common national shifts, not state-specific election-year changes. Strictly preceding presidential results are preferable to concurrent presidential results, which can themselves receive spillovers from the star candidate.

Lag adjustment changes the interpretation to the incremental current-election association beyond the party's established performance. Earlier House/governor support can already contain lasting organizational benefits created by the senator. Consequently, the lag-adjusted result cannot be presented as the senator's entire accumulated political contribution.

House/governor candidate quality controls require a clear estimand. If a strong Senate nominee improves recruitment, donations, or campaigning by teammates, their current quality and resources are part of the total pathway. Do not automatically control for those post-nomination measures. A model holding current teammate quality fixed estimates a narrower direct association and belongs in a separately labeled sensitivity. The same applies to current turnout, spending, and party mobilization.

## Historical working inputs and corrections

The temporary paths in this design document record the original development environment; they are not package dependencies. The portable preparation and commands in README.md replace them.

- `governor/input/senate_sample.csv (generated locally)`: 689 Senate elections, with the final prior-score fields and fixed splits. Start the new merged data from this table rather than the older returning-winner sample when claiming coverage of nominees generally.
- `/tmp/coattails_identification/data/prior_house_sample.csv`: 3,175 district observations; the `past` field was constructed but not used in the original main regression. The old score builder also selected on current major-party vote fraction and current share. Do not inherit those outcome-dependent thresholds into the new nominally pre-election design.
- `/tmp/coattails_identification/data/house_history_matched.csv`: 2,151 observations with valid same-boundary lag matching. This is useful as a verified join template, but remains a selected returning-incumbent sample and must not be advertised as all Senate nominees.
- `/tmp/coattails_identification/data/prior_governor_sample.csv`: 196 observations and no previous gubernatorial result. A lag must be added from `/tmp/coattails_identification/data/governor_state_returns.csv` (999 state-years), with timing checks and known missing-count coverage. Its current sample also inherited outcome-share thresholds.

Construct eligibility from known ballot structure, comparable geography/timing, and data availability. Describe restrictions such as two major-party nominees explicitly. Avoid exclusions based on a candidate's eventual winning margin, current two-party share, or the desired sign of the effect. Known missing counties and documented extraction errors can justify data-quality exclusions with a coverage table.

## Uncertainty and diagnostics

The Senate election is the exposure unit; thousands of House districts are not thousands of independent star assignments. Use state-clustered uncertainty, show the number of states and independent Senate elections, and prespecify whether each state-election or each district receives equal weight. Equal state-election weighting answers an average exposed-election question; population weighting answers a voter-weighted question. Both can be reported if their roles are frozen in advance.

Keep the continuous primary test distinct from top/bottom descriptive contrasts. Show tail counts by cycle and party; extreme tails may be too sparse for precise estimates. Do not choose cutoffs to produce significant coefficients. Report House and governor separately and disclose the multiple secondary contrasts.

Report prior-outcome/placebo associations and changes from the previous election. A large association with already-realized other-office support is evidence that the score partly captures persistent party strength. Because a veteran candidate may already affect that support, a nonzero placebo is not uniquely diagnostic of bias, and a zero placebo does not prove random assignment. These are sensitivity checks, not a natural experiment.

## Causal next step

A stronger design needs a source of plausibly random candidate assignment. One option is close primaries between independently scored candidates: freeze quality before the primary, then compare cases where the higher-scoring nominee barely wins versus barely loses. Outcomes are the other party nominees' same-ballot votes, margins, and turnout. Check primary-margin sorting, baseline balance, geographic/timing comparability, and prespecify bandwidths. This identifies the local total effect of nominating the higher-scoring candidate's whole package, including money and organization; it does not isolate charisma.

The present files do not contain the required primary contests, pre-primary scores for all competing candidates, or assignment checks. Senate election schedules alone are not random assignment of exceptional nominees. An on-ballot versus off-ballot analysis of a sitting star could be useful, but would need its own career roster, timing assumptions, and controls for the other Senate seat. The existing observational regressions should not be relabeled as that experiment.
