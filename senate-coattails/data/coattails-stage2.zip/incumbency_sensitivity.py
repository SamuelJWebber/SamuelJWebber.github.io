"""Audit sensitivity: add pre-election Senate incumbency without changing quality.

Run from the stage2 root after the House and governor main analyses. All primary
samples, quality scores, transformations and outcome periods remain fixed.
"""
from pathlib import Path
import importlib.util
import pandas as pd

ROOT = Path(__file__).resolve().parent


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    h = load_module('house_stage2', ROOT / 'house/analyze_house.py')
    house = pd.read_csv(ROOT / 'house/sample.csv')
    senate = pd.read_csv(ROOT / 'governor/input/senate_sample.csv')
    house = house.merge(senate[['state_abbrev', 'year', 'incumbency']].rename(
        columns={'incumbency': 'senate_incumbency'}), on=['state_abbrev', 'year'],
        validate='many_to_one')
    h.BASELINE = h.BASELINE + ['senate_incumbency']
    h.MODELS = {'baseline': h.BASELINE, 'continuous_prior_quality': h.BASELINE + h.QUALITY,
                'training_defined_tails': h.BASELINE + h.STARS}
    records = []
    for label, frame in [('all_period', house), ('since_2000', house[house.year.ge(2000)]),
                         ('test_period', house[house.split.eq('test')])]:
        for terms in [h.QUALITY, h.STARS]:
            records.extend({'period': label, **row} for row in h.association(frame, terms))
    pd.DataFrame(records).to_csv(ROOT / 'house/senate_incumbency_sensitivity_associations.csv', index=False)
    _, metrics = h.forecasts(house)
    metrics.to_csv(ROOT / 'house/senate_incumbency_sensitivity_forecasts.csv', index=False)

    g = load_module('governor_stage2', ROOT / 'governor/governor_stage2.py')
    governor = pd.read_csv(ROOT / 'governor/results/governor_sample.csv')
    governor['senate_incumbency'] = governor['incumbency']
    controls = ['prior_gov_share', 'prior_pres_lean', 'gov_incumbency', 'senate_incumbency'] + g.FLAGS
    records = []
    for label, terms in [('continuous', [g.QUALITY]), ('tails_secondary', g.TAILS)]:
        _, table = g.ols(governor, controls + terms, fe=True)
        table = table[table.term.isin(terms)].copy()
        table['model'] = label
        records.append(table)
    result = pd.concat(records, ignore_index=True)
    result.to_csv(ROOT / 'governor/results/senate_incumbency_sensitivity_associations.csv', index=False)
    print(result[['term', 'estimate_pp', 'ci_low_pp', 'ci_high_pp']].to_string(index=False))


if __name__ == '__main__':
    main()
