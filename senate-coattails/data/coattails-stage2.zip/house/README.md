# House spillovers after freezing the Senate proxy

This stage follows the Senate prediction benchmark. It carries forward the prior Senate performance measure chosen using candidates' own Senate vote predictions. House outcomes do not choose the proxy, its scale, or its tail thresholds.

The primary predictor is the Democratic nominee's earlier Senate overperformance minus the Republican nominee's earlier overperformance. The source features are already constructed before the target year in `sample.csv` from the Senate benchmark. Unknown candidate histories receive zero plus separate observed-history indicators in both the baseline and extended model.

The two tail indicators are the number of Democratic nominees in a tail minus the number of Republican nominees in the same tail. Both enter together. The cutoffs come from 371 observed prior-history nominee appearances in the Senate training population of 1982–2008, before the House join. The bottom tenth is below −3.6578 points of prior overperformance. The top tenth is above +19.4517 points. Repeat candidates contribute repeated appearances to this historical population. No prior comparable history is reported separately from known middle or tail observations.

## Reproduce

Python requires numpy, pandas, scipy and scikit-learn. Generate the Senate benchmark sample first, then run

    OPENBLAS_NUM_THREADS=1 python analyze_house.py --house-data /path/to/house_districts.csv --senate-data /path/to/senate/sample.csv --output-dir ./results

The House input is the locally reconstructed district file from DeLuca, Moskowitz and Schneer's public replication package. The Senate input is the completed stage-one feature table. The output manifest records SHA-256 fingerprints of both.

## Sample and weighting

The target is Democratic two-party House vote share in a contest with named Democratic and Republican candidates. Each district has a House result exactly two years earlier on the same documented geography. The previous result may have been uncontested. The model includes prior and current House incumbency as separate covariates.

The unchanged-geography match uses the source's state/district/redistricting identifier. For states with an at-large district in both years, the statewide geography is retained even when the source identifier increments at a census boundary. The source's `redist` field is zero for every 2022 district, so that field alone cannot establish unchanged geography. Multi-district 2022 comparisons are excluded. Only one 2022 district remains after the other eligibility rules. Coverage for each election year is provided in `coverage_by_year.csv`.

Each state-election receives total weight one. Its districts divide that weight equally, so a large state cannot dominate the coefficient merely through its number of House seats. There is no vote-share inclusion cutoff.

## Prediction and association

The out-of-time baseline includes the previous House share, previous and current House incumbency, strictly earlier statewide presidential lean, indicators of which Senate nominees have a prior comparable result, and the known White House party and its midterm interaction. The primary model adds the frozen continuous Senate-history advantage. A secondary diagnostic replaces that continuous value with the two frozen tail indicators. Training covers elections through 2008 and development covers 2010–2014. The test predictions refit coefficients on data through 2014 and evaluate the eligible 2016–2022 elections. The quality measure remains fixed.

The separate association model uses the same lagged controls plus state and election-year fixed effects. Its continuous coefficient is scaled to the House share change associated with a ten-point increase in prior Senate advantage. Tail coefficients compare a party with one additional top- or bottom-decile nominee against its opponent. Standard errors cluster by state. They describe an incremental current-election association beyond established party performance. A previous House result can already contain earlier coattails, and state-specific election shocks can remain after state and year fixed effects.

All forecast improvements use exactly matched outcomes and weights. Positive MAE improvement means the Senate measure improves accuracy. Negative improvement means a larger error than the baseline. The 95% forecast improvement interval resamples states 4,000 times while treating predictions as fixed.

## Interpretation

The full-sample continuous association is close to zero and the frozen Senate score slightly worsens heldout House forecasts. The separate 2016–2022 association is positive, emphasizing variation across time and specifications. The files include this diagnostic and the tail estimates. These results do not identify causal charisma or establish that every individual candidate has zero coattails. Two-party vote share also cannot separate turnout from persuasion or quantify additional total ballots.

`summary.json` packages all estimates, coverage, thresholds and limitations. `association_estimates.csv` contains all-period, since-2000 and test-period coefficients. `forecast_metrics.csv` and `predictions.csv` contain matched forecast comparisons. `strength_counts.csv` gives top, bottom, known-middle and unknown-history counts separately by party. `sample.csv` is generated locally and allows review of individual districts and their inherited Senate predictors. District samples and individual predictions are deliberately excluded from the distributed package. Run `python run_all.py --fetch` from the package root to rebuild all inputs and outputs.
