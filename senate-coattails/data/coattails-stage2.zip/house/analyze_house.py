"""House stage of a frozen Senate-quality benchmark.

Out-of-time prediction and separate lag-adjusted observational associations.
All candidate-strength inputs precede the target election.
"""
from pathlib import Path
import argparse
import hashlib
import json

import numpy as np
import pandas as pd
from scipy.stats import t
from sklearn.linear_model import LinearRegression

BASE=Path(__file__).resolve().parent
BASELINE=['prior_house_share','house_incumbency','prior_house_incumbency',
          'prior_pres_lean','prior_D_observed','prior_R_observed',
          'white_house_party','midterm_white_house']
QUALITY=['prior_candidate_advantage']
STARS=['high_quality_difference','low_quality_difference']
MODELS={'baseline':BASELINE,'continuous_prior_quality':BASELINE+QUALITY,
        'training_defined_tails':BASELINE+STARS}


def prepare(house_path,senate_path):
    house=pd.read_csv(house_path)
    senate=pd.read_csv(senate_path)
    training=senate.loc[senate.year.le(2008)]
    previous=pd.concat([training.loc[training.prior_D_observed.eq(1),'prior_D_advantage'],
                        training.loc[training.prior_R_observed.eq(1),'prior_R_advantage']])
    low,high=previous.quantile([.1,.9])
    threshold={'population':'Observed nominee-history appearances in all Senate training rows, before joining House data',
               'n_nominee_appearances':len(previous),'low_p10':low,'high_p90':high,'last_training_year':2008}
    for side in ['D','R']:
        senate[f'{side}_high']=senate[f'prior_{side}_observed'].eq(1)&senate[f'prior_{side}_advantage'].ge(high)
        senate[f'{side}_low']=senate[f'prior_{side}_observed'].eq(1)&senate[f'prior_{side}_advantage'].le(low)
    senate['high_quality_difference']=senate.D_high.astype(int)-senate.R_high.astype(int)
    senate['low_quality_difference']=senate.D_low.astype(int)-senate.R_low.astype(int)
    # Same state/district/unchanged-boundary identifier, with an exact two-year lag.
    past=house[['st_dist_redist_FE','year','d2pshare','incumbency']].copy()
    past['year']+=2
    past=past.rename(columns={'d2pshare':'prior_house_share','incumbency':'prior_house_incumbency'})
    house=house.merge(past,on=['st_dist_redist_FE','year'],how='left',validate='one_to_one')
    # The source's geography ID also advances each census decade for at-large
    # districts. A state-wide at-large seat in both years has identical geography.
    statewide=house.loc[house.dist.eq(0),['state_abbrev','year','d2pshare','incumbency']].copy()
    statewide['year']+=2
    statewide=statewide.rename(columns={'d2pshare':'statewide_prior_share','incumbency':'statewide_prior_incumbency'})
    house=house.merge(statewide,on=['state_abbrev','year'],how='left',validate='many_to_one')
    eligible_statewide=house.dist.eq(0)&house.prior_house_share.isna()
    house.loc[eligible_statewide,'prior_house_share']=house.loc[eligible_statewide,'statewide_prior_share']
    house.loc[eligible_statewide,'prior_house_incumbency']=house.loc[eligible_statewide,'statewide_prior_incumbency']

    selected=house.loc[house.cand_d.notna()&house.cand_r.notna()&house.votes_d.gt(0)&house.votes_r.gt(0)].copy()
    selected=selected.rename(columns={'incumbency':'house_incumbency'})
    senate_fields=['state_abbrev','year','split','candidate_DEMOCRAT','candidate_REPUBLICAN',
                   'prior_pres_lean','prior_D_observed','prior_R_observed',
                   'prior_candidate_advantage','white_house_party','midterm_white_house',
                   'D_high','R_high','D_low','R_low',*STARS]
    matched=selected.merge(senate[senate_fields],on=['state_abbrev','year'],validate='many_to_one')
    matched=matched.loc[matched.year.le(2022)]
    coverage_before=matched.groupby('split').agg(district_races=('dist','size'),state_elections=('syFE','nunique')).reset_index()
    sample=matched.dropna(subset=['d2pshare',*BASELINE,*QUALITY,*STARS]).copy()
    sample['weight']=1/sample.groupby(['state_abbrev','year']).dist.transform('size')
    coverage_after=sample.groupby('split').agg(district_races=('dist','size'),state_elections=('syFE','nunique')).reset_index()
    return sample,threshold,coverage_before,coverage_after


def prediction(train,test,features):
    x=train[features].astype(float)
    center=x.mean();scale=x.std().replace(0,1).fillna(1)
    model=LinearRegression().fit((x-center)/scale,train.d2pshare,sample_weight=train.weight)
    return np.clip(model.predict((test[features].astype(float)-center)/scale),0,1)


def summarize(rows):
    w=rows.weight.to_numpy();y=rows.actual.to_numpy();p=rows.prediction.to_numpy();b=rows.baseline_prediction.to_numpy()
    mae=np.average(abs(y-p),weights=w)*100
    rmse=np.sqrt(np.average((y-p)**2,weights=w))*100
    bmae=np.average(abs(y-b),weights=w)*100
    brmse=np.sqrt(np.average((y-b)**2,weights=w))*100
    grouped=rows.assign(gain=(abs(y-b)-abs(y-p))*w*100).groupby('state_abbrev').agg(gain=('gain','sum'),weight=('weight','sum'))
    rng=np.random.default_rng(20261105)
    draws=rng.integers(0,len(grouped),size=(4000,len(grouped)))
    boot=grouped.gain.to_numpy()[draws].sum(axis=1)/grouped.weight.to_numpy()[draws].sum(axis=1)
    lo,hi=np.quantile(boot,[.025,.975])
    return {'district_races':len(rows),'state_elections':len(rows[['state_abbrev','year']].drop_duplicates()),
            'states':rows.state_abbrev.nunique(),'mae_pp':mae,'rmse_pp':rmse,'matched_baseline_mae_pp':bmae,
            'matched_baseline_rmse_pp':brmse,'mae_gain_pp':bmae-mae,'mae_gain_low95':lo,'mae_gain_high95':hi}


def forecasts(sample):
    predictions=[]
    for stage,cutoff in [('development',2008),('test',2014)]:
        train=sample.loc[sample.year.le(cutoff)]
        test=sample.loc[sample.split.eq(stage)]
        baseline=prediction(train,test,BASELINE)
        for name,features in MODELS.items():
            frame=test[['state_abbrev','year','dist','weight','candidate_DEMOCRAT','candidate_REPUBLICAN',
                        'prior_candidate_advantage','high_quality_difference','low_quality_difference']].copy()
            frame['actual']=test.d2pshare.to_numpy()
            frame['prediction']=prediction(train,test,features)
            frame['baseline_prediction']=baseline
            frame['model']=name;frame['stage']=stage
            frame['training_state_elections']=train.syFE.nunique()
            predictions.append(frame)
    output=pd.concat(predictions,ignore_index=True)
    metrics=[]
    for (model,stage),rows in output.groupby(['model','stage']):
        metrics.append({'model':model,'stage':stage,**summarize(rows)})
    return output,pd.DataFrame(metrics)


def association(frame,extra):
    # Election-year fixed effects absorb national shocks here, independently of forecasts.
    controls=[x for x in BASELINE if x not in ['white_house_party','midterm_white_house']]
    features=extra+controls
    year=pd.get_dummies(frame.year,drop_first=True,dtype=float)
    state=pd.get_dummies(frame.state_abbrev,drop_first=True,dtype=float)
    x=np.column_stack([np.ones(len(frame)),frame[features],year,state]).astype(float)
    y=frame.d2pshare.to_numpy();w=frame.weight.to_numpy()
    wx=np.sqrt(w)[:,None]*x
    b,_,rank,_=np.linalg.lstsq(wx,np.sqrt(w)*y,rcond=None)
    states,groups=np.unique(frame.state_abbrev,return_inverse=True)
    scores=np.zeros((len(states),x.shape[1]))
    np.add.at(scores,groups,x*(w*(y-x@b))[:,None])
    bread=np.linalg.pinv(wx.T@wx)
    cov=bread@(scores.T@scores)@bread
    cov*=len(states)/(len(states)-1)*(len(frame)-1)/(len(frame)-rank)
    se=np.sqrt(np.maximum(0,np.diag(cov)));crit=t.ppf(.975,len(states)-1)
    results=[]
    for feature in extra:
        i=1+features.index(feature)
        scale=10 if feature=='prior_candidate_advantage' else 100
        results.append({'predictor':feature,'estimate_pp':b[i]*scale,'se_pp':se[i]*scale,
                        'low95':(b[i]-crit*se[i])*scale,'high95':(b[i]+crit*se[i])*scale,
                        'units':'per 10 pp extra prior Senate advantage' if scale==10 else 'one additional party top/bottom-decile nominee vs opponent',
                        'district_races':len(frame),'state_elections':frame.syFE.nunique(),'states':len(states),
                        'first_year':int(frame.year.min()),'last_year':int(frame.year.max()),
                        'state_fixed_effects':True,'year_fixed_effects':True})
    return results


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--house-data',type=Path,default=BASE.parent/'_work/inputs/house_districts.csv')
    parser.add_argument('--senate-data',type=Path,default=BASE.parent/'governor/input/senate_sample.csv')
    parser.add_argument('--output-dir',type=Path,default=BASE)
    args=parser.parse_args();root=args.output_dir;root.mkdir(exist_ok=True,parents=True)
    sample,threshold,before,after=prepare(args.house_data,args.senate_data)
    sample.to_csv(root/'sample.csv',index=False)
    year_counts=sample.groupby('year').agg(district_races=('dist','size'),state_elections=('syFE','nunique')).reset_index()
    year_counts.to_csv(root/'coverage_by_year.csv',index=False)
    strength_counts=[]
    for label,frame in [('all_period',sample),('test',sample.loc[sample.split.eq('test')])]:
        units=frame.drop_duplicates(['state_abbrev','year'])
        for side in ['D','R']:
            strength_counts.append({'period':label,'party':side,'state_elections':len(units),
                'top_decile':int(units[f'{side}_high'].sum()),'bottom_decile':int(units[f'{side}_low'].sum()),
                'known_middle':int((units[f'prior_{side}_observed'].eq(1)&~units[f'{side}_high']&~units[f'{side}_low']).sum()),
                'no_prior_comparable_result':int(units[f'prior_{side}_observed'].eq(0).sum())})
    counts=pd.DataFrame(strength_counts)
    counts.to_csv(root/'strength_counts.csv',index=False)
    before.to_csv(root/'coverage_before_boundary_requirement.csv',index=False)
    after.to_csv(root/'coverage_after_boundary_requirement.csv',index=False)
    pred,metrics=forecasts(sample)
    pred.to_csv(root/'predictions.csv',index=False);metrics.to_csv(root/'forecast_metrics.csv',index=False)
    estimates=[]
    for label,frame in [('all_period',sample),('since_2000',sample.loc[sample.year.ge(2000)]),('test_period',sample.loc[sample.split.eq('test')])]:
        for extra in [QUALITY,STARS]:
            for row in association(frame,extra):
                estimates.append({'period':label,**row})
    estimates=pd.DataFrame(estimates);estimates.to_csv(root/'association_estimates.csv',index=False)
    summary={'outcome':'Democratic two-party House vote share','unit':'House district election, with every state-election receiving total weight one',
             'quality_proxy':'Frozen stage-one prior Senate performance advantage, Democratic nominee minus Republican nominee',
             'thresholds':threshold,'strength_counts':json.loads(counts.to_json(orient='records')),'coverage_by_year':json.loads(year_counts.to_json(orient='records')),'forecast_baseline':BASELINE,'models':MODELS,
             'forecast_metrics':json.loads(metrics.to_json(orient='records')),
             'association_estimates':json.loads(estimates.to_json(orient='records')),
             'coverage_before_boundary_requirement':json.loads(before.to_json(orient='records')),
             'coverage_after_boundary_requirement':json.loads(after.to_json(orient='records')),
             'limitations':['Observed associations do not establish causal coattails.',
              'The lagged House baseline may already contain coattails from previous elections.',
              'Districts without a two-year prior result on the same boundary are excluded, including most redistricting years. At-large districts in both years retain a statewide prior result.',
              'The source redist flag is zero for every 2022 row, so it is not used to identify unchanged 2022 boundaries. Only at-large seats can contribute in 2022.',
              'Two-party share does not separate turnout from persuasion or measure additional total ballots.',
              'The Senate quality proxy was selected using Senate own-vote development performance and was frozen before examining House outcomes.',
              'The star thresholds use 371 prior nominee appearances in Senate training data, including repeat nominees, before joining House outcomes.',
              'Bootstrap forecast intervals resample states and treat fitted predictions as fixed.'],
             'source_sha256':{str(path):hashlib.sha256(path.read_bytes()).hexdigest() for path in [args.house_data,args.senate_data]}}
    (root/'summary.json').write_text(json.dumps(summary,indent=2,allow_nan=False))
    print('coverage before');print(before.to_string(index=False));print('coverage after');print(after.to_string(index=False))
    print(metrics.to_string(index=False));print(estimates.to_string(index=False))

if __name__=='__main__':
    main()
