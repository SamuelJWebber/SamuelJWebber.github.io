# Stage-2 analytical audit

Audit date: 2026-11-05. Reviewed `house/analyze_house.py`, `governor/governor_stage2.py`, generated samples, summaries and coefficients. No site changes were made.

## Verdict and appropriate headline

No blocking numerical error or current-election outcome leakage was found in the reviewed models. A defensible headline is: **This frozen measure does not deliver a stable, transferable coattail estimate.** The results do not establish that exceptionally effective candidates have no coattails.

The full-period, lag-adjusted House association is −0.013 percentage points per 10 points of historical Senate advantage, with 95% interval [−0.524, +0.497]. Refitting on 2016–2022 produces +2.863 [1.365, 4.362], so period sensitivity is substantive and must appear with the main conclusion. The recent refit is an association fitted to those outcomes, not a successful held-out forecast. The actual held-out House forecast worsens from 4.946 to 5.052 points MAE when the frozen quality measure is added.

The recent House sample contains only two top-decile candidate appearances, and the governor test sample contains none. Therefore, the held-out checks do not provide a meaningful contemporary validation of the specific 'all-star' tail. The broader continuous-score test and sparse star-tail test should be described separately.

## Construction and timing checks

- Senate scores come from the already frozen own-vote benchmark. Top/bottom cutoffs are calculated from 371 observed training nominee-history appearances before the House/governor merge. Unknown histories are not classified into either tail.
- Current Senate vote, current presidential vote, current turnout, and current campaign spending are not predictors. Previous House/governor votes and preceding presidential lean are prior outcomes, not current outcomes.
- House lag matching uses the redistricting-era geography identifier and an explicit same-state at-large fallback. It does not rely on the erroneous all-zero 2022 redistricting flag. Only one House observation survives in 2022, so '2016–2022' requires that coverage qualification.
- Governor lags come from previous regular elections, with the Arizona 1990/1991 timing issue and Oregon 2016 special-election issue handled explicitly. Utah 2010 and West Virginia 2011 special returns are absent from the actual source. Lag-share and current-share variables remain distinct.
- House forecasts refit through 2014 for the test. Governor forecasts retain the model fitted through 2008 for both development and test. These are different training protocols and should be labeled accordingly.
- State/year fixed effects occur only in the association models. Forecasts do not estimate coefficients using the future test outcomes. Uncertainty accounts for state clustering but remains conditional on modeling choices and the observed periods.

## Pre-election Senate-incumbency sensitivity

Both main stage-2 models omit Senate incumbency while including history flags and teammate incumbency. Omitting it is not current-outcome leakage, but incumbency could confound interpretation of candidate strength. It was proposed in the design, so an explicit sensitivity was run without changing the proxy, thresholds, rows or periods. Keep it labeled as a sensitivity rather than silently replacing a model after seeing its results.

| Outcome / period | Primary continuous estimate | With Senate incumbency | Sensitivity 95% interval |
|---|---:|---:|---:|
| House / full period | −0.013 | −0.001 | [−0.560, +0.559] |
| House / 2016–2022 refit | +2.863 | +2.925 | [+1.379, +4.472] |
| Governor / full period | +0.440 | +0.131 | [−1.665, +1.927] |

Units are outcome-share percentage points per 10 points of historical Senate advantage. House test MAE with Senate incumbency is 4.960 for baseline and 5.045 with quality, still worse. The main interpretation and recent-period instability persist. Reproduce with `incumbency_sensitivity.py`; separate CSV outputs accompany the main results.

## Remaining identification limits

The score can reflect opponent weakness and persistent local political conditions. Lag adjustment addresses established party strength but can absorb benefits the senator already created, making the coefficient an incremental current-election association. State-specific contemporary swings and candidate selection remain uncontrolled; state/year effects do not remove them. Two-party share does not measure additional total votes or identify turnout versus persuasion. No random nomination or other natural-experiment assignment is present in these files.
