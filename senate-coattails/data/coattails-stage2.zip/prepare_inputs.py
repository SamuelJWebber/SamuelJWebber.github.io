"""Reconstruct stage-two inputs using the frozen stage-one construction.

Downloaded district source data and row derivatives are local working files and
are intentionally absent from the distributed package.
"""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parent


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def prepare(inputs, fetch=False):
    if fetch:
        module('stage1_fetch', ROOT/'stage1/fetch_inputs.py').fetch(inputs)
    for name in ['mit_senate.tsv', 'mit_president.csv', 'house_districts.csv']:
        if not (inputs/name).exists():
            raise FileNotFoundError(f'{inputs/name}: use --fetch to acquire source inputs')
    benchmark = module('stage1_benchmark', ROOT/'stage1/benchmark.py')
    benchmark.SOURCE = inputs
    benchmark.BASE = ROOT/'_work/stage1'
    senate = benchmark.prepare_sample()
    assert len(senate) == 689, 'The frozen Senate population has changed'
    observed = pd.concat([senate.loc[senate.year.le(2008) & senate.prior_D_observed.eq(1), 'prior_D_advantage'],
                          senate.loc[senate.year.le(2008) & senate.prior_R_observed.eq(1), 'prior_R_advantage']])
    assert len(observed) == 371
    p10, p90 = observed.quantile([.1,.9])
    assert abs(p10 - (-.0365778847380102)) < 1e-12
    assert abs(p90 - .1945173590766114) < 1e-12
    destination = ROOT/'governor/input'
    destination.mkdir(parents=True, exist_ok=True)
    senate.to_csv(destination/'senate_sample.csv', index=False)
    district = pd.read_csv(inputs/'house_districts.csv', low_memory=False)
    key = ['state_abbrev','year']
    assert district.groupby(key).incumbency_G.nunique().max() <= 1
    district.groupby(key, as_index=False).incumbency_G.first().to_csv(
        destination/'house_governor_incumbency.csv', index=False)
    work = ROOT/'_work'
    work.mkdir(exist_ok=True)
    manifest = {'senate_rows':len(senate), 'threshold_observed_appearances':len(observed),
                'p10':p10, 'p90':p90,
                'source_sha256': {name:hashlib.sha256((inputs/name).read_bytes()).hexdigest()
                                  for name in ['mit_senate.tsv','mit_president.csv','house_districts.csv']}}
    (work/'prepared_inputs.json').write_text(json.dumps(manifest, indent=2)+'\n')
    print(f'Prepared {len(senate)} Senate races; training thresholds use {len(observed)} appearances.')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input-dir', type=Path, default=ROOT/'_work/inputs')
    parser.add_argument('--fetch', action='store_true')
    args = parser.parse_args()
    prepare(args.input_dir.resolve(), args.fetch)
