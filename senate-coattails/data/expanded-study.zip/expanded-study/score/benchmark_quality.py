"""Joint own-Senate validation and earlier-cycle candidate scoring.

Architecture is selected on fixed development predictions only. Candidate
contributions use identical D/R slopes and an explicit all-zero reference.
No House or governor outcome is loaded or used by this program.
"""
from pathlib import Path
import argparse
import hashlib
import json
import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from core import BASELINE as STRUCTURAL, KEY, scores, paired_uncertainty

OFFICES = ['local', 'state_leg', 'statewide', 'house', 'governor', 'former_senator']
OFFICE_FEATURES = ['office_' + x for x in OFFICES] + ['office_other_elected']
PRIMARY_FEATURES = ['primary_contested_share', 'primary_unopposed', 'primary_log_field']
MODEL_COMPONENTS = {
    'baseline': [],
    'history_raw': ['history_raw'],
    'history_centered': ['history_centered'],
    'office': OFFICE_FEATURES,
    'office_history_raw': OFFICE_FEATURES + ['history_raw'],
    'office_history_centered': OFFICE_FEATURES + ['history_centered'],
    'office_primary': OFFICE_FEATURES + PRIMARY_FEATURES,
    'office_primary_history_raw': OFFICE_FEATURES + PRIMARY_FEATURES + ['history_raw'],
    'office_primary_history_centered': OFFICE_FEATURES + PRIMARY_FEATURES + ['history_centered'],
}
AVAILABLE = ['history_observed', 'office_observed', 'primary_share_observed', 'primary_field_observed']
BASELINE = STRUCTURAL + [f'{x}_{p}' for x in AVAILABLE for p in ['D', 'R']]


def prepare(history, experience):
    assert not experience.duplicated(KEY).any()
    d = history.merge(experience, on=KEY, how='left', validate='one_to_one')
    for party in ['D', 'R']:
        d[f'office_observed_{party}'] = pd.to_numeric(d[f'office_{party}_observed'], errors='coerce').fillna(0)
        office = d[f'office_{party}'].fillna('unknown')
        for category in OFFICES:
            d[f'office_{category}_{party}'] = office.eq(category).astype(float)
        elected = pd.to_numeric(d[f'prior_elected_{party}'], errors='coerce')
        elected_known = pd.to_numeric(d[f'prior_elected_{party}_observed'], errors='coerce').fillna(0).eq(1)
        d[f'office_other_elected_{party}'] = (office.eq('unknown') & elected_known & elected.eq(1)).astype(float)
        d[f'office_signal_observed_{party}'] = d[f'office_observed_{party}'].eq(1) | elected_known
        share = pd.to_numeric(d[f'preprimary_share_{party}'], errors='coerce')
        share_known = pd.to_numeric(d[f'preprimary_share_{party}_observed'], errors='coerce').fillna(0).eq(1) & share.notna()
        assert share[share_known].between(0, 1).all()
        field = pd.to_numeric(d[f'primary_on_ballot_count_{party}'], errors='coerce')
        field_known = field.notna() & field.ge(0)
        unopposed = pd.to_numeric(d[f'primary_unopposed_{party}'], errors='coerce')
        d[f'primary_share_observed_{party}'] = share_known.astype(int)
        d[f'primary_field_observed_{party}'] = field_known.astype(int)
        d[f'primary_contested_share_{party}'] = share.where(share_known & field.gt(1), 0.)
        d[f'primary_unopposed_{party}'] = unopposed.where(unopposed.notna(), field.eq(1)).fillna(0).astype(float)
        d[f'primary_log_field_{party}'] = np.log1p(field.where(field_known, 0))
    for component in sorted(set(sum(MODEL_COMPONENTS.values(), []))):
        d[component + '_difference'] = d[component + '_D'] - d[component + '_R']
    assert not d[BASELINE].isna().any().any()
    return d


def fit(train, components):
    features = BASELINE + [x + '_difference' for x in components]
    means = train[features].mean()
    scales = train[features].std().replace(0, 1).fillna(1)
    model = LinearRegression().fit((train[features] - means) / scales, train.dshare)
    raw = pd.Series(model.coef_ / scales.to_numpy(), index=features)
    intercept = float(model.intercept_ - (raw * means).sum())
    return {'features': features, 'coef': raw, 'intercept': intercept, 'components': components}


def apply(fitted, test):
    pred = fitted['intercept'] + test[fitted['features']].to_numpy(float) @ fitted['coef'].to_numpy()
    return np.clip(pred, 0, 1)


def contributions(fitted, frame, party):
    result = np.zeros(len(frame))
    for component in fitted['components']:
        result += fitted['coef'][component + '_difference'] * frame[component + '_' + party].to_numpy(float)
    return result


def known_signal(frame, components, party):
    known = np.zeros(len(frame), dtype=bool)
    if any(x.startswith('history_') for x in components):
        known |= frame[f'history_observed_{party}'].eq(1).to_numpy()
    if any(x.startswith('office_') for x in components):
        known |= frame[f'office_signal_observed_{party}'].to_numpy(bool)
    if any(x.startswith('primary_') for x in components):
        known |= frame[f'primary_field_observed_{party}'].eq(1).to_numpy()
    return known


def metrics(predictions):
    rows = []
    for (protocol, model, stage), f in predictions.groupby(['protocol', 'model', 'stage']):
        for subgroup in ['all', 'neither_history', 'any_history']:
            data = f
            if subgroup == 'neither_history':
                data = f[f.history_count.eq(0)]
            elif subgroup == 'any_history':
                data = f[f.history_count.gt(0)]
            if not len(data):
                continue
            stats = scores(data.actual, data.prediction)
            base = scores(data.actual, data.baseline_prediction)
            low, high = paired_uncertainty(data)
            rows.append({'protocol': protocol, 'model': model, 'stage': stage, 'subgroup': subgroup,
                         'races': len(data), 'states': data.state_abbrev.nunique(), **stats,
                         'baseline_mae_pp': base['mae_pp'], 'mae_gain_pp': base['mae_pp'] - stats['mae_pp'],
                         'mae_gain_low95': low, 'mae_gain_high95': high})
    return pd.DataFrame(rows)


def fixed_predictions(d):
    records = []
    for stage, cutoff in [('development', 2008), ('test', 2014), ('confirmation', 2022)]:
        train = d[d.year.le(cutoff)]
        test = d[d.split.eq(stage)]
        baseline = apply(fit(train, []), test)
        for model, components in MODEL_COMPONENTS.items():
            fitted = fit(train, components)
            r = test[KEY + ['candidate_DEMOCRAT', 'candidate_REPUBLICAN']].copy()
            r['actual'] = test.dshare.to_numpy()
            r['prediction'] = apply(fitted, test)
            r['baseline_prediction'] = baseline
            r['history_count'] = (test.history_observed_D + test.history_observed_R).to_numpy()
            r['model'] = model; r['stage'] = stage; r['protocol'] = 'fixed_cutoff'
            r['training_last_year'] = cutoff
            records.append(r)
    return pd.concat(records, ignore_index=True)


def rolling_scores(d, selected):
    components = MODEL_COMPONENTS[selected]
    output = d[KEY + ['split', 'candidate_DEMOCRAT', 'candidate_REPUBLICAN', 'person_D_id', 'person_R_id']].copy()
    for col in ['quality_score_D', 'quality_score_R', 'quality_score_difference', 'own_prediction',
                'baseline_prediction', 'score_training_last_year', 'score_training_n']:
        output[col] = np.nan
    output['quality_observed_D'] = False; output['quality_observed_R'] = False
    coefficients = []
    for year in sorted(d.year.unique()):
        tr = d[d.year.lt(year)]; te = d[d.year.eq(year)]
        structure = np.column_stack([np.ones(len(tr)), tr[STRUCTURAL].to_numpy(float)])
        if tr.year.nunique() < 4 or np.linalg.matrix_rank(structure) != structure.shape[1]:
            continue
        fitted = fit(tr, components)
        baseline = fit(tr, [])
        output.loc[te.index, 'own_prediction'] = apply(fitted, te)
        output.loc[te.index, 'baseline_prediction'] = apply(baseline, te)
        for party in ['D', 'R']:
            output.loc[te.index, f'quality_score_{party}'] = contributions(fitted, te, party)
            output.loc[te.index, f'quality_observed_{party}'] = known_signal(te, components, party)
        output.loc[te.index, 'score_training_last_year'] = tr.year.max()
        output.loc[te.index, 'score_training_n'] = len(tr)
        for feature, coefficient in fitted['coef'].items():
            coefficients.append({'score_year': year, 'training_last_year': tr.year.max(),
                                 'model': selected, 'feature': feature, 'coefficient_raw_units': coefficient})
    output['quality_score_difference'] = output.quality_score_D - output.quality_score_R
    known = output.score_training_last_year.notna()
    assert (output.loc[known, 'score_training_last_year'] < output.loc[known, 'year']).all()
    training_values = pd.concat([output.loc[output.year.le(2008) & output[f'quality_observed_{p}'], f'quality_score_{p}']
                                 for p in ['D', 'R']]).dropna()
    thresholds = {'model': selected, 'reference': 'Identical all-zero substantive candidate features for both parties; no outcome-dependent individual recentering.',
                  'population': 'Observed candidate-score appearances through2008, coefficients fitted strictly before each appearance.',
                  'n': len(training_values), 'p10': None, 'p90': None}
    if len(training_values):
        thresholds['p10'], thresholds['p90'] = map(float, training_values.quantile([.1, .9]))
        for party in ['D', 'R']:
            output[f'quality_high_{party}'] = output[f'quality_observed_{party}'] & output[f'quality_score_{party}'].ge(thresholds['p90'])
            output[f'quality_low_{party}'] = output[f'quality_observed_{party}'] & output[f'quality_score_{party}'].le(thresholds['p10'])
    return output, pd.DataFrame(coefficients), thresholds


def main():
    root = Path(__file__).resolve().parent
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--history', type=Path, default=root / 'results/history_sample.csv')
    p.add_argument('--experience', type=Path, default=root / 'input/experience_features.csv')
    p.add_argument('--output', type=Path, default=root / 'results')
    args = p.parse_args(); args.output.mkdir(parents=True, exist_ok=True)
    d = prepare(pd.read_csv(args.history), pd.read_csv(args.experience))
    d.to_csv(args.output / 'joint_sample.csv', index=False)
    fixed = fixed_predictions(d)
    table = metrics(fixed)
    dev = table.query("protocol=='fixed_cutoff' and stage=='development' and subgroup=='all'").sort_values(['mae_pp', 'model'])
    selected = dev.iloc[0].model
    output, coefficients, thresholds = rolling_scores(d, selected)
    output.to_csv(args.output / 'frozen_candidate_scores.csv', index=False)
    coefficients.to_csv(args.output / 'rolling_score_coefficients.csv', index=False)
    (args.output / 'score_thresholds.json').write_text(json.dumps(thresholds, indent=2))
    roll = output[output.split.isin(['development', 'test', 'confirmation']) & output.own_prediction.notna()].copy()
    roll = roll.rename(columns={'own_prediction': 'prediction'})
    roll = roll.merge(d[KEY + ['dshare', 'history_observed_D', 'history_observed_R']], on=KEY, validate='one_to_one')
    roll['actual'] = roll.dshare
    roll['history_count'] = roll.history_observed_D + roll.history_observed_R
    roll['stage'] = roll['split']; roll['model'] = selected; roll['protocol'] = 'expanding_past_only'
    predictions = pd.concat([fixed, roll], ignore_index=True)
    predictions.to_csv(args.output / 'own_vote_predictions.csv', index=False)
    table = metrics(predictions)
    table.to_csv(args.output / 'own_vote_metrics.csv', index=False)
    selection = {'selected_model': selected, 'selected_components': MODEL_COMPONENTS[selected],
                 'selection': 'Minimum2010–2014own-Senate-vote MAE, fixed fitting cutoff2008; no teammate outcomes.',
                 'development_ranking': dev[['model', 'mae_pp', 'baseline_mae_pp', 'mae_gain_pp']].to_dict(orient='records'),
                 'baseline': BASELINE, 'models': MODEL_COMPONENTS,
                 'reference': thresholds['reference'],
                 'timing': 'Stage2-facing scores use selected architecture and coefficients fitted strictly before each scored election.',
                 'limitations': ['Architecture chosen using2010–2014means earlier scores are retrospective in architecture.',
                                 'The two parties share additive candidate-feature slopes; individual effects are not causally identified.',
                                 ('Selected model does not score newcomers without calibrated Senate history.' if selected in ['history_raw', 'history_centered'] else 'Newcomer scores reflect measured officeholding/nomination signals, not unmeasured charisma.'),
                                 'Source primary dollar share is not general-election donor breadth and historical filing availability is unverified.',
                                 'Fixed-prediction bootstrap intervals exclude fitting and model-selection uncertainty.',
                                 'Tail ties can produce more than10percent of observed candidates; counts must be reported.'],
                 'inputs_sha256': {str(x): hashlib.sha256(x.read_bytes()).hexdigest() for x in [args.history, args.experience]}}
    (args.output / 'model_selection.json').write_text(json.dumps(selection, indent=2))
    print('DEVELOPMENT SELECTION'); print(dev[['model', 'mae_pp', 'mae_gain_pp']].to_string(index=False))
    print('SELECTED MODEL', selected)
    print(table.query('model == @selected and subgroup == "all"').to_string(index=False))


if __name__ == '__main__':
    main()
