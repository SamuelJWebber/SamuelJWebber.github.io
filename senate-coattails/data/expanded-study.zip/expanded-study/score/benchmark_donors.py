"""Common-cohort own-vote benchmark of fundraising above structural expectation.

Development chooses architecture. Every donor normalizer and vote model is fit
on its training rows only. No teammate outcome is read. Primary June30 inputs
must be finalized before running; a source snapshot and hashes are retained.
"""
from pathlib import Path
import argparse
import hashlib
import json
import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
import benchmark_quality as q
from core import KEY

DONORS = ['donor_national', 'donor_in_state']
MONEY = ['donor_money']
HISTORY = ['history_centered']
MODELS = {
    'baseline': [],
    'history': HISTORY,
    'office_history': q.OFFICE_FEATURES + HISTORY,
    'national_breadth': ['donor_national'],
    'in_state_breadth': ['donor_in_state'],
    'individual_money': MONEY,
    'both_breadth': DONORS,
    'breadth_and_money': DONORS + MONEY,
    'history_and_breadth': HISTORY + DONORS,
    'history_breadth_money': HISTORY + DONORS + MONEY,
    'office_history_breadth_money': q.OFFICE_FEATURES + HISTORY + DONORS + MONEY,
}


def prepare(joint, breadth, money, population):
    b = breadth.loc[breadth.window.eq('june30')].copy()
    for data in [joint, b, money, population]:
        assert not data.duplicated(KEY).any()
    d = joint.merge(b, on=KEY, how='left', validate='one_to_one')
    d = d.merge(money[KEY + ['individual_contributions_D', 'individual_contributions_R', 'both_observed']],
                on=KEY, how='left', validate='one_to_one')
    d = d.merge(population[KEY + ['prior_census_population', 'population_census_year']],
                on=KEY, how='left', validate='one_to_one')
    valid = d.paired_breadth_observed.eq(True) & d.both_observed.eq(True) & d.prior_census_population.gt(0)
    for party in ['D', 'R']:
        for scope, component in [('national', 'donor_national'), ('in_state', 'donor_in_state')]:
            raw = d[f'approx_contributors_{scope}_per100k_prior_census_{party}']
            large = d[f'approx_contributors_gt200_{scope}_per100k_prior_census_{party}']
            valid &= raw.notna() & raw.ge(0) & large.notna() & large.ge(0)
            d[f'{component}_raw_{party}'] = np.log1p(raw)
            d[f'{component}_gt200_raw_{party}'] = np.log1p(large)
        raw_money = d[f'individual_contributions_{party}']
        valid &= raw_money.notna() & raw_money.ge(0)
        d[f'donor_money_raw_{party}'] = np.log1p(raw_money / d.prior_census_population * 100000)
    d['included_common_cohort'] = valid
    assert (d.loc[valid, 'population_census_year'] < d.loc[valid, 'year']).all()
    return d.loc[valid].copy(), d


def normalizer_design(d, party):
    sign = 1 if party == 'D' else -1
    year = (d.year - 2000) / 10
    return pd.DataFrame({
        'party_lean': sign * d.prior_pres_lean,
        'absolute_lean': d.prior_pres_lean.abs(),
        'own_incumbent': d.incumbency.eq(sign).astype(float),
        'opponent_incumbent': d.incumbency.eq(-sign).astype(float),
        'party': sign * np.ones(len(d)),
        'white_house_alignment': sign * d.white_house_party,
        'midterm': d.year.mod(4).eq(2).astype(float),
        'year_trend': year,
        'party_year_trend': sign * year,
    }, index=d.index)


def normalize(train, test, sensitivity='primary'):
    tr = train.copy(); te = test.copy(); records = []
    x = pd.concat([normalizer_design(tr, p) for p in ['D', 'R']], ignore_index=True)
    for component in DONORS + MONEY:
        rawtag = '_gt200_raw_' if sensitivity == 'gt200' and component in DONORS else '_raw_'
        y = np.concatenate([tr[component + rawtag + p].to_numpy(float) for p in ['D', 'R']])
        model = LinearRegression().fit(x, y)
        records.append({'quantity': component, 'intercept': float(model.intercept_),
                        **{k: float(v) for k, v in zip(x.columns, model.coef_)}})
        for data in [tr, te]:
            for party in ['D', 'R']:
                expected = model.predict(normalizer_design(data, party))
                data[f'{component}_expected_{party}'] = expected
                data[f'{component}_{party}'] = data[component + rawtag + party] - expected
                if sensitivity == 'cycle_centered':
                    residual = data[f'{component}_{party}'].copy()
                    adjustments = pd.Series(0., index=data.index)
                    for year, frame in data.groupby('year'):
                        for idx, row in frame.iterrows():
                            other = frame.state_abbrev.ne(row.state_abbrev)
                            if other.any():
                                adjustments.loc[idx] = residual.loc[frame.index[other]].median()
                    data[f'{component}_{party}'] -= adjustments
            data[component + '_difference'] = data[component + '_D'] - data[component + '_R']
    return tr, te, records


def fixed_predictions(d, sensitivity='primary', model_names=None):
    results = []; normalizers = []
    for stage, cutoff in [('development', 2008), ('test', 2014)]:
        train = d[d.year.le(cutoff)]; test = d[d.split.eq(stage)]
        tr, te, norms = normalize(train, test, sensitivity)
        normalizers.extend({'stage': stage, 'training_last_year': cutoff, **x} for x in norms)
        baseline = q.apply(q.fit(tr, []), te)
        for model in (model_names or list(MODELS)):
            fitted = q.fit(tr, MODELS[model])
            r = te[KEY + ['candidate_DEMOCRAT', 'candidate_REPUBLICAN']].copy()
            r['actual'] = te.dshare.to_numpy()
            r['prediction'] = q.apply(fitted, te)
            r['baseline_prediction'] = baseline
            r['history_count'] = (te.history_observed_D + te.history_observed_R).to_numpy()
            r['stage'] = stage; r['model'] = model; r['protocol'] = 'fixed_cutoff_' + sensitivity
            results.append(r)
    return pd.concat(results, ignore_index=True), pd.DataFrame(normalizers)


def rolling_scores(d, selected):
    components = MODELS[selected]
    output = d[KEY + ['split', 'candidate_DEMOCRAT', 'candidate_REPUBLICAN', 'person_D_id', 'person_R_id']].copy()
    for column in ['quality_score_D', 'quality_score_R', 'quality_score_difference', 'prediction',
                   'baseline_prediction', 'score_training_last_year', 'score_training_n']:
        output[column] = np.nan
    for party in ['D', 'R']:
        output[f'quality_observed_{party}'] = False
    coefficients = []; normalizers = []
    for year in sorted(d.year.unique()):
        train = d[d.year.lt(year)]; test = d[d.year.eq(year)]
        structure = np.column_stack([np.ones(len(train)), train[q.STRUCTURAL].to_numpy(float)])
        if train.year.nunique() < 4 or np.linalg.matrix_rank(structure) != structure.shape[1]:
            continue
        tr, te, norms = normalize(train, test)
        normalizers.extend({'score_year': year, 'training_last_year': train.year.max(), **x} for x in norms)
        fitted = q.fit(tr, components)
        output.loc[te.index, 'prediction'] = q.apply(fitted, te)
        output.loc[te.index, 'baseline_prediction'] = q.apply(q.fit(tr, []), te)
        for party in ['D', 'R']:
            output.loc[te.index, f'quality_score_{party}'] = q.contributions(fitted, te, party)
            known = np.ones(len(te), dtype=bool) if any(c.startswith('donor_') for c in components) else q.known_signal(te, components, party)
            output.loc[te.index, f'quality_observed_{party}'] = known
        output.loc[te.index, 'score_training_last_year'] = train.year.max()
        output.loc[te.index, 'score_training_n'] = len(train)
        coefficients.extend({'score_year': year, 'model': selected, 'feature': f,
                             'coefficient_raw_units': v} for f, v in fitted['coef'].items())
    output['quality_score_difference'] = output.quality_score_D - output.quality_score_R
    values = pd.concat([output.loc[output.year.le(2008) & output[f'quality_observed_{p}'], f'quality_score_{p}'] for p in ['D', 'R']]).dropna()
    thresholds = {'model': selected, 'n': len(values), 'p10': None, 'p90': None,
                  'reference': 'Expected log fundraising conditional on earlier-trained structural model; zero historical residual and amateur office reference.',
                  'population': 'Observed candidate-score appearances through2008; coefficients and donor normalization fitted strictly before each scored election.'}
    if len(values):
        thresholds['p10'], thresholds['p90'] = map(float, values.quantile([.1, .9]))
        for p in ['D', 'R']:
            output[f'quality_high_{p}'] = output[f'quality_observed_{p}'] & output[f'quality_score_{p}'].ge(thresholds['p90'])
            output[f'quality_low_{p}'] = output[f'quality_observed_{p}'] & output[f'quality_score_{p}'].le(thresholds['p10'])
    return output, pd.DataFrame(coefficients), pd.DataFrame(normalizers), thresholds


def main():
    root = Path(__file__).resolve().parent
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input', type=Path, default=root / 'input')
    p.add_argument('--output', type=Path, default=root / 'donor_results')
    args = p.parse_args(); args.output.mkdir(parents=True, exist_ok=True)
    files = {'joint': root / 'results/joint_sample.csv', 'breadth': args.input / 'race_breadth_features.csv',
             'money': args.input / 'senate_june30_race_money.csv', 'population': args.input / 'prior_census_population.csv'}
    d, audit = prepare(*(pd.read_csv(files[x]) for x in ['joint', 'breadth', 'money', 'population']))
    audit.to_csv(args.output / 'common_cohort_audit.csv', index=False)
    d.to_csv(args.output / 'common_sample.csv', index=False)
    predictions, norms = fixed_predictions(d)
    table = q.metrics(predictions)
    dev = table.query('stage == "development" and subgroup == "all"').sort_values(['mae_pp', 'model'])
    selected = dev.iloc[0].model
    scored, coefficients, rolling_norms, thresholds = rolling_scores(d, selected)
    scored.to_csv(args.output / 'frozen_candidate_scores.csv', index=False)
    coefficients.to_csv(args.output / 'rolling_score_coefficients.csv', index=False)
    rolling_norms.to_csv(args.output / 'rolling_normalizers.csv', index=False)
    norms.to_csv(args.output / 'fixed_normalizers.csv', index=False)
    (args.output / 'score_thresholds.json').write_text(json.dumps(thresholds, indent=2))
    roll = scored.loc[scored.split.isin(['development', 'test']) & scored.prediction.notna()].copy()
    roll = roll.merge(d[KEY + ['dshare', 'history_observed_D', 'history_observed_R']], on=KEY, validate='one_to_one')
    roll['actual'] = roll.dshare; roll['history_count'] = roll.history_observed_D + roll.history_observed_R
    roll['stage'] = roll['split']; roll['model'] = selected; roll['protocol'] = 'expanding_past_only_primary'
    frames = [predictions, roll]
    for sensitivity in ['gt200', 'cycle_centered']:
        extra, _ = fixed_predictions(d, sensitivity, [selected])
        frames.append(extra)
    predictions = pd.concat(frames, ignore_index=True)
    predictions.to_csv(args.output / 'own_vote_predictions.csv', index=False)
    q.metrics(predictions).to_csv(args.output / 'own_vote_metrics.csv', index=False)
    selection = {'selected_model': selected, 'selected_components': MODELS[selected], 'models': MODELS,
                 'selection': 'Lowest fixed2010–2014own-Senate-vote MAE; all models use identical money/breadth common cohort; no teammate outcomes.',
                 'development_ranking': dev[['model', 'mae_pp', 'baseline_mae_pp', 'mae_gain_pp']].to_dict(orient='records'),
                 'split_counts': d.groupby('split').size().to_dict(),
                 'normalizer_features': list(normalizer_design(d, 'D').columns),
                 'first_rolling_score_year': int(scored.loc[scored.score_training_last_year.notna(), 'year'].min()),
                 'limitations': ['Counts are approximate disclosed identities, not all unique donors.',
                                'Historical filing availability and amendments prevent a pure archival real-time forecasting claim.',
                                'Common cohort requires official money and both nominees donor coverage; selection limits generalization.',
                                'Candidate-party fundraising models do not remove all campaign-age, effort or disclosure-regime differences.',
                                'Coefficients and normalizers are earlier-only; architecture selected on2010–2014makes older scores retrospective in architecture.',
                                'Predicted individual contributions use a shared additive D/R model and are not causal talent effects.',
                                '2024 is outside the current FEC source coverage.'],
                 'inputs_sha256': {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in files.values()}}
    (args.output / 'model_selection.json').write_text(json.dumps(selection, indent=2))
    print('FEC DEVELOPMENT SELECTION'); print(dev[['model', 'mae_pp', 'mae_gain_pp']].to_string(index=False))
    print('SELECTED', selected)
    print(q.metrics(predictions).query('model == @selected and subgroup == "all"').to_string(index=False))


if __name__ == '__main__':
    main()
