# Scoring audit

The broad and FEC scoring rules were frozen using own-Senate development results before passing score files to the teammate-outcome analysis. No House or gubernatorial outcome is loaded by either scoring benchmark. The House source is read only for historical Senate-incumbency metadata.

Historical baseline fits precede the historical election being residualized. Carried-forward residuals precede the target election. Current-cycle centering in the historical score is known only after that historical election and is used only later. Earlier-only score cutoffs are asserted in code. General reversed-name normalization and the Connie Mack III/IV exception are explicit; raw names and derived IDs are retained in a ledger.

The joint broad benchmark uses identical train/evaluation rows across its nine architectures, baseline availability flags, and development-only model selection. The currently selected model is history-only, so the output does not claim to measure first-time candidates' latent talent.

The FEC benchmark uses identical rows with both donor and official-money coverage across eleven architectures. Its donor normalizers use only training candidate X values, and its vote models use only training own-Senate outcomes. Both donor normalizers and coefficients are strictly earlier than every score delivered for the teammate analysis. Missing coverage is not zero fundraising. An independent code audit reconstructed all fixed predictions and all selected rolling predictions to within 1.3e-15; normalizer and active vote-model ranks were checked, and changing a scored row's current own-vote outcome did not change its prediction.

The selected donor model's own-vote holdout failure is a material finding, not a reason to retune on the test. Keep it prominent in any spillover result. Candidate score tails are model-dependent estimates under an additive D/R symmetry assumption, not experimentally identified personal talent. None of these score-validation steps removes common state political shocks from the eventual coattail regression.
