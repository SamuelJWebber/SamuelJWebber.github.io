"""Independent NumPy reconstruction of the donor benchmark; no production edits."""
import argparse,json,hashlib
from pathlib import Path
import numpy as np
import pandas as pd
import benchmark_donors as b
import benchmark_quality as q

R=Path(__file__).resolve().parent
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--results',type=Path,default=R/'donor_results');p.add_argument('--output',type=Path,default=R/'donor_results/independent_audit.json');a=p.parse_args()
d=pd.read_csv(a.results/'common_sample.csv');pred=pd.read_csv(a.results/'own_vote_predictions.csv');stored=pd.read_csv(a.results/'frozen_candidate_scores.csv');norms=pd.read_csv(a.results/'fixed_normalizers.csv');rollingnorms=pd.read_csv(a.results/'rolling_normalizers.csv');selection=json.loads((a.results/'model_selection.json').read_text());thresholds=json.loads((a.results/'score_thresholds.json').read_text())
KEY=['state_abbrev','year'];assert not d.duplicated(KEY).any();assert len(d)==391
assert d.groupby('split').size().to_dict()=={'development':85,'test':112,'train':194}
assert d.included_common_cohort.all() and d.paired_breadth_observed.all() and d.both_observed.all()
assert (d.population_census_year<d.year).all()
assert d.year.min()==1996 and d.year.max()==2022
assert q.STRUCTURAL==['prior_pres_lean','incumbency','white_house_party','midterm_white_house']
for party in ['D','R']:
 for scope in ['national','in_state']:
  for infix in ['','gt200_']:
   count=f'approx_contributors_{infix}{scope}_{party}'
   normalized=f'approx_contributors_{infix}{scope}_per100k_prior_census_{party}'
   assert np.allclose(d[normalized],d[count]/d.prior_census_population*100000)
 assert (d.loc[d[f'history_observed_{party}'].eq(1),f'history_year_{party}']<d.loc[d[f'history_observed_{party}'].eq(1),'year']).all()

NORMAL_FEATURES=['party_lean','absolute_lean','own_incumbent','opponent_incumbent','party','white_house_alignment','midterm','year_trend','party_year_trend']
def normal_X(frame,side):
 s=1 if side=='D' else -1;y=(frame.year.to_numpy()-2000)/10
 return np.column_stack([np.ones(len(frame)),s*frame.prior_pres_lean,frame.prior_pres_lean.abs(),frame.incumbency.eq(s),frame.incumbency.eq(-s),s*np.ones(len(frame)),s*frame.white_house_party,frame.year.mod(4).eq(2),y,s*y]).astype(float)
def independent_normalize(train,test):
 tr=train.copy();te=test.copy();records={}
 x=np.vstack([normal_X(tr,p) for p in ['D','R']])
 for c in ['donor_national','donor_in_state','donor_money']:
  y=np.concatenate([tr[f'{c}_raw_{p}'].to_numpy() for p in ['D','R']]);coef=np.linalg.lstsq(x,y,rcond=None)[0];records[c]=coef
  for f in [tr,te]:
   for p in ['D','R']:f[f'{c}_{p}']=f[f'{c}_raw_{p}'].to_numpy()-normal_X(f,p)@coef
   f[c+'_difference']=f[c+'_D']-f[c+'_R']
 return tr,te,records
def independent_fit(train,test,components):
 columns=q.BASELINE+[c+'_difference' for c in components]
 mean=train[columns].mean().to_numpy();scale=train[columns].std().replace(0,1).fillna(1).to_numpy()
 x=np.column_stack([np.ones(len(train)),(train[columns].to_numpy()-mean)/scale]);coef=np.linalg.lstsq(x,train.dshare.to_numpy(),rcond=None)[0]
 raw=coef[1:]/scale;intercept=coef[0]-raw@mean
 result=intercept+test[columns].to_numpy()@raw
 return np.clip(result,0,1),dict(zip(columns,raw)),intercept
max_prediction_error=0.;max_normalizer_error=0.;fixed_rows=[]
for stage,cutoff in [('development',2008),('test',2014)]:
 train=d.loc[d.year.le(cutoff)];test=d.loc[d.split.eq(stage)]
 assert train.year.max()<test.year.min()
 tr,te,n=independent_normalize(train,test)
 for quantity,coef in n.items():
  record=norms.loc[norms.stage.eq(stage)&norms.quantity.eq(quantity)].iloc[0]
  max_normalizer_error=max(max_normalizer_error,np.max(np.abs(coef-record[['intercept']+NORMAL_FEATURES].to_numpy(float))))
 baseline,_,_=independent_fit(tr,te,[])
 for model,components in b.MODELS.items():
  prediction,coefs,intercept=independent_fit(tr,te,components)
  computed=te[KEY].copy();computed['independent_prediction']=prediction;computed['independent_baseline']=baseline
  saved=pred.loc[pred.protocol.eq('fixed_cutoff_primary')&pred.stage.eq(stage)&pred.model.eq(model)]
  joined=computed.merge(saved,on=KEY,validate='one_to_one');assert len(joined)==len(test)
  max_prediction_error=max(max_prediction_error,np.max(abs(joined.independent_prediction-joined.prediction)),np.max(abs(joined.independent_baseline-joined.baseline_prediction)))
  fixed_rows.append({'stage':stage,'model':model,'races':len(joined),'mae_pp':np.mean(abs(joined.actual-joined.independent_prediction))*100,'baseline_mae_pp':np.mean(abs(joined.actual-joined.independent_baseline))*100})
fixed=pd.DataFrame(fixed_rows)
assert fixed.loc[fixed.stage.eq('development')].sort_values(['mae_pp','model']).iloc[0].model==selection['selected_model']=='national_breadth'
selected=selection['selected_model'];components=b.MODELS[selected]
max_score_error=0.;max_rolling_pred_error=0.;max_rolling_normalizer_error=0.;score_rows=[]
for year in sorted(stored.loc[stored.quality_observed_D,'year'].unique()):
 train=d.loc[d.year.lt(year)];test=d.loc[d.year.eq(year)];tr,te,n=independent_normalize(train,test)
 saved=stored.loc[stored.year.eq(year)]
 assert saved.score_training_last_year.eq(train.year.max()).all() and saved.score_training_n.eq(len(train)).all()
 assert train.year.nunique()>=4
 predicted,coefficients,intercept=independent_fit(tr,te,components)
 check=te[KEY].copy();check['independent_prediction']=predicted
 for side in ['D','R']:check['independent_score_'+side]=sum(coefficients[c+'_difference']*te[c+'_'+side] for c in components)
 result=check.merge(saved,on=KEY,validate='one_to_one')
 max_rolling_pred_error=max(max_rolling_pred_error,np.max(abs(result.independent_prediction-result.prediction)))
 for side in ['D','R']:max_score_error=max(max_score_error,np.max(abs(result['independent_score_'+side]-result['quality_score_'+side])))
 assert np.allclose(result.quality_score_difference,result.quality_score_D-result.quality_score_R)
 for quantity,coef in n.items():
  record=rollingnorms.loc[rollingnorms.score_year.eq(year)&rollingnorms.quantity.eq(quantity)].iloc[0]
  assert record.training_last_year<year
  max_rolling_normalizer_error=max(max_rolling_normalizer_error,np.max(np.abs(coef-record[['intercept']+NORMAL_FEATURES].to_numpy(float))))
 score_rows.append({'year':int(year),'training_last_year':int(train.year.max()),'training_races':len(train),'scored_races':len(test)})
v=pd.concat([stored.loc[stored.year.le(2008)&stored[f'quality_observed_{side}'],f'quality_score_{side}'] for side in ['D','R']]);assert len(v)==thresholds['n']==174
assert np.allclose(v.quantile([.1,.9]),[thresholds['p10'],thresholds['p90']])
for side in ['D','R']:
 assert (stored[f'quality_high_{side}']==(stored[f'quality_observed_{side}']&stored[f'quality_score_{side}'].ge(thresholds['p90']))).all()
 assert (stored[f'quality_low_{side}']==(stored[f'quality_observed_{side}']&stored[f'quality_score_{side}'].le(thresholds['p10']))).all()
metrics=pd.read_csv(a.results/'own_vote_metrics.csv');csv_mae_error=0.;csv_rmse_error=0.
for keys,group in pred.groupby(['protocol','model','stage']):
 protocol,model,stage=keys;row=metrics.loc[metrics.protocol.eq(protocol)&metrics.model.eq(model)&metrics.stage.eq(stage)&metrics.subgroup.eq('all')].iloc[0]
 mae=np.mean(abs(group.actual-group.prediction))*100;rmse=np.sqrt(np.mean((group.actual-group.prediction)**2))*100
 csv_mae_error=max(csv_mae_error,abs(row.mae_pp-mae));csv_rmse_error=max(csv_rmse_error,abs(row.rmse_pp-rmse))
assert max_prediction_error<1e-10 and max_score_error<1e-10 and max_rolling_pred_error<1e-10
assert max_normalizer_error<1e-10 and max_rolling_normalizer_error<1e-10
assert csv_mae_error<1e-10 and csv_rmse_error<1e-10
selected_metrics=metrics.loc[metrics.model.eq(selected)&metrics.subgroup.eq('all')].to_dict(orient='records')
summary={'status':'PASS: independent normalization, OLS predictions, individual contributions, metrics and tail thresholds agree','common_races':len(d),'common_split_counts':d.groupby('split').size().to_dict(),'first_year':int(d.year.min()),'last_year':int(d.year.max()),'selected_model':selected,'selection_unchanged':True,'max_fixed_prediction_error':max_prediction_error,'max_fixed_normalizer_coefficient_error':max_normalizer_error,'max_rolling_normalizer_coefficient_error':max_rolling_normalizer_error,'max_rolling_prediction_error':max_rolling_pred_error,'max_individual_score_error':max_score_error,'max_csv_mae_error_pp':csv_mae_error,'max_csv_rmse_error_pp':csv_rmse_error,'fixed_common_cohort_metrics':fixed.to_dict(orient='records'),'selected_all_protocol_metrics':selected_metrics,'rolling_training_audit':score_rows,'tail_thresholds':thresholds,'findings':['No current Senate own-vote, historical t0 residual, House or governor outcome enters the donor normalizer or selected vote-model predictor columns.','Fixed development normalization/vote fitting ends2008; fixed test ends2014. Rolling normalization/vote fitting uses only earlier years.','The same391race money/count/population intersection defines every competing model;85development and112test rows are identical across models.','Prior history features point to elections strictly earlier than their target.','Scores equal the shared candidate-feature slope times each candidate residual; D score minus R score reproduces the substantive contribution, before clipping.','The selected model remains national_breadth despite inferior heldout MAE. No post-test switch to history or office_history was made.','Cycle-centered sensitivity uses same-cycle other-state fundraising covariates, not votes. It is a separately labeled sensitivity, not the primary selected model.','Historical amendments, nominee conditioning and approximate disclosed donor identities limit real-time and general-population interpretation. These are data/design limitations, not numerical explanations for a reversed heldout result.'],'sha256':{str(path):hashlib.sha256(path.read_bytes()).hexdigest() for path in [R/'benchmark_donors.py',R/'benchmark_quality.py',a.results/'common_sample.csv',a.results/'own_vote_predictions.csv',a.results/'frozen_candidate_scores.csv']}}
a.output.write_text(json.dumps(summary,indent=2));fixed.to_csv(a.results/'independent_fixed_metrics.csv',index=False)
print(json.dumps({k:v for k,v in summary.items() if not isinstance(v,(list,dict))},indent=2));print(fixed.to_string(index=False))
