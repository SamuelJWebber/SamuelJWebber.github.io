"""Earlier-cycle-only, incumbency-adjusted historical Senate performance.

No teammate outcomes are used. Historical-cycle centering is known only AFTER
that historical election and is carried forward strictly to a later election.
"""
from pathlib import Path
import argparse
import hashlib
import json
import re
import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from core import BASELINE, KEY, major_races, candidate_key


def person_key(name, state, year):
    text = str(name).upper().strip()
    if ',' in text:
        left, right = text.split(',', 1)
        if re.sub('[^A-Z]', '', right) not in {'JR', 'SR', 'II', 'III', 'IV', 'V'}:
            text = right.strip() + ' ' + left.strip()
    key = candidate_key(text, state)
    if state == 'FL' and int(year) == 2012 and 'MACK' in text:
        key = 'FL|MACK|C|IV'
    return key


def historical_frame(inp):
    target = pd.read_csv(inp / 'senate_sample.csv')
    raw = major_races(pd.read_csv(inp / 'mit_senate.tsv', sep='\t'))
    raw = raw[raw.year.isin([1978, 1980])].copy()
    pres = major_races(pd.read_csv(inp / 'mit_president.csv'))
    totals = pres.groupby('year')[['votes_DEMOCRAT', 'votes_REPUBLICAN']].sum()
    national = totals.votes_DEMOCRAT / totals.sum(axis=1)
    pres['prior_pres_lean'] = pres.dshare - pres.year.map(national)
    raw['pres_previous_year'] = raw.year - 1 - (raw.year - 1) % 4
    raw = raw.merge(pres[['state_abbrev', 'year', 'prior_pres_lean']].rename(
        columns={'year': 'pres_previous_year'}), on=['state_abbrev', 'pres_previous_year'], validate='many_to_one')
    meta = pd.read_csv(inp / 'house_districts.csv')
    inc = meta.groupby(KEY, as_index=False).incumbency_S.first().rename(columns={'incumbency_S': 'incumbency'})
    raw = raw.merge(inc, on=KEY, how='left', validate='one_to_one')
    raw['white_house_party'] = 1
    raw['midterm_white_house'] = raw.year.mod(4).eq(2).astype(int)
    raw['split'] = 'historical_warmup'
    all_rows = pd.concat([raw, target], ignore_index=True).sort_values(['year', 'state_abbrev'])
    assert not all_rows.duplicated(KEY).any()
    overrides = inp / 'incumbency_overrides.csv'
    if overrides.exists():
        for _, correction in pd.read_csv(overrides).iterrows():
            mask = all_rows.state_abbrev.eq(correction.state_abbrev) & all_rows.year.eq(correction.year)
            assert mask.sum() == 1
            assert all_rows.loc[mask, 'incumbency'].iloc[0] in [correction.old_value, correction.new_value]
            all_rows.loc[mask, 'incumbency'] = correction.new_value
            all_rows.loc[mask, 'incumbency_source'] = correction.source_url
    for party, full in [('D', 'DEMOCRAT'), ('R', 'REPUBLICAN')]:
        all_rows[f'person_{party}_id'] = [person_key(n, s, y) for n, s, y in zip(
            all_rows[f'candidate_{full}'], all_rows.state_abbrev, all_rows.year)]
    return all_rows


def construct(frame):
    frame = frame.copy()
    for column in ['historical_expected_D_share', 'historical_residual_raw',
                   'historical_residual_centered', 'historical_model_last_year',
                   'historical_model_n', 'historical_cycle_other_states']:
        frame[column] = np.nan
    fits = []
    for year in sorted(frame.year.unique()):
        tr = frame.loc[frame.year.lt(year)].dropna(subset=BASELINE + ['dshare'])
        te = frame.loc[frame.year.eq(year)].dropna(subset=BASELINE + ['dshare'])
        if tr.year.nunique() < 4 or not len(te):
            continue
        x = tr[BASELINE].astype(float)
        design = np.column_stack([np.ones(len(x)), x])
        if np.linalg.matrix_rank(design) < design.shape[1]:
            continue
        model = LinearRegression().fit(x, tr.dshare)
        expected = model.predict(te[BASELINE].astype(float))
        residual = te.dshare.to_numpy(dtype=float) - expected
        # Do not clip the historical residual baseline: that changes residual
        # meaning at boundaries. Forecast clipping is a separate evaluation rule.
        centered = []
        other_n = []
        for state, value in zip(te.state_abbrev, residual):
            other = te.state_abbrev.ne(state).to_numpy()
            centered.append(value - np.median(residual[other]))
            other_n.append(int(other.sum()))
        frame.loc[te.index, 'historical_expected_D_share'] = expected
        frame.loc[te.index, 'historical_residual_raw'] = residual
        frame.loc[te.index, 'historical_residual_centered'] = centered
        frame.loc[te.index, 'historical_model_last_year'] = tr.year.max()
        frame.loc[te.index, 'historical_model_n'] = len(tr)
        frame.loc[te.index, 'historical_cycle_other_states'] = other_n
        fits.append({'scored_year': int(year), 'training_last_year': int(tr.year.max()),
                     'training_races': len(tr), 'training_cycles': tr.year.nunique(),
                     'intercept': float(model.intercept_),
                     **{f'coefficient_{f}': float(c) for f, c in zip(BASELINE, model.coef_)}})

    histories = {}
    for party in ['D', 'R']:
        for variant in ['raw', 'centered']:
            frame[f'history_{variant}_{party}'] = 0.0
        frame[f'history_observed_{party}'] = 0
        for column in ['year', 'model_last_year', 'model_n']:
            frame[f'history_{column}_{party}'] = np.nan
    for year in sorted(frame.year.unique()):
        for idx, row in frame.loc[frame.year.eq(year)].iterrows():
            for party in ['D', 'R']:
                key = row[f'person_{party}_id']
                if key not in histories:
                    continue
                old = histories[key]
                frame.loc[idx, f'history_observed_{party}'] = 1
                for variant in ['raw', 'centered']:
                    frame.loc[idx, f'history_{variant}_{party}'] = old[variant]
                for column in ['year', 'model_last_year', 'model_n']:
                    frame.loc[idx, f'history_{column}_{party}'] = old[column]
        # Update after every nominee in this calendar year has been scored.
        for _, row in frame.loc[frame.year.eq(year)].iterrows():
            if pd.isna(row.historical_residual_raw):
                continue
            for party, sign in [('D', 1), ('R', -1)]:
                histories[row[f'person_{party}_id']] = {
                    'raw': sign * row.historical_residual_raw,
                    'centered': sign * row.historical_residual_centered,
                    'year': row.year, 'model_last_year': row.historical_model_last_year,
                    'model_n': row.historical_model_n}
    for variant in ['raw', 'centered']:
        frame[f'history_{variant}_difference'] = frame[f'history_{variant}_D'] - frame[f'history_{variant}_R']
    return frame, pd.DataFrame(fits)


def main():
    root = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', type=Path, default=root / 'input')
    parser.add_argument('--output', type=Path, default=root / 'results')
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    full, fits = construct(historical_frame(args.input))
    sample = full.loc[full.year.between(1982, 2024)].copy()
    for party in ['D', 'R']:
        known = sample[f'history_observed_{party}'].eq(1)
        assert (sample.loc[known, f'history_year_{party}'] < sample.loc[known, 'year']).all()
        assert (sample.loc[known, f'history_model_last_year_{party}'] < sample.loc[known, f'history_year_{party}']).all()
    assert len(sample) == len(pd.read_csv(args.input / 'senate_sample.csv'))
    sample.to_csv(args.output / 'history_sample.csv', index=False)
    full.to_csv(args.output / 'historical_election_audit.csv', index=False)
    fits.to_csv(args.output / 'historical_baseline_fits.csv', index=False)
    features = KEY + [c for c in sample if c.startswith('history_') or c.startswith('person_')]
    sample[features].to_csv(args.output / 'history_features.csv', index=False)
    ledger = pd.concat([sample[KEY + [f'candidate_{p}', f'person_{s}_id']].rename(
        columns={f'candidate_{p}': 'raw_name', f'person_{s}_id': 'person_id'}).assign(party=s)
        for s, p in [('D', 'DEMOCRAT'), ('R', 'REPUBLICAN')]], ignore_index=True)
    ledger.to_csv(args.output / 'candidate_identity_ledger.csv', index=False)
    provenance = {'baseline': BASELINE, 'minimum_earlier_cycles': 4,
                  'first_calibrated_historical_year': int(fits.scored_year.min()),
                  'timing': 'Historical baseline fitted strictly before historical election; residual available only for later elections.',
                  'variants': ['raw forecast residual', 'residual centered by same historical cycle leave-one-state-out median'],
                  'warnings': ['Individual D/R residuals of a contest are exact sign reversals, not separately identified personal effects.',
                               'Historical residuals retain state-specific shocks and opponent strength.',
                               'No scores exist for nominees without an observed calibrated prior regular Senate race.'],
                  'input_sha256': {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                                   for p in sorted(args.input.glob('*')) if p.is_file()}}
    (args.output / 'history_provenance.json').write_text(json.dumps(provenance, indent=2))
    print(sample.groupby('split')[['history_observed_D', 'history_observed_R']].agg(['sum', 'size']))


if __name__ == '__main__':
    main()
