> Distribution note: the package includes code and aggregate outputs. Raw inputs, individual modeled scores, merged samples and observation-level predictions mentioned below are regenerated in the external working directory by the top-level `reproduce.py`. Run optional source scripts inside that working copy to keep caches out of the checkout.

# Independent candidate-strength scoring

This package builds candidate scores using only earlier own-Senate results and pre-election candidate features. It never fits a scoring rule to House or governor results. See `../DESIGN.md` for the frozen protocol and amendments written before the new fits.

## Reproduction

With Python, numpy, pandas (2.2 or later), scipy and scikit-learn installed, run from this directory:

```sh
python build_history.py
python benchmark_quality.py
python benchmark_donors.py
```

Inputs are local files in `input/`; the donor benchmark also consumes the broad benchmark's `results/joint_sample.csv`. Raw sources and corrected values are retained separately. Three pre-election Senate-incumbency corrections are documented in `input/incumbency_overrides.csv`. The copied `core.py` supplies common identity/parsing and metric functions.

## Broad model

Historical performance is observed earlier Senate vote share minus a baseline trained on still earlier elections. The baseline estimates, rather than fixes, the presidential-lean slope and accounts for incumbency. A centered variant removes the historical cycle's leave-one-state-out median surprise. Both are carried forward only to later elections.

Nine fixed architectures compare these history measures with independently audited officeholding categories and source pre-primary financial/context signals. All use the same 689 target races and common baseline/availability indicators. Selection uses only 2010–2014 own-vote MAE.

The selected architecture is `history_centered`. Fixed-cutoff test MAE is 5.950 baseline versus 5.341 with history; expanding-past-only test MAE is 5.723 versus 5.156. The separate 2024 improvement is small and uncertain. This selected score cannot classify newcomers without a comparable calibrated Senate history. Office/primary additions did not win development selection.

## Donor comparison on identical coverage

The donor benchmark uses June 30 approximate disclosed contributor breadth and official individual-contribution dollars, on the same complete-case cohort for all models. National counts, in-state counts and dollars are expressed per 100,000 residents in the latest census strictly preceding the election, log-transformed, and residualized against earlier-trained structural fundraising expectations. Competitiveness uses prior presidential lean; current general-election polls and margins are excluded.

Eleven fixed architectures are compared using development only. National donor breadth wins development MAE (5.120 versus baseline 6.058), but **does not replicate on the held-out elections**: fixed-cutoff test MAE is 5.384 versus baseline 4.989, and expanding-past-only test MAE is 4.828 versus 4.679. Prespecified newcomer-only results are imprecise. The frozen donor score can be carried into an exploratory spillover analysis, but should not be described as a validated new-star measure. Official money, in-state breadth and other models remain visible; none replaces the winner after observing the test.

Source disclosure limits, later amendments and uncertain archival filing availability prevent a pure real-time forecasting claim. Approximate name/ZIP identities are not a census of unique people. June 30 quantity definitions, source mapping and collection provenance are in the accompanying fundraising source files.

## Score contract

Broad scores: `results/frozen_candidate_scores.csv`; donor scores: `donor_results/frozen_candidate_scores.csv`.

| Field | Meaning |
|---|---|
| `state_abbrev`, `year` | Unique state-election key |
| `quality_score_D`, `quality_score_R` | Individual fitted contribution in vote-share fractions; multiply by 100 for percentage points |
| `quality_score_difference` | Democratic contribution minus Republican contribution |
| `quality_observed_D`, `quality_observed_R` | Required measurement signal and an earlier-fitted scoring model are available |
| `quality_high_D/R`, `quality_low_D/R` | Frozen training-tail classification; unknowns are never assigned to a tail |
| `score_training_last_year`, `score_training_n` | Earlier-only coefficient training cutoff and number of races |

Numeric zero in an unknown history row is a placeholder, not average or weak talent. Consumers must preserve the observed flags. Rows before sufficient earlier training have missing scores. A score of 0.03 means a three-point fitted own-vote contribution under this additive model, not a causal three-point personal effect. The D/R coefficients are shared and opponents' contributions are not independently identified by a single two-party result.

`model_selection.json` records architecture choice and all development rankings. `score_thresholds.json` records reference and tail population. Tail cutoffs use observed earlier-only training score appearances, never teammate-specific subsets. Scoring weights and donor normalizers precede each scored election, but choosing architecture on 2010–2014 makes earlier historical scores retrospective in architecture.

Own-vote predictions, subgroup metrics, fitted historical baseline audits, candidate identity ledger, rolling coefficients, donor normalizers and common-cohort exclusions are included for review. State-bootstrap intervals condition on the fitted predictions and do not cover all model-selection or future-cycle uncertainty.
