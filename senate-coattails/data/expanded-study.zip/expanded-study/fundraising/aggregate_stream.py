"""Bounded-memory equivalent of aggregate_bulk.py; exports aggregates only."""
from pathlib import Path
from collections import defaultdict
import argparse,json,zipfile
import numpy as np,pandas as pd
from aggregate_bulk import P,R,F,USE,roster,filehash

def aggregate(year,outdir):
 cn,link,conflicts=roster(year);mapping=link.set_index('committee_id').candidate_id.to_dict();state=cn.set_index('candidate_id').state_abbrev.to_dict()
 identities=defaultdict(dict);zips=defaultdict(set);states=defaultdict(set)
 stats=defaultdict(lambda:np.zeros(5,dtype=float));seen_rows=set();seen_electronic=set()
 nraw=ntarget=npositive=duplicates=repeated=0
 path=R/f'indiv{str(year)[-2:]}.zip'
 with zipfile.ZipFile(path) as z:
  with z.open(z.namelist()[0]) as f:
   for i,frame in enumerate(pd.read_csv(f,sep='|',header=None,names=F,usecols=USE,dtype=str,encoding='latin1',keep_default_na=False,chunksize=250000)):
    nraw+=len(frame);d=frame[frame.committee_id.isin(mapping)].copy();ntarget+=len(d)
    d=d[d.transaction_type.isin(['15','15E']) & d.entity_type.isin(['','IND'])].copy()
    d['amount']=pd.to_numeric(d.amount,errors='coerce');d=d[d.amount.gt(0)]
    d['parsed_date']=pd.to_datetime(d.date.str.zfill(8),format='%m%d%Y',errors='coerce')
    d=d[d.parsed_date.between(f'{year-1}-01-01',f'{year}-09-30')].copy()
    if len(d)==0:continue
    # FEC record IDs are numeric unique rows. Keep their exact integer identity.
    keep=[]
    for sub in d.sub_id:
     key=int(sub)
     keep.append(key not in seen_rows)
     if key in seen_rows:duplicates+=1
     else:seen_rows.add(key)
    d=d[np.array(keep)].copy();npositive+=len(d)
    d['candidate_id']=d.committee_id.map(mapping)
    e=d[d.transaction_id.ne('')]
    # Diagnostic only, never a substitute for full report amendment chains.
    for h in pd.util.hash_pandas_object(e[['committee_id','report_type','transaction_id','date']],index=False):
     h=int(h)
     if h in seen_electronic:repeated+=1
     else:seen_electronic.add(h)
    d['name_key']=d.name.str.upper().str.replace(r'[^A-Z0-9 ]',' ',regex=True).str.replace(r'\s+',' ',regex=True).str.strip()
    d['zip5']=d['zip'].str.extract(r'^(\d{5})',expand=False).fillna('')
    d['valid']=d.name_key.ne('')&d.zip5.ne('')
    d['in_state']=d.donor_state.eq(d.candidate_id.map(state))
    d['june']=d.parsed_date.le(f'{year}-06-30');d['large']=d.amount.gt(200)
    d['missing_identity']=(~d.valid).astype(int);d['entity_unknown']=d.entity_type.eq('').astype(int);d['memo_flag']=d.memo.eq('X').astype(int)
    for window,part in [('sept30',d),('june30',d[d.june])]:
     g=part.groupby('candidate_id').agg(n=('amount','size'),dollars=('amount','sum'),missing=('missing_identity','sum'),unknown=('entity_unknown','sum'),memo=('memo_flag','sum'))
     for cand,row in g.iterrows():stats[(cand,window)]+=row.to_numpy(float)
     for cand,group in part[part.valid].groupby('candidate_id'):zips[(cand,window)].update(group.zip5)
     for cand,group in part[part.donor_state.str.fullmatch('[A-Z]{2}')].groupby('candidate_id'):states[(cand,window)].update(group.donor_state)
    valid=d[d.valid].copy()
    # A64-bit deterministic internal hash bounds memory; no hash or donor identity
    # is exported. With millions of identities, collision risk is negligible for
    # this already approximate name+ZIP proxy, but it is not a formal person ID.
    keys=pd.util.hash_pandas_object(valid.name_key+'|'+valid.zip5,index=False).to_numpy(dtype=np.uint64)
    june=valid.june.to_numpy(dtype=np.uint8);inside=valid.in_state.to_numpy(dtype=np.uint8);large=valid.large.to_numpy(dtype=np.uint8)
    masks=(2+june)+(8+4*june)*inside+(32+16*june)*large+(128+64*june)*inside*large
    for cand,h,mask in zip(valid.candidate_id,keys,masks):
     bucket=identities[cand];h=int(h);bucket[h]=bucket.get(h,0)|int(mask)
    if i%20==0:print(f'{year}: scanned {nraw:,}; eligible {npositive:,}',flush=True)
 rows=[]
 for _,r in cn.iterrows():
  cand=r.candidate_id;mask=np.fromiter(identities[cand].values(),dtype=np.uint8)
  for window,sh in [('june30',0),('sept30',1)]:
   mapped=pd.notna(r.authorized_committees);v=stats[(cand,window)]
   row={k:r[k] for k in ['candidate_id','candidate_name','party','election_year','state_abbrev','incumbent_status','authorized_committees','committee_mapping_method']}
   data=dict(positive_individual_records=v[0],positive_itemized_dollars=v[1],records_missing_identity=v[2],records_entity_unspecified=v[3],records_memo=v[4],
             approx_contributors_national=int(((mask & (1<<sh))>0).sum()),approx_contributors_in_state=int(((mask & (4<<sh))>0).sum()),
             approx_contributors_gt200_national=int(((mask & (16<<sh))>0).sum()),approx_contributors_gt200_in_state=int(((mask & (64<<sh))>0).sum()),
             donor_zip5_count=len(zips[(cand,window)]),donor_state_count=len(states[(cand,window)]))
   row.update({k:(value if mapped else np.nan) for k,value in data.items()})
   row.update(year=year,window=window,window_start=f'{year-1}-01-01',window_end=f'{year}-'+('06-30' if window=='june30' else '09-30'),retrospective_amendments=True)
   rows.append(row)
 outdir.mkdir(exist_ok=True,parents=True);pd.DataFrame(rows).to_csv(outdir/f'candidate_breadth_{year}.csv',index=False)
 audit=dict(year=year,raw_records=nraw,target_campaign_records=ntarget,positive_individual_records_through_sept30=npositive,duplicate_sub_ids_removed=duplicates,repeated_electronic_ids_same_committee_report_date=repeated,candidate_rows=len(cn),mapped_candidates=int(cn.authorized_committees.notna().sum()),conflicting_committee_mappings_excluded=conflicts,raw_zip_sha256=filehash(path),bounded_memory=True,identity_hash='internal deterministic64-bit,not exported')
 (outdir/f'audit_{year}.json').write_text(json.dumps(audit,indent=2)+'\n');print(json.dumps(audit),flush=True)

if __name__=='__main__':
 a=argparse.ArgumentParser(description=__doc__);a.add_argument('--years',nargs='+',type=int,required=True);a.add_argument('--output',type=Path,default=P);args=a.parse_args()
 for year in args.years:aggregate(year,args.output)
