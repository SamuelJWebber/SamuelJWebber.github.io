from pathlib import Path
import pandas as pd,numpy as np,re,unicodedata
ROOT=Path(__file__).resolve().parent
ALIASES={'BOB':'ROBERT','BILL':'WILLIAM','DICK':'RICHARD','JIM':'JAMES','TED':'EDWARD','TOM':'THOMAS','CHUCK':'CHARLES','JOE':'JOSEPH','JACK':'JOHN','BEN':'BENJAMIN','JERRY':'GERALD','DAVE':'DAVID','MIKE':'MICHAEL','STEVE':'STEVEN','JON':'JOHN','RON':'RONALD','DAN':'DANIEL','RICK':'RICHARD','PAT':'PATRICK','PHIL':'PHILIP','JOSH':'JOSHUA','AL':'ALBERT','ED':'EDWARD','FRED':'FREDERICK','MATT':'MATTHEW','LIZ':'ELIZABETH','CATHY':'CATHERINE','ROD':'RODNEY','TIM':'TIMOTHY','CHRIS':'CHRISTOPHER','KEN':'KENNETH','ROB':'ROBERT','LARRY':'LAWRENCE','DANNY':'DANIEL','BOBB':'ROBERT','BETO':'ROBERT','NED':'EDWARD','GENE':'EUGENE','EDMOND':'EDMUND'}
SURNAME={'WEICHER':'WEICKER','PEREY':'PERCY','CHAFFEE':'CHAFEE','DONNELL':'ODONNELL','DELL':'ODELL','CONNOR':'OCONNOR','OCONNER':'OCONNOR','AMOURS':'DAMOURS','AMATO':'DAMATO','ROURKE':'OROURKE','ROCCO':'LAROCCO'}
IGNORE={'MR','MRS','MS','DR','JR','SR','II','III','IV','V','SIR','ESQ','SENATOR','HON','MD','PHD','SEN','PASTOR'}
# Audited legal/middle-name variants within state, year and party. They change
# matching only; no outcome or experience value is inferred from a name.
MIDDLE={('AR','HUTCHINSON'):{'ASA':'WILLIAM'},('FL','GRAHAM'):{'ROBERT':'DANIEL'},
('FL','GRANT'):{'WILLIAM':'JAMES'},('GA','HICKS'):{'MICHAEL':'JOHN'},
('GA','CLELAND'):{'MAX':'JOSEPH'},('IA','GANSKE'):{'GREG':'JOHN'},
('ID','MITCHELL'):{'NELS':'BRIANE'},('ID','STURGILL'):{'GERALD':'STEPHEN'},
('KY','BAESLER'):{'SCOTTY':'HENRY'},('MD','CAMPBELL'):{'TONY':'ANTONO'},
('ME','PINGREE'):{'CHELLIE':'ROCHELLE'},('MI','ABRAHAM'):{'SPENCER':'EDMUND'},
('MS','COCHRAN'):{'THAD':'WILLIAM'},('NC','SANFORD'):{'TERRY':'JAMES'},
('NC','FAIRCLOTH'):{'LAUCH':'DUNCAN'},('NC','BUDD'):{'EDWARD':'THEODORE'},
('ND','CONRAD'):{'KENT':'GAYLORD'},('NH','MESSNER'):{'CORKY':'BRYANT'},
('OH','CELESTE'):{'EDWARD':'THEODORE'},('PA','HEINZ'):{'JOHN':'HENRY'},
('SC','THURMOND'):{'STROM':'JAMES'},('SC','HUTTO'):{'BRAD':'CHARLES'},
('SD','MUENSTER'):{'EDWARD':'THEODORE'},('TN','CLARK'):{'JEFF':'WILLIAM'},
('TX','GRAMM'):{'PHILIP':'WILLIAM'},('TX','BOULTER'):{'BEAU':'ELDON'},
('WV','WOLFE'):{'JAY':'MATTHEW'},('WY','HELLING'):{'KATHY':'MARY'}}

def parts(name,state):
 name=unicodedata.normalize('NFKD',str(name)).encode('ascii','ignore').decode().upper().strip()
 name=name.replace("'",'')
 if state=='OR' and name=='WYDEN RON':name='RON WYDEN'
 if state=='OR' and name=='PERKINS JO RAE':name='JO RAE PERKINS'
 if ',' in name and re.sub('[^A-Z ]',' ',name.split(',',1)[1]).strip().replace(' ','') not in {'JR','SR','II','III','IV'}:
  last,rest=name.split(',',1);lasts=[x for x in re.sub('[^A-Z ]',' ',last).split() if x not in IGNORE]; last=lasts[-1] if lasts else "?"; tokens=re.sub('[^A-Z ]',' ',rest).split()
 else:
  tokens=re.sub('[^A-Z ]',' ',name).split();tokens=[t for t in tokens if t not in IGNORE];last=tokens[-1];tokens=tokens[:-1]
 tokens=[t for t in tokens if t not in IGNORE];first=next((x for x in tokens if len(x)>1),tokens[0] if tokens else '?');first=ALIASES.get(first,first);last=SURNAME.get(last,last)
 if state=='TX' and last=='CRUZ':first='RAFAEL'
 if state=='FL' and last=='NELSON':first='WILLIAM'
 first=MIDDLE.get((state,last),{}).get(first,first)
 return last,first
