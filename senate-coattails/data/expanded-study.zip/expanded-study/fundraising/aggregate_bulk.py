"""Candidate-level disclosed individual contributor proxies from FEC bulk records.

No contributor-level records or identifiers are exported. Primary window is
January 1 of preceding year through June 30; September 30 is a sensitivity.
The bulk extract includes retrospective amendments, not a historical data vintage.
"""
from pathlib import Path
import argparse, hashlib, json, re, zipfile
import numpy as np
import pandas as pd
P=Path(__file__).resolve().parent;R=P/'raw'
CN=['candidate_id','candidate_name','party','election_year','state_abbrev','office','district','incumbent_status','status','principal_committee','street1','street2','city','state2','zip']
CCL=['candidate_id','candidate_election_year','cycle','committee_id','committee_type','designation','linkage_id']
F=['committee_id','amendment','report_type','election_type','image','transaction_type','entity_type','name','city','donor_state','zip','employer','occupation','date','amount','other_id','transaction_id','file_number','memo','memo_text','sub_id']
USE=['committee_id','amendment','report_type','image','transaction_type','entity_type','name','donor_state','zip','date','amount','transaction_id','file_number','memo','sub_id']

def filehash(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  while b:=f.read(4*1024*1024):h.update(b)
 return h.hexdigest()

def readzip(path,names):
 with zipfile.ZipFile(path) as z:
  with z.open(z.namelist()[0]) as f:return pd.read_csv(f,sep='|',header=None,names=names,dtype=str,encoding='latin1',keep_default_na=False)

def roster(year):
 suffix=str(year)[-2:]
 cn=readzip(R/f'cn{suffix}.zip',CN)
 cn=cn.loc[cn.office.eq('S') & cn.candidate_id.str.startswith('S') & (cn.party.isin(['DEM','REP','DFL']) | cn.candidate_id.eq('S0AK00196'))].drop_duplicates('candidate_id')
 cn['party']=cn.party.replace({'DFL':'DEM'})
 # Same-person duplicate registrations audited from official names, election year,
 # and shared principal committee. Keep the canonical registration for this cycle.
 alias={'S4IA11126':'S4IA00046'} if year==2004 else ({'S8WV00119':'S0WV00215'} if year==2020 else {})
 cn=cn[~cn.candidate_id.isin(alias)]
 if (R/f'ccl{suffix}.zip').exists():
  link=readzip(R/f'ccl{suffix}.zip',CCL)
  link=link.loc[link.committee_type.eq('S') & link.designation.isin(['P','A']),['candidate_id','committee_id']]
  method='official candidate-committee linkage, principal/authorized'
 else:
  cm_names=['committee_id','committee_name','treasurer','street1','street2','city','state','zip','designation','committee_type','party','frequency','org_type','connected','candidate_id']
  cm=readzip(R/f'cm{suffix}.zip',cm_names)
  link=cm.loc[cm.committee_type.eq('S') & cm.designation.isin(['P','A']),['candidate_id','committee_id']]
  method='official committee master candidate field, principal/authorized; historical linkage unavailable'
 link['candidate_id']=link.candidate_id.replace(alias)
 # Principal committee from candidate master is also an official candidate link.
 link=pd.concat([link,cn[['candidate_id','principal_committee']].rename(columns={'principal_committee':'committee_id'})]).drop_duplicates()
 link=link[link.candidate_id.isin(cn.candidate_id)&link.committee_id.str.startswith('C')]
 conflicts=link.groupby('committee_id').candidate_id.nunique();bad=conflicts[conflicts.gt(1)].index
 link=link[~link.committee_id.isin(bad)]
 counts=link.groupby('candidate_id').size().rename('authorized_committees')
 cn=cn.merge(counts,on='candidate_id',how='left');cn['committee_mapping_method']=method
 return cn,link,len(bad)

def aggregate(year):
 cn,link,conflicts=roster(year)
 mapping=link.set_index('committee_id').candidate_id.to_dict()
 parts=[];nraw=0;ntarget=0
 path=R/f'indiv{str(year)[-2:]}.zip'
 with zipfile.ZipFile(path) as z:
  with z.open(z.namelist()[0]) as f:
   for frame in pd.read_csv(f,sep='|',header=None,names=F,usecols=USE,dtype=str,encoding='latin1',keep_default_na=False,chunksize=400000):
    nraw+=len(frame)
    d=frame[frame.committee_id.isin(mapping)].copy();ntarget+=len(d)
    # Direct and earmarked individual receipts. Exclude candidate self-financing,
    # refunds, pass-through intermediary records and known organizational entities.
    d=d[d.transaction_type.isin(['15','15E']) & d.entity_type.isin(['','IND'])].copy()
    d['amount']=pd.to_numeric(d.amount,errors='coerce')
    d=d[d.amount.gt(0)]
    d['parsed_date']=pd.to_datetime(d.date.str.zfill(8),format='%m%d%Y',errors='coerce')
    d=d[d.parsed_date.between(f'{year-1}-01-01',f'{year}-09-30')].copy()
    if len(d):
     d['candidate_id']=d.committee_id.map(mapping);parts.append(d)
 sample=pd.concat(parts,ignore_index=True) if parts else pd.DataFrame(columns=USE+['parsed_date','candidate_id'])
 del parts
 # SUB_ID is FEC's row identifier. Deduplicate repeated copies of an identical row.
 source_duplicates=sample.sub_id.duplicated().sum();sample=sample.drop_duplicates('sub_id')
 sample['name_key']=sample.name.str.upper().str.replace(r'[^A-Z0-9 ]',' ',regex=True).str.replace(r'\s+',' ',regex=True).str.strip()
 sample['zip5']=sample['zip'].str.extract(r'^(\d{5})',expand=False).fillna('')
 sample['identity_valid']=sample.name_key.ne('')&sample.zip5.ne('')
 sample['identity']=sample.name_key+'|'+sample.zip5
 sample['candidate_state']=sample.candidate_id.map(cn.set_index('candidate_id').state_abbrev)
 sample['in_state']=sample.donor_state.eq(sample.candidate_state)
 # Audit potential repeated electronic transaction IDs. The bulk source is treated
 # as the FEC-provided extract; no report-chain reconstruction is claimed.
 electronic=sample[sample.transaction_id.ne('')]
 repeated_electronic=electronic.duplicated(['committee_id','report_type','transaction_id','date']).sum()
 outputs=[]
 for window,cut in [('june30',f'{year}-06-30'),('sept30',f'{year}-09-30')]:
  d=sample[sample.parsed_date.le(cut)]
  by=d.groupby('candidate_id')
  agg=by.agg(positive_individual_records=('amount','size'),positive_itemized_dollars=('amount','sum'),
             records_missing_identity=('identity_valid',lambda x:(~x).sum()),
             records_entity_unspecified=('entity_type',lambda x:x.eq('').sum()),
             records_memo=('memo',lambda x:x.eq('X').sum())).reset_index()
  valid=d[d.identity_valid]
  national=valid.groupby('candidate_id').identity.nunique().rename('approx_contributors_national')
  instate=valid[valid.in_state].groupby('candidate_id').identity.nunique().rename('approx_contributors_in_state')
  zip_count=valid.groupby('candidate_id').zip5.nunique().rename('donor_zip5_count')
  states=d[d.donor_state.str.fullmatch('[A-Z]{2}')].groupby('candidate_id').donor_state.nunique().rename('donor_state_count')
  agg=agg.merge(national,on='candidate_id',how='left').merge(instate,on='candidate_id',how='left').merge(zip_count,on='candidate_id',how='left').merge(states,on='candidate_id',how='left')
  # A positive gift above $200 itself crosses the individual-disclosure threshold,
  # avoiding later gifts making an earlier small contribution retrospectively visible.
  large=valid[valid.amount.gt(200)]
  for series in [large.groupby('candidate_id').identity.nunique().rename('approx_contributors_gt200_national'),
                 large[large.in_state].groupby('candidate_id').identity.nunique().rename('approx_contributors_gt200_in_state')]:
   agg=agg.merge(series,on='candidate_id',how='left')
  out=cn[['candidate_id','candidate_name','party','election_year','state_abbrev','incumbent_status','authorized_committees','committee_mapping_method']].merge(agg,on='candidate_id',how='left')
  numeric=list(agg.columns.drop('candidate_id'))
  # Zero is conditional on an observed official campaign-committee mapping and the
  # complete bulk file. No mapped committee remains missing, not silently zero.
  mapped=out.authorized_committees.notna()
  out.loc[mapped,numeric]=out.loc[mapped,numeric].fillna(0)
  out['year']=year;out['window']=window;out['window_start']=f'{year-1}-01-01';out['window_end']=cut
  out['retrospective_amendments']=True
  outputs.append(out)
 result=pd.concat(outputs,ignore_index=True)
 result.to_csv(P/f'candidate_breadth_{year}.csv',index=False)
 audit={'year':year,'raw_records':nraw,'target_campaign_records':ntarget,'positive_individual_records_through_sept30':len(sample),
        'duplicate_sub_ids_removed':int(source_duplicates),'repeated_electronic_ids_same_committee_report_date':int(repeated_electronic),
        'candidate_rows':len(cn),'mapped_candidates':int(cn.authorized_committees.notna().sum()),'conflicting_committee_mappings_excluded':conflicts,
        'raw_zip_sha256':filehash(path)}
 (P/f'audit_{year}.json').write_text(json.dumps(audit,indent=2)+'\n')
 print(json.dumps(audit),flush=True)
 return result

if __name__=='__main__':
 a=argparse.ArgumentParser(description=__doc__);a.add_argument('--years',nargs='+',type=int,default=list(range(1996,2024,2)));args=a.parse_args()
 for year in args.years:aggregate(year)
 pd.concat([pd.read_csv(p) for p in sorted(P.glob('candidate_breadth_*.csv'))],ignore_index=True).to_csv(P/'candidate_breadth.csv',index=False)
