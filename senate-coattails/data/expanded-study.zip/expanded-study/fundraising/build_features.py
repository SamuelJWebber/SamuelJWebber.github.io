"""Join only aggregate fundraising features to verified Senate nominees."""
from pathlib import Path
import argparse,json
import numpy as np,pandas as pd
P=Path(__file__).resolve().parent
COUNTS=['approx_contributors_national','approx_contributors_in_state','approx_contributors_gt200_national','approx_contributors_gt200_in_state']
MEASURES=COUNTS+['positive_individual_records','positive_itemized_dollars','donor_zip5_count','donor_state_count','records_missing_identity','records_entity_unspecified','records_memo']

def main():
 a=argparse.ArgumentParser(description=__doc__);a.add_argument('--population',type=Path,default=P.parent/'population/prior_census_population.csv');args=a.parse_args()
 mapping=pd.read_csv(P/'nominee_fec_mapping.csv')
 parts=[pd.read_csv(p) for p in sorted(P.glob('candidate_breadth_*.csv'))]
 bulk=pd.concat(parts,ignore_index=True)
 assert not bulk.duplicated(['candidate_id','year','window']).any()
 # Only publish a cycle as final when the prespecified threshold sensitivity exists.
 available=bulk.groupby('year').approx_contributors_gt200_national.count()
 ready=set(available[available.gt(0)].index)
 bulk=bulk[bulk.year.isin(ready)]
 pd.concat(parts,ignore_index=True).to_csv(P/'candidate_breadth.csv',index=False)
 x=mapping.merge(pd.DataFrame({'window':['june30','sept30']}),how='cross')
 keep=['candidate_id','year','window','authorized_committees','window_start','window_end','retrospective_amendments']+MEASURES
 x=x.merge(bulk[keep],on=['candidate_id','year','window'],how='left',validate='one_to_one')
 population=pd.read_csv(args.population)
 x=x.merge(population,on=['state_abbrev','year'],how='left',validate='many_to_one')
 x['bulk_cycle_available']=x.year.isin(ready)
 x['committee_mapped']=x.authorized_committees.notna()
 x['observed_zero_disclosed_records']=x.positive_individual_records.eq(0)&x.committee_mapped
 for col in COUNTS:x[col+'_per100k_prior_census']=100000*x[col]/x.prior_census_population
 assert (x.population_census_year<x.year).all()
 x.to_csv(P/'nominee_breadth_features.csv',index=False)
 featurecols=MEASURES+[c+'_per100k_prior_census' for c in COUNTS]+['committee_mapped','observed_zero_disclosed_records','bulk_cycle_available']
 w=x.pivot(index=['state_abbrev','year','window'],columns='party',values=featurecols)
 w.columns=[f'{a}_{b}' for a,b in w.columns]
 w=w.reset_index();w['paired_breadth_observed']=w.bulk_cycle_available_D&w.bulk_cycle_available_R&w.committee_mapped_D&w.committee_mapped_R
 w.to_csv(P/'race_breadth_features.csv',index=False)
 cov=x.groupby(['year','window']).agg(nominees=('party','size'),mapped=('committee_mapped','sum'),zero=('observed_zero_disclosed_records','sum')).reset_index()
 paired=w.groupby(['year','window']).paired_breadth_observed.sum().rename('paired_races').reset_index()
 cov=cov.merge(paired,on=['year','window'])
 cov.to_csv(P/'coverage.csv',index=False)
 print(cov.to_string(index=False))
if __name__=='__main__':main()
