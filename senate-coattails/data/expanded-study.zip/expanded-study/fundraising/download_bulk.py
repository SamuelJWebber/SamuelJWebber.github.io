"""Acquire official FEC bulk inputs without exporting contributor-level rows."""
from pathlib import Path
import argparse, concurrent.futures, hashlib, json, shutil, urllib.request, time, zipfile
P=Path(__file__).resolve().parent;R=P/'raw';R.mkdir(exist_ok=True)
YEARS=list(range(1996,2024,2))
EXPECTED={r['file']:r['sha256'] for r in json.loads((P/'source_manifest.json').read_text()).get('files',[])} if (P/'source_manifest.json').exists() else {}
def get(job):
 year,kind=job;n=f'{kind}{str(year)[-2:]}.zip';p=R/n;u=f'https://www.fec.gov/files/bulk-downloads/{year}/{n}'
 t=time.time()
 try:
  if not p.exists():
   temp=p.with_suffix('.partial')
   with urllib.request.urlopen(u,timeout=120) as response,temp.open('wb') as out:
    while block:=response.read(4*1024*1024):out.write(block)
   temp.rename(p)
  with zipfile.ZipFile(p) as z:members=[{'name':i.filename,'bytes':i.file_size} for i in z.infolist()]
  h=hashlib.sha256()
  with p.open('rb') as f:
   while b:=f.read(4*1024*1024):h.update(b)
  actual=h.hexdigest()
  if n in EXPECTED and actual!=EXPECTED[n]:raise ValueError(f'Source version changed for {n}: expected {EXPECTED[n]}, got {actual}')
  rec=dict(year=year,kind=kind,file=n,url=u,bytes=p.stat().st_size,sha256=actual,members=members)
  print(year,kind,p.stat().st_size,'seconds',round(time.time()-t,1),flush=True)
  return rec
 except Exception as e:
  print('ERROR',year,kind,str(e),flush=True);return dict(year=year,kind=kind,file=n,url=u,error=str(e))
if __name__=='__main__':
 parser=argparse.ArgumentParser(description=__doc__)
 parser.add_argument('--years',nargs='+',type=int,default=YEARS)
 args=parser.parse_args()
 jobs=[(y,k) for k in ['cn','ccl','indiv'] for y in args.years if not(k=='ccl' and y<2000)]
 jobs += [(y,'cm') for y in args.years if y<2000]
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:
  results=[]
  for rec in ex.map(get,jobs):
   results.append(rec);(P/'bulk_source_manifest.json').write_text(json.dumps(results,indent=2)+'\n')

 if any('error' in r for r in results):raise SystemExit('One or more source downloads failed or changed version.')
