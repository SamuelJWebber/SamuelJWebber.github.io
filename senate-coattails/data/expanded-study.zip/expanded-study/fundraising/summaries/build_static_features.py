"""Official FEC table5 candidate summaries, fixed June30/September30 coverage.
Retain only the current two-year reporting block from each Senate six-year table.
Join to official FEC IDs and independent election nominees; never use vote totals
for identity resolution. Ambiguous identities remain missing and auditable.
"""
from pathlib import Path
import argparse,re,zipfile,urllib.request,xml.etree.ElementTree as ET
import pandas as pd
import numpy as np
ROOT=Path(__file__).resolve().parent
CN_COLUMNS=['candidate_id','candidate_name','party','candidate_election_year','state_abbrev','office','district','incumbent_challenger','status','principal_committee_id','street1','street2','city','mail_state','zip']
FIELDS=['state_name','source_candidate_name','party_label','source_incumbency','two_year_period','receipts','individual_contributions','pac_other_committee_contributions','candidate_contributions_loans','transfers','disbursements','cash_on_hand','debts_owed']
ALIASES={'BILL':'WILLIAM','BOB':'ROBERT','DICK':'RICHARD','JIM':'JAMES','TED':'EDWARD','TOM':'THOMAS','CHUCK':'CHARLES','JOE':'JOSEPH','JACK':'JOHN','BEN':'BENJAMIN','JERRY':'GERALD','DAVE':'DAVID','MIKE':'MICHAEL','STEVE':'STEVEN','JON':'JOHN','BETO':'ROBERT','MAGGIE':'MARGARET'}
STOP={'SEN','SENATOR','MR','MRS','MS','DR','JR','SR','II','III','IV'}

def words(s):return [w for w in re.sub('[^A-Z ]',' ',str(s).upper().replace("'",'')).split() if w not in STOP]

def identity(name):
 name=str(name).upper().replace('*','').strip()
 if ',' in name and words(name.split(',',1)[1]):
  a,b=name.split(',',1);last=' '.join(words(a));given=words(b)
 else:
  w=words(name)
  if name.startswith('WYDEN RON'):w=['RON','WYDEN']
  if name.startswith('PERKINS JO RAE'):w=['JO','RAE','PERKINS']
  compound=next((c for c in ['CORTEZ MASTO','BUSCH VALENTINE','BLUNT ROCHESTER','HYDE SMITH','MUCARSEL POWELL'] if w[-len(c.split()):]==c.split()),None)
  if compound:last=compound;given=w[:-len(compound.split())]
  else:last=w[-1];given=w[:-1]
 first=next((x for x in given if len(x)>1),given[0] if given else '')
 first=ALIASES.get(first,first)
 if last=='BUDD':first='THEODORE'
 if last=='CRUZ' and first in ['EDWARD','RAFAEL']:first='RAFAEL'
 if last=='CAMPBELL' and first=='TONY':first='ANTONO'
 if last=='MESSNER' and first=='CORKY':first='BRYANT'
 return last+'|'+first[:1]

def normalized(name):return ' '.join(words(str(name).replace('*','')))

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--candidate-dir',type=Path,default=Path('/tmp/coattails_prediction/fundraising/raw'));ap.add_argument('--benchmark',type=Path,default=Path('/tmp/coattails_prediction/sample.csv'));ap.add_argument('--state-source',type=Path,default=Path('/tmp/coattails_identification/data/mit_senate.tsv'));args=ap.parse_args()
 states=pd.read_csv(args.state_source,sep='\t',usecols=['state','state_po']).drop_duplicates();st=dict(zip(states.state.str.upper(),states.state_po))
 allrows=[];candidate_maps=[]
 for file in sorted(list(ROOT.glob('ConCand[25]_*_*m.xlsx'))+list(ROOT.glob('ConCand5_2016_18m_pdf_extracted.csv'))):
  match=re.fullmatch(r'ConCand[25]_(\d+)_(18|21)m(?:.xlsx|_pdf_extracted.csv)',file.name)
  if not match:continue
  year,months=map(int,match.groups())
  if file.suffix=='.csv':d=pd.read_csv(file)[FIELDS].copy()
  else:
   d=pd.read_excel(file,header=None)
   offset=1 if d.shape[1]==14 else 0
   d=d.iloc[4:,offset:offset+13].copy();d.columns=FIELDS
  d['two_year_period']=pd.to_numeric(d.two_year_period,errors='coerce')
  d=d.loc[d.two_year_period.eq(year) & d.source_candidate_name.notna()].copy()
  d['year']=year;d['months']=months;d['coverage_start_date']=f'{year-1}-01-01';d['coverage_end_date']=f'{year}-'+('06-30' if months==18 else '09-30')
  d['state_abbrev']=d.state_name.astype(str).str.upper().str.strip().map(st)
  d['party']=d.party_label.map({'Democratic Party':'DEM','Republican Party':'REP','Democratic-Farm-Labor':'DEM','Democratic-Farmer-Labor':'DEM'})
  for col in FIELDS[5:]:d[col]=pd.to_numeric(d[col],errors='coerce')
  d['source_file']=file.name;d['source_url']=f'https://www.fec.gov/resources/campaign-finance-statistics/{year}/tables/congressional/{file.name}'
  if file.suffix=='.xlsx':
   with zipfile.ZipFile(file) as z:
    core=ET.fromstring(z.read('docProps/core.xml'));modified=next((x.text for x in core if x.tag.endswith('}modified')),None)
  else:
   modified=None
   d['source_url']=f'https://www.fec.gov/resources/campaign-finance-statistics/2016/tables/congressional/ConCand5_2016_18m.pdf'
  d['workbook_modified_date']=modified
  # This timestamp is file metadata, not proof of initial publication.
  cnpath=args.candidate_dir/f'cn{str(year)[-2:]}.zip'
  if not cnpath.exists():
   cnpath=ROOT/cnpath.name
   if not cnpath.exists():urllib.request.urlretrieve(f'https://www.fec.gov/files/bulk-downloads/{year}/cn{str(year)[-2:]}.zip',cnpath)
  with zipfile.ZipFile(cnpath) as z:cn=pd.read_csv(z.open(z.namelist()[0]),sep='|',header=None,names=CN_COLUMNS,dtype=str)
  cn=cn.loc[cn.office.eq('S')].copy();cn['party']=cn.party.replace({'DFL':'DEM'});cn['name_norm']=cn.candidate_name.map(normalized);cn['identity']=cn.candidate_name.map(identity)
  d['candidate_id']=None;d['id_match_method']='unmatched';d['identity']=d.source_candidate_name.map(identity)
  for ix,row in d.iterrows():
   pool=cn.loc[cn.state_abbrev.eq(row.state_abbrev)]
   current=pool.loc[pd.to_numeric(pool.candidate_election_year,errors='coerce').eq(year)]
   if len(current):pool=current
   if pool.candidate_id.str.startswith('S').any():pool=pool.loc[pool.candidate_id.str.startswith('S')]
   if pd.notna(row.party):pool=pool.loc[pool.party.eq(row.party)]
   exact=pool.loc[pool.name_norm.eq(normalized(row.source_candidate_name))]
   exact=exact.drop_duplicates('candidate_id')
   if len(exact)==1:chosen=exact.iloc[0];method='exact_name_state_party'
   else:
    key=pool.loc[pool.identity.eq(row.identity)].drop_duplicates('candidate_id')
    if len(key)==1:chosen=key.iloc[0];method='unique_surname_given_initial_state_party'
    else:continue
   d.loc[ix,'candidate_id']=chosen.candidate_id;d.loc[ix,'id_match_method']=method
   candidate_maps.append({'year':year,'months':months,'state_abbrev':row.state_abbrev,'party':row.party,'source_name':row.source_candidate_name,'fec_name':chosen.candidate_name,'candidate_id':chosen.candidate_id,'match_method':method})
  allrows.append(d)
 out=pd.concat(allrows,ignore_index=True)
 out.to_csv(ROOT/'senate_june_september_money.csv',index=False)
 pd.DataFrame(candidate_maps).to_csv(ROOT/'static_fec_candidate_mapping.csv',index=False)
 benchmark=pd.read_csv(args.benchmark);names=[]
 for _,race in benchmark.iterrows():
  for party,label in [('DEM','DEMOCRAT'),('REP','REPUBLICAN')]:
   names.append({'year':race.year,'state_abbrev':race.state_abbrev,'party':party,'benchmark_name':race[f'candidate_{label}'],'identity':identity(race[f'candidate_{label}'])})
 names=pd.DataFrame(names)
 merged=[]
 for months in [18,21]:
  subset=out.loc[out.months.eq(months)&out.party.notna()]
  dup=subset.duplicated(['year','state_abbrev','party','identity'],keep=False)
  subset=subset.loc[~dup]
  x=names.loc[names.year.isin(subset.year)].merge(subset,on=['year','state_abbrev','party','identity'],how='left',validate='many_to_one')
  x['months']=months;x['money_observed']=x.receipts.notna()
  merged.append(x)
 joined=pd.concat(merged,ignore_index=True)
 joined.to_csv(ROOT/'benchmark_candidate_money.csv',index=False)
 counts=joined.groupby(['months','year']).agg(nominees=('benchmark_name','size'),with_money=('money_observed','sum'),with_fec_id=('candidate_id','count')).reset_index()
 pairs=joined.groupby(['months','year','state_abbrev']).money_observed.sum().eq(2).groupby(['months','year']).sum().rename('complete_races').reset_index()
 counts=counts.merge(pairs,on=['months','year'])
 counts.to_csv(ROOT/'static_coverage.csv',index=False)
 joined.loc[~joined.money_observed,['months','year','state_abbrev','party','benchmark_name']].to_csv(ROOT/'static_unmatched_nominees.csv',index=False)
 print(counts.to_string(index=False))
 print('all source rows',len(out),'id matched',out.candidate_id.notna().sum())
if __name__=='__main__':main()
