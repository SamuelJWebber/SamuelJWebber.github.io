> Distribution note: the package includes code and aggregate outputs. Raw inputs, individual modeled scores, merged samples and observation-level predictions mentioned below are regenerated in the external working directory by the top-level `reproduce.py`. Run optional source scripts inside that working copy to keep caches out of the checkout.

# Official pre-election Senate money summaries

The primary usable deliverable is `senate_june30_nominee_money.csv`: all 866 Democratic/Republican nominees in the independent benchmark for 1996–2022, with official June 30 money observed for 824 nominees. There are 391 complete two-party races across 14 cycles. Among 520 nominees without a comparable earlier Senate performance in that benchmark, 481 have observed money. These data therefore cover newcomers substantially better than the earlier-performance-only proxy.

`senate_june30_race_money.csv` contains one row per benchmark state election and D/R amounts and differences in log(1+amount). Raw signed amounts remain in the candidate file; log transforms clip the very few negative receipts/cash observations at zero. Total individual contributions are nonnegative in all observed benchmark rows. Prefer the individual-contribution measure for a simple initial fundraising signal: candidate self-funding and PAC/other-committee contributions are separate columns. No counts of contributors are contained in these financial summary files.

## Source and coverage window

All source money tables are official Federal Election Commission static statistical releases. Through 2010, Table 2 is “Senate Campaign Financial Activity by State”; from 2012, Table 5 is the Senate financial summary. The tables retain several two-year blocks from a senator's six-year election cycle. The code selects **only the block labeled with the current election year**, which covers January 1 of the previous year through June 30. It never sums the preceding four years.

The fixed download pattern is:

`https://www.fec.gov/resources/campaign-finance-statistics/YEAR/tables/congressional/ConCandTABLE_YEAR_18m.xlsx`

TABLE is 2 for 1996–2010 and 5 for 2012 onward. The 2016 workbook endpoint returned an error; its official PDF is available at the identical path ending `.pdf`. `parse_2016_pdf.py` extracts all 195 current-period candidate rows and eight monetary columns, with row text and page numbers retained. Their total receipts sum to $366,147,046, consistent with the FEC's published $366.1 million. All 195 extracted rows map to an official FEC candidate ID; no manual monetary changes are applied. The PDF itself states its publication date as September 9, 2016.

`financial_source_manifest.json` records exact downloaded URLs, sizes and SHA-256 hashes. `CHECKS.json` records coverage and validation. The modern file collection includes 2024, but the canonical 866-row nominee output stops at 2022 because that is the supplied audited roster's coverage.

## Dates and historical availability

June 30 is the financial activity cutoff, **not a claim these compiled amounts were available on July 15**. Modern FEC release dates are independently documented in `publication_dates.json` and exported on each row. The June releases were published during August–October before their general elections. The 2012 linked FEC Record article is October 31 and establishes availability by that date; it is not necessarily the initial release. Workbooks retain separate modification timestamps, which are file metadata and do not establish an initial publication date.

For the migrated 1996–2010 tables, original publication dates have not been verified. Treat that part of the data as retrospective amounts for a pre-election activity window. The timing of all later corrections and amendments cannot be reconstructed from these static tables. Any strict July 15 real-time forecast claim would need original reports and a filing-vintage audit.

The 2020 source explicitly notes delayed processing of some paper reports during COVID-19 office closures. Missing money is left missing, including nominees who had not raised reportable money or had not entered by the cutoff. Absence is never treated as a verified zero. Candidates who withdraw, switch offices, or make late replacements can complicate a financial roster; joining to the independently audited actual nominees avoids choosing nominees by their funding or votes, but does not solve historical vintage uncertainty.

An additional September 30 sensitivity currently covers 2022 only. Its FEC release date is January 5, 2023, after the election, and it is labeled retrospective rather than a contemporaneously available forecast input. It is in `nominee_money_all_windows.csv`.

## Candidate identity and outputs

`build_static_features.py` maps source table names to the FEC's official candidate master files using state, party, exact names and conservative surname/given-initial fallbacks. Candidate IDs prefer current-election Senate registrations where duplicate earlier House or Senate IDs exist. The full match audit is `static_fec_candidate_mapping.csv`.

`join_static_to_nominees.py` then joins by year and FEC candidate ID to the parent's audited `../nominee_fec_mapping.csv`, preserving its state/year/party/nominee choices. Independent Al Gross follows the existing benchmark's Democratic-side assignment, while the source party label remains independently recorded. Identical duplicate financial rows are collapsed only after checking equality of all eight amount fields; conflicting duplicates would stop the script.

Useful outputs:

- `senate_june30_nominee_money.csv`: canonical candidate-level input, D/R party labels.
- `senate_june30_race_money.csv`: paired features; missing-side indicators and explicit complete-pair flag.
- `nominee_money_coverage.csv`: canonical coverage by cycle.
- `senate_june_september_money.csv`: all source-table candidates with money and mappings.
- `nominee_money_all_windows.csv`: canonical rows including the separate September sensitivity.
- `ConCand5_2016_18m_pdf_extracted.csv`: reproducible PDF extraction audit.

Commands, with pandas/openpyxl/pdfplumber/numpy installed:

```sh
python acquire_static.py
python acquire_older_static.py
python parse_2016_pdf.py
python build_static_features.py --candidate-dir /path/to/fec-candidate-zips --benchmark /path/to/benchmark/sample.csv --state-source /path/to/mit_senate.tsv
python join_static_to_nominees.py --nominees /path/to/nominee_fec_mapping.csv
```

## Separate pre-general original-report acquisition

The earlier API route is retained as a timing-oriented alternative, not combined with the June primary measure. `acquire_reports.py` obtained complete original pre-general report pages for 1982–2010; the public DEMO_KEY then returned HTTP 429 at 2012, and requests stopped. A single 2020 page is partial and explicitly flagged incomplete. Existing cached reports were reused. `reports_manifest.json` records exact requests, hashes, pages and the failure.

`build_report_features.py` exports `senate_original_pregeneral_money.csv` by linking the principal campaign committee from the candidate master. It requires a report received before Election Day and coverage ending before that day. Standard-window amounts additionally require October 1 through the statutory 20th day before Election Day and are scaled by the number of days. It uses the latest original report received before the election; later amendments are not incorporated. It does not sum all authorized committees.

The F3 `_ytd` fields need particular care. FEC reporting changed from calendar-year reporting to election-cycle reporting beginning January 2001. A Senate election cycle can span six years. These fields are retained for audit but must not be treated as a uniform two-year fundraising measure. Cash snapshots and explicitly restricted report-period amounts avoid that specific horizon problem. The source rules are documented at:

- https://www.fec.gov/help-candidates-and-committees/filing-reports/election-cycle-aggregation/
- https://www.fec.gov/about/fec-historical-timeline/
- https://www.fec.gov/help-candidates-and-committees/filing-reports/pre-election-reports/

## Interpretation

Fundraising reflects popularity, access, campaign organization, wealth, opponents, expected competitiveness, donor strategy and the political environment. These amounts are possible predictors of electoral strength, not a pure measurement of charisma. Even a genuinely pre-election amount is endogenous to the race. A strong Senate-money signal does not alone identify causal coattails or distinguish mobilization from persuasion.

All outputs here are aggregate candidate/committee financial amounts and public candidate identities. No individual donor names, addresses, contact details, or transaction-level donor records are used by this summary-table route or exported in these outputs.
