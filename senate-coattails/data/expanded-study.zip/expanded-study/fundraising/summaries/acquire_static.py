"""Official FEC Senate tables through June30; no API key required."""
from pathlib import Path
import urllib.request,json,concurrent.futures,hashlib
ROOT=Path(__file__).resolve().parent

def get(year):
 name=f'ConCand5_{year}_18m.xlsx';url=f'https://www.fec.gov/resources/campaign-finance-statistics/{year}/tables/congressional/{name}';p=ROOT/name
 try:
  if not p.exists():p.write_bytes(urllib.request.urlopen(url,timeout=45).read())
  r={'year':year,'name':name,'url':url,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
 except Exception as e:r={'year':year,'name':name,'url':url,'error':str(e)}
 print(r,flush=True);return r
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:r=list(pool.map(get,range(2006,2026,2)))
(ROOT/'static_manifest.json').write_text(json.dumps(r,indent=2)+'\n')
