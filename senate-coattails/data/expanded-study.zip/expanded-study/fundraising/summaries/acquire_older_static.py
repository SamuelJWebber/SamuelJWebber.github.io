from pathlib import Path
import urllib.request,concurrent.futures,json,hashlib
P=Path(__file__).resolve().parent
jobs=[(y,f'ConCand2_{y}_18m.xlsx') for y in range(1996,2012,2)]+[(2016,'ConCand5_2016_18m.pdf')]
def get(job):
 y,name=job;url=f'https://www.fec.gov/resources/campaign-finance-statistics/{y}/tables/congressional/{name}';f=P/name
 try:
  if not f.exists():f.write_bytes(urllib.request.urlopen(url,timeout=45).read())
  r={'year':y,'name':name,'url':url,'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()}
 except Exception as e:r={'year':y,'name':name,'url':url,'error':str(e)}
 print(r,flush=True);return r
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as e:r=list(e.map(get,jobs))
(P/'older_static_manifest.json').write_text(json.dumps(r,indent=2)+'\n')
