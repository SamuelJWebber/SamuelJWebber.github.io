"""Join fixed-window FEC summary amounts to the audited independent nominee roster."""
from pathlib import Path
import argparse,json
import numpy as np
import pandas as pd
P=Path(__file__).resolve().parent
AMOUNTS=['receipts','individual_contributions','pac_other_committee_contributions','candidate_contributions_loans','transfers','disbursements','cash_on_hand','debts_owed']
# These are independently published release dates, not filing due dates. Earlier
# migrated tables remain retrospective coverage-date extracts until vintage audited.
PUBLICATION={2012:('2012-10-31','https://www.fec.gov/updates/fec-summarizes-first-18-months-of-campaign-activity-for-the-2012-election-cycle/'),2014:('2014-09-16','https://www.fec.gov/updates/fec-summarizes-18-month-campaign-activity-of-the-2013-2014-election-cycle/'),2016:('2016-09-09','https://www.fec.gov/updates/fec-summarizes-first-18-months-of-campaign-activity-for-2015-2016-election-cycle/'),2018:('2018-08-30','https://www.fec.gov/updates/statistical-summary-18-month-campaign-activity-2017-2018-election-cycle/'),2020:('2020-09-18','https://www.fec.gov/updates/statistical-summary-18-month-campaign-activity-2019-2020-election-cycle/'),2022:('2022-09-07','https://www.fec.gov/updates/statistical-summary-of-18-month-campaign-activity-of-the-2021-2022-election-cycle/'),2024:('2024-09-25','https://www.fec.gov/updates/statistical-summary-of-18-month-campaign-activity-of-the-2023-2024-election-cycle/')}

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--nominees',type=Path,default=P.parent/'nominee_fec_mapping.csv');a=ap.parse_args()
 source=pd.read_csv(P/'senate_june_september_money.csv')
 roster=pd.read_csv(a.nominees)
 out=[]
 for months in [18,21]:
  s=source.loc[source.months.eq(months)&source.candidate_id.notna()].copy()
  duplicate=s[s.duplicated(['year','candidate_id'],keep=False)]
  for _,g in duplicate.groupby(['year','candidate_id']):
   assert g[AMOUNTS].drop_duplicates().shape[0]==1,'Conflicting duplicate financial records'
  s=s.drop_duplicates(['year','candidate_id'])
  s=s.rename(columns={'state_abbrev':'source_state_abbrev','party':'source_party'})
  take=['year','candidate_id','source_state_abbrev','source_party','source_candidate_name','source_incumbency','coverage_start_date','coverage_end_date','workbook_modified_date','source_file','source_url']+AMOUNTS
  d=roster.loc[roster.year.isin(s.year)].merge(s[take],on=['year','candidate_id'],how='left',validate='one_to_one')
  d['money_observed']=d.receipts.notna();d['months']=months
  assert d.loc[d.money_observed,'state_abbrev'].eq(d.loc[d.money_observed,'source_state_abbrev']).all()
  d['known_publication_date']=d.year.map({y:x[0] for y,x in PUBLICATION.items()})
  d['publication_source_url']=d.year.map({y:x[1] for y,x in PUBLICATION.items()})
  if months==21:
   d.loc[d.year.eq(2022),'known_publication_date']='2023-01-05'
   d.loc[d.year.eq(2022),'publication_source_url']='https://www.fec.gov/updates/statistical-summary-of-21-month-campaign-activity-of-the-2021-2022-election-cycle/'
  d['vintage_status']=np.where(d.known_publication_date.notna(),'pre-election coverage; release date audited; not a July15 vintage','pre-election coverage; historical release date not verified')
  if months==21:d['vintage_status']='pre-election coverage; release after election; retrospective sensitivity only'
  out.append(d)
 d=pd.concat(out,ignore_index=True)
 d.to_csv(P/'nominee_money_all_windows.csv',index=False)
 june=d.loc[d.months.eq(18)].copy();june.to_csv(P/'senate_june30_nominee_money.csv',index=False)
 wide=june.pivot(index=['state_abbrev','year'],columns='party',values=AMOUNTS+['candidate_id','benchmark_candidate','money_observed'])
 wide.columns=[f'{x}_{p}' for x,p in wide.columns];wide=wide.reset_index()
 for f in AMOUNTS:
  for side in ['D','R']:wide[f+'_'+side]=pd.to_numeric(wide[f+'_'+side],errors='coerce')
  wide['log_'+f+'_DminusR']=np.log1p(wide[f+'_D'].clip(lower=0))-np.log1p(wide[f+'_R'].clip(lower=0))
 wide['both_observed']=wide.money_observed_D & wide.money_observed_R
 wide.to_csv(P/'senate_june30_race_money.csv',index=False)
 coverage=june.groupby('year').agg(nominees=('candidate_id','size'),money_observed=('money_observed','sum')).join(wide.groupby('year').both_observed.sum().rename('complete_races')).reset_index()
 coverage.to_csv(P/'nominee_money_coverage.csv',index=False)
 (P/'publication_dates.json').write_text(json.dumps({str(y):{'date':v[0],'url':v[1]} for y,v in PUBLICATION.items()},indent=2)+'\n')
 print(coverage.to_string(index=False));print('TOTAL',len(june),'nominees;',june.money_observed.sum(),'withmoney;',wide.both_observed.sum(),'complete races')
if __name__=='__main__':main()
