"""Extract official 2016 table5's current two-year block from its public PDF.
The official workbook URL is unavailable. PDF values are read from eight monetary
columns; page/row text is retained for auditing the candidate identity join.
"""
from pathlib import Path
import re,pdfplumber,pandas as pd
P=Path(__file__).resolve().parent
rows=[]
with pdfplumber.open(P/'ConCand5_2016_18m.pdf') as pdf:
 for page_number,page in enumerate(pdf.pages,1):
  words=page.extract_words(x_tolerance=1,y_tolerance=1)
  anchors=[w for w in words if w['text']=='2016' and 350<w['x0']<420]
  for anchor in anchors:
   line=sorted([w for w in words if abs(w['top']-anchor['top'])<1],key=lambda w:w['x0'])
   money=[w['text'] for w in line if w['x0']>415 and re.fullmatch(r'\(?-?\$[\d,]+(?:\.\d+)?\)?',w['text'])]
   assert len(money)==8,(page_number,anchor,line)
   numeric=[float(x.replace('$','').replace(',','').replace('(','-').replace(')','')) for x in money]
   state=' '.join(w['text'] for w in line if w['x0']<74)
   name=' '.join(w['text'] for w in line if 74<=w['x0']<190)
   # Very long names overlap the printed party column. Their surnames/first given
   # names remain legible and are validated against the independent FEC roster.
   nearparty=' '.join(w['text'] for w in line if 170<=w['x0']<290)
   if 'ocratic' in nearparty:party='Democratic Party'
   elif 'publican' in nearparty:party='Republican Party'
   else:party=' '.join(w['text'] for w in line if 198<=w['x0']<290)
   status=' '.join(w['text'] for w in line if 290<=w['x0']<360)
   rows.append([state,name,party,status,2016,*numeric,page_number,' '.join(w['text'] for w in line)])
fields=['state_name','source_candidate_name','party_label','source_incumbency','two_year_period','receipts','individual_contributions','pac_other_committee_contributions','candidate_contributions_loans','transfers','disbursements','cash_on_hand','debts_owed','pdf_page','pdf_row_text']
d=pd.DataFrame(rows,columns=fields)
assert len(d)==195,len(d)
assert abs(d.receipts.sum()-366100000)<100000
# No manual numeric changes are applied.
d.to_csv(P/'ConCand5_2016_18m_pdf_extracted.csv',index=False)
print('2016 PDF rows',len(d),'receipts',d.receipts.sum(),'party counts',d.party_label.value_counts().to_dict())
