"""Audited general-election nominee mapping to official FEC candidate identifiers."""
from pathlib import Path
import argparse,importlib.util,json
import numpy as np,pandas as pd
from aggregate_bulk import readzip,CN,R,P
q=P/'name_rules.py'
spec=importlib.util.spec_from_file_location('quality_names',q);names=importlib.util.module_from_spec(spec);spec.loader.exec_module(names)

def main():
 parser=argparse.ArgumentParser(description=__doc__)
 parser.add_argument('--benchmark',type=Path,default=P.parent.parent/'coattails_prediction/sample.csv')
 args=parser.parse_args()
 s=pd.read_csv(args.benchmark);s=s[s.year.between(1996,2022)]
 rows=[];reviews=[]
 for year,group in s.groupby('year'):
  c=readzip(R/f'cn{str(year)[-2:]}.zip',CN)
  c=c[c.office.eq('S') & c.candidate_id.str.startswith('S')].drop_duplicates('candidate_id')
  c['party']=c.party.replace({'DFL':'DEM'})
  c['last']=[names.parts(n,st)[0] for n,st in zip(c.candidate_name,c.state_abbrev)]
  c['first']=[names.parts(n,st)[1] for n,st in zip(c.candidate_name,c.state_abbrev)]
  for _,r in group.iterrows():
   for side,party,label in [('D','DEM','DEMOCRAT'),('R','REP','REPUBLICAN')]:
    name=r[f'candidate_{label}'];last,first=names.parts(name,r.state_abbrev)
    pool=c[c.state_abbrev.eq(r.state_abbrev)&c.party.eq(party)]
    m=pool[pool['last'].eq(last)&pool['first'].eq(first)];method='surname_given_alias'
    override={('AK',1996,'R'):'S2AK00010',('AK',2002,'R'):'S2AK00010',('AK',2008,'R'):'S2AK00010',
              ('IA',2004,'D'):'S4IA00046',('OH',2006,'R'):'S2OH00113',('AK',2020,'D'):'S0AK00196',
              ('WV',2020,'D'):'S0WV00215'}.get((r.state_abbrev,year,side))
    if override:
     m=c[c.candidate_id.eq(override)];method='audited_legal_name_or_duplicate_registration'
    if len(m)==0:
     m=pool[pool['last'].eq(last)&pool['first'].str[0].eq(first[0])];method='surname_first_initial'
    out={'state_abbrev':r.state_abbrev,'year':year,'party':side,'benchmark_candidate':name,'candidate_id':None,'fec_candidate':None,'match_method':method}
    if len(m)==1:
     z=m.iloc[0];out.update(candidate_id=z.candidate_id,fec_candidate=z.candidate_name,fec_election_year=z.election_year)
    else:
     out['match_method']='unmatched' if len(m)==0 else 'ambiguous'
     rev=dict(out);rev['possible_matches']=' | '.join(pool.candidate_id+':'+pool.candidate_name);reviews.append(rev)
    rows.append(out)
 x=pd.DataFrame(rows);x.to_csv(P/'nominee_fec_mapping.csv',index=False);pd.DataFrame(reviews).to_csv(P/'nominee_fec_unresolved.csv',index=False)
 print(x.groupby('match_method').size());print(pd.DataFrame(reviews)[['state_abbrev','year','party','benchmark_candidate']].to_string(index=False) if reviews else 'No unresolved')
if __name__=='__main__':main()
