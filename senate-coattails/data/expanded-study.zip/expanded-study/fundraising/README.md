> Distribution note: the package includes code and aggregate outputs. Raw inputs, individual modeled scores, merged samples and observation-level predictions mentioned below are regenerated in the external working directory by the top-level `reproduce.py`. Run optional source scripts inside that working copy to keep caches out of the checkout.

# Senate fundraising and disclosed contributor breadth, 1996–2022

This input project supplies pre-general-election fundraising proxies for Senate nominees, including newcomers. It does not select an all-star model or estimate coattails. Model selection belongs to the separate own-Senate-outcome validation pipeline; House and governor outcomes must not choose these features.

The primary activity cutoff is June 30 of the election year, starting January 1 of the preceding year. September 30 is a separately declared sensitivity. Neither window includes later general-election or runoff contributions. These are retrospectively assembled, receipt-date-defined features. They are not verified historical July 15 data vintages.

Final coverage is **853 of 866 nominees** and **420 of 433 complete D/R races** across all 14 cycles, including all 2020 and 2022 benchmark nominees. Of 520 nominees without an earlier comparable Senate result, 508 have observed breadth. Thirteen nominees lack a usable campaign-committee mapping and remain missing.

## Ready modeling files

* `nominee_fec_mapping.csv`: audited state/year/party nominee-to-FEC-ID mapping, including all 866 benchmark nominees in 1996–2022. The original benchmark supplies ballot eligibility; final margins never choose a match.
* `nominee_breadth_features.csv`: candidate-level June/September receipt-window proxies and prior-Census denominators. `bulk_cycle_available` and `committee_mapped` distinguish missing sources/mappings from observed zero disclosed records.
* `race_breadth_features.csv`: the same measures in D/R columns, with explicit `paired_breadth_observed` requiring available bulk data and both committee mappings.
* `coverage.csv`: nominee and complete-race coverage by cycle and window. Inspect this rather than interpreting unavailable cycles as zeros.
* `summaries/senate_june30_nominee_money.csv`: separate official June 30 financial-summary data, 824 observed nominees out of 866 and 391 complete races. Includes 481 of 520 nominees without a comparable earlier Senate result. See that folder's README and provenance for exact official workbook/PDF sources and dates.
* `summaries/senate_june30_race_money.csv`: corresponding D/R official financial amounts.

## Breadth definitions

The receipt source is the official FEC individual-contribution bulk archive. Recipient committees must be linked to a Senate candidate as principal or authorized campaign committees. The analysis includes positive type 15 or 15E receipts whose entity is IND or unspecified, and excludes candidate self-funding, known nonindividual entities, intermediary pass-through legs, and refunds. Blank entity type is needed for historical paper filings, and can include partnerships or LLCs; the proxy is therefore approximate disclosed contributor identities rather than a census of verified people.

`approx_contributors_national` counts distinct uppercased, punctuation/whitespace-normalized contributor names joined to a five-digit ZIP prefix across all eligible authorized committees. The label “national” denotes the campaign's total reported locations, not an independently verified census of US residents. `approx_contributors_in_state` counts identities with at least one qualifying record whose reported STATE matches the candidate's state. Identity matching can merge same-name people and split aliases, titles, address moves, or ZIP variants. Honorifics and generational suffixes are retained; a bounded audit found title/alias normalization can change some prominent candidate counts by several percent. Five-digit placeholder ZIPs can also enter this approximate primary definition and are a small measurement limitation.

`approx_contributors_gt200_national` and `approx_contributors_gt200_in_state` restrict the union to identities with at least one positive individual receipt strictly greater than$200 before the cutoff. This declared threshold sensitivity reduces a source change: before 2015 the bulk files included reporting-period amounts of at least$200; from 2015 they use candidate-cycle cumulative amounts over$200. A donor crossing the cumulative threshold afterJune 30 can cause an earlier small gift to appear in a later extract. The >$200-single-gift check avoids that particular source of later-threshold visibility, while later amendments can still affect every retrospective version.

`positive_individual_records` is the number of qualifying disclosed records after removing duplicate FEC SUB_ID rows. It is not necessarily the number of original payments. `positive_itemized_dollars` sums gross positive amounts; it is an audit measure, not net fundraising. Memo entries and amendments can overlap, and refunds/negative corrections are not subtracted. In a bounded 2018 audit, some campaigns' gross bulk dollars exceeded official individual-receipt summaries. Use the official financial-summary amount for monetary prediction features. Identity unions are much less sensitive to duplicate records with the same normalized identity.

Memo records are retained, consistent with FEC's bulk-file documentation: earmarked individual details can be memo items. OTHER_ID is not required to be blank, because earmarked individual contributions can contain conduit identifiers. All amendments are not discarded; a true amendment-chain reconstruction would require report-level lineage. The scripts record duplicate SUB_IDs and potential repeated electronic transaction IDs as diagnostics. No contributor names, addresses, identity hashes, or individual transaction rows are exported.

`donor_zip5_count` counts reported numeric ZIP prefixes; `donor_state_count` counts reported two-letter postal jurisdictions, which can include military or nonstate codes. These auxiliary fields are not independent demographic reach measurements.

## Population and timing

The four contributor-count measures also appear per 100,000 prior-Census residents. The denominator comes from `/tmp/coattails_stage3/population/prior_census_population.csv`: the latest decennial Census strictly preceding the election year. For example, a 2000 election uses 1990 Census population. These are residents in an older Census, not current population, eligible voters, or turnout. National contributions per home-state resident can reflect attention from outside the electorate; in-state counts have a closer geographic relationship to same-ballot voters.

June 30 is before the general election but after some states' primaries. It must not be described as a common pre-primary cutoff. Official compiled June 30 money tables were published during August–October in verified modern cycles, after the July reporting deadline and before the general election. Earlier original release dates are not fully verified. Source summaries include reported unitemized individual dollars; the bulk identity counts do not observe every small donor. Senate six-year cumulative totals from the separate pre-general report API must not be silently substituted for the consistent 18-month static-summary amounts.

Fundraising responds to competitiveness, national attention, opponents, party investment and campaign strategy. No final margin is used to build these inputs. Models should handle prior state lean, its absolute value, incumbency, missing histories, and missing fundraising using training data only. A useful prediction proxy would still not identify personal charisma or a causal spillover.

## Reproduce

Requirements: Python 3, pandas and NumPy; financial workbooks/PDFs need the dependencies described under `summaries/`.

```sh
python download_bulk.py
python map_nominees.py --benchmark /path/to/frozen_senate_sample.csv
OPENBLAS_NUM_THREADS=1 python aggregate_stream.py --years 1996 1998 2000 2002 2004 2006 2008 2010 2012 2014 2016 2018 2020 2022
python build_features.py --population /path/to/prior_census_population.csv
```

The download is large (roughly 15 GB compressed across these cycles). Files are streamed without extracting the full uncompressed archive to disk. `aggregate_bulk.py` is the original in-memory implementation, used through 2020. The bounded-memory `aggregate_stream.py` is mathematically equivalent for candidate totals and identity unions, using internal 64-bit hashes to bound memory; no identities or hashes are exported. Its equivalence was verified on all 994 candidate-window rows and 11 output measures in 2006. Hash collisions have negligible probability at this scale, and the underlying name/ZIP measure is already approximate. Prefer the streaming command for large recent cycles.

Candidate mappings use official candidate-master and candidate-committee files. The 1996/1998 linkage ZIPs do not exist, so official committee-master plus principal-committee fields supply those links. Ambiguous committees connected to different candidate registrations are excluded unless a duplicate registration was explicitly audited. Corrections include Minnesota DFL affiliation, Ted Stevens and Mike DeWine legal-name variants, and the current Senate registrations of Roger Marshall and Paula Jean Swearengin. Alaska 2020 Al Gross is an independent placed in the benchmark's Democratic slot; his actual FEC candidate ID is used and the distinction is retained in the audit.

## Official sources

* [FEC individual bulk schema and historical inclusion thresholds](https://www.fec.gov/campaign-finance-data/contributions-individuals-file-description/).
* [FEC candidate–committee linkage schema](https://www.fec.gov/campaign-finance-data/candidate-committee-linkage-file-description/).
* [FEC transaction type definitions](https://www.fec.gov/campaign-finance-data/transaction-type-code-descriptions/).
* [FEC individual-aggregation methodology](https://www.fec.gov/campaign-finance-data/about-campaign-finance-data/methodology/).
* [FEC bulk downloads](https://www.fec.gov/data/browse-data/?tab=bulk-data).

Exact file URLs, sizes and SHA-256 fingerprints are in `source_manifest.json`. Statistical tables and numeric aggregates are the only intended public deliverables. Original contributor bulk archives remain local research inputs under FEC's sale/use restrictions and must not be bundled into the user-facing study archive.
