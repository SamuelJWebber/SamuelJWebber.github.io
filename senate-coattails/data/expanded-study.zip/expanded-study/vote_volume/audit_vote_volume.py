"""Independently reproduce target coefficients via FWL and clustered covariance."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from scipy.stats import t

ROOT = Path(__file__).resolve().parent


def main():
    reported = pd.read_csv(ROOT / 'estimates.csv')
    checks = []
    for model in ['broad_history', 'donor_breadth_exploratory']:
        for outcome, kind in [('party_house_votes', 'party'), ('total_reported_house_votes', 'total')]:
            d = pd.read_csv(ROOT / f'{model}_{kind}_panel.csv')
            if kind == 'party':
                targets = ['own_quality_10pp', 'opponent_quality_10pp']
                controls = ['lag_volume', 'own_incumbent', 'opponent_incumbent', 'own_observed', 'opponent_observed']
                fixed = ['state_party', 'year_party']
            else:
                targets = ['quality_D_10pp', 'quality_R_10pp']
                controls = ['lag_volume', 'incumbent_D', 'incumbent_R', 'observed_D', 'observed_R']
                fixed = ['state_abbrev', 'year']
            z = np.column_stack([np.ones(len(d)), d[controls].to_numpy(float),
                *[pd.get_dummies(d[c], drop_first=True, dtype=float).to_numpy() for c in fixed]])
            target = d[targets].to_numpy(float); y = d.outcome.to_numpy(float)
            xr = target - z @ np.linalg.lstsq(z, target, rcond=None)[0]
            yr = y - z @ np.linalg.lstsq(z, y, rcond=None)[0]
            b = np.linalg.solve(xr.T @ xr, xr.T @ yr)
            residual = yr - xr @ b
            states = sorted(d.state_abbrev.unique())
            cluster = np.array([xr[d.state_abbrev.eq(s)].T @ residual[d.state_abbrev.eq(s)] for s in states])
            bread = np.linalg.inv(xr.T @ xr)
            rank = np.linalg.matrix_rank(np.column_stack([target, z]))
            cov = bread @ (cluster.T @ cluster) @ bread
            cov *= len(states) / (len(states) - 1) * (len(d) - 1) / (len(d) - rank)
            critical = t.ppf(.975, len(states) - 1)
            comparison = reported[reported.score_model.eq(model) & reported.outcome.eq(outcome)]
            errors = []
            for (_, row), contrast in zip(comparison.iterrows(), [np.array([1, 0]), np.array([0, 1]), np.array([1, 1])]):
                estimate = contrast @ b; se = np.sqrt(contrast @ cov @ contrast)
                errors.extend([abs(estimate - row.estimate_votes_per100_residents),
                    abs(estimate - critical * se - row.low95), abs(estimate + critical * se - row.high95)])
            assert max(errors) < 1e-7
            assert d.district_count_complete.all() and d[f'included_{kind}'].all()
            assert d.score_training_last_year.lt(d.year).all() and d.population_census_year.lt(d.year).all()
            checks.append({'model': model, 'outcome': outcome, 'n': len(d), 'states': len(states),
                           'rank': int(rank), 'max_estimate_or_ci_difference': float(max(errors))})
    expected = pd.read_csv(ROOT / 'expected_districts.csv')
    assert len(expected) == 1100
    assert expected.groupby('year').expected_districts.sum().eq(435).all()
    assert expected.groupby('year').size().eq(50).all()
    audit = {'independent_method': 'FWL nuisance residualization, target2x2solve and state-cluster sandwich; full-design rank correction.',
             'results': checks, 'apportionment_check': '50states and435seats for each1980–2022election.',
             'data_checks': 'All analysis rows have complete district counts, earlier score fitting and strictly prior population.'}
    (ROOT / 'independent_numerical_audit.json').write_text(json.dumps(audit, indent=2))
    print(json.dumps(audit, indent=2))


if __name__ == '__main__':
    main()
