# Secondary House vote volume

The count-based checks preserve the possibility of mobilization by both parties. They use separate own- and opposing-candidate scores instead of subtracting their strength. The frozen quality models were not retuned for these outcomes. This secondary specification was fixed before its own estimates, after the primary analyses; it is not study-level preregistration.

The main history-based estimate is **−0.34 additional same-party House votes per100 prior-census residents** for a10-point increase in predicted Senate candidate contribution, with a95% state-clustered interval of **−4.29 to+3.61**. The donor-score estimate is **+0.05 [−1.33,+1.43]**, explicitly exploratory because that proxy failed held-out own-race validation. Neither supports a precise positive own-party volume effect.

| Frozen score | Outcome and contrast | Estimate | 95% interval | State-elections | States |
|---|---|---:|---:|---:|---:|
| History | Focal-party votes, own score+10points | −0.344 | −4.294 to3.606 | 221 | 41 |
| History | Focal-party votes, opponent score+10points | 1.618 | −1.356 to4.592 | 221 | 41 |
| History | Focal-party votes, both scores+10points | 1.274 | −2.641 to5.189 | 221 | 41 |
| Exploratory donor breadth | Focal-party votes, own score+10points | 0.051 | −1.328 to1.429 | 149 | 39 |
| Exploratory donor breadth | Focal-party votes, opponent score+10points | −0.087 | −1.532 to1.358 | 149 | 39 |
| Exploratory donor breadth | Focal-party votes, both scores+10points | −0.037 | −1.216 to1.143 | 149 | 39 |
| History | All reported House votes, both scores+10points | −0.039 | −3.762 to3.683 | 411 | 48 |
| Exploratory donor breadth | All reported House votes, both scores+10points | 1.298 | 0.002 to2.594 | 270 | 48 |

All outcome estimates are votes per100 residents in the most recent strictly prior census. **They are not turnout rates**: the denominator includes children and noncitizens and may be up to10years old. Recorded House votes also differ from all ballots cast because of roll-off. The history party-count sample's mean is19.68 votes per100 residents; the donor sample's mean is20.06. Broader total-vote means are38.76 and39.88, respectively.

The last table row is one marginal nominal interval among multiple secondary contrasts, from a failed-validation donor proxy and a different, broader reporting sample. It does not establish mobilization. All contrasts, including separate D and R effects on total votes, are retained in `estimates.csv`.

## Coverage and interpretation

The party outcome requires all officially apportioned districts and directly reported D/R vote counts in every district in both the current and previous election. Missing counts are not replaced by zeros. Counts must be nonnegative, reported totals positive, and D+R no larger than the total. Complete reporting is selective: **California, Florida, New York and Texas never enter either party-count estimation sample**. Louisiana is absent from the underlying district source. Texas1996 has24/30 expected districts and2006 has29/32; the seat-count check excludes these incomplete aggregates.

The separate all-House-votes check permits missing party counts when the total is positive and all known party counts are consistent. Its larger sample is displayed separately. Total votes include votes outside the D/R pair; the result is not merely the sum of two-party counts on the smaller sample.

The party regression stacks D and R outcomes with shared own/opponent slopes. Each outcome uses the lagged same-party vote count divided by the current denominator, state×party and year×party fixed effects, pre-election own/opponent Senate incumbency and score-availability flags. The total model uses separate D/R score slopes, a lagged total using the current denominator, state/year fixed effects, and analogous controls. Both cluster uncertainty by state. Current turnout and spending are not controls.

For the party regression, the coefficient sum describes **one focal party's** response when both Senate scores rise10points. Under its shared-slope additive assumption, the implied D+R response when both rise is twice this sum. The separate total-vote model's sum is already the response of the full reported House-vote total. Neither is a two-star interaction estimate. The history samples contain no races where both candidates exceed the frozen high-tail cutoff; the donor samples contain20 such races. Thus a two-high-score history comparison depends on additive extrapolation.

The associations combine pathways that could include mobilization, vote switching, campaign conditions and candidate selection. They do not causally separate turnout from persuasion. Lagged House votes can contain earlier candidate influence, and state-specific waves remain possible confounders. The broad history model lacks an observed history for272 of442 party observations; their score is the unknown reference with explicit availability controls. Donor histories are fully observed in their matched sample, but incomplete disclosure and retrospective amendments remain source limitations.

## Reproduce and audit

`build_expected_districts.py` reads the official Census apportionment compilation. The allocation for census yearC first applies to the C+2 House election. Each1980–2022 election has50states and435expected seats. `expected_districts_provenance.json` records the source and hash.

```bash
OPENBLAS_NUM_THREADS=1 python analyze_vote_volume.py --house HOUSE_DISTRICTS_CSV --population PRIOR_CENSUS_POPULATION_CSV --expected-districts EXPECTED_DISTRICTS_CSV --joint JOINT_SAMPLE_CSV --broad-scores BROAD_FROZEN_SCORES_CSV --donor-scores DONOR_FROZEN_SCORES_CSV --output OUTPUT_DIR
```

Dependencies are numpy, pandas and scipy. All paths are CLI arguments. The upstream score construction and source download instructions are in the main package. No new quality training occurs here.

Shareable aggregate outputs are `estimates.csv`, `coverage.csv`, `summary.json` and `independent_numerical_audit.json`. The numerical audit independently residualizes fixed effects and reproduces all four models' coefficients and clustered intervals within4.5e−13. Local row-level eligibility, panels and reporting audits are regenerated from the licensed House input and omitted from the redistribution package.
