"""Official Census apportionment seat counts for House election completeness.

Decennial allocations apply to the election two years after the census:
1980 uses1970, 1982–1990 use1980, and2022 uses2020.
"""
from pathlib import Path
import argparse
import csv
import hashlib
import json

NAMES = 'Alabama|Alaska|Arizona|Arkansas|California|Colorado|Connecticut|Delaware|Florida|Georgia|Hawaii|Idaho|Illinois|Indiana|Iowa|Kansas|Kentucky|Louisiana|Maine|Maryland|Massachusetts|Michigan|Minnesota|Mississippi|Missouri|Montana|Nebraska|Nevada|New Hampshire|New Jersey|New Mexico|New York|North Carolina|North Dakota|Ohio|Oklahoma|Oregon|Pennsylvania|Rhode Island|South Carolina|South Dakota|Tennessee|Texas|Utah|Vermont|Virginia|Washington|West Virginia|Wisconsin|Wyoming'.split('|')
ABBR = 'AL AK AZ AR CA CO CT DE FL GA HI ID IL IN IA KS KY LA ME MD MA MI MN MS MO MT NE NV NH NJ NM NY NC ND OH OK OR PA RI SC SD TN TX UT VT VA WA WV WI WY'.split()
URL = 'https://www2.census.gov/programs-surveys/decennial/2020/data/apportionment/apportionment.csv'
PAGE = 'https://www.census.gov/data/tables/time-series/dec/apportionment-data-text.html'


def main():
    root = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, default=root.parent / 'population/apportionment.csv')
    parser.add_argument('--output', type=Path, default=root)
    args = parser.parse_args(); args.output.mkdir(parents=True, exist_ok=True)
    with args.source.open(encoding='utf-8-sig') as handle:
        records = list(csv.DictReader(handle))
    lookup = {(r['Name'], int(r['Year'])): int(r['Number of Representatives'])
              for r in records if r['Geography Type'] == 'State' and r['Name'] in NAMES and int(r['Year']) >= 1970}
    for census in range(1970, 2021, 10):
        assert sum(lookup[state, census] for state in NAMES) == 435
    rows = []
    for state, abbreviation in zip(NAMES, ABBR):
        for year in range(1980, 2023, 2):
            census = (year - 2) // 10 * 10
            rows.append({'state_abbrev': abbreviation, 'year': year,
                         'expected_districts': lookup[state, census], 'apportionment_census_year': census})
    assert len(rows) == 1100
    for year in range(1980, 2023, 2):
        assert sum(r['expected_districts'] for r in rows if r['year'] == year) == 435
    with (args.output / 'expected_districts.csv').open('w', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)
    provenance = {'source_url': URL, 'source_page': PAGE,
                  'source_sha256': hashlib.sha256(args.source.read_bytes()).hexdigest(),
                  'source_field': 'Number of Representatives',
                  'rule': 'Apportionment census year=floor((electionyear−2)/10)*10; allocation first used in election censusyear+2.',
                  'checks': '50states and435seats for each1980–2022election; each1970–2020census allocation sums435.',
                  'rows': len(rows), 'first_election': 1980, 'last_election': 2022}
    (args.output / 'expected_districts_provenance.json').write_text(json.dumps(provenance, indent=2))
    print(f'Wrote {len(rows)} state-year expected seat counts; every election totals435.')


if __name__ == '__main__':
    main()
