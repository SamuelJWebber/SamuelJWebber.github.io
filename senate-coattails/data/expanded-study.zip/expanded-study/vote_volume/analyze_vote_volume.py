"""Secondary House vote-volume association specified before its own fit.

No quality selection or retuning uses a House outcome. Votes per100 prior-census
residents are not turnout rates. Donor-score results remain exploratory because
that model failed its held-out own-vote comparison.
"""
import argparse,hashlib,json
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import t

ROOT=Path(__file__).resolve().parent
KEY=['state_abbrev','year']


def build_house(house,expected):
 h=house.loc[house.year.between(1980,2022)].copy()
 assert not h.duplicated(KEY+['dist']).any()
 numeric=h[['votes_d','votes_r','votes_total']]
 h['party_complete']=numeric.notna().all(axis=1)&numeric.ge(0).all(axis=1)&h.votes_total.gt(0)&(h.votes_d+h.votes_r).le(h.votes_total+.5)
 h['known_count_consistent']=h.votes_d.fillna(0).ge(0)&h.votes_r.fillna(0).ge(0)&h.votes_d.fillna(0).le(h.votes_total+.5)&h.votes_r.fillna(0).le(h.votes_total+.5)
 both=h.votes_d.notna()&h.votes_r.notna()
 h.loc[both,'known_count_consistent']&=(h.loc[both,'votes_d']+h.loc[both,'votes_r']).le(h.loc[both,'votes_total']+.5)
 # fillna above tests reported counts only; it is never used to sum/impute votes.
 h['total_complete']=h.votes_total.notna()&h.votes_total.gt(0)&h.known_count_consistent
 rows=[]
 for (state,year),x in h.groupby(KEY):
  rows.append({'state_abbrev':state,'year':int(year),'source_districts':len(x),'source_unique_districts':x.dist.nunique(),
   'all_party_counts_reported':bool(x.party_complete.all()),'all_total_counts_reported':bool(x.total_complete.all()),
   'districts_missing_party_counts':int(x[['votes_d','votes_r']].isna().any(axis=1).sum()),
   'districts_zero_or_missing_total':int((x.votes_total.isna()|x.votes_total.le(0)).sum()),
   'districts_inconsistent_counts':int((~x.known_count_consistent).sum()),
   'votes_D':x.votes_d.sum(min_count=len(x)),'votes_R':x.votes_r.sum(min_count=len(x)),
   'votes_total':x.votes_total.sum(min_count=len(x))})
 a=pd.DataFrame(rows).merge(expected,on=KEY,how='outer',validate='one_to_one')
 a['district_count_complete']=a.source_districts.eq(a.expected_districts)&a.source_unique_districts.eq(a.expected_districts)
 for category in ['party','total']:a[f'{category}_eligible']=a.district_count_complete&a[f'all_{category}_counts_reported'].eq(True)
 lag=a[KEY+['party_eligible','total_eligible','votes_D','votes_R','votes_total']].copy();lag['year']+=2
 lag=lag.rename(columns={c:'lag_'+c for c in lag if c not in KEY})
 return a.merge(lag,on=KEY,how='left',validate='one_to_one')


def prepare(house,population,joint,scores,label):
 for d in [population,joint,scores]:assert not d.duplicated(KEY).any()
 x=scores.merge(joint[KEY+['incumbency']],on=KEY,validate='one_to_one').merge(house,on=KEY,how='left',validate='one_to_one').merge(population,on=KEY,how='left',validate='one_to_one')
 x['score_model']=label
 x['score_defined']=x.quality_score_D.notna()&x.quality_score_R.notna()&x.score_training_last_year.lt(x.year)
 x['population_known']=x.prior_census_population.gt(0)&x.population_census_year.lt(x.year)
 for category in ['party','total']:
  x[f'included_{category}']=x.score_defined&x.population_known&x[f'{category}_eligible'].eq(True)&x[f'lag_{category}_eligible'].eq(True)
 return x


def party_stack(a):
 rows=[]
 for side,other,sign in [('D','R',1),('R','D',-1)]:
  x=a.loc[a.included_party].copy();x['party']=side
  x['outcome']=100*x[f'votes_{side}']/x.prior_census_population
  x['lag_volume']=100*x[f'lag_votes_{side}']/x.prior_census_population
  x['own_quality_10pp']=10*x[f'quality_score_{side}'];x['opponent_quality_10pp']=10*x[f'quality_score_{other}']
  x['own_incumbent']=x.incumbency.eq(sign).astype(int);x['opponent_incumbent']=x.incumbency.eq(-sign).astype(int)
  x['own_observed']=x[f'quality_observed_{side}'].astype(int);x['opponent_observed']=x[f'quality_observed_{other}'].astype(int)
  x['state_party']=x.state_abbrev+'-'+side;x['year_party']=x.year.astype(str)+'-'+side
  rows.append(x)
 return pd.concat(rows,ignore_index=True)


def total_frame(a):
 x=a.loc[a.included_total].copy();x['outcome']=100*x.votes_total/x.prior_census_population
 x['lag_volume']=100*x.lag_votes_total/x.prior_census_population
 for side,sign in [('D',1),('R',-1)]:
  x[f'quality_{side}_10pp']=10*x[f'quality_score_{side}'];x[f'incumbent_{side}']=x.incumbency.eq(sign).astype(int);x[f'observed_{side}']=x[f'quality_observed_{side}'].astype(int)
 return x


def estimate(frame,features,fe,contrasts,outcome_label,model):
 nuisance=[pd.get_dummies(frame[c],drop_first=True,dtype=float).to_numpy() for c in fe]
 x=np.column_stack([np.ones(len(frame)),frame[features].to_numpy(float),*nuisance]);y=frame.outcome.to_numpy(float)
 coef,_,rank,_=np.linalg.lstsq(x,y,rcond=None);resid=y-x@coef
 groups,indices=np.unique(frame.state_abbrev,return_inverse=True);cluster_scores=np.zeros((len(groups),x.shape[1]));np.add.at(cluster_scores,indices,x*resid[:,None])
 bread=np.linalg.pinv(x.T@x);cov=bread@cluster_scores.T@cluster_scores@bread
 cov*=len(groups)/(len(groups)-1)*(len(frame)-1)/(len(frame)-rank);critical=t.ppf(.975,len(groups)-1)
 # Check the two target score columns survive nuisance fixed effects.
 targets=frame[features[:2]].to_numpy(float);z=np.column_stack([np.ones(len(frame)),frame[features[2:]].to_numpy(float),*nuisance]);target_resid=targets-z@np.linalg.lstsq(z,targets,rcond=None)[0]
 assert np.linalg.matrix_rank(target_resid)==2
 results=[]
 for name,weights in contrasts.items():
  vector=np.zeros(x.shape[1])
  for feature,value in weights.items():vector[1+features.index(feature)]=value
  value=float(vector@coef);se=float(np.sqrt(max(0,vector@cov@vector)))
  results.append({'score_model':model,'outcome':outcome_label,'contrast':name,'estimate_votes_per100_residents':value,'se':se,'low95':value-critical*se,'high95':value+critical*se,'state_elections':len(frame[KEY].drop_duplicates()),'party_observations':len(frame) if outcome_label=='party_house_votes' else 0,'regression_observations':len(frame),'states':len(groups),'first_year':int(frame.year.min()),'last_year':int(frame.year.max()),'rank':int(rank),'columns':x.shape[1],'target_rank':2,'mean_outcome_votes_per100_residents':float(frame.outcome.mean()),'mean_lag_votes_per100_current_residents':float(frame.lag_volume.mean()),'contrast_outcome_unit':'focal-party House votes per100 residents' if outcome_label=='party_house_votes' else 'all reported House votes per100 residents'})
 return results


def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--house',type=Path,default=Path('/tmp/coattails_identification/data/house_districts.csv'))
 p.add_argument('--population',type=Path,default=Path('/tmp/coattails_stage3/population/prior_census_population.csv'))
 p.add_argument('--expected-districts',type=Path,default=ROOT/'expected_districts.csv')
 p.add_argument('--joint',type=Path,default=Path('/tmp/coattails_stage3/score/results/joint_sample.csv'))
 p.add_argument('--broad-scores',type=Path,default=Path('/tmp/coattails_stage3/score/results/frozen_candidate_scores.csv'))
 p.add_argument('--donor-scores',type=Path,default=Path('/tmp/coattails_stage3/score/donor_results/frozen_candidate_scores.csv'))
 p.add_argument('--output',type=Path,default=ROOT)
 args=p.parse_args();args.output.mkdir(parents=True,exist_ok=True)
 house=build_house(pd.read_csv(args.house),pd.read_csv(args.expected_districts));house.to_csv(args.output/'house_reporting_audit.csv',index=False)
 population=pd.read_csv(args.population);joint=pd.read_csv(args.joint);results=[];coverage=[];audits=[]
 for label,path in [('broad_history',args.broad_scores),('donor_breadth_exploratory',args.donor_scores)]:
  a=prepare(house,population,joint,pd.read_csv(path),label);a.to_csv(args.output/f'{label}_eligibility.csv',index=False)
  party=party_stack(a);total=total_frame(a)
  party.to_csv(args.output/f'{label}_party_panel.csv',index=False);total.to_csv(args.output/f'{label}_total_panel.csv',index=False)
  features=['own_quality_10pp','opponent_quality_10pp','lag_volume','own_incumbent','opponent_incumbent','own_observed','opponent_observed']
  contrasts={'own_senate_quality_plus10pp':{'own_quality_10pp':1},'opponent_senate_quality_plus10pp':{'opponent_quality_10pp':1},'both_senate_qualities_plus10pp':{'own_quality_10pp':1,'opponent_quality_10pp':1}}
  results+=estimate(party,features,['state_party','year_party'],contrasts,'party_house_votes',label)
  features=['quality_D_10pp','quality_R_10pp','lag_volume','incumbent_D','incumbent_R','observed_D','observed_R']
  contrasts={'Democratic_senate_quality_plus10pp':{'quality_D_10pp':1},'Republican_senate_quality_plus10pp':{'quality_R_10pp':1},'both_senate_qualities_plus10pp':{'quality_D_10pp':1,'quality_R_10pp':1}}
  results+=estimate(total,features,['state_abbrev','year'],contrasts,'total_reported_house_votes',label)
  for outcome,frame in [('party_house_votes',party),('total_reported_house_votes',total)]:
   for year,g in frame.groupby('year'):
    coverage.append({'score_model':label,'outcome':outcome,'year':int(year),'state_elections':len(g[KEY].drop_duplicates()),'regression_observations':len(g)})
  audits.append({'score_model':label,'score_source_races':len(a),'defined_earlier_only_scores':int(a.score_defined.sum()),'party_complete_current':int((a.score_defined&a.party_eligible.eq(True)).sum()),'party_complete_current_and_lag':int(a.included_party.sum()),'total_complete_current_and_lag':int(a.included_total.sum()),'party_unknown_own_quality_observations':int((party.own_observed==0).sum()),'party_observations':len(party),'party_both_high_score_races':int((a.included_party&a.quality_high_D&a.quality_high_R).sum()),'total_both_high_score_races':int((a.included_total&a.quality_high_D&a.quality_high_R).sum()),'party_high_D_races':int((a.included_party&a.quality_high_D).sum()),'party_high_R_races':int((a.included_party&a.quality_high_R).sum()),'first_party_year':int(party.year.min()),'last_party_year':int(party.year.max())})
 estimates=pd.DataFrame(results);estimates.to_csv(args.output/'estimates.csv',index=False);pd.DataFrame(coverage).to_csv(args.output/'coverage.csv',index=False)
 summary={'analysis':'Secondary analysis specified before its own fit, after the primary analyses; no proxy retuning','units':'Additional reported House votes per100 residents in the most recent strictly prior decennial census, per10 predicted percentage points of Senate candidate score','not_turnout_rate':True,'models':audits,'estimates':results,
 'reporting_rule':'All officially apportioned districts present; no duplicate districts; every party count directly reported and nonnegative; district total positive; D+R cannot exceed total. Both current and t−2 elections must qualify. No missing-party zeroes or unreported-uncontested votes are imputed.',
 'total_rule':'Separate complete-total outcome allows missing party counts but requires positive reported total and every known party count to be consistent. Its support is larger and separately reported.',
 'specification':'Party-stacked own/opponent quality slopes separately, lagged same-party House votes using the current denominator, state×party and year×party fixed effects, own/opponent pre-election Senate incumbency and score-availability flags; state-clustered confidence intervals. Total check uses D/R score slopes with state/year fixed effects and analogous controls.',
 'limits':['Observational association, not a causal turnout or persuasion decomposition.','Denominator includes children and noncitizens and can be up to10years old; this is not VEP, VAP, registered-voter or turnout rate.','Recorded House votes differ from total election ballots because of roll-off and other contests.','Complete reporting and both-party count requirements select states and elections; results do not generalize automatically to omitted unopposed races.','Current and lag state totals cover the whole state across district-boundary changes; lag votes can absorb earlier candidate influence.','The donor proxy failed held-out own-vote validation; donor coattail associations remain exploratory regardless of sign.','Broad selected history proxy assigns an unknown-history reference score to newcomers with explicit availability controls.','Architecture selection is retrospective for earlier years, although fitted coefficients and inputs precede each scored election.','Simultaneously stronger Senate candidates do not cancel: own and opponent coefficients, and their sum, are reported separately. In the party-stacked model the both-score sum is the response of one focal party to both scores rising; the implied D+R total response to both rising is twice that sum. The separate total-vote model sum is already the full recorded-total response. The sum is an additive-model contrast, not an estimated interaction of two stars. There are no simultaneous high-tail broad-history pairs in either eligible outcome sample; donor samples contain20 such pairs.'],
 'input_sha256':{str(path):hashlib.sha256(path.read_bytes()).hexdigest() for path in [args.house,args.population,args.expected_districts,args.joint,args.broad_scores,args.donor_scores]}}
 (args.output/'summary.json').write_text(json.dumps(summary,indent=2,allow_nan=False))
 print(json.dumps(audits,indent=2));print(estimates.to_string(index=False))

if __name__=='__main__':main()
