"""Build the public dashboard from frozen aggregate analysis outputs."""
from pathlib import Path
import csv,json,math,sys
ROOT=Path(__file__).resolve().parent.parent
def rows(path):
    with (ROOT/path).open() as f:return list(csv.DictReader(f))
def read(path):return json.loads((ROOT/path).read_text())
def n(x):return None if x in ('',None,'nan','NaN') else float(x)
def yes(x):return str(x).lower() in ('true','1','1.0')
def one(items,**wanted):return next(r for r in items if all(r.get(k)==v for k,v in wanted.items()))
def metric(items,model,stage):
    try:return one(items,protocol='fixed_cutoff',model=model,stage=stage,subgroup='all')
    except StopIteration:return None
LABELS={'baseline':'Party, incumbency & availability baseline','history_centered':'Calibrated history, cycle adjusted','history_raw':'Calibrated history','office':'Prior political experience','office_primary':'Experience + primary fundraising share','office_history_centered':'Experience + adjusted history','office_history_raw':'Experience + history','office_primary_history_centered':'Experience + primary share + adjusted history','office_primary_history_raw':'Experience + primary share + history'}

def spillovers(lane):
    s=read(f'spillover/{lane}/summary.json');a=s['association_estimates'];result={}
    for key,term in [('star','star_difference'),('continuous','quality_10pp')]:
        matches=[r for r in a if r['period']=='all_period' and r['predictor']==term and r['identified']]
        result[key]={'description':('One party’s top-decile nominee relative to the other party; lower-decile status is controlled separately. Two opposing stars cancel in this relative vote-share comparison; that does not mean neither mobilizes voters.' if key=='star' else 'Other-race percentage points per +10 points of predicted candidate contribution in the Senate race. This is a linear association, not an identified causal effect.'),'rows':[dict(office=r['outcome'].title(),estimate=r['estimate_pp'],low=r['low95'],high=r['high95'],races=r['rows'],state_elections=r['state_elections'],stars=r['any_star_races']) for r in matches]}
    h=one(a,outcome='house',period='all_period',predictor='quality_10pp');g=one(a,outcome='governor',period='all_period',predictor='quality_10pp')
    result['coverage']=f"House: {h['rows']:,} district races / {h['state_elections']} state elections, {h['first_year']}–{h['last_year']}, with each state election weighted equally. Governor: {g['rows']} races, {g['first_year']}–{g['last_year']}. Only one comparable-boundary House district contributes in 2022. Intervals cluster by state."
    result['reading']='These intervals include both gains and losses. The estimates do not establish that strong candidates have no coattails, and they do not support a stable causal effect in percentage points. The score and tail cutoff were fixed using own-Senate outcomes before this analysis.'
    result['periods']=[dict(label=r['outcome'].title()+' · '+{'all_period':'full sample','since_2000':'2000 onward','test_period':'recent-period refit'}[r['period']],estimate=r['estimate_pp'],low=r['low95'],high=r['high95']) for r in a if r['predictor']=='quality_10pp' and r['identified']]
    result['period_note']='Each row refits the association on that period; the recent row is not an untouched forecast. Recent governor models with state and year effects have too little independent variation to identify the coefficient and are omitted. Complete coverage, forecast checks and exclusions are in the download.'
    return result

def candidate_list(score_path,sample_path):
    sample={(r['state_abbrev'],r['year']):r for r in rows(sample_path)}
    donor={}
    if (ROOT/'fundraising/nominee_breadth_features.csv').exists():
        donor={(r['state_abbrev'],r['year'],r['party']):r for r in rows('fundraising/nominee_breadth_features.csv') if r['window']=='june30'}
    out=[]
    for r in rows(score_path):
        x=sample[(r['state_abbrev'],r['year'])]
        for p,party in [('D','DEMOCRAT'),('R','REPUBLICAN')]:
            if not yes(r[f'quality_observed_{p}']):continue
            score=n(r[f'quality_score_{p}'])
            if score is None:continue
            d=donor.get((r['state_abbrev'],r['year'],p),donor.get((r['state_abbrev'],r['year'],party),{}))
            out.append(dict(name=r[f'candidate_{party}'].title(),state=r['state_abbrev'],year=int(r['year']),party='Democrat' if p=='D' else 'Republican',score=score*100,star=yes(r[f'quality_high_{p}']),history_known=yes(x.get(f'history_observed_{p}')),instate_donors=n(d.get('approx_contributors_in_state'))))
    return out

def broad():
    selection=read('score/results/model_selection.json');metrics=rows('score/results/own_vote_metrics.csv');selected=selection['selected_model'];threshold=read('score/results/score_thresholds.json');base=metric(metrics,'baseline','test');test=metric(metrics,selected,'test');v=[]
    for model in selection['models']:
        values=[metric(metrics,model,stage) for stage in ['development','test','confirmation']]
        v.append(dict(label=LABELS.get(model,model),selected=model==selected,dev_mae=n(values[0]['mae_pp']) if values[0] else None,test_mae=n(values[1]['mae_pp']) if values[1] else None,confirmation_mae=n(values[2]['mae_pp']) if values[2] else None))
    gain=(float(base['mae_pp'])-float(test['mae_pp']))/float(base['mae_pp'])*100
    return dict(id='broad',label='Broad Senate comparison · 1982–2024',model_label=LABELS[selected],summary='Nine candidate measures compete on the same Senate elections. Historical performance wins the development comparison. Prior experience and primary fundraising share do not displace it, so this broad definition still leaves newcomers unscored.',metrics=[dict(label='Own-race test error',value=f"{float(base['mae_pp']):.2f} → {float(test['mae_pp']):.2f}",note=f"{int(test['races'])} Senate races · percentage points"),dict(label='Reduction in own-race error',value=f'{gain:.1f}%',note='Held-out 2016–2022 elections'),dict(label='Fixed top-decile cutoff',value=f"+{threshold['p90']*100:.2f} pp",note=f"{threshold['n']} observed training appearances")],definition=f"All-star means an observed candidate score at or above +{threshold['p90']*100:.2f} predicted own-vote points. The cutoff comes from training appearances through 2008, before any House or governor merge. Each score uses coefficients fitted on earlier elections.",validation_description='The target is the candidate’s own two-party Senate vote share. All measures use the same baseline and election rows. Select on 2010–2014 development error, then evaluate on 2016–2022 and separately on 2024.',validation_rows=v,validation_note='Mean absolute error, in percentage points; lower is better. Development fits end in 2008; test fits end in 2014; the 2024 confirmation fit ends in 2022. The selected model is not changed because another model later performs better in 2024.',validation_reading='Corrected electoral history improves held-out forecasts. Experience and primary fundraising share do not provide a validated general replacement for missing Senate history. A small improvement in races with no history can come from changed baseline coefficients; it does not mean those candidates acquired an individual talent score.',coattails=spillovers('broad'),candidates=candidate_list('score/results/frozen_candidate_scores.csv','score/results/joint_sample.csv'),candidate_note='Scores are the model’s predicted contribution from measured candidate attributes, relative to a common reference. They are not observed causal effects or intrinsic charisma. The broad winner uses prior Senate performance; candidates without that information are unscored and absent from this table. Repeat candidacies appear separately.')

def onoff():
    data=rows('house_design/quality_comparison_estimates.csv');s=read('house_design/quality_comparison_summary.json');r=[]
    for contrast,label in [('off_cycle_placebo_4_minus_2','Off-ballot placebo: fourth year vs second'),('scheduled_6_vs_mean_off_2_4','Scheduled Senate election vs intervening elections'),('scheduled_6_after_linear_offcycle_trend','Scheduled election after extrapolating prior trend')]:
        x=one(data,score_model='corrected_centered',sample='scheduled_ITT',predictor='quality_phase',contrast=contrast)
        r.append(dict(label=label,estimate=n(x['estimate_pp']),low=n(x['low95']),high=n(x['high95'])))
    return dict(description=f"Follow {s['matched_cohorts']} senator-term cohorts across the same House districts in {s['states']} states. Fix strength using the senator’s completed term-start election, then compare years two, four and six. Results below are House points per +10 points of corrected historical Senate overperformance, a different scale from the learned candidate score above.",rows=r,note='The corrected-score estimates remain uncertain. Retirement, death and promotion are retained in the scheduled-election comparison, so this is not the effect of actual rerunning alone. Off this Senate schedule does not mean politically inactive: Obama and McCain ran for president during intervening years. Geography matching disproportionately excludes terms crossing redistricting. Extrapolating one off-cycle change is a sensitivity, not a proven counterfactual. The original historical score, matched-sample comparisons and tail estimates are in the download.')

def donors():
    s=read('score/donor_results/model_selection.json');t=read('score/donor_results/score_thresholds.json');m=rows('score/donor_results/own_vote_metrics.csv');selected=s['selected_model']
    labels={'baseline':'Party, incumbency & availability baseline','national_breadth':'National disclosed contributor breadth','in_state_breadth':'In-state disclosed contributor breadth','both_breadth':'National + in-state breadth','individual_money':'Official individual contribution dollars','breadth_and_money':'Breadth + dollars','history':'Corrected electoral history','history_and_breadth':'History + breadth','history_breadth_money':'History + breadth + dollars','office_history':'Experience + history','office_history_breadth_money':'Experience + history + breadth + dollars'}
    values=[]
    for model in s['models']:
        dev=one(m,protocol='fixed_cutoff_primary',model=model,stage='development',subgroup='all');test=one(m,protocol='fixed_cutoff_primary',model=model,stage='test',subgroup='all')
        values.append(dict(label=labels.get(model,model),selected=model==selected,dev_mae=n(dev['mae_pp']),test_mae=n(test['mae_pp']),confirmation_mae=None))
    base=one(m,protocol='fixed_cutoff_primary',model='baseline',stage='test',subgroup='all');test=one(m,protocol='fixed_cutoff_primary',model=selected,stage='test',subgroup='all');rolling=one(m,protocol='expanding_past_only_primary',model=selected,stage='test',subgroup='all')
    spill=spillovers('donor');spill['reading']='Exploratory: this donor definition failed to improve held-out own-Senate forecasts. Its House and governor coattail intervals are also wide. These associations cannot validate the definition after the fact or identify a causal all-star effect.'
    return dict(id='donors',label='Matched Senate donor comparison · 1996–2022',model_label='National contributor breadth · exploratory',summary='More contributors than expected for population, prior party lean, competitiveness, incumbency and fundraising trends. This measure won development selection but did not improve later own-race prediction. It is a provisional donor screen, not a validated all-star definition.',metrics=[dict(label='Own-race test error',value=f"{float(base['mae_pp']):.2f} → {float(test['mae_pp']):.2f}",note='Error increases in 112 held-out Senate races'),dict(label='Donor coverage for newcomers',value='508 / 520',note='Nominees without prior comparable Senate history; before matched-money restrictions'),dict(label='Frozen top-decile cutoff',value=f"+{t['p90']*100:.2f} pp",note=f"{t['n']} earlier-scored training appearances")],definition=f"Provisional top decile: a donor-based predicted contribution of about +{t['p90']*100:.2f} points or more, using a cutoff fixed from training data. The donation and vote models for each candidate use only earlier elections. The failed own-vote holdout remains a limitation of every coattail estimate below.",validation_description='Compare national and in-state contributor breadth with official individual-contribution dollars, experience and electoral history on exactly the same 391 Senate races: 194 training, 85 development and 112 test races. No 2024 FEC confirmation is available in this dataset.',validation_rows=values,validation_note=f"Mean absolute error in vote-share percentage points. Development: 2010–2014, fitted through 2008. Test: 2016–2022, refitted through 2014. For the expanding earlier-years-only score used in the coattail analysis, test error also worsens: {float(rolling['baseline_mae_pp']):.2f} → {float(rolling['mae_pp']):.2f}. The development-selected measure stays fixed after its disappointing test.",validation_reading='National contributor breadth beats dollars in development, then loses that advantage in later elections. Corrected history has lower error on those same later races. A disclosure-threshold sensitivity counting only identities with a single receipt above $200 has a small, uncertain improvement; it is not substituted after seeing the test.',coattails=spill,candidates=candidate_list('score/donor_results/frozen_candidate_scores.csv','score/donor_results/common_sample.csv'),candidate_note='This table shows the frozen donor screen, which failed its own-vote holdout test. “Top decile” is a model classification, not proof of exceptional talent. The score reflects unexpected national contributor breadth; the in-state count is shown separately. Counts are approximate disclosed name+ZIP identities through June 30. A candidate can be scored without any previous Senate race.')

def volume():
    r=rows('vote_volume/estimates.csv');out={}
    contrasts=[('party_house_votes','own_senate_quality_plus10pp','Party votes · its own Senate candidate stronger'),('party_house_votes','opponent_senate_quality_plus10pp','Party votes · opposing Senate candidate stronger'),('party_house_votes','both_senate_qualities_plus10pp','Party votes · both Senate candidates stronger'),('total_reported_house_votes','both_senate_qualities_plus10pp','All reported House votes · both candidates stronger')]
    for key,model in [('broad','broad_history'),('donors','donor_breadth_exploratory')]:
        values=[]
        for outcome,contrast,label in contrasts:
            x=one(r,score_model=model,outcome=outcome,contrast=contrast)
            values.append(dict(label=label,estimate=n(x['estimate_votes_per100_residents']),low=n(x['low95']),high=n(x['high95']),state_elections=int(x['state_elections'])))
        out[key]=dict(label='Historical-strength score' if key=='broad' else 'Exploratory donor score',rows=values,note='Changes are reported House votes per 100 residents counted in the most recent preceding census, per +10 predicted Senate points for the indicated candidate or each candidate. This is not a turnout percentage: the population includes children and noncitizens. The party-vote sample requires complete reported D/R counts and excludes California, Florida, New York and Texas. The all-votes check has broader, different reporting coverage. The both-stronger contrast adds two model coefficients; it is not a separately identified two-star interaction.'+(' No two top-decile historical-score candidates occur together in this sample, so that case is an extrapolation.' if key=='broad' else ' The all-votes interval barely excludes zero before rounding (0.002 to 2.594). It is one of multiple secondary contrasts using a donor proxy that failed its own-vote holdout; it does not establish mobilization or causality.'))
    return out

def main():
    result=dict(headline='Donor breadth did not improve later Senate forecasts. Historical performance still works better, and the coattail estimates remain uncertain.',default_comparison='donors',comparisons=[donors(),broad()],onoff=onoff(),data_note='Donor breadth counts approximate disclosed identities after normalizing names and ZIP codes, not all donors or all small donors. The main cutoff is June 30 before the general election. The records are reconstructed from later FEC bulk releases; amendments and disclosure thresholds prevent a claim that every record was publicly available by that date. Contributor counts are scaled by the most recent preceding decennial census population. Official summary receipts are used for dollars because gross positive transaction records can double-count amended or memo entries. Prior-office categories and incumbency were audited before model comparison; uncertain attributes remain missing.')
    result['volume']=volume()
    out=Path(sys.argv[1]) if len(sys.argv)>1 else ROOT/'site/expanded-study.json'
    out.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n');print(out)

if __name__=='__main__':main()
