"""Rebuild stage-three analyses outside the checkout, from verified inputs.

The default uses included anonymous candidate aggregates. --rebuild-fec is an
optional ~15.1 GB source acquisition and streaming transaction aggregation.
"""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.request

PACKAGE = Path(__file__).resolve().parent
ENV = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1')

def digest(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        while block:=f.read(4*1024*1024): h.update(block)
    return h.hexdigest()

def run(study, *args):
    subprocess.run([sys.executable,*map(str,args)],cwd=study,env=ENV,check=True)

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    result=importlib.util.module_from_spec(spec);spec.loader.exec_module(result)
    return result

def copy(source,destination):
    destination.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(source,destination)

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--work-dir',type=Path,default=Path(tempfile.gettempdir())/'senate-coattails-stage3-reproduction')
    p.add_argument('--fetch',action='store_true',help='Fetch/hash-check MIT and district inputs and the experience source')
    p.add_argument('--input-dir',type=Path,help='Reuse mit_senate.tsv, mit_president.csv, house_districts.csv')
    p.add_argument('--experience-source-dir',type=Path,help='Reuse the four original author CSVs; hashes checked')
    p.add_argument('--rebuild-fec',action='store_true',help='Download/hash-check about15.1GB and rebuild receipt aggregates; much slower')
    p.add_argument('--fec-source-dir',type=Path,help='Reuse verified FEC ZIPs with --rebuild-fec (copied or linked outside checkout)')
    p.add_argument('--skip-donor',action='store_true',help='Rebuild only the broad historical score and its peer analyses')
    args=p.parse_args();start=time.time()
    work=args.work_dir.resolve()
    if work==PACKAGE or PACKAGE in work.parents:
        raise ValueError('Choose a work directory outside the package/checkout.')
    work.mkdir(parents=True,exist_ok=True);study=work/'study';inputs=work/'source_inputs'
    shutil.copytree(PACKAGE,study,dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__','*.pyc','.git'))
    inputs.mkdir(exist_ok=True)
    fetcher=load('stage3_fetch',study/'fetch_inputs.py')
    if args.input_dir:
        for name in ['mit_senate.tsv','mit_president.csv','house_districts.csv']:
            copy(args.input_dir.resolve()/name,inputs/name)
    elif args.fetch:
        fetcher.fetch(inputs)
    required={'mit_senate.tsv':fetcher.SOURCES['mit_senate.tsv'][1],
              'mit_president.csv':fetcher.SOURCES['mit_president.csv'][1],
              'house_districts.csv':'331993fa904c232a24ed098d2ce8fea14c501a900e2c5d3d63707ffc656e504a'}
    for name,expected in required.items():
        source=inputs/name
        if not source.exists(): raise FileNotFoundError(f'{source}; use --fetch or --input-dir')
        if digest(source)!=expected:raise ValueError(f'Source version mismatch: {name}')
    # The full Senate frame contains licensed metadata; it exists only in work.
    import pandas as pd
    sys.path.insert(0,str(study/'score'))
    core=load('stage3_core',study/'score/core.py');core.SOURCE=inputs;core.BASE=study/'score'
    senate=core.prepare_sample();assert len(senate)==689
    score_in=study/'score/input';score_in.mkdir(exist_ok=True)
    senate.to_csv(score_in/'senate_sample.csv',index=False)
    for name in required:copy(inputs/name,score_in/name)
    q=study/'quality_sources';raw=q/'raw';raw.mkdir(exist_ok=True)
    source_manifest=json.loads((PACKAGE/'quality_sources/provenance.json').read_text())
    if args.experience_source_dir:
        for name in source_manifest['files']:copy(args.experience_source_dir.resolve()/name,raw/name)
    elif args.fetch:
        run(study,q/'acquire_experience.py')
    for name,meta in source_manifest['files'].items():
        if not (raw/name).exists():raise FileNotFoundError(f'{raw/name}; use --fetch or --experience-source-dir')
        if digest(raw/name)!=meta['sha256']:raise ValueError(f'Experience source version mismatch: {name}')
    run(study,q/'map_experience.py','--sample',score_in/'senate_sample.csv')
    run(study,q/'finalize_features.py')
    copy(q/'experience_features.csv',score_in/'experience_features.csv')
    run(study,study/'score/build_history.py','--input',score_in,'--output',study/'score/results')
    run(study,study/'score/benchmark_quality.py','--history',study/'score/results/history_sample.csv',
        '--experience',score_in/'experience_features.csv','--output',study/'score/results')
    def spillover(score_dir,lane,senate_path):
        out=study/'spillover'/lane
        extra=(['--own-validation-status','failed_heldout_own_vote_validation','--extra-availability',
                'committee_mapped_D','committee_mapped_R','bulk_cycle_available_D','bulk_cycle_available_R',
                'both_observed','paired_breadth_observed'] if lane=='donor' else [])
        run(study,study/'spillover/spillover.py','--house-data',inputs/'house_districts.csv',
            '--governor-data',study/'inputs/governor_state_returns.csv','--senate-data',senate_path,
            '--score-data',score_dir/'frozen_candidate_scores.csv','--selection-json',score_dir/'model_selection.json',
            '--threshold-json',score_dir/'score_thresholds.json','--output',out,'--lane',('matched_fec' if lane=='donor' else lane),*extra)
        run(study,study/'spillover/verify_numeric.py',out)
    spillover(study/'score/results','broad',study/'score/results/joint_sample.csv')
    hd=study/'house_design'
    run(study,hd/'on_off.py','--root',hd,'--senate-data',score_in/'senate_sample.csv',
        '--house-data',inputs/'house_districts.csv','--raw-senate',inputs/'mit_senate.tsv',
        '--threshold-file',study/'inputs/legacy_thresholds.json')
    run(study,hd/'compare_quality.py','--root',hd,'--historical-audit',study/'score/results/historical_election_audit.csv',
        '--selection',study/'score/results/model_selection.json')
    run(study,hd/'audit_data.py','--root',hd,'--house-data',inputs/'house_districts.csv')
    run(study,study/'audits/audit_corrected_on_off.py','--root',hd)
    if not args.skip_donor:
        f=study/'fundraising'
        if args.rebuild_fec:
            target=f/'raw';target.mkdir(exist_ok=True)
            if args.fec_source_dir:
                manifest=json.loads((f/'source_manifest.json').read_text())
                for meta in manifest['files']:
                    source=args.fec_source_dir.resolve()/meta['file'];dest=target/meta['file']
                    if not source.exists():raise FileNotFoundError(source)
                    if not dest.exists():dest.symlink_to(source)
            run(study,f/'download_bulk.py')
            run(study,f/'map_nominees.py','--benchmark',score_in/'senate_sample.csv')
            run(study,f/'aggregate_stream.py','--years',*range(1996,2024,2))
            run(study,f/'build_features.py','--population',study/'population/prior_census_population.csv')
        for source,name in [(f/'race_breadth_features.csv','race_breadth_features.csv'),
                            (f/'summaries/senate_june30_race_money.csv','senate_june30_race_money.csv'),
                            (study/'population/prior_census_population.csv','prior_census_population.csv')]:
            copy(source,score_in/name)
        run(study,study/'score/benchmark_donors.py','--input',score_in,'--output',study/'score/donor_results')
        spillover(study/'score/donor_results','donor',study/'score/donor_results/common_sample.csv')
        run(study,study/'audits/verify_donor_benchmark.py','--score-dir',study/'score',
            '--report',study/'audits/regenerated_donor_benchmark_audit.txt')
        vv=study/'vote_volume'
        if (vv/'analyze_vote_volume.py').exists():
            run(study,vv/'build_expected_districts.py','--source',study/'population/apportionment.csv','--output',vv)
            run(study,vv/'analyze_vote_volume.py','--house',inputs/'house_districts.csv',
                '--population',study/'population/prior_census_population.csv','--expected-districts',vv/'expected_districts.csv',
                '--joint',study/'score/results/joint_sample.csv','--broad-scores',study/'score/results/frozen_candidate_scores.csv',
                '--donor-scores',study/'score/donor_results/frozen_candidate_scores.csv','--output',vv)
            run(study,vv/'audit_vote_volume.py')
            run(study,study/'site/build_expanded.py',study/'site/expanded-study.json')
    run(study,PACKAGE/'verify_results.py','--reproduced',study,*(['--skip-donor'] if args.skip_donor else []))
    report={'elapsed_seconds':round(time.time()-start,2),'work_dir':str(work),
            'used_included_candidate_aggregates':not args.rebuild_fec,'source_hashes':{k:digest(inputs/k) for k in required},
            'reconstructed_restricted_rows_remain_local':True,'completed':True}
    (work/'REPRODUCTION.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))

if __name__=='__main__':main()
