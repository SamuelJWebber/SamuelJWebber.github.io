from pathlib import Path
import argparse,json
import pandas as pd,numpy as np
from scipy.linalg import lstsq
import spillover as m
ap=argparse.ArgumentParser();ap.add_argument('results',type=Path);args=ap.parse_args();p=args.results
availability=json.loads((p/'summary.json').read_text()).get('availability_controls',m.AVAIL)
est=pd.read_csv(p/'association_estimates.csv');out=[]
for office,controls in [('house',['prior_house_share','house_incumbency','prior_house_incumbency','prior_pres_lean','senate_incumbency']),('governor',['prior_gov_share','gov_incumbency','prior_pres_lean','senate_incumbency'])]:
 d=pd.read_csv(p/f'{office}_sample.csv');q=d.quality_10pp.to_numpy();y=d.outcome.to_numpy();w=d.weight.to_numpy();z,_=m.design(d,controls+availability,True);z=z.to_numpy();zw=z*np.sqrt(w)[:,None]
 qr=q-z@lstsq(zw,q*np.sqrt(w))[0];yr=y-z@lstsq(zw,y*np.sqrt(w))[0];beta=(qr*w)@yr/((qr*w)@qr)
 r=est[(est.outcome==office)&(est.period=='all_period')&(est.predictor=='quality_10pp')].iloc[0];assert abs(beta*100-r.estimate_pp)<1e-7
 a=np.column_stack([z,q]);b=lstsq(a*np.sqrt(w)[:,None],y*np.sqrt(w))[0];resid=y-a@b;infl=qr*w*resid/((qr*w)@qr);s=pd.Series(infl).groupby(d.state_abbrev.to_numpy()).sum();G=len(s);N=len(d);K=int(np.linalg.matrix_rank(a));se=np.sqrt(sum(s*s)*G/(G-1)*(N-1)/(N-K));assert abs(se*100-r.se_pp)<1e-7
 assert np.allclose(d.groupby(['state_abbrev','year']).weight.sum(),1)
 assert (d.score_training_last_year<d.year).all()
 assert len(d[['state_abbrev','year']].drop_duplicates())==r.state_elections
 out.append({'outcome':office,'rows':len(d),'state_elections':int(r.state_elections),'frisch_waugh_beta_pp':float(beta*100),'independent_cluster_se_pp':float(se*100),'rank':K})
print(json.dumps(out,indent=2));(p/'independent_verification.json').write_text(json.dumps(out,indent=2)+'\n')
