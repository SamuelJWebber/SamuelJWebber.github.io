#!/usr/bin/env python3
"""Follow a frozen own-Senate-vote score into House and governor outcomes.

No selection of candidate-strength definitions uses these peer outcomes.
All source paths and score artifacts are explicit CLI arguments.
"""
from pathlib import Path
import argparse,json,hashlib
import numpy as np
import pandas as pd
from scipy.stats import t

KEY=['state_abbrev','year']
AVAIL=['history_observed_D','history_observed_R','office_observed_D','office_observed_R',
       'primary_share_observed_D','primary_share_observed_R','primary_field_observed_D','primary_field_observed_R',
       'quality_observed_D','quality_observed_R']
EXTRA={'continuous':['quality_10pp'],'tails_secondary':['star_difference','low_difference']}


def senate_features(sample, scores):
    cols=KEY+['split','candidate_DEMOCRAT','candidate_REPUBLICAN','incumbency','prior_pres_lean',
              'white_house_party','midterm_white_house']+[c for c in AVAIL if c in sample and not c.startswith('quality_observed_')]
    s=sample[cols].rename(columns={'incumbency':'senate_incumbency'})
    fields=KEY+['quality_score_D','quality_score_R','quality_score_difference','quality_observed_D','quality_observed_R',
                'quality_high_D','quality_high_R','quality_low_D','quality_low_R','score_training_last_year','score_training_n']
    s=s.merge(scores[fields],on=KEY,validate='one_to_one')
    assert (s.loc[s.score_training_last_year.notna(),'score_training_last_year']<s.loc[s.score_training_last_year.notna(),'year']).all()
    s['quality_10pp']=s.quality_score_difference/.1
    s['star_difference']=s.quality_high_D.astype(int)-s.quality_high_R.astype(int)
    s['low_difference']=s.quality_low_D.astype(int)-s.quality_low_R.astype(int)
    s['score_model_available']=s.score_training_last_year.notna()&s.quality_score_difference.notna()
    for side in ['D','R']:
        assert not (s[f'quality_high_{side}']&~s[f'quality_observed_{side}']).any()
        assert not (s[f'quality_low_{side}']&~s[f'quality_observed_{side}']).any()
    return s


def prepare_house(h, s):
    past=h[['st_dist_redist_FE','year','d2pshare','incumbency']].copy();past['year']+=2
    past=past.rename(columns={'d2pshare':'prior_house_share','incumbency':'prior_house_incumbency'})
    x=h.merge(past,on=['st_dist_redist_FE','year'],how='left',validate='one_to_one')
    statewide=h.loc[h.dist.eq(0),KEY+['d2pshare','incumbency']].copy();statewide['year']+=2
    statewide=statewide.rename(columns={'d2pshare':'statewide_prior_share','incumbency':'statewide_prior_incumbency'})
    x=x.merge(statewide,on=KEY,how='left',validate='many_to_one')
    use=x.dist.eq(0)&x.prior_house_share.isna()
    x.loc[use,'prior_house_share']=x.loc[use,'statewide_prior_share']
    x.loc[use,'prior_house_incumbency']=x.loc[use,'statewide_prior_incumbency']
    x['at_large_lag_fallback']=use&x.statewide_prior_share.notna()
    x=x.loc[x.cand_d.notna()&x.cand_r.notna()&x.votes_d.gt(0)&x.votes_r.gt(0)].copy()
    fields=KEY+['dist','st_dist_redist_FE','d2pshare','incumbency','prior_house_share','prior_house_incumbency','at_large_lag_fallback']
    x=x[fields].rename(columns={'d2pshare':'outcome','incumbency':'house_incumbency'}).merge(s,on=KEY,validate='many_to_one')
    controls=['prior_house_share','house_incumbency','prior_house_incumbency','prior_pres_lean','senate_incumbency']
    x=x.loc[x.year.le(2022)&x.score_model_available].dropna(subset=['outcome']+controls+AVAIL+['quality_10pp']).copy()
    x['weight']=1/x.groupby(KEY).outcome.transform('size')
    return x,controls


def prepare_governor(g,h,s):
    g=g.sort_values(KEY).copy();g['is_special']=g.state_abbrev.eq('OR')&g.year.eq(2016)
    g['cycle_year']=g.year;g.loc[g.state_abbrev.eq('AZ')&g.year.eq(1991),'cycle_year']=1990
    prior_fields=['year','cycle_year','share','dem_votes','rep_votes','missing_counties']
    rows=[]
    for _,group in g.groupby('state_abbrev'):
        prev=None
        for _,r in group.iterrows():
            d=r.to_dict()
            for c in prior_fields:d['prior_gov_'+c]=prev[c] if prev is not None else np.nan
            rows.append(d)
            if not r.is_special:prev=r
    x=pd.DataFrame(rows);x['previous_regular_gap']=x.cycle_year-x.prior_gov_cycle_year
    assert h.groupby(KEY).incumbency_G.nunique().max()<=1
    inc=h.groupby(KEY,as_index=False).incumbency_G.first().rename(columns={'incumbency_G':'gov_incumbency'})
    x=x.merge(inc,on=KEY,how='left',validate='one_to_one')
    for st,yr in [('NE',2014),('MN',1982)]:x.loc[x.state_abbrev.eq(st)&x.year.eq(yr),'gov_incumbency']=0
    x=x.rename(columns={'share':'outcome'}).merge(s,on=KEY,validate='one_to_one')
    x['exclusion_reason']=''
    rules=[(x.is_special,'special election'),
           (~(x.dem_votes.gt(0)&x.rep_votes.gt(0)),'invalid current two-party return'),
           (~(x.prior_gov_dem_votes.gt(0)&x.prior_gov_rep_votes.gt(0)),'invalid previous regular return'),
           (x.missing_counties.gt(0)|x.prior_gov_missing_counties.gt(0),'county completeness flag'),
           (~x.previous_regular_gap.isin([2,4]),'unresolved regular-election gap'),
           (~x.score_model_available,'own-score model unavailable')]
    for mask,why in rules:x.loc[mask,'exclusion_reason']+=why+'; '
    audit=x.copy()
    controls=['prior_gov_share','gov_incumbency','prior_pres_lean','senate_incumbency']
    x=x.loc[x.exclusion_reason.eq('')&x.year.le(2020)].dropna(subset=['outcome']+controls+AVAIL+['quality_10pp']).copy()
    x['weight']=1.
    return x,controls,audit


def design(d,features,fe=False,columns=None):
    x=pd.DataFrame({'intercept':np.ones(len(d))},index=d.index)
    if fe:
        for k in ['year','state_abbrev']:
            x=pd.concat([x,pd.get_dummies(d[k].astype(str),prefix=k,drop_first=True,dtype=float)],axis=1)
        # Fixed effects and nuisance controls take precedence. A substantive
        # score absorbed by them is UNIDENTIFIED; never drop a state effect to
        # manufacture a score coefficient in a sparse recent-period sample.
        extra=[c for c in features if c in ['quality_10pp','star_difference','low_difference']]
        features=[c for c in features if c not in extra]+extra
    x=pd.concat([x,d[features].astype(float)],axis=1)
    if columns is not None:return x.reindex(columns=columns,fill_value=0)
    # Exact duplicate/constant nuisance flags cannot have separate coefficients;
    # document drops. In FE models the score terms occur after every control.
    keep=[];dropped=[];a=x.to_numpy();rank=0
    for i,c in enumerate(x.columns):
        r=np.linalg.matrix_rank(a[:,keep+[i]])
        if r>rank:keep.append(i);rank=r
        else:dropped.append(c)
    return x.iloc[:,keep],dropped


def fit(d,features,fe=False):
    x,dropped=design(d,features,fe);a=x.to_numpy();y=d.outcome.to_numpy();w=d.weight.to_numpy()
    aw=a*np.sqrt(w)[:,None];b=np.linalg.lstsq(aw,y*np.sqrt(w),rcond=None)[0]
    resid=y-a@b;states,idx=np.unique(d.state_abbrev.to_numpy(),return_inverse=True)
    scores=np.zeros((len(states),a.shape[1]));np.add.at(scores,idx,a*(w*resid)[:,None])
    bread=np.linalg.pinv(aw.T@aw);cov=bread@(scores.T@scores)@bread
    if len(d)>a.shape[1] and len(states)>1:
        cov*=len(states)/(len(states)-1)*(len(d)-1)/(len(d)-a.shape[1])
        se=np.sqrt(np.maximum(0,np.diag(cov)));crit=t.ppf(.975,len(states)-1)
    else:
        se=np.full(len(b),np.nan);crit=np.nan
    coeff=pd.DataFrame({'term':x.columns,'estimate_pp':100*b,'se_pp':100*se,
                        'low95':100*(b-crit*se),'high95':100*(b+crit*se)})
    return b,list(x.columns),coeff,dropped


def counts(d,period,outcome,lane):
    u=d.drop_duplicates(KEY)
    return {'lane':lane,'outcome':outcome,'period':period,'rows':len(d),'state_elections':len(u),'states':u.state_abbrev.nunique(),
            'first_year':int(u.year.min()),'last_year':int(u.year.max()),
            'D_stars':int(u.quality_high_D.sum()),'R_stars':int(u.quality_high_R.sum()),
            'any_star_races':int((u.quality_high_D|u.quality_high_R).sum()),
            'both_star_races':int((u.quality_high_D&u.quality_high_R).sum()),
            'D_low':int(u.quality_low_D.sum()),'R_low':int(u.quality_low_R.sum()),
            'D_score_observed':int(u.quality_observed_D.sum()),'R_score_observed':int(u.quality_observed_R.sum()),
            'both_scores_observed':int((u.quality_observed_D&u.quality_observed_R).sum()),
            'neither_score_observed':int((~u.quality_observed_D&~u.quality_observed_R).sum())}


def association(d,controls,outcome,lane):
    rows=[];coef=[];ns=[]
    for label,a in [('all_period',d),('since_2000',d.loc[d.year.ge(2000)]),('test_period',d.loc[d.split.eq('test')])]:
        if len(a)==0:continue
        n=counts(a,label,outcome,lane);ns.append(n)
        for model,extra in EXTRA.items():
            _,cols,tab,dropped=fit(a,extra+controls+AVAIL,True)
            tab=tab.assign(lane=lane,outcome=outcome,period=label,model=model);coef.append(tab)
            for term in extra:
                z=tab.loc[tab.term.eq(term)]
                record={**n,'model':model,'predictor':term,'units':'peer vote-share pp per10 predicted own-vote pp' if term=='quality_10pp' else 'peer vote-share pp per1 signed tail indicator',
                        'state_fixed_effects':True,'year_fixed_effects':True,'rank':len(cols),'dropped_redundant_columns':'|'.join(dropped)}
                if len(z) and z.se_pp.notna().all():record.update(z[['estimate_pp','se_pp','low95','high95']].iloc[0].to_dict());record['identified']=True
                else:record.update({'estimate_pp':None,'se_pp':None,'low95':None,'high95':None,'identified':False})
                rows.append(record)
    return pd.DataFrame(rows),pd.concat(coef,ignore_index=True),pd.DataFrame(ns)


def forecast(d,controls,outcome,lane):
    records=[];metrics=[];base=controls+AVAIL+['white_house_party','midterm_white_house']
    for period,cutoff in [('development',2008),('test',2014)]:
        tr=d.loc[d.year.le(cutoff)];te=d.loc[d.split.eq(period)]
        if len(tr)<20 or te.empty:continue
        preds={}
        for model,extra in [('baseline',[]),('continuous',['quality_10pp']),('tails_secondary',['star_difference','low_difference'])]:
            features=extra+base;b,cols,_,dropped=fit(tr,features)
            pr=design(te,features,columns=cols).to_numpy()@b
            preds[model]=pr
            z=te[KEY+(['dist'] if 'dist' in te else [])+['outcome','weight']].copy()
            z['prediction']=pr;z['baseline_prediction']=preds['baseline'];z['model']=model;z['period']=period;z['lane']=lane;z['office']=outcome
            records.append(z)
            err=abs(pr-te.outcome.to_numpy());berr=abs(preds['baseline']-te.outcome.to_numpy());w=te.weight.to_numpy()
            groups=te.assign(gain=(berr-err)*w*100).groupby('state_abbrev').agg(gain=('gain','sum'),w=('weight','sum'))
            rng=np.random.default_rng(190707);ids=rng.integers(0,len(groups),(10000,len(groups)))
            boot=groups.gain.to_numpy()[ids].sum(1)/groups.w.to_numpy()[ids].sum(1);lo,hi=np.quantile(boot,[.025,.975])
            metrics.append({**counts(te,period,outcome,lane),'model':model,'training_last_year':cutoff,'training_state_elections':len(tr[KEY].drop_duplicates()),
                'mae_pp':100*np.average(err,weights=w),'baseline_mae_pp':100*np.average(berr,weights=w),
                'rmse_pp':100*np.sqrt(np.average((pr-te.outcome.to_numpy())**2,weights=w)),
                'mae_gain_pp':100*np.average(berr-err,weights=w),'gain_low95':lo,'gain_high95':hi,
                'dropped_redundant_columns':'|'.join(dropped)})
    return pd.concat(records,ignore_index=True),pd.DataFrame(metrics)


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    for name in ['house-data','governor-data','senate-data','score-data','selection-json','threshold-json']:
        ap.add_argument('--'+name,type=Path,required=True)
    ap.add_argument('--output',type=Path,required=True);ap.add_argument('--lane',default='broad')
    ap.add_argument('--extra-availability',nargs='*',default=[])
    ap.add_argument('--own-validation-status',default='independently_selected')
    args=ap.parse_args();args.output.mkdir(parents=True,exist_ok=True)
    AVAIL.extend(c for c in args.extra_availability if c not in AVAIL)
    selection=json.loads(args.selection_json.read_text());threshold=json.loads(args.threshold_json.read_text())
    assert selection.get('selected_model'), 'Freeze own-outcome model before peer analysis'
    s=senate_features(pd.read_csv(args.senate_data),pd.read_csv(args.score_data))
    h=pd.read_csv(args.house_data);g=pd.read_csv(args.governor_data)
    hs,hc=prepare_house(h,s);gs,gc,gaudit=prepare_governor(g,h,s)
    gaudit.to_csv(args.output/'governor_join_audit.csv',index=False)
    estimates=[];coefs=[];ns=[];preds=[];metrics=[]
    for outcome,d,controls in [('house',hs,hc),('governor',gs,gc)]:
        d.to_csv(args.output/f'{outcome}_sample.csv',index=False)
        a,b,c=association(d,controls,outcome,args.lane);estimates.append(a);coefs.append(b);ns.append(c)
        p,m=forecast(d,controls,outcome,args.lane);preds.append(p);metrics.append(m)
    for name,parts in [('association_estimates',estimates),('association_coefficients',coefs),('sample_counts',ns),('forecast_predictions',preds),('forecast_metrics',metrics)]:
        pd.concat(parts,ignore_index=True).to_csv(args.output/f'{name}.csv',index=False)
    inputs={k:str(getattr(args,k)) for k in ['house_data','governor_data','senate_data','score_data','selection_json','threshold_json']}
    summary={'lane':args.lane,'selected_own_model':selection['selected_model'],'thresholds':threshold,
       'own_validation_status':args.own_validation_status,'availability_controls':AVAIL,
       'association_estimates':json.loads(pd.concat(estimates,ignore_index=True).to_json(orient='records')),
       'sample_counts':json.loads(pd.concat(ns,ignore_index=True).to_json(orient='records')),
       'forecast_metrics':json.loads(pd.concat(metrics,ignore_index=True).to_json(orient='records')),
       'inputs':inputs,'sha256':{k:hashlib.sha256(Path(v).read_bytes()).hexdigest() for k,v in inputs.items()},
       'limitations':['Observational associations do not identify causal coattails.','Intervals condition on the generated score and selected architecture; they omit first-stage and selection uncertainty.',
         'Previous teammate votes may already contain effects of the senator, so this is incremental current association.',
         'Two-party share does not identify turnout versus persuasion or total additional votes.',
         'The architecture was selected using2010–2014own-vote outcomes; earlier rolling-score applications are retrospective in architecture.',
         'House geography requirements leave only at-large observations in2022; governor returns end2020.',
         'Observed historical availability and score availability are separate fields; exact redundant controls are dropped and listed.',
         'Unknown candidate scores are never classified as stars or lower-tail nominees.']}
    (args.output/'summary.json').write_text(json.dumps(summary,indent=2,allow_nan=False)+'\n')
    print(pd.concat(estimates,ignore_index=True)[['outcome','period','predictor','estimate_pp','low95','high95','state_elections','states','any_star_races']].to_string(index=False))
    print(pd.concat(metrics,ignore_index=True)[['outcome','period','model','mae_pp','baseline_mae_pp','mae_gain_pp','gain_low95','gain_high95']].to_string(index=False))


if __name__=='__main__':main()
