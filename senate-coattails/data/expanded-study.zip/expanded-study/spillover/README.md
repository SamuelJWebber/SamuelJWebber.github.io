> Distribution note: the package includes code and aggregate outputs. Raw inputs, individual modeled scores, merged samples and observation-level predictions mentioned below are regenerated in the external working directory by the top-level `reproduce.py`. Run optional source scripts inside that working copy to keep caches out of the checkout.

# Frozen learned Senate strength and same-ballot outcomes

This module follows the independently selected own-Senate-vote score into House and governor outcomes. Its candidate-strength architecture and star thresholds were frozen by the own-vote module before these peer-outcome fits. No peer result chooses or retunes the score. This remains an observational study, not a natural experiment.

## Reproduction and inputs

Python dependencies: pandas, NumPy and SciPy. Example command, with explicit paths to prepared source files and the frozen score artifacts:

```sh
OPENBLAS_NUM_THREADS=1 python spillover.py \
  --house-data /path/to/house_districts.csv \
  --governor-data /path/to/governor_state_returns.csv \
  --senate-data ../score/results/joint_sample.csv \
  --score-data ../score/results/frozen_candidate_scores.csv \
  --selection-json ../score/results/model_selection.json \
  --threshold-json ../score/results/score_thresholds.json \
  --output broad --lane broad
python verify_numeric.py broad
```

All paths are caller supplied. `summary.json` records input fingerprints. The source files are the same prepared district and statewide governor returns used by stage2. The module itself rebuilds geography-compatible House lags and previous regular governor lags; its outcome files are not required as inputs. `verify_numeric.py` independently verifies the full-period continuous coefficients and clustered standard errors using weighted residualization and SciPy least squares.

## Frozen score and units

The broad own-vote development comparison selected `history_centered`, after testing office experience, pre-primary fundraising dominance and combinations on2010–2014own-Senate results. Thus the winning broad score still requires earlier Senate performance; the new-source search did **not** establish a stronger score for first-time Senate candidates. Unknown histories remain unknown and do not become low-quality candidates.

Individual scores are learned candidate contributions to own Senate two-party vote share relative to the own-model's fixed all-zero candidate-feature reference. They are supplied in vote-share **fractions**. `quality_10pp = (score_D − score_R)/0.1`; its regression coefficient, multiplied by100, reports peer vote-share percentage points per10additional predicted own-vote points. This scale differs from stage2's ten points of raw historical performance. It is a reporting scale, not a promise that ten-point changes are common within the observed score support.

Each scored election uses coefficients fitted strictly before that election. The first scoring year is1996, after enough earlier training observations become available. The architecture was selected using2010–2014outcomes, so applying that architecture to earlier elections is retrospective even though each year's fitted coefficients use only earlier outcomes.

The star cutoff is **+3.224656596335925 predicted own-vote points** and the lower cutoff is **−1.4622881209231381 points**. The reference consists of182observed individual-score appearances through2008, retaining repeated nominees, with every appearance scored by strictly earlier coefficients. Thresholds are supplied by the own-vote module and never recomputed after a peer join. Stars and lower-tail labels require an observed score. The tail regression uses `star_D − star_R` and `low_D − low_R` jointly, imposing party-reversal symmetry. Moving from an R star to a D star changes the signed exposure by two units, not one.

## Samples and boundaries

House:2,338district elections in345state-elections across49states,1996–2022. Each state-election has total weight1, divided equally across its available districts. The lag is exactly two years earlier on the same `st_dist_redist_FE` geography. A seat that is statewide at-large in both years uses the state's preceding at-large result even if a census-era identifier changes. District numbers alone do not establish unchanged geography. Source rows for2022have an unreliable all-zero redistricting flag, so that flag is not used to override the boundary identifier; only one at-large observation survives in2022. Both current major-party candidates must have positive votes and named candidates. Prior House share and both current and previous House incumbent-party controls must be observed.

Governor:173regular races in43states,1996–2020, one equal weight per race. The immediately preceding regular governor election is used, not a universal four-year lag. Biennial terms are accepted. Arizona's1991runoff is the completion of the1990regular cycle and can be the known lag for1994; it is not treated as a same-ballot1990outcome. Oregon2016is excluded as a special race and from regular predecessors. Current or previous county-completeness flags exclude the affected Hawaii records conservatively; the flag is not proof that every flagged statewide total is wrong. Invalid zero-party current or previous returns and unresolved cycle gaps are excluded. Governor incumbent metadata is corrected for Nebraska2014and Minnesota1982, following the documented stage2 audit. `governor_join_audit.csv` records exclusions.

All observations lacking a fitted own-score model are excluded. A fitted model with one or both nominees' substantive score unknown can still produce a row: source-availability indicators remain explicit, and the unknown nominee is never called an ordinary observed candidate or assigned to a tail.

## Specifications

Continuous and tail regressions are separate. Both control for previous peer share, strictly preceding presidential state lean, current peer incumbent party, corrected Senate incumbent party, and source-availability indicators. House also controls for previous House incumbent party. There are separate D/R indicators for earlier-Senate-history availability, office-category availability, primary fundraising-share availability, primary-field availability, and generated-score availability. These fields remain separate in the data even when some coincide exactly. Duplicate or constant controls are dropped only as redundant columns and are listed in the output.

The observational associations add state and election-year fixed effects. Fixed effects and nuisance controls take precedence in rank checks: a score absorbed by them is marked **not identified**, rather than keeping the score by dropping a state effect. Current Senate votes, current presidential votes, current turnout and current spending do not enter these peer models. No quadratic or other functional-form search is performed using peer outcomes.

State-clustered sandwich covariance uses G/(G−1) × (N−1)/(N−rank), with t critical values on G−1degrees of freedom. House point estimates use equal-state-election weights; the covariance clusters all of a state's rows together. Intervals condition on the generated scores and chosen architecture: they omit first-stage fitting, measurement, threshold and model-selection uncertainty. Reported secondary intervals are not multiplicity adjusted.

Recent governor-only fixed-effects associations are not identified:32races across30states leave no residual variation after the fixed effects and controls. This is an explicit sample limitation, not a zero-effect estimate.

Forecasts are a separate secondary diagnostic. For development, both peer models train through2008and predict2010–2014. For test, both refit through2014and predict2016–2022House or2016–2020governor results. This common protocol differs from the old stage2governor model that retained its2008fit during test. Forecasts contain the known WhiteHouse party and its midterm interaction instead of state/year fixed effects; they are ordinary weighted least squares and are not clipped. Baseline and augmented errors use the exact same rows and weights. The paired error interval resamples states10,000times, conditioning on the fitted forecasts; it does not represent uncertainty over new national election cycles.

## Broad-score results

All effects below are observational peer-share points. The continuous unit is ten predicted own-vote points; star effects are one signed star-indicator unit with the lower tail controlled separately.

| Outcome/period | Elections | Continuous association | 95% interval | Star races |
|---|---:|---:|---:|---:|
| House,all available years |345|−1.49|−4.20to+1.22|27|
| House,2000onward |282|−0.18|−3.29to+2.92|22|
| House,test-period refit |90|+8.15|−0.77to+17.08|3|
| Governor,all available years |173|−2.77|−11.73to+6.19|14|
| Governor,2000onward |144|+4.01|−6.74to+14.75|11|
| Governor,test-period refit |32|Not identified|—|1|

The full-period star association is−0.34[−2.31,+1.64]for House and−0.22[−6.97,+6.53]for governor. Wide intervals and sparse recent star coverage preclude a confident transferable star effect.

Held-out House MAE is5.036points for baseline and5.066with the continuous score: improvement−0.030[−0.107,+0.047]. Governor MAE is5.059and5.465: improvement−0.406[−0.709,−0.088]. Positive improvement means lower error after adding the score. Neither held-out comparison improves. The recent-period association is fitted to those recent outcomes and must not be presented as successful out-of-time prediction.

## Interpretation and output

Prior peer results address persistent party strength but may already include the senator's earlier coattails. The coefficient therefore describes incremental current association beyond recorded prior support. Candidate recruitment, opponent weakness, local trends and common state campaign shocks can still confound it. Fixed effects do not create random nomination. Two-party share can reflect turnout and persuasion but does not separate them or measure total additional voters. These results cannot supply an Ossoff-specific causal effect or establish that effective candidates have no coattails.

`association_estimates.csv` supplies effects and identification flags; `sample_counts.csv` supplies star/score coverage; `forecast_metrics.csv` supplies matched prediction comparisons; `forecast_predictions.csv` supplies every prediction. Full coefficients, prepared outcome rows, audit files and a combined `summary.json` are also emitted. A separately frozen matched-FEC lane can use the same interface when its own-vote validation is complete; the broad lane must not be replaced merely because another measure has larger peer associations.

## Matched-FEC exploratory followthrough

The separate matched-FEC own-vote exercise froze `national_breadth`: approximate disclosed national contributor breadth, normalized using earlier-fitted structural models. It won the development comparison but **failed held-out own-vote validation**: own-Senate MAE increased from 4.989 to 5.384 points on 112 test races. Its peer followthrough is therefore exploratory, not confirmation of a validated talent measure. The common own-vote cohort requires both nominees' donor-breadth coverage and official contribution totals. Its rows and normalizers are specified by the own-vote/fundraising modules; the peer module does not retune them.

Run the same command using `../score/donor_results/common_sample.csv`, `../score/donor_results/frozen_candidate_scores.csv` and that folder's selection/threshold JSON files, with:

```sh
--output donor --lane matched_fec \
--own-validation-status failed_heldout_own_vote_validation \
--extra-availability committee_mapped_D committee_mapped_R \
  bulk_cycle_available_D bulk_cycle_available_R both_observed paired_breadth_observed
```

Those additional financial-coverage indicators are constant in the complete common cohort and are retained in the data, then dropped as redundant design columns. They are not donation amounts or postulated mediators. Statewide donor totals are approximate disclosed identities, not every unique donor; transaction-date filtering does not recreate the historical filing archive because amendments can arrive later.

FEC rolling scores start in 2004. The fixed star cutoff is +4.837330120777927 predicted own-vote points; the lower cutoff is −5.9731939078632064 points. They come from 174 observed training nominee-score appearances through 2008, before the peer join.

| Peer outcome | District rows | State elections | States | Star appearances D/R | Races with a star | Both-star races |
|---|---:|---:|---:|---:|---:|---:|
| House, 2004–2022 | 1,601 | 225 | 49 | 38 / 27 | 47 | 18 |
| Governor, 2004–2020 | 109 | 109 | 42 | 17 / 12 | 22 | 7 |
| House test period | 576 | 83 | 46 | 21 / 11 | 24 | 8 |
| Governor test period | 31 | 31 | 29 | 9 / 4 | 11 | 2 |

Both nominees have observed scores in every included FEC race. A signed star difference of zero in a both-star race does **not** mean neither candidate is exceptional; it means their star indicators give no relative party advantage under this symmetric model. Two-party share cannot identify common mobilization by both parties.

| FEC peer association | Estimate | 95% state-cluster interval |
|---|---:|---:|
| House, per 10 predicted own-vote points | −0.26 | −1.76 to +1.25 |
| House, signed star indicator | +0.77 | −1.08 to +2.62 |
| Governor, per 10 predicted own-vote points | +5.03 | −1.27 to +11.33 |
| Governor, signed star indicator | +2.43 | −4.93 to +9.79 |

The recent House continuous association is −0.11 [−1.39, +1.17]; recent governor fixed-effects coefficients are not identified. The 2000-onward sensitivity equals the full-period estimate because this score begins in 2004; it is not independent supporting evidence.

On identical held-out rows, House baseline MAE is 4.940 versus 5.025 with the score, an improvement of −0.085 [−0.144, −0.027]. Governor MAE is 4.860 versus 5.662, improvement −0.802 [−1.369, −0.242]. These are within-lane comparisons; raw errors should not rank the FEC and broad measures against each other because the cohorts differ. The FEC score's own-vote and peer-vote holdouts both fail to improve in this exercise. No stronger causal interpretation is justified by the positive but imprecise governor association.
