#!/usr/bin/env python3
"""Audit reconstructed donor benchmark outputs without writing row-level data.

Usage: python verify_donor_benchmark.py --score-dir /path/to/score \
    --report donor_benchmark_audit.txt

Requires the locally reconstructed score/input, score/results/joint_sample.csv,
and score/donor_results files. None of those row-level inputs are redistributed
by this script. This checks numerical consistency, timing and reference rules;
it does not independently revalidate upstream candidate/donor identities.
"""
import argparse
import hashlib
import importlib
import json
from pathlib import Path
import sys

import numpy as np
import pandas as pd


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def rank_check(frame):
    active = frame.loc[:, frame.nunique() > 1]
    design = np.column_stack([np.ones(len(active)), active])
    assert np.isfinite(design).all()
    rank = int(np.linalg.matrix_rank(design))
    assert rank == design.shape[1], (rank, design.shape[1])
    return {'active_rank': rank, 'active_columns_with_intercept': design.shape[1],
            'constant_columns': frame.columns[frame.nunique() <= 1].tolist()}


def compare_predictions(frame, values, saved):
    computed = frame[['state_abbrev', 'year']].copy()
    computed['recomputed'] = values
    merged = computed.merge(saved[['state_abbrev', 'year', 'prediction']],
                            on=['state_abbrev', 'year'], validate='one_to_one')
    assert len(merged) == len(computed) == len(saved)
    error = float(np.max(np.abs(merged.recomputed - merged.prediction)))
    assert error < 1e-10, error
    return error


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--score-dir', type=Path, required=True)
    parser.add_argument('--results-dir', type=Path)
    parser.add_argument('--report', type=Path)
    args = parser.parse_args()
    root = args.score_dir.resolve()
    out = args.results_dir.resolve() if args.results_dir else root / 'donor_results'
    sys.path.insert(0, str(root))
    b = importlib.import_module('benchmark_donors')
    d = pd.read_csv(out / 'common_sample.csv')
    s = pd.read_csv(out / 'frozen_candidate_scores.csv')
    p = pd.read_csv(out / 'own_vote_predictions.csv')
    metrics = pd.read_csv(out / 'own_vote_metrics.csv')
    selection = json.loads((out / 'model_selection.json').read_text())
    thresholds = json.loads((out / 'score_thresholds.json').read_text())
    assert len(b.MODELS) == 11
    selected = selection['selected_model']
    dev = metrics.query('protocol == "fixed_cutoff_primary" and stage == "development" and subgroup == "all"')
    assert selected == dev.sort_values(['mae_pp', 'model']).iloc[0].model
    assert d.groupby('split').size().to_dict() == selection['split_counts']
    assert not p.duplicated(['protocol', 'model', 'stage', 'state_abbrev', 'year']).any()
    fixed_checks = []
    for stage, cutoff in [('development', 2008), ('test', 2014)]:
        train = d[d.year <= cutoff]
        test = d[d.split == stage]
        assert test.year.min() > cutoff
        tr, te, norms = b.normalize(train, test)
        x = pd.concat([b.normalizer_design(tr, party) for party in ['D', 'R']])
        rank_check(x)
        changed = test.copy()
        changed['dshare'] = .123456
        _, changed_te, changed_norms = b.normalize(train, changed)
        assert norms == changed_norms
        for name, components in b.MODELS.items():
            fitted = b.q.fit(tr, components)
            assert np.isfinite(fitted['coef']).all()
            rank = rank_check(tr[fitted['features']])
            prediction = b.q.apply(fitted, te)
            assert np.array_equal(prediction, b.q.apply(fitted, changed_te))
            saved = p[(p.protocol == 'fixed_cutoff_primary') &
                      (p.stage == stage) & (p.model == name)]
            error = compare_predictions(te, prediction, saved)
            fixed_checks.append({'stage': stage, 'model': name,
                                 'maximum_prediction_error': error, **rank})
    rolling_checks = []
    for year in sorted(s.loc[s.prediction.notna(), 'year'].unique()):
        train = d[d.year < year]
        test = d[d.year == year]
        assert train.year.nunique() >= 4 and train.year.max() < year
        tr, te, norms = b.normalize(train, test)
        rank_check(pd.concat([b.normalizer_design(tr, party) for party in ['D', 'R']]))
        fitted = b.q.fit(tr, b.MODELS[selected])
        rank = rank_check(tr[fitted['features']])
        error = compare_predictions(te, b.q.apply(fitted, te), s[s.year == year])
        for party in ['D', 'R']:
            zero = te.copy()
            for component in b.MODELS[selected]:
                zero[component + '_' + party] = 0.
            assert np.array_equal(b.q.contributions(fitted, zero, party), np.zeros(len(zero)))
        rolling_checks.append({'year': int(year), 'maximum_prediction_error': error, **rank})
    unavailable = s.prediction.isna()
    flags = [f'quality_{kind}_{party}' for kind in ['observed', 'high', 'low'] for party in ['D', 'R']]
    assert not s.loc[unavailable, flags].to_numpy().any()
    assert s.loc[unavailable, ['quality_score_D', 'quality_score_R', 'quality_score_difference']].isna().all().all()
    scored = s.score_training_last_year.notna()
    assert (s.loc[scored, 'score_training_last_year'] < s.loc[scored, 'year']).all()
    appearances = pd.concat([s.loc[s.year.le(2008) & s[f'quality_observed_{party}'], f'quality_score_{party}'] for party in ['D', 'R']]).dropna()
    assert len(appearances) == thresholds['n']
    assert np.allclose(appearances.quantile([.1, .9]), [thresholds['p10'], thresholds['p90']], atol=1e-12)
    metric_checks = []
    for (protocol, model, stage), group in p.groupby(['protocol', 'model', 'stage']):
        row = metrics[(metrics.protocol == protocol) & (metrics.model == model) &
                      (metrics.stage == stage) & (metrics.subgroup == 'all')].iloc[0]
        mae = float(np.mean(np.abs(group.actual - group.prediction)) * 100)
        baseline = float(np.mean(np.abs(group.actual - group.baseline_prediction)) * 100)
        assert np.isclose(mae, row.mae_pp, atol=1e-10)
        assert np.isclose(baseline, row.baseline_mae_pp, atol=1e-10)
        if model == selected:
            metric_checks.append({'protocol': protocol, 'stage': stage, 'races': len(group),
                                 'mae_pp': mae, 'baseline_mae_pp': baseline,
                                 'mae_gain_pp': baseline - mae})
    inputs = {'joint': root / 'results/joint_sample.csv',
              'breadth': root / 'input/race_breadth_features.csv',
              'money': root / 'input/senate_june30_race_money.csv',
              'population': root / 'input/prior_census_population.csv'}
    recorded_hashes = {Path(k).name: v for k, v in selection['inputs_sha256'].items()}
    input_hashes = {str(path.relative_to(root)): sha256(path) for path in inputs.values()}
    for path in inputs.values():
        assert sha256(path) == recorded_hashes[path.name]
    report = {
        'result': 'PASS: no blocking numerical, chronology, missing-score or shared-reference defect found.',
        'scope': 'Authored-code audit and reconstructed-output verification; no upstream identity or archival-vintage revalidation.',
        'selection': '11 fixed architectures, lowest 2010–2014 development MAE only; national_breadth wins.',
        'selected_model': selected,
        'split_counts': d.groupby('split').size().to_dict(),
        'first_rolling_score_year': int(s.loc[scored, 'year'].min()),
        'unscored_early_races': int(unavailable.sum()),
        'threshold_appearances': len(appearances),
        'fixed_prediction_checks': fixed_checks,
        'rolling_prediction_checks': rolling_checks,
        'metric_checks': metric_checks,
        'input_sha256': input_hashes,
        'code_sha256': {name: sha256(root / name) for name in ['benchmark_donors.py', 'benchmark_quality.py', 'core.py']},
        'verifier_sha256': sha256(Path(__file__).resolve()),
        'results_sha256': {name: sha256(out / name) for name in ['common_sample.csv', 'frozen_candidate_scores.csv', 'own_vote_predictions.csv', 'own_vote_metrics.csv', 'model_selection.json', 'score_thresholds.json']},
        'interpretation': 'Primary held-out and expanding held-out MAE worsen versus baseline. The donor score has failed held-out own-vote validation and supports exploratory follow-through only.',
        'limitations': ['Architecture is selected on 2010–2014; earlier rolling scores are retrospective in architecture.',
                       'Source contribution files and amendments are retrospective, not verified historical releases.',
                       'Cycle-centered sensitivity uses contemporaneous other-state fundraising, not their vote outcomes.',
                       'Reported bootstrap intervals and upstream candidate/donor matching are not independently revalidated here.'],
        'handoff_review': 'Spillover code joins state/year one-to-one, requires prior score training cutoff, filters score_model_available, rejects unknown tail flags; donor summary marks failed_heldout_own_vote_validation.'
    }
    rendered = 'DONOR BENCHMARK INDEPENDENT AUDIT\n\n' + json.dumps(report, indent=2) + '\n'
    if args.report:
        args.report.write_text(rendered)
        print(f'PASS: {len(fixed_checks)} fixed fits, {len(rolling_checks)} rolling fits; report: {args.report}')
    else:
        print(rendered)


if __name__ == '__main__':
    main()
