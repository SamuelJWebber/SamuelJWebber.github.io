import sys,json,argparse
from pathlib import Path
import numpy as np,pandas as pd
from scipy.stats import t
ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,required=True);ap.add_argument('--output',type=Path);args=ap.parse_args();sys.path.insert(0,str(args.root));import on_off as m
p=args.root;d=pd.read_csv(p/'corrected_panel.csv')
terms=['quality_phase4','quality_phase6'];n=len(d)
# FWL residualization independently using lstsq on nuisance design, then 2-regressor OLS.
f1=pd.get_dummies(d.event_id,drop_first=True,dtype=float);f2=pd.get_dummies(d.party.astype(str)+'-'+d.year.astype(str),drop_first=True,dtype=float)
z=np.column_stack([np.ones(n),d[m.PRIMARY_CONTROLS],f1,f2]).astype(float);x=d[terms].to_numpy();y=d.outcome_party_share.to_numpy()
xr=x-z@np.linalg.lstsq(z,x,rcond=None)[0];yr=y-z@np.linalg.lstsq(z,y,rcond=None)[0];b=np.linalg.solve(xr.T@xr,xr.T@yr);u=yr-xr@b
fullrank=np.linalg.matrix_rank(np.column_stack([z,x]));states,ids=np.unique(d.state_abbrev,return_inverse=True);scores=np.zeros((len(states),2));np.add.at(scores,ids,xr*u[:,None]);bread=np.linalg.inv(xr.T@xr);cov=bread@scores.T@scores@bread*len(states)/(len(states)-1)*(n-1)/(n-fullrank)
legacy=m.fit(d,terms);max_b_diff=float(np.max(np.abs(b-legacy[0][1:3])));max_cov_diff=float(np.max(np.abs(cov-legacy[1][1:3,1:3])))
crit=t.ppf(.975,len(states)-1);out=[]
for name,v in [('placebo',[1,0]),('scheduled_vs_meanoff',[-.5,1]),('scheduled_vs_lastoff',[-1,1]),('scheduled_after_trend',[-2,1])]:
 v=np.array(v);est=float(v@b)*10;se=float(np.sqrt(v@cov@v))*10;out.append(dict(contrast=name,estimate_pp=est,se_pp=se,low95=est-crit*se,high95=est+crit*se))
result={'n':n,'events':d.event_id.nunique(),'states':len(states),'full_columns':z.shape[1]+2,'full_rank':fullrank,'rank_residualized_x':np.linalg.matrix_rank(xr),'coefficient_max_abs_diff':max_b_diff,'covariance_max_abs_diff':max_cov_diff,'estimates':out,'duplicate_event_phase':int(d.duplicated(['event_id','phase']).sum()),'balanced_event_counts':d.groupby('event_id').size().value_counts().to_dict(),'phase_count':d.phase.value_counts().to_dict(),'bad_score_change_within_event':int(d.groupby('event_id').score_own.nunique().ne(1).sum()),'actual_rerun_count':int(d[d.phase.eq(6)].actual_rerun.sum())}
(args.output or p/'independent_numerical_audit.json').write_text(json.dumps(result,indent=2,default=int));print(json.dumps(result,indent=2,default=int))
# Nuisance controls may use subsequent political events; show estimate robustness when omitted.
for controls in [['phase4','phase6'],m.PRIMARY_CONTROLS]:
 bb,cv,names,c,rank=m.fit(d,terms,controls=controls);vv=np.zeros(len(bb));vv[1:3]=[-2,1];print('trend controls',controls,'est',float(vv@bb*10),'se',float(np.sqrt(vv@cv@vv)*10))
print('phase6 years',d[d.phase.eq(6)].year.value_counts().sort_index().to_dict())
