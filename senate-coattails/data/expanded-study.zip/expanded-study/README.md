# Expanded Senate candidate-strength and coattails study

This package tests independently constructed candidate-strength proxies against the candidate's own Senate result, freezes the selected models, and follows those scores into same-ballot House and governor outcomes. It also compares House outcomes across a senator's scheduled on- and off-ballot years. **These are observational estimates and prediction checks, not an identified causal contribution for one candidate.**

The new donor experiment reaches newcomers, but its selected national-breadth model fails the held-out own-election check. On 112 Senate races in 2016–2022, fixed-model MAE increases from **4.989 to 5.384 percentage points**; the expanding historical model also worsens, **4.679 to 4.828**. The donor-based coattail results are therefore an explicitly exploratory follow-through, not validation of “charisma.” The broad experience/history competition selects prior Senate history and still leaves newcomers unscored when they have no qualifying history.

The corrected schedule comparison covers 296 Senate-term cohorts and 49 states. Per ten points of prior Senate overperformance, its scheduled-versus-average-off-cycle House association is **−0.17 points**, 95% interval **−1.44 to +1.11**. A linear off-cycle trend adjustment gives **+1.31**, interval **−1.59 to +4.21**. The uncertainty and selection of geography-compatible cohorts matter; these findings do not prove a zero causal effect.

## Reproduce the models

Python 3.12 was used. From this directory:

```sh
python -m pip install -r requirements.txt
OPENBLAS_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 python reproduce.py --fetch --work-dir /tmp/senate-coattails-reproduction
```

This is a complete model reproduction from hash-verified MIT/district and experience-source inputs **plus the included FEC candidate aggregates and public statewide governor returns**. It does not download or reprocess the 15.1 GB donor archives by default. It rebuilds nominee attributes, historical features, both own-vote model competitions, both spillover lanes, the corrected schedule comparison, and the reported aggregate checks. All fetched data, restricted row derivatives, caches and regenerated results go to the external work directory. The script rejects a work directory inside this package.

Internet access to Harvard Dataverse and the author's public experience-data page is required on the first run. Source versions are pinned by SHA-256. A changed or unavailable upstream file stops the run rather than silently changing the study. Reuse already acquired exact inputs with:

```sh
OPENBLAS_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 python reproduce.py \
  --input-dir /path/to/three-input-files \
  --experience-source-dir /path/to/four-author-csv-files \
  --work-dir /tmp/senate-coattails-reproduction
```

The first directory must contain `mit_senate.tsv`, `mit_president.csv` and `house_districts.csv`; the second contains the four filenames in `quality_sources/provenance.json`. Hashes are checked in both modes. `--skip-donor` reproduces only the broad historical-score and schedule analyses.

## Optional reconstruction of FEC counts

The included anonymous nominee aggregates make the main reproduction practical. To reconstruct them from the original receipt files as well:

```sh
OPENBLAS_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 python reproduce.py --fetch \
  --rebuild-fec --work-dir /tmp/senate-coattails-full-rebuild
```

This fetches and checks the 42 files in `fundraising/source_manifest.json`, including **15.1 GB compressed individual-contribution files**. Allow at least 20 GB free disk, several GB of RAM, and substantial download and processing time; runtime depends on the machine and network. The streaming aggregator avoids extracting the full text archives. An existing source cache can be reused with `--fec-source-dir /path/to/fec-zips`. The published package test uses the included aggregate counts; it does not repeat this entire large-source extraction. The streaming and original aggregators were independently compared on all 994 candidate-window rows and 11 measures for 2006.

The optional raw reconstruction is limited to donor breadth. Official June financial-summary amounts are included separately; their acquisition, workbook/PDF parsing and nominee-joining scripts are in `fundraising/summaries/`. Its README and source manifest give the exact sources and commands. The optional governor-source rebuild requires `pyreadr`, which is not needed for the main command.

## Files and measurement boundaries

- `score/`: own-Senate validation, fixed development selection, rolling historical scoring, aggregate coefficients and metrics. Broad and FEC-matched models have separate results.
- `fundraising/`: public FEC candidate mappings, anonymous count aggregates, coverage, extraction code and source hashes. Counts are approximate disclosed name+ZIP identities, not all donors or a small-donor census. Gross positive bulk dollars are an audit field; the models use official summary money.
- `quality_sources/`: acquisition and audited mapping code, source provenance and aggregate coverage. The author page lists “CC BY 4.0 (proposed)”; the package does not represent that as a confirmed archival license. Source rows and row-level experience features are reconstructed locally.
- `population/`: prior-decennial Census residents. Census years strictly precede election years; the denominator is neither current population nor eligible voters.
- `spillover/`: aggregate House/governor associations, held-out forecasts and independent numeric checks. Generated district/race samples and predictions are intentionally omitted.
- `vote_volume/`: secondary House vote-count-per-resident checks with separate own/opponent scores; these are not turnout rates and do not isolate persuasion.
- `house_design/`: schedule comparison, corrected-score sensitivities, aggregate coverage and audits. Public CC0 legislator roster snapshots are included to keep historical identities reproducible.
- `audits/` and `literature/`: authored audits, methodological notes and primary-source citations. Downloaded papers, third-party replication archives and donor-level records are excluded.
- `site/`: the public dashboard generator and its curated JSON snapshot, including public candidate facts, FEC counts and newly computed modeled contributions. This is an analysis display, not a causal effect for an individual.
- `inputs/`: public governor-return aggregate, MIT-only Senate nominee returns and frozen legacy thresholds. These files do not contain the licensed district metadata.

`DATA_AVAILABILITY.md` states what is included, reconstructed, or optional. `SOURCES.json` and the module manifests supply URLs, attribution and hashes. `SOURCE_SNAPSHOT.json` records the working snapshots used for the included files. `SHA256.json` verifies packaged files; `verify_results.py` compares regenerated numeric tables with their frozen references. `REPRODUCTION.json` records the package-level validation performed for this release: the fresh-download model run finished in 83.93 seconds in the checked environment, with 18 aggregate tables and the complete public dashboard JSON reproduced. This timing excludes the optional 15.1 GB raw FEC reconstruction.

June 30 is a fixed pre-general cutoff, not a universal pre-primary date. Later amendments and changing itemization thresholds make these receipt-date-defined retrospective features, not exact historical July data vintages. The 2015 disclosure change receives a declared >$200-single-receipt sensitivity. Model architecture is selected on 2010–2014 own-election results, so applications to earlier elections are retrospective in architecture even when their coefficients use only earlier observations. Confidence intervals condition on that architecture and generated scores and omit some first-stage and selection uncertainty.

The public distribution omits the DeLuca–Moskowitz–Schneer district source and its merged row derivatives, including standalone individual fitted-score tables; the curated public dashboard snapshot is included as an authorized analysis output. This is the package's distribution boundary; it does not purport to settle all rights in derived statistics. Public availability is not presented as proof of a redistribution license. See the original providers' terms and source attribution before sharing locally reconstructed source-derived tables.

Study author: Samuel Webber. Assembly and numerical verification were performed with Codex.
