"""Check package integrity and, optionally, reproduced aggregate results."""
import argparse,hashlib,json
from pathlib import Path
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parent
CHECKS=['score/results/own_vote_metrics.csv','score/results/historical_baseline_fits.csv',
 'score/results/rolling_score_coefficients.csv','score/donor_results/own_vote_metrics.csv',
 'score/donor_results/rolling_score_coefficients.csv','score/donor_results/fixed_normalizers.csv',
 'score/donor_results/rolling_normalizers.csv','spillover/broad/association_estimates.csv',
 'spillover/broad/forecast_metrics.csv','spillover/broad/sample_counts.csv',
 'spillover/donor/association_estimates.csv','spillover/donor/forecast_metrics.csv','spillover/donor/sample_counts.csv',
 'house_design/quality_comparison_estimates.csv','house_design/coverage_by_cohort.csv',
 'vote_volume/estimates.csv','vote_volume/coverage.csv','vote_volume/expected_districts.csv']

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--reproduced',type=Path);p.add_argument('--skip-donor',action='store_true');a=p.parse_args()
 checked=[]
 if (ROOT/'SHA256.json').exists():
  for name,expected in json.loads((ROOT/'SHA256.json').read_text()).items():
   actual=hashlib.sha256((ROOT/name).read_bytes()).hexdigest()
   if actual!=expected:raise AssertionError(f'Package checksum mismatch: {name}')
 if a.reproduced:
  for name in CHECKS:
   if a.skip_donor and ('donor_results' in name or '/donor/' in name or 'vote_volume/' in name):continue
   ref=ROOT/name;new=a.reproduced/name
   if not ref.exists():raise FileNotFoundError(f'Frozen expected aggregate absent: {name}')
   left=pd.read_csv(ref);right=pd.read_csv(new)
   pd.testing.assert_frame_equal(left,right,check_dtype=False,check_exact=False,rtol=1e-7,atol=1e-8)
   checked.append({'file':name,'rows':len(left)})
  for name in ['score/results/model_selection.json','score/results/score_thresholds.json',
               'score/donor_results/model_selection.json','score/donor_results/score_thresholds.json']:
   if a.skip_donor and 'donor_results' in name:continue
   expected=json.loads((ROOT/name).read_text());actual=json.loads((a.reproduced/name).read_text())
   for key in ['selected_model','model','p10','p90','n']:
    if key in expected:
     if isinstance(expected[key],float):assert np.isclose(expected[key],actual[key],rtol=1e-9,atol=1e-12),(name,key)
     else:assert expected[key]==actual[key],(name,key)
  if not a.skip_donor:
   expected=json.loads((ROOT/'site/expanded-study.json').read_text())
   actual=json.loads((a.reproduced/'site/expanded-study.json').read_text())
   def compare_json(x,y,path='root'):
    if isinstance(x,dict):
     assert set(x)==set(y),path
     for k in x:compare_json(x[k],y[k],path+'.'+k)
    elif isinstance(x,list):
     assert len(x)==len(y),path
     for i,(xx,yy) in enumerate(zip(x,y)):compare_json(xx,yy,path+'.'+str(i))
    elif isinstance(x,(float,int)) and not isinstance(x,bool):assert np.isclose(x,y,rtol=1e-7,atol=1e-8),path
    else:assert x==y,path
   compare_json(expected,actual)
  report={'passed':True,'dashboard_json_verified':not a.skip_donor,'aggregate_comparisons':checked,'floating_tolerance':{'rtol':1e-7,'atol':1e-8}}
  (a.reproduced/'VERIFICATION.json').write_text(json.dumps(report,indent=2)+'\n')
 else:report={'package_checksums_passed':(ROOT/'SHA256.json').exists(),'note':'Use reproduce.py to regenerate source-dependent results.'}
 print(json.dumps(report,indent=2))
if __name__=='__main__':main()
