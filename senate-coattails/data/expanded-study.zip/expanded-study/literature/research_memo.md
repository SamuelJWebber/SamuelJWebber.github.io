# Independent candidate strength and causal coattails: stage 3 research memo

Prepared 2026-11-05. Purpose: choose an independently defined candidate-strength treatment, freeze it before observing the concurrent down-ballot outcome, and distinguish descriptive association from a credible natural experiment.

## Recommendation

The most immediately useful broad Senate input remains Algara's pre-primary candidate file plus FEC individual-receipt records. Use breadth measured by a fixed pre-primary cutoff, distinguishing distinct identifiable itemized donors, in-state donors, geographic spread, and dollar totals. Call these fundraising or support-breadth measures rather than charisma. Own-race performance should come from prior elections or strictly out-of-sample predictions. Neither contemporary Senate residuals nor general-election receipts are clean pretreatment definitions.

A close-primary design could compare nomination of the independently stronger versus weaker candidate where their primary vote shares nearly tie, then measure same-ballot House/governor vote outcomes. This identifies the nomination package for marginally decided primaries, not an individual candidate's full contribution. First verify primary runoff handling, exact election dates, lagged House/presidential outcome balance, pre-primary candidate characteristics, and adequate sample size. Broadly pooled Senate and governor primaries could improve power but alter the estimand. Senate class timing provides useful on/off-ballot comparison and placebo cycles; it does not itself randomize candidate strength or recruitment.

The current literature search did not find a ready, validated dataset that simultaneously contains an independent Senate 'all-star' score, quasi-random nomination, and same-ballot outcomes. The sources below enable credible next steps but should not be represented as having solved that identification problem.

## Myers: large, reusable primary data, but no donor breadth

Andrew C. W. Myers, *Do Donors Punish Extremist Primary Nominees? Evidence from Congress and American State Legislatures*, APSR online 2025 / volume 120 (2026), DOI https://doi.org/10.1017/S000305542510138X . Article: https://www.cambridge.org/core/journals/american-political-science-review/article/do-donors-punish-extremist-primary-nominees-evidence-from-congress-and-american-state-legislatures/50ACE93E42F2CE12BC079CAD78F2D240 . Replication: https://doi.org/10.7910/DVN/PCPPHI . Download API https://dataverse.harvard.edu/api/access/datafile/12110235 . Local archive `myers_replication.zip` (~9 MB), codebook and README extracted here.

The design assigns ideological labels using only individuals' donations made during the primary, with donor ideology inferred from roll-call-scored incumbent recipients and leaving the focal candidate out. The two highest-vote primary candidates define a close-primary RD; applicable runoffs are used. The treatment is barely nominating the more extreme candidate, and the outcome is the party's **general-election fundraising share**, including source-specific shares. This is neither charisma nor a coattail outcome. The paper diagnoses bias from using donations made after nomination: changing nomination can itself change the donor pool. Its timing discipline is directly useful for this project.

`MoneyRD_hs_primary.dta` contains 10,861 primary-party race rows across Congress and state legislatures, 53 variables. Filtering office='S' and level='congress' leaves **436 US Senate primary-party rows, 365 state-years, all 50 states, 1980–2022**. These are selected contested primaries with usable ideology, not all Senate candidates. There are 48 rows with |rv|<.025, 93 with |rv|<.05, 179 with |rv|<.10, and 245 with |rv|<.15. These are raw counts, before an ideological-gap or new all-star eligibility restriction.

Useful fields: state, year, office, district, level, party, cand_last0, cand_last1, rv, treat, absdist, inc, experienced, cand_gender, cand_race, lag_vote_share_g, lag_pres_twoparty_vote_share, lag_shareOVR_total. `amount_total`, `amount_total_opp`, and `shareOVR_*` are **general-election outcomes**, not pre-primary support metrics. The archive contains no candidate donor-count/breadth field. The incumbent-donor table only holds donor shares without candidate IDs. Derived Senate subset: `myers_senate_primaries.csv`.

**Merge warning:** codebook says cand_last0 is moderate and cand_last1 extremist, while treat indicates extremist victory. Known 2018 WV and WY winners appear inconsistent with that mapping: for example WV Republican cand_last0=MORRISEY, cand_last1=JENKINS, treat=1. Treat and rv may be valid while name slots are mislabeled; do not infer nominees from these fields without independent election validation. No claim about the underlying estimates follows from this diagnostic.

## Hall and Thompson correction: a necessary RD caution

Andrew B. Hall and Daniel M. Thompson's March 2025 correction: https://www.andrewbenjaminhall.com/pdfs/hall_thompson_revised.pdf . Local `hall_correction.pdf`.

They explicitly withdraw reliance on the original large extremist-turnout effects in their 2006–2014 close House primary sample. Lagged presidential voting differs by roughly 6–12 points around the nomination threshold; adjusting for baseline differences yields small, imprecise estimates. The older, longer 1980–2012 analyses retain smaller own-race penalties. This is unusually direct evidence that close primaries require pretreatment balance checks and that a short Senate sample may have substantial chance imbalance. Hall 2015 original: https://www.andrewbenjaminhall.com/pdfs/Hall_APSR.pdf . It estimates the nominee's own electoral consequences, not same-ballot effects.

Additional close-election warning: Caughey and Sekhon (2011), *Elections and the Regression Discontinuity Design: Lessons from Close U.S. House Races, 1942–2008*, DOI https://doi.org/10.1093/pan/mpr032 . Author PDF downloaded as `close_rd.pdf`. Bare winners and losers can differ in observable pretreatment strength. Do not describe every close race as automatically random.

## Broockman: fully downloaded causal comparator

David E. Broockman (2009), *Do Congressional Candidates Have Reverse Coattails? Evidence from a Regression Discontinuity Design*, Political Analysis, DOI https://doi.org/10.1093/pan/mpp013 . Primary publication summary https://isps.yale.edu/resource/do-congressional-candidates-have-reverse-coattails-evidence-from-a-regression . Data/code https://doi.org/10.60600/YU/IOEQKE . Downloaded `broockman.tab`, `broockman.do`, `broockman_meta.json`; public CC0 dataset.

Treatment is a Democratic House candidate barely winning the previous election rather than barely losing; the outcome is Democratic presidential two-party share in the district at the next election. The author uses the subsequent incumbency advantage as a source of candidate popularity and finds no reverse coattail effect. This is a different direction of influence and an incumbency package rather than all-star charisma. The final author sample is 4,563 presidential-year district pairs, 1952–2004, after exclusions.

Code excludes prior third-party winners, party switching, multicandidate/at-large districts, intervening special elections, and redistricting, then excludes midterms and 2008 placeholders. Fields include centered `dv_c_t1`, `dv_c_t2`, `dv_p_t2`, `t2_year`, and named exclusion flags. Reanalysis should use local-linear RD with sensitivity and pretreatment checks, not blindly retain the original high-order polynomial. This archive is immediately runnable, but adding it would illustrate a comparator, not answer Senate-to-House all-star effects.

## Meredith: credible local-appeal instrument, different estimand

Marc Meredith (2013), *Exploiting Friends-and-Neighbors to Estimate Coattail Effects*, APSR 107(4):742–765, DOI https://doi.org/10.1017/S0003055413000439 . Author paper indexed at https://citeseerx.ist.psu.edu/document?doi=774b5066b4fa64644336224ca489da226208df8b&repid=rep1&type=pdf . Publisher abstract and methods read; original replication download not recovered in this search.

Uses county-level statewide executive returns, 1987–2010. A governor candidate's birthplace/residence proximity supplies variation in personal support; concurrent attorney-general and secretary-of-state vote shares are outcomes. Identifying exclusion: conditional on controls, a governor's local ties affect other candidates only through coattails, not independently through shared local partisan shifts or the down-ballot candidates' own local ties. The paper reports around 0.1–0.2 points of down-ballot vote per point of local personal governor vote, with no analogous reverse effect. It estimates transmission of local personal appeal, not statewide replacement of a mediocre nominee with an all-star. If we seek a stronger natural experiment, collecting nominee geographic roots and county outcomes is a defensible next project, with placebo ties, own ties, and weak-instrument diagnostics.

## Other designs, lower immediate fit

Arenas (2024), *Coattail effects and turnout: Evidence from a quasi-experiment*, Research & Politics, https://doi.org/10.1177/20531680241229930 . Selective Batasuna bans in concurrent Basque local/provincial elections create candidate/party availability shocks; difference-in-differences uses 251 municipalities and null ballots when the party asked banned supporters to cast them. This supplies a more exogenous presence shock but is a different institution and party-ban treatment. It should inform design rather than be extrapolated to US candidate charisma.

Rudolph and Leininger (2021), *Coattails and spillover-effects: Quasi-experimental evidence from concurrent executive and legislative elections*, Electoral Studies, DOI https://doi.org/10.1016/j.electstud.2020.102264 . German concurrent mayoral/legislative timing; replication listed at https://zenodo.org/records/18230905 but not inspected (rate limited). Timing designs are useful for turnout channels but do not independently assign personal quality.

## Practical decision for this stage

1. Freeze support measures from information recorded before the relevant primary or another common pre-election cutoff. Broad itemized-donor counts cover fewer than all donors; do not call them total donors, and report linkage/coverage.
2. Validate first-stage predictive relevance against own election performance using training years or held-out elections; preserve the separation between validation and choosing cutoffs/outcomes.
3. Estimate House/governor associations with incumbent and challenger quality controls, historical partisanship, state and cycle effects, on/off-ballot and lagged-outcome placebo checks. Label them observational.
4. If close-primary contrasts survive a minimum separation in frozen strength, run a separately specified RD with effective race count, balance and density tests, clustered inference, bandwidth sensitivity, and uncertainty. Do not report the nomination-package effect as an exact single-candidate contribution.
