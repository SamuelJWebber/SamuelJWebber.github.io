"""Prior-decennial resident population: fixed pre-election scale for donor counts.

The census year must be strictly earlier than the election year. This avoids
using decennial counts published after that year's election. The denominator
is population measured at that earlier census, not election-year population.
"""
from pathlib import Path
from urllib.request import urlopen
import csv
import hashlib
import json

ROOT = Path(__file__).resolve().parent
URL = 'https://www2.census.gov/programs-surveys/decennial/2020/data/apportionment/apportionment.csv'
PAGE = 'https://www.census.gov/data/tables/time-series/dec/popchange-data-text.html'
NAMES = 'Alabama|Alaska|Arizona|Arkansas|California|Colorado|Connecticut|Delaware|Florida|Georgia|Hawaii|Idaho|Illinois|Indiana|Iowa|Kansas|Kentucky|Louisiana|Maine|Maryland|Massachusetts|Michigan|Minnesota|Mississippi|Missouri|Montana|Nebraska|Nevada|New Hampshire|New Jersey|New Mexico|New York|North Carolina|North Dakota|Ohio|Oklahoma|Oregon|Pennsylvania|Rhode Island|South Carolina|South Dakota|Tennessee|Texas|Utah|Vermont|Virginia|Washington|West Virginia|Wisconsin|Wyoming'.split('|')
ABBREVIATIONS = 'AL AK AZ AR CA CO CT DE FL GA HI ID IL IN IA KS KY LA ME MD MA MI MN MS MO MT NE NV NH NJ NM NY NC ND OH OK OR PA RI SC SD TN TX UT VT VA WA WV WI WY'.split()

def main():
    raw = ROOT/'apportionment.csv'
    if not raw.exists():
        raw.write_bytes(urlopen(URL, timeout=60).read())
    with raw.open(encoding='utf-8-sig') as f:
        rows = list(csv.DictReader(f))
    lookup = {(r['Name'],int(r['Year'])):int(r['Resident Population'].replace(',',''))
              for r in rows if r['Geography Type']=='State'}
    output = []
    for state,abbr in zip(NAMES,ABBREVIATIONS):
        for year in range(1982,2025,2):
            census_year = (year-1)//10*10
            output.append(dict(state_abbrev=abbr,year=year,population_census_year=census_year,
                               prior_census_population=lookup[state,census_year]))
    assert len(output)==50*22
    with (ROOT/'prior_census_population.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(output[0]));w.writeheader();w.writerows(output)
    (ROOT/'provenance.json').write_text(json.dumps(dict(source=URL,source_page=PAGE,
        raw_sha256=hashlib.sha256(raw.read_bytes()).hexdigest(),retrieved='2026-11-05',
        denominator='Resident population at the most recent census strictly preceding the election year; not voting eligible population.',
        timing='Census-year elections use the previous decade. Historical published counts are read from the current Census compilation; no claim of archival real-time data vintage.',
        rows=len(output)),indent=2)+'\n')
    print(f'Created {len(output)} state-election population rows; all census years precede election years.')

if __name__=='__main__': main()
