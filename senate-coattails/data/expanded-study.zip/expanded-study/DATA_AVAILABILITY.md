# Data availability and reconstruction

| Component | Included | Reconstructed by main command | Separate optional step |
|---|---|---|---|
| MIT Senate/presidential returns | MIT-only benchmark nominee returns and attribution | Exact source files downloaded and hashed | Supply cached source files instead |
| DeLuca–Moskowitz–Schneer district data | URL, hash, construction code and aggregate results | Source download, prepared districts, incumbency metadata and all merged row derivatives | Source provider must remain accessible, or supply exact cached files |
| Algara et al. candidate experience | Acquisition/mapping code, source hashes, coverage | Four author CSVs, corrected nominee attributes and mapping audits | Exact historical versions must match recorded hashes |
| FEC receipt breadth | Anonymous nominee/race aggregates, mappings, audits | Model joins and training-only normalization | Approximately 15.1 GB compressed archives; full count extraction |
| FEC official financial summaries | Candidate/race totals, source manifest and parsing code | Model joins | Download workbooks/PDF and rerun the documented summary parsers |
| Prior Census residents | Source CSV, denominator table and provenance | Used directly | `population/build_population.py` rebuilds the denominator |
| Governor returns | CC0 statewide aggregate and rebuild code | Geography and predecessor checks | Download CC0 county file; `pyreadr` required |
| Senate service roster | CC0 public legislator YAML snapshots | Cohort identity and schedule checks | Updated upstream files are not silently substituted |
| Literature | Authored memo and citations | Not required | Retrieve cited papers from publishers/authors; PDFs are not redistributed |

No contributor names, addresses, donor identity hashes or transaction-level donor records are distributed. Public candidate names and identifiers are necessary for nominee mapping and are separate from donor identities. The legislator snapshots describe public elected officials.

No licensed-source district sample, merged governor/Senate source row, standalone individual-score table, or observation-level fitted-prediction file is distributed. The authorized public dashboard snapshot in site/expanded-study.json is an exception for curated newly computed candidate contributions and tail flags, public candidate identities, and FEC aggregate counts; it contains no raw experience codes or licensed incumbent collapse. Main reproduction creates these intermediate files only in the external working directory. The code and aggregate results are sufficient to examine the reported specifications; a fresh model fit additionally requires the stated source access.

Source rights are recorded as observed. MIT election returns, the Algara/Amlani county governor source and the Congress Legislators roster are identified as CC0 in their source provenance. Federal FEC and Census data are government sources, subject to the providers' published use rules. The separate 2026 candidate-experience page says “CC BY 4.0 (proposed)”; this is not relabeled as a verified license. The district replication's reuse terms remain as provided by its authors. Article licenses are not assumed to license accompanying datasets.

The fast model command is feasible without a 15 GB transfer because it explicitly begins from included FEC aggregates. The optional source-to-count route is supplied and has a cross-implementation check for 2006; do not interpret a successful fast model run as a rerun of every raw transaction extraction.
