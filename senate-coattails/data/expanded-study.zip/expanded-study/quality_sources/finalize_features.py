from pathlib import Path
import pandas as pd,numpy as np,json
R=Path(__file__).resolve().parent
m=pd.read_csv(R/'nominee_mapping_initial.csv')
g=pd.read_csv(R/'raw/clean_senate_races_1914_2024.csv').rename(columns={'state':'state_abbrev'})
g=g[g.special_election.eq(0)]
c=pd.read_csv(R/'raw/senate_candidates_cleaned_1980_2024.csv')
CAT={'Amateur':'amateur','U.S. Senator':'senator','State Legislator':'state_leg','Member of the U.S. House of Representatives':'house','U.S. House Rep':'house','Local Office':'local','Local Official':'local','Lower Statewide Elected Office':'statewide','Lesser Statewide Office':'statewide','State Governor':'governor','Governor':'governor','Former U.S. Senator':'former_senator','Fmr. U.S. Senator':'former_senator'}
x=m.merge(g[['state_abbrev','year','dem_quality','rep_quality']],on=['state_abbrev','year'],how='left',validate='many_to_one')
x['office_raw']=x.political_experience.map(CAT)
x['office_general']=[CAT.get(r.dem_quality if r.party=='D' else r.rep_quality) for _,r in x.iterrows()]
x['office']=x.office_raw.fillna('unknown');x['office_observed']=x.office_raw.notna().astype(int)
x['prior_elected']=(x.office_raw.ne('amateur')).astype(float);x.loc[x.office_raw.isna(),'prior_elected']=np.nan
x['audit_status']='source_files_agree'
x['audit_source']='https://calgara.github.io/senate_candidate_quality.html'
disagree=x.office_raw.notna()&x.office_general.notna()&x.office_raw.ne(x.office_general)
x.loc[disagree,'office']='unknown';x.loc[disagree,'office_observed']=0;x.loc[disagree,'audit_status']='category_disagreement_binary_agrees'
binarydis=disagree&(x.office_raw.eq('amateur')!=x.office_general.eq('amateur'))
x.loc[binarydis,'prior_elected']=np.nan;x.loc[binarydis,'audit_status']='unresolved_elected_status'
x.loc[x.office_raw.isna(),'audit_status']='unmatched_nominee'
x.loc[x.office_raw.notna()&x.office_general.isna(),'audit_status']='candidate_file_only'
# Only directly documented exceptions; do not silently pick a source on disputes.
FIX={
 ('VA',2012,'D'):('governor','https://www.kaine.senate.gov/about','Future Senate office corrected; Kaine was governor2006–10 and sworn into SenateJan2013.'),
 ('WV',2020,'R'):('senator','https://www.capito.senate.gov/imo/media/doc/sen_capito_official_bio1.pdf','Corrupt raw candidate name quarantined; office independently verified, fundraising unmatched.'),
 ('CT',1986,'R'):('state_leg','https://www.dvidshub.net/news/404428/new-class-warrior-legends-inducted-during-10th-mountain-division-ceremony','US Army biography documents CT House1959–61 and Senate1967–71.'),
 ('IN',1986,'D'):('local','https://history.house.gov/People/Detail/17117','House biography documents Valparaiso city council1984–86 before Senate campaign.'),
 ('TN',2006,'R'):('local','https://chattanooga.gov/government/mayors-office/past-mayors','City documents Corker elected mayor2001 and term2001–05.'),
 ('VA',2020,'D'):('senator','https://www.warner.senate.gov/public/index.cfm/biography','General file swaps D/R attributes; mapped incumbent is Mark Warner.'),
 ('VA',2020,'R'):('amateur','https://calgara.github.io/senate_candidate_quality.html','General file swaps D/R attributes; retain named candidate-file category for Daniel Gade, not Warner senator category.'),
 ('ME',2018,'D'):('amateur','https://calgara.github.io/senate_candidate_quality.html','General file describes independent Angus King in nominal D slot; retain named Democratic nominee Ringelstein category.'),
 ('ME',2012,'D'):('state_leg','https://calgara.github.io/senate_candidate_quality.html','General file describes independent Angus King in nominal D slot; retain named Democratic nominee Dill category.'),
}
corrections=[]
for (st,yr,pa),(cat,url,why) in FIX.items():
 z=x.state_abbrev.eq(st)&x.year.eq(yr)&x.party.eq(pa);assert z.sum()==1
 corrections.append({'state_abbrev':st,'year':yr,'party':pa,'raw_office':x.loc[z,'office_raw'].iat[0],'final_office':cat,'source_url':url,'reason':why})
 x.loc[z,['office','office_observed','prior_elected','audit_status','audit_source']]=[cat,1,float(cat!='amateur'),'verified_override',url]
# Serving senators are baseline incumbency, not evidence of prior ELECTED office:
# some were appointed. Do not manufacture an elected-office history for them.
x['office_incumbent']=x.office.eq('senator').astype(int)
x.loc[x.office_incumbent.eq(1),'prior_elected']=np.nan
x['prior_elected_observed']=x.prior_elected.notna().astype(int)
counts=c.groupby('primary_id').candidate_in_primary.apply(lambda z:int(z.eq(1).sum()))
x['primary_on_ballot_count']=x.primary_id.map(counts)
x['primary_unopposed']=np.where(x.nomination_type.notna(),(x.nomination_type.eq('No Primary Held (Unopposed)')|x.primary_on_ballot_count.eq(1)).astype(float),np.nan)
x['preprimary_share']=x.pre_contributions_as_prop_of_race
x['preprimary_share_observed']=x.preprimary_share.notna().astype(int)
x['primary_share_timing']='Author describes pre-primary itemized contributions; exact cutoff dates absent from trimmed file.'
x['fec_id']=pd.NA
x.to_csv(R/'nominee_features.csv',index=False)
x[disagree].to_csv(R/'office_disagreement_audit.csv',index=False)
pd.DataFrame(corrections).to_csv(R/'attribute_corrections.csv',index=False)
vals=['office','office_observed','office_incumbent','office_raw','prior_elected','prior_elected_observed','source_row','source_candidate','match_method','audit_status','preprimary_share','preprimary_share_observed','nomination_type','primary_on_ballot_count','primary_unopposed','primary_id']
w=x.pivot(index=['state_abbrev','year'],columns='party',values=vals);w.columns=[f'{a}_{b}' for a,b in w.columns];w=w.reset_index()
# Names initially announced use office_D_observed etc; expose aliases explicitly.
for party in ['D','R']:
 for base in ['office','prior_elected','preprimary_share']:
  w[f'{base}_{party}_observed']=w[f'{base}_observed_{party}']
 w[f'office_{party}_incumbent']=w[f'office_incumbent_{party}']
w.to_csv(R/'experience_features.csv',index=False)
pd.DataFrame([{'state_abbrev':'AL','year':1992,'field':'incumbency','old':0,'new':1,'url':'https://history.house.gov/People/Detail/21534'},
 {'state_abbrev':'ME','year':1982,'field':'incumbency','old':0,'new':1,'url':'https://www.senate.gov/senators/FeaturedBios/Featured_Bio_MitchellGeorge.htm'},
 {'state_abbrev':'WA','year':2016,'field':'incumbency','old':0,'new':1,'url':'https://www.senate.gov/about/resources/pdf/book-pro-tem-2024.pdf'}]).to_csv(R/'baseline_incumbency_corrections.csv',index=False)
summary={'nominees':len(x),'races':len(w),'name_matches':int(x.source_row.notna().sum()),'office_known':int(x.office_observed.sum()),'office_unknown':int(x.office_observed.eq(0).sum()),'serving_senators':int(x.office_incumbent.sum()),'nonincumbent_prior_elected_known':int(x.prior_elected_observed.sum()),'unresolved_nonincumbent_binary':int((x.prior_elected_observed.eq(0)&x.office_incumbent.eq(0)).sum()),'preprimary_share_observed':int(x.preprimary_share_observed.sum()),'raw_office_disagreements':int(disagree.sum()),'data_source':'author-embedded CSV; DOI endpoint did not resolve during retrieval','frozen_status':'audited available features; unresolved categories/binaries are explicit unknowns'}
(R/'feature_coverage.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
