> Distribution note: the package includes code and aggregate outputs. Raw inputs, individual modeled scores, merged samples and observation-level predictions mentioned below are regenerated in the external working directory by the top-level `reproduce.py`. Run optional source scripts inside that working copy to keep caches out of the checkout.

# Broad pre-election office-experience features

This folder supplies nominee attributes to the stage-three own-vote prediction exercise. It does not define a star or estimate a coattail. Experience is an independent historical attribute, not a direct measurement of charisma. The learned model must be selected on own-race outcomes before examining other candidates' outcomes.

## Reproduction

With pandas and NumPy, run:

```sh
python acquire_experience.py
python map_experience.py --sample input/benchmark_nominees.csv
python finalize_features.py
```

The first script retrieves the author's public page and extracts its four embedded CSV downloads. Subsequent steps are local. The compact input roster contains the 689 benchmark elections and the same two major-party nominee names used there. The mapping script also accepts the full corrected Senate sample. Original data, source URLs and hashes are recorded in `raw/` and `provenance.json`. The author's Dataverse DOI endpoint returned HTTP400 during acquisition, so the actual acquired files are the author-hosted CSVs; we do not claim archival identity was independently verified. The author page lists “CC BY4.0 (proposed)”, which is not confirmation of a finalized archival license.

Primary source: Carlos Algara, Byengseon Bae, Isaac Hale, Michael Heseltine and Evan Lieber, *The Rise of Amateur Candidate Pipelines & Declining Value of Candidate Experience in U.S. Senate Primaries,1980–2024*: <https://calgara.github.io/senate_candidate_quality.html>. Its page describes prior **elected** office as the quality proxy; this is the source authors' definition, not our learned-star definition. It supplies6,595candidate records,1,596party-primary records,1,976general-election records and a draft codebook. The files were downloaded and decoded, not inferred from summary text.

## Available files and schema

`experience_features.csv` contains one row for each of689state/year elections. `nominee_features.csv` contains1378nominee appearances with raw names, source-row numbers, matching methods and audit flags. Source-row numbers are zero-based data-row positions in `raw/senate_candidates_cleaned_1980_2024.csv`; they are not FEC identifiers. No FEC identifier is exposed by this trimmed source.

For each party suffix `_D` or `_R`:

- `office`: amateur,local,state_leg,statewide,house,governor,former_senator,senator,unknown.
- `office_D_observed` and `office_D_incumbent` (and R analogues): known detailed category and serving-senator indicator.
- `prior_elected` and its observed indicator: binary prior elected experience for **nonincumbent** nominees. Serving senators deliberately have this field missing because some entered by appointment; their current office is a separate known baseline attribute.
- `office_raw`: normalized original candidate-file category, retained for audit and **not** the default modeling category.
- `source_row`, `source_candidate`, `match_method`, `audit_status`: provenance and mapping status.
- `preprimary_share` and its observed indicator: nominee's share of all **itemized pre-primary contributions within their same-party primary**, not their share of D-versus-R general-election funds. The source supplies no exact cutoff date in the trimmed file. Missing values are not zero.
- `primary_on_ballot_count`, `primary_unopposed`, `nomination_type`, `primary_id`: contextual variables for the fundraising measure. On-ballot count sums candidate-in-primary flags within the source primary identifier. Unopposed means the source explicitly says no primary was held because unopposed, or there was exactly one candidate on the primary ballot. Convention nomination and missing data are not silently called unopposed.

Original labels such as `quality_candidate`, primary winners, gender, partisanship and general-election vote results remain only in raw/audit files. They are not the learned quality score. General-election outcomes are not used to assign nominee experience. Primary-winner information is used only to resolve a rare duplicate nominee record, as nomination precedes the general election.

## Coverage and audit policy

The mapping links1376of1378nominee appearances by state,year,party and names, using explicit punctuation,legal-name,middle-name and nickname rules. The remaining cases are Alaska2020AlGross, an independent in the benchmark's Democratic slot, and WestVirginia2020ShelleyMooreCapito, whose source name is corrupted to “capito,archalfredmoore”. Capito's serving-senator status is independently verified from her official biography, but no fundraising record is attached through that corrupt name. Gross remains unknown. All first-initial matches and legal-name aliases remain visible in the mapping ledger; not every historical biography has been independently re-researched.

Detailed office categories are known for1339of1378appearances;39are unknown. Of827nonincumbent appearances,810have a known prior-elected binary and17remain unknown. There are551serving-senator appearances, kept separately. Fundraising shares are observed for782nominee appearances. These are row counts, not claims of universal source accuracy.

The candidate file and general-election file disagree on46matched office categories. `office_disagreement_audit.csv` preserves them all. Differences between two nonzero offices may reflect most-recent versus highest prior office, but they can also be errors: detailed category is therefore quarantined as unknown while the agreed binary remains known. Elected-versus-amateur disagreements remain unknown unless independently resolved. We do not choose whichever source produces a preferable model result.

Clear resolved exceptions appear in `attribute_corrections.csv`, with sources. TimKaine2012 is corrected from senator to governor, eliminating future-office leakage. RogerEddy1986,JillLong1986 and BobCorker2006 had earlier elected service despite amateur labels. Maine's general file sometimes substitutes independent AngusKing for the actual Democratic nominee, and Virginia2020swaps the parties' attributes; named candidate-file records are retained in those cases. Unresolved cases include distinctions between appointment and elected office, such as TedCruz's Texas solicitor-general role and KellyAyotte's attorney-general role; no unsupported elected-office claim is forced into the features.

Comparing **all** candidate-file senator labels with the benchmark's incumbent party exposed only four discrepancies. One was Kaine's future office; the other three were errors in the old benchmark incumbent coding. `baseline_incumbency_corrections.csv` documents ShelbyAlabama1992,MitchellMaine1982 and MurrayWashington2016as Democratic incumbents, using official congressional biographies. These are stage-three corrections; the original source files are preserved.

General-file outcome checks additionally exposed the use of runoff instead of November results in Georgia2020,a reversed Nebraska2020share and independent candidates in Maine's nominal Democratic slot. Consequently the general file's vote outcomes are never substituted for benchmark outcomes, and its office categories are never blindly joined as nominee attributes. The source's Georgia2022special-election flag is also inconsistent with the regular Senate contest; individual name/year/party matching is retained and the raw flag is preserved.

These historical attributes were coded retrospectively in a2026release. Their content can be known before each election, but this is not proof the exact coded dataset existed as a real-time historical snapshot. The audit is a concrete improvement over using raw labels; it is not an exhaustive validation of every source record.
