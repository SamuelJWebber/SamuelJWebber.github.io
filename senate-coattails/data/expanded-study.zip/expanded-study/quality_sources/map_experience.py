from pathlib import Path
import pandas as pd,numpy as np,re,unicodedata,argparse
ROOT=Path(__file__).resolve().parent
ALIASES={'BOB':'ROBERT','BILL':'WILLIAM','DICK':'RICHARD','JIM':'JAMES','TED':'EDWARD','TOM':'THOMAS','CHUCK':'CHARLES','JOE':'JOSEPH','JACK':'JOHN','BEN':'BENJAMIN','JERRY':'GERALD','DAVE':'DAVID','MIKE':'MICHAEL','STEVE':'STEVEN','JON':'JOHN','RON':'RONALD','DAN':'DANIEL','RICK':'RICHARD','PAT':'PATRICK','PHIL':'PHILIP','JOSH':'JOSHUA','AL':'ALBERT','ED':'EDWARD','FRED':'FREDERICK','MATT':'MATTHEW','LIZ':'ELIZABETH','CATHY':'CATHERINE','ROD':'RODNEY','TIM':'TIMOTHY','CHRIS':'CHRISTOPHER','KEN':'KENNETH','ROB':'ROBERT','LARRY':'LAWRENCE','DANNY':'DANIEL','BOBB':'ROBERT','BETO':'ROBERT','NED':'EDWARD','GENE':'EUGENE','EDMOND':'EDMUND'}
SURNAME={'WEICHER':'WEICKER','PEREY':'PERCY','CHAFFEE':'CHAFEE','DONNELL':'ODONNELL','DELL':'ODELL','CONNOR':'OCONNOR','OCONNER':'OCONNOR','AMOURS':'DAMOURS','AMATO':'DAMATO','ROURKE':'OROURKE','ROCCO':'LAROCCO'}
IGNORE={'MR','MRS','MS','DR','JR','SR','II','III','IV','V','SIR','ESQ','SENATOR','HON','MD','PHD','SEN','PASTOR'}
# Audited legal/middle-name variants within state, year and party. They change
# matching only; no outcome or experience value is inferred from a name.
MIDDLE={('AR','HUTCHINSON'):{'ASA':'WILLIAM'},('FL','GRAHAM'):{'ROBERT':'DANIEL'},
('FL','GRANT'):{'WILLIAM':'JAMES'},('GA','HICKS'):{'MICHAEL':'JOHN'},
('GA','CLELAND'):{'MAX':'JOSEPH'},('IA','GANSKE'):{'GREG':'JOHN'},
('ID','MITCHELL'):{'NELS':'BRIANE'},('ID','STURGILL'):{'GERALD':'STEPHEN'},
('KY','BAESLER'):{'SCOTTY':'HENRY'},('MD','CAMPBELL'):{'TONY':'ANTONO'},
('ME','PINGREE'):{'CHELLIE':'ROCHELLE'},('MI','ABRAHAM'):{'SPENCER':'EDMUND'},
('MS','COCHRAN'):{'THAD':'WILLIAM'},('NC','SANFORD'):{'TERRY':'JAMES'},
('NC','FAIRCLOTH'):{'LAUCH':'DUNCAN'},('NC','BUDD'):{'EDWARD':'THEODORE'},
('ND','CONRAD'):{'KENT':'GAYLORD'},('NH','MESSNER'):{'CORKY':'BRYANT'},
('OH','CELESTE'):{'EDWARD':'THEODORE'},('PA','HEINZ'):{'JOHN':'HENRY'},
('SC','THURMOND'):{'STROM':'JAMES'},('SC','HUTTO'):{'BRAD':'CHARLES'},
('SD','MUENSTER'):{'EDWARD':'THEODORE'},('TN','CLARK'):{'JEFF':'WILLIAM'},
('TX','GRAMM'):{'PHILIP':'WILLIAM'},('TX','BOULTER'):{'BEAU':'ELDON'},
('WV','WOLFE'):{'JAY':'MATTHEW'},('WY','HELLING'):{'KATHY':'MARY'}}

def parts(name,state):
 name=unicodedata.normalize('NFKD',str(name)).encode('ascii','ignore').decode().upper().strip()
 name=name.replace("'",'')
 if state=='OR' and name=='WYDEN RON':name='RON WYDEN'
 if state=='OR' and name=='PERKINS JO RAE':name='JO RAE PERKINS'
 if ',' in name and re.sub('[^A-Z ]',' ',name.split(',',1)[1]).strip().replace(' ','') not in {'JR','SR','II','III','IV'}:
  last,rest=name.split(',',1);lasts=[x for x in re.sub('[^A-Z ]',' ',last).split() if x not in IGNORE]; last=lasts[-1] if lasts else "?"; tokens=re.sub('[^A-Z ]',' ',rest).split()
 else:
  tokens=re.sub('[^A-Z ]',' ',name).split();tokens=[t for t in tokens if t not in IGNORE];last=tokens[-1];tokens=tokens[:-1]
 tokens=[t for t in tokens if t not in IGNORE];first=next((x for x in tokens if len(x)>1),tokens[0] if tokens else '?');first=ALIASES.get(first,first);last=SURNAME.get(last,last)
 if state=='TX' and last=='CRUZ':first='RAFAEL'
 if state=='FL' and last=='NELSON':first='WILLIAM'
 first=MIDDLE.get((state,last),{}).get(first,first)
 return last,first

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--sample',type=Path,default=ROOT/'input/benchmark_nominees.csv');args=ap.parse_args()
 s=pd.read_csv(args.sample)
 c=pd.read_csv(ROOT/'raw/senate_candidates_cleaned_1980_2024.csv').reset_index(names='source_row')
 c['last']=[parts(n,st)[0] for n,st in zip(c.name,c.state)];c['first']=[parts(n,st)[1] for n,st in zip(c.name,c.state)]
 rows=[];unmatched=[];ambig=[]
 for _,r in s.iterrows():
  for p,party,field in [('D','Democratic','candidate_DEMOCRAT'),('R','Republican','candidate_REPUBLICAN')]:
   last,first=parts(r[field],r.state_abbrev);pool=c[c.state.eq(r.state_abbrev)&c.fecyear.eq(r.year)&c.party.eq(party)]
   a=pool[pool['last'].eq(last)&pool['first'].eq(first)];method='surname_given_alias'
   if len(a)==0:
    a=pool[pool['last'].eq(last)&pool['first'].str[0].eq(first[0])];method='surname_first_initial'
   if len(a)>1:
    regular=a[a.special_election.eq(0)]
    if len(regular)==1:a=regular;method+='_regular'
    elif a.political_experience.nunique()==1:
     wins=a[a.win_primary.eq(1)]
     if len(wins)==1:a=wins;method+='_primary_nominee'
   d={'state_abbrev':r.state_abbrev,'year':r.year,'party':p,'benchmark_candidate':r[field],'match_method':method,'source_row':np.nan,'source_candidate':None,'political_experience':None}
   if len(a)==1:
    z=a.iloc[0];d.update({'source_row':int(z.source_row),'source_candidate':z['name'],'political_experience':z.political_experience})
    for v in ['quality_candidate','special_election','inc','candidate_in_primary','win_primary','pre_contributions_as_prop_of_race','number_total_candidates_from_effective','nomination_type','primary_type','seat_class','primary_id','win_primary_effective']:d[v]=z[v]
   else:
    d['match_method']='unmatched' if len(a)==0 else 'ambiguous'
    rev={k:d[k] for k in ['state_abbrev','year','party','benchmark_candidate','match_method']};rev['possible_matches']=' | '.join(pool['name'].astype(str));unmatched.append(rev)
   rows.append(d)
 x=pd.DataFrame(rows);x.to_csv(ROOT/'nominee_mapping_initial.csv',index=False);pd.DataFrame(unmatched).to_csv(ROOT/'unmatched_initial.csv',index=False)
 print(x.groupby('match_method').size().to_string());print(pd.DataFrame(unmatched)[['state_abbrev','year','party','benchmark_candidate']].to_string(index=False));
if __name__=='__main__':main()
