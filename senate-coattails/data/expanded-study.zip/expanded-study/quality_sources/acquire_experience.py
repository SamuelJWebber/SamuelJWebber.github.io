from pathlib import Path
import urllib.request,re,hashlib,json
ROOT=Path(__file__).resolve().parent
RAW=ROOT/'raw'; RAW.mkdir(exist_ok=True)
URL='https://calgara.github.io/senate_candidate_quality.html'
EXPECTED={
 'senate_candidates_cleaned_1980_2024.csv':'a93e333a62ccc7d357fce840a02ca6f3cbdea54c3c37f48a7cf02b60bb3f8ecb',
 'senate_elections_cleaned_1980_2024.csv':'b47803817eabc13d0f7b18834bfc4e94ccd54d9be80b9ce00bb4fdda47fe693e',
 'clean_senate_races_1914_2024.csv':'586127153959c257f807e4e789a79124db8ece9406da877c4e77cea1bf8cb409',
 'codebook.csv':'6e26deed73e4cec5f79814187cd24ae4feb35421b115123c21173106421a55f2'}
p=RAW/'author_page.html'
if not p.exists():p.write_bytes(urllib.request.urlopen(URL,timeout=60).read())
s=p.read_text()
files={}
for tag,name in [('csv_cand','senate_candidates_cleaned_1980_2024.csv'),('csv_elec','senate_elections_cleaned_1980_2024.csv'),('csv_races','clean_senate_races_1914_2024.csv'),('csv_codebook','codebook.csv')]:
 match=re.search(r'<script type="text/plain" id="'+tag+r'">(.*?)</script>',s,re.S)
 assert match,tag
 content=match.group(1).encode()
 actual=hashlib.sha256(content).hexdigest()
 if actual!=EXPECTED[name]:raise ValueError(f'Source version changed for {name}: expected {EXPECTED[name]}, got {actual}')
 (RAW/name).write_bytes(content)
 files[name]={'source':URL+'#'+tag,'sha256':hashlib.sha256(content).hexdigest(),'bytes':len(content)}
(ROOT/'provenance.json').write_text(json.dumps({'source_url':URL,'archive_doi':'10.7910/DVN/52OFMP','retrieved':'2026-11-05','html_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'files':files,'license_note':'Author page says CC BY 4.0 (proposed); do not claim a finalized license without checking archive terms.'},indent=2)+'\n')
print(json.dumps(files,indent=2))
