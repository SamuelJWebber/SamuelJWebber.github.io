> Distribution note: the package includes code and aggregate outputs. Raw inputs, individual modeled scores, merged samples and observation-level predictions mentioned below are regenerated in the external working directory by the top-level `reproduce.py`. Run optional source scripts inside that working copy to keep caches out of the checkout.

# Senate schedule and same-party House performance

This extension asks whether a party's House vote improves when a previously strong senator's **Senate class next comes due**, compared with the two intervening House elections. It is an observational comparison of a scheduled opportunity for a strong incumbent, not an identified causal effect of their actual appearance on the ballot.

The corrected primary comparison is close to zero and imprecise. For each +10 percentage points of the independently selected historical residual, the scheduled election's House share is **−0.166 percentage points** relative to the mean of the two off-cycle elections (95% state-clustered interval **−1.444 to +1.112**). The off-cycle change is **−0.983 points** (−2.915 to +0.948). Extrapolating that off-cycle change into the scheduled year yields **+1.309 points** (−1.592 to +4.210). This last contrast is a trend sensitivity; it does not establish the counterfactual trend.

## Frozen design

1. Start with a regular Senate election at t0 and verify that its elected D/R nominee begins a term in the scheduled Senate class. Names must match surname and a recognizable given name in the dated Congress Legislators roster. Brief service and delayed seating count. No condition is imposed on later retirement, survival, promotion, rerunning, or reelection.
2. Freeze the winner's historical strength after t0 and before all House outcomes. Observe House elections at t0+2, t0+4, and the scheduled t0+6 Senate election.
3. Within each cohort, retain exactly the same House geographic districts at all three dates. Average their Democratic two-party vote shares, then orient that mean to the senator's original party. Unopposed D/R seats receive 1/0. Independent votes are outside this two-party denominator. A senator's later party switch does not change the original party outcome.
4. Fit term fixed effects, original-party × calendar-year fixed effects, common phase indicators, the relative party of the other Senate seat's scheduled incumbent, and an indicator that a Senate special election occurs that year. Standard errors cluster by state, with finite-cluster t critical values and finite-sample covariance correction. Each cohort-phase receives equal weight; large states do not gain weight from their district count. Multiple overlapping cohorts are included, and state clustering accounts for their common observations.
5. Report all four preregistered algebraic contrasts. With phase2 as reference and quality interactions b4/b6: off-cycle placebo=b4; scheduled versus mean off=b6−0.5b4; scheduled versus most recent off=b6−b4; scheduled after extrapolating the off-cycle change=b6−2b4. Continuous estimates multiply coefficients by10 to express House percentage points per10 historical-residual points. Tail-dummy estimates multiply by100.

## Corrected score and matched comparison

`historical_election_audit.csv`, produced by the separate quality-model analysis, gives the completed t0 race's residual from an expected-D-share model fitted only to earlier elections (minimum four prior cycles). The centered score subtracts the contemporaneous other-state median residual and is oriented to the elected senator's party. These race results are all observed before t0+2. The score contains the candidate, their opponent and remaining campaign conditions; it is not pure personal charisma.

The centered-history architecture was selected by 2010–2014 **own-Senate-vote** development accuracy, without teammate outcomes. This selection is retrospective for early cohorts. The raw residual is a prespecified sensitivity. Neither coefficient uses the senator's t0+6 result. The score units here are historical residual points, not the separate model's rolling predicted candidate bonus.

All corrected-centered, corrected-raw and matched-legacy comparisons use the **identical 296 cohorts, 888 observations, and 49 states**. Term starts run1986–2016, and House outcomes1988–2022. The legacy full panel has360 cohorts:64 starts from1982/1984 lack the corrected score's required training history. The starting pool has570 candidate-pair Senate elections;206 have no common House geography and4 fail the elected-and-serving nominee criterion.

The primary score's tails are frozen before the House join using231 observed nominee-history appearances in1982–2008, including repeat appearances: p10=−0.0614923455340774 and p90=+0.1267705429908936. There are35 high-tail and24 low-tail completed winner cohorts. These are historical residual tails, not proven 'great' and 'awful' people. Their estimates are secondary and exploratory. All related contrasts are provided, without multiplicity adjustment.

## Coverage and interpretation

`coverage_by_cohort.csv` is essential. Starts1986/88,1996/98,2006/08 and2016 largely cross redistricting boundaries; only4–5 cohorts per such start year remain, usually at-large states. Do not imply representative estimates for every scheduled election. The source's geography identifiers identify redistricting periods; statewide at-large districts are explicitly linked across periods. The district sample is constant within each cohort. This controls composition but makes coverage selective. Mean coverage among included corrected cohorts is97.97%, and a ≥80% coverage sensitivity is also reported.

Of296 corrected cohorts,213 feature the same nominee rerunning at t0+6 and277 still have the original senator in office immediately before that election. Actual rerunners and cohorts with no special elections are **conditional sensitivities**, not the primary sample. Selecting eventual rerunners would condition on decisions that strength and changing conditions can influence.

Being off this Senate-class schedule does not mean politically absent. For example, Obama's2004 cohort contains his2008 presidential campaign in phase4 and the2010 Senate election after he departed. McCain's2004 cohort similarly includes2008. Officeholding, party organization, national campaigns and other-seat elections can affect off-cycle House performance. Senate classes are predetermined, but quality, retirement and state-specific trends are not randomized. This design estimates the extra scheduled-cycle association, not the politician's total contribution while in office. House two-party shares combine turnout and vote choice without identifying their mechanisms.

The matched legacy score produces a negative scheduled-minus-off association alongside a nearly equal negative off-cycle placebo. The corrected selected score greatly reduces that apparent scheduled penalty. Preserve both versions and their placebo/trend contrasts; the results do not support claiming strong candidates harm teammates.

## Audit and files

- `quality_comparison_estimates.csv`: every corrected/matched continuous and tail contrast, confidence interval and sample count.
- `quality_comparison_summary.json`: machine-readable primary metadata, thresholds, all estimates and input hashes.
- `corrected_panel.csv`: final centered-score estimation panel; `matched_quality_panel.csv` retains all three scores.
- `matched_quality_cohorts.csv`, `top_cohort_ledger.csv`, `bottom_cohort_ledger.csv`: named cohort ledger and frozen classifications.
- `cohort_ledger.csv`: all570 initial candidate pairs and explicit inclusion/exclusion reasons.
- `coverage_by_cohort.csv`: scheduled-year counts, tail counts, actual reruns and geography coverage.
- `hand_audit_examples.csv`, `data_audit.json`: independent reconstruction of all888 outcome means plus interpretable Obama/Biden/McCain examples.
- `panel.csv`, `estimates.csv`, `summary.json`: full360-cohort legacy comparison, retained for traceability.
- Separate numerical audit files in `../literature/`: `on_off_numerical_audit.json` and `corrected_on_off_numerical_audit.json`. Independent Frisch–Waugh–Lovell residualization agrees with full-design coefficients and clustered covariance to floating-point precision. Two nuisance fixed-effect aliases are expected from age/period/cohort dependence; the two target quality interactions are full rank.

Identity audit fixes retain Biden's January6–15,2009 Senate service, distinguish John and Mark Warner in1996, and avoid conflating Mel and Jean Carnahan. Remaining excluded elections are AK2010 (Murkowski write-in), CT2006 (Lieberman independent), ME2012 (King independent), and MO2000 (Mel Carnahan never began service).

## Reproduce

Python dependencies: numpy, pandas, scipy, PyYAML. Inputs and outputs are ordinary local files. `--root` is a directory containing the two roster YAMLs and receiving outputs.

```bash
OPENBLAS_NUM_THREADS=1 python on_off.py --root OUTPUT_DIR --senate-data MAIN_SENATE_SAMPLE --house-data HOUSE_DISTRICTS --raw-senate MIT_SENATE_TSV --threshold-file STAGE2_HOUSE_SUMMARY_JSON
OPENBLAS_NUM_THREADS=1 python compare_quality.py --root OUTPUT_DIR --historical-audit HISTORICAL_ELECTION_AUDIT_CSV --selection MODEL_SELECTION_JSON
OPENBLAS_NUM_THREADS=1 python audit_data.py --root OUTPUT_DIR --house-data HOUSE_DISTRICTS
```

The roster files are the public-domain Congress Legislators project, downloaded2026-11-05:
- https://raw.githubusercontent.com/unitedstates/congress-legislators/main/legislators-historical.yaml
- https://raw.githubusercontent.com/unitedstates/congress-legislators/main/legislators-current.yaml

Their hashes and the historical election/House input hashes are recorded in the summary JSONs. The underlying House district source is the DeLuca replication dataset, DOI10.7910/DVN/J6C26T, file11807548; Senate election data are MIT Election Lab Dataverse file13887039. The main analysis bundle contains the upstream fetch and quality-score construction scripts.
