"""Senate-term on/off schedule design with frozen, previously observed strength.

The primary scheduled-election comparison is an observational intention-to-treat
contrast. It does not condition on later rerunning, survival, promotion, or victory.
"""
import argparse
import hashlib
import json
from datetime import date,timedelta
from pathlib import Path
import re
import numpy as np
import pandas as pd
from scipy.stats import t
import yaml

ROOT=Path(__file__).resolve().parent
PRIMARY_CONTROLS=['phase4','phase6','other_scheduled_party','special_count']


def last_token(text):
    text=str(text).strip().upper()
    if ',' in text:
        left,right=text.split(',',1)
        if right.strip() not in {'JR.','JR','SR.','SR','II','III','IV'}:
            text=right+' '+left
    words=re.sub('[^A-Z ]',' ',text).split()
    words=[x for x in words if x not in {'JR','SR','II','III','IV','V'}]
    aliases={'WEICHER':'WEICKER','PEREY':'PERCY','CHAFFEE':'CHAFEE'}
    return aliases.get(words[-1],words[-1])


def election_date(year):
    start=date(int(year),11,1)
    return start+timedelta(days=(7-start.weekday())%7+1)


def candidate_words(text):
    text=str(text).strip().upper()
    if ',' in text:
        left,right=text.split(',',1)
        if right.strip() not in {'JR.','JR','SR.','SR','II','III','IV'}:
            text=right+' '+left
    return [x for x in re.sub('[^A-Z ]',' ',text).split() if x not in {'JR','SR','II','III','IV','V'}]


def matches_person(candidate,holder):
    """Require surname AND a recognizable given name; never conflate spouses."""
    if last_token(candidate)!=last_token(holder['last']): return False
    given=candidate_words(candidate)[:-1]
    allowed=set(candidate_words(holder['given_names']))
    aliases={'BILL':['WILLIAM'],'BOB':['ROBERT'],'DICK':['RICHARD'],'RICK':['RICHARD'],
             'JIM':['JAMES'],'JIMMY':['JAMES'],'TED':['EDWARD','THEODORE'],
             'ED':['EDWARD','EDMUND'],'AL':['ALAN','ALBERT'],'BEN':['BENJAMIN'],
             'JOE':['JOSEPH'],'TOM':['THOMAS'],'CHUCK':['CHARLES'],
             'JACK':['JOHN'],'CHRIS':['CHRISTOPHER'],'MIKE':['MICHAEL'],
             'PAT':['PATRICK'],'RON':['RONALD'],'DON':['DONALD'],
             'DAN':['DANIEL'],'FRANK':['FRANCIS'],'PETE':['PETER'],
             'THAD':['WILLIAM'],'MITT':['WILLARD'],'KIT':['CHRISTOPHER'],
             'SAM':['SAMUEL'],'MAX':['MAXWELL'],'STEVE':['STEVEN','STEPHEN'],
             'DAVE':['DAVID'],'MICH':['MITCH'],'RUSSEL':['RUSSELL']}
    for word in list(allowed): allowed.update(aliases.get(word,[]))
    # A first initial is permitted only when the source actually provides an initial.
    first=next((word for word in given if len(word)>1),given[0] if given else '')
    possibilities={first,*aliases.get(first,[])}
    return bool(possibilities&allowed) or (len(first)==1 and first in {x[0] for x in allowed})


def load_roster(root):
    rows=[]
    for filename in ['legislators-historical.yaml','legislators-current.yaml']:
        people=yaml.load((root/filename).read_text(),Loader=yaml.CSafeLoader)
        for person in people:
            name=person['name'];identifier=person['id']['bioguide']
            for term in person['terms']:
                if term['type']!='sen' or str(term['end'])<'1980-01-01':
                    continue
                rows.append({'bioguide':identifier,'first':name['first'],'last':name['last'],
                             'given_names':' '.join(str(name.get(k,'')) for k in ['first','middle','nickname']),
                             'start':str(term['start']),'end':str(term['end']),'state':term['state'],
                             'class':term['class'],'party':term['party']})
    return pd.DataFrame(rows).drop_duplicates()


def at_date(roster,state,when):
    x=roster.loc[roster.state.eq(state)&roster.start.le(str(when))&roster.end.gt(str(when))]
    return x.drop_duplicates('bioguide')


def build_data(senate_path,house_path,raw_senate_path,root):
    senate=pd.read_csv(senate_path)
    house=pd.read_csv(house_path)
    raw=pd.read_csv(raw_senate_path,sep='\t')
    roster=load_roster(root)
    specials=raw.loc[raw.special].groupby(['state_po','year']).size().to_dict()
    # Party outcomes include unopposed major-party districts without selecting on
    # future contestedness. Two-party shares are undefined if both parties absent.
    house['outcome_D']=house.d2pshare
    house.loc[house.cand_d.notna()&house.cand_r.isna(),'outcome_D']=1.
    house.loc[house.cand_r.notna()&house.cand_d.isna(),'outcome_D']=0.
    house['geography']=house.st_dist_redist_FE.astype(str)
    house.loc[house.dist.eq(0),'geography']=house.loc[house.dist.eq(0),'state_abbrev']+'-at-large'
    # Keep every scheduled cohort that can finish in the available House era.
    starts=senate.loc[senate.year.between(1982,2016)].copy()
    data=[];ledger=[]
    for _,term in starts.iterrows():
        state=term.state_abbrev;t0=int(term.year);senate_class=(t0%6)//2 or 3
        # Match a newly beginning Senate term, including brief service (Biden
        # 2009) and delayed seating (Franken 2009). Do not condition on survival
        # until an arbitrary post-inauguration inspection date.
        occupants=roster.loc[roster.state.eq(state)&roster['class'].eq(senate_class)&
                            roster.start.ge(f'{t0}-11-01')&roster.start.le(f'{t0+1}-12-31')]
        verified=[]
        for _,person in occupants.drop_duplicates('bioguide').iterrows():
            for sign,label in [(1,'DEMOCRAT'),(-1,'REPUBLICAN')]:
                if matches_person(term[f'candidate_{label}'],person): verified.append((person,sign,label))
        record={'state_abbrev':state,'start_year':t0,'scheduled_year':t0+6,
                'candidate_D':term.candidate_DEMOCRAT,'candidate_R':term.candidate_REPUBLICAN}
        if len(verified)!=1:
            ledger.append({**record,'included':False,'reason':'no unique elected nominee verified as beginning Senate service',
                           'roster_possible_holders':' | '.join(occupants.given_names+' '+occupants['last'])});continue
        holder,party,label=verified[0];holder_date=holder.start
        score=party*term.historical_advantage
        if pd.isna(score):
            ledger.append({**record,'included':False,'reason':'historical score missing'});continue
        years=[t0+2,t0+4,t0+6]
        panel=house.loc[house.state_abbrev.eq(state)&house.year.isin(years)&house.outcome_D.notna()].copy()
        complete=panel.groupby('geography').year.nunique().eq(3)
        geographies=complete.index[complete]
        panel=panel.loc[panel.geography.isin(geographies)]
        if not len(geographies):
            ledger.append({**record,'included':False,'reason':'no House geography observed across all three outcomes'});continue
        event_id=f'{state}-{holder.bioguide}-{t0}'
        for phase in [2,4,6]:
            year=t0+phase;districts=panel.loc[panel.year.eq(year)]
            pre=at_date(roster,state,election_date(year)-timedelta(days=1))
            other=pre.loc[pre['class'].ne(senate_class)]
            other_due=other.loc[other['class'].map(lambda c: year%6==(2*c)%6)]
            other_sign=sum(1 if x=='Democrat' else -1 if x=='Republican' else 0 for x in other_due.party)
            current=senate.loc[senate.state_abbrev.eq(state)&senate.year.eq(year)]
            actual_rerun=False
            if phase==6 and len(current)==1:
                actual_rerun=matches_person(current.iloc[0][f'candidate_{label}'],holder)
            all_districts=house.loc[house.state_abbrev.eq(state)&house.year.eq(year)]
            dshare=districts.outcome_D.mean()
            data.append({'event_id':event_id,'state_abbrev':state,'start_year':t0,'year':year,'phase':phase,
                         'bioguide':holder.bioguide,'senator':term[f'candidate_{label}'],'party':party,'score_own':score,
                         'outcome_party_share':.5+party*(dshare-.5),'outcome_D':dshare,'phase4':int(phase==4),
                         'phase6':int(phase==6),'quality_phase4':score*int(phase==4),'quality_phase6':score*int(phase==6),
                         'other_scheduled_party':party*other_sign,'special_count':int((state,year) in specials),
                         'still_senator':holder.bioguide in set(pre.bioguide),'actual_rerun':actual_rerun,
                         'n_house_districts':len(districts),'source_state_districts':len(all_districts),
                         'district_coverage':len(districts)/len(all_districts),'roster_verification_date':holder_date})
        ledger.append({**record,'included':True,'reason':'balanced House geography panel','event_id':event_id,
                       'score_own':score,'party':party,'senator':term[f'candidate_{label}'],'n_house_districts':len(geographies)})
    return pd.DataFrame(data),pd.DataFrame(ledger)


def fit(data,terms,controls=PRIMARY_CONTROLS):
    frame=data.copy();n=len(frame)
    year_party=frame.party.astype(str)+'-'+frame.year.astype(str)
    f1=pd.get_dummies(frame.event_id,drop_first=True,dtype=float)
    f2=pd.get_dummies(year_party,drop_first=True,dtype=float)
    names=terms+controls
    x=np.column_stack([np.ones(n),frame[names],f1,f2]).astype(float)
    y=frame.outcome_party_share.to_numpy()
    b,_,rank,_=np.linalg.lstsq(x,y,rcond=None)
    residual=y-x@b
    states,groups=np.unique(frame.state_abbrev,return_inverse=True)
    scores=np.zeros((len(states),x.shape[1]));np.add.at(scores,groups,x*residual[:,None])
    bread=np.linalg.pinv(x.T@x);cov=bread@(scores.T@scores)@bread
    cov*=len(states)/(len(states)-1)*(n-1)/(n-rank)
    return b,cov,names,t.ppf(.975,len(states)-1),rank


def contrasts(data,label,terms,prefix,scale):
    b,cov,names,critical,rank=fit(data,terms)
    definitions={
        'off_cycle_placebo_4_minus_2':{prefix+'4':1},
        'scheduled_6_vs_mean_off_2_4':{prefix+'6':1,prefix+'4':-.5},
        'scheduled_6_minus_off_4':{prefix+'6':1,prefix+'4':-1},
        'scheduled_6_after_linear_offcycle_trend':{prefix+'6':1,prefix+'4':-2},
    }
    result=[]
    for name,values in definitions.items():
        vector=np.zeros(len(b))
        for feature,factor in values.items():vector[1+names.index(feature)]=factor
        estimate=vector@b;se=np.sqrt(max(0,vector@cov@vector))
        result.append({'sample':label,'predictor':prefix.rstrip('_'),'contrast':name,
                       'estimate_pp':estimate*scale,'low95':(estimate-critical*se)*scale,'high95':(estimate+critical*se)*scale,
                       'se_pp':se*scale,'term_cohorts':data.event_id.nunique(),'observations':len(data),'states':data.state_abbrev.nunique(),
                       'first_house_year':int(data.year.min()),'last_house_year':int(data.year.max()),'rank':int(rank)})
    return result


def analyze(data,threshold):
    data['high']=data.score_own.ge(threshold['high_p90']).astype(int)
    data['low']=data.score_own.le(threshold['low_p10']).astype(int)
    for strength in ['high','low']:
        for phase in [4,6]:data[f'{strength}_phase{phase}']=data[strength]*data.phase.eq(phase)
    actual_ids=set(data.loc[data.phase.eq(6)&data.actual_rerun,'event_id'])
    full_coverage=data.groupby('event_id').district_coverage.min().ge(.8)
    no_special=data.groupby('event_id').special_count.sum().eq(0)
    selections={'scheduled_ITT':data,'coverage_at_least_80pct':data.loc[data.event_id.isin(full_coverage.index[full_coverage])],
                'no_specials_conditional':data.loc[data.event_id.isin(no_special.index[no_special])],
                'actual_rerunners_conditional':data.loc[data.event_id.isin(actual_ids)]}
    estimates=[]
    for label,frame in selections.items():
        estimates.extend(contrasts(frame,label,['quality_phase4','quality_phase6'],'quality_phase',10))
        if label=='scheduled_ITT':
            terms=['high_phase4','high_phase6','low_phase4','low_phase6']
            estimates.extend(contrasts(frame,label,terms,'high_phase',100))
            estimates.extend(contrasts(frame,label,terms,'low_phase',100))
    return data,pd.DataFrame(estimates)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--senate-data',type=Path,default=Path('/tmp/coattails_prediction/sample.csv'))
    p.add_argument('--house-data',type=Path,default=Path('/tmp/coattails_identification/data/house_districts.csv'))
    p.add_argument('--raw-senate',type=Path,default=Path('/tmp/coattails_identification/data/mit_senate.tsv'))
    p.add_argument('--threshold-file',type=Path,default=Path('/tmp/coattails_stage2/house/summary.json'))
    p.add_argument('--root',type=Path,default=ROOT)
    args=p.parse_args();root=args.root
    threshold=json.loads(args.threshold_file.read_text())['thresholds']
    data,ledger=build_data(args.senate_data,args.house_data,args.raw_senate,root)
    data,estimates=analyze(data,threshold)
    data.to_csv(root/'panel.csv',index=False);ledger.to_csv(root/'cohort_ledger.csv',index=False)
    estimates.to_csv(root/'estimates.csv',index=False)
    counts=data.loc[data.phase.eq(6)]
    summary={'design':'Previously observed Senate strength across off-cycle House elections and the scheduled next Senate election',
             'primary':'Scheduled-election ITT, preserving later nonparticipation and turnover',
             'score':'Prior completed Senate election historical overperformance, frozen at the start of each term',
             'score_model':'Legacy phase-one median-adjusted score, pending independently validated broad-score update',
             'outcome':'Mean same-party two-party House share across identical geographic districts within the term cohort; includes unopposed 0/1 outcomes',
             'models':'Term fixed effects, party-by-calendar-year fixed effects, generic phase effects, other-seat scheduled incumbent party and special-election count',
             'thresholds':threshold,'cohorts':len(counts),'top_decile_cohorts':int(counts.high.sum()),'bottom_decile_cohorts':int(counts.low.sum()),
             'actual_reruns':int(counts.actual_rerun.sum()),'still_senator_before_scheduled_election':int(counts.still_senator.sum()),
             'estimates':json.loads(estimates.to_json(orient='records')),
             'exclusions':ledger.loc[~ledger.included].reason.value_counts().to_dict(),
             'limitations':['Senate classes are predetermined, but strength, retirement and state-specific trends are not randomized.',
                'The primary scheduled-election estimate includes senators who later retire, leave office or pursue national office. It is not an actual-appearance treatment.',
                'Term fixed effects remove permanent level differences. Off-cycle placebo and trend-adjusted contrasts assess lingering state-party trends and mean reversion.',
                'Balanced geography avoids changing district composition but restricts the covered Senate cohorts.',
                'Two-party vote share includes unopposed seats and does not isolate turnout or persuasion.',
                'Source historical score includes opponents and campaign environment as well as the candidate.'],
             'sha256':{str(path):hashlib.sha256(path.read_bytes()).hexdigest() for path in [args.senate_data,args.house_data,args.raw_senate,root/'legislators-historical.yaml',root/'legislators-current.yaml']}}
    (root/'summary.json').write_text(json.dumps(summary,indent=2,allow_nan=False))
    print('Cohort reasons');print(ledger.groupby(['included','reason']).size().to_string())
    print('Cohorts',len(counts),'top',counts.high.sum(),'bottom',counts.low.sum(),'rerun',counts.actual_rerun.sum(),'still',counts.still_senator.sum())
    print(estimates.to_string(index=False))

if __name__=='__main__':main()
