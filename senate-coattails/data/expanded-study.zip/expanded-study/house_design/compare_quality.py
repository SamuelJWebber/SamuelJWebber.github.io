"""Compare legacy and corrected term-start strength on exactly the same cohorts.

Primary corrected centered historical residual was selected on Senate own-vote
2010-14 development performance, not any House outcome. A term-start residual is
known after t0 and before every outcome t0+2,+4,+6. Its scale is historical vote
share residual, not the rolling model's predicted candidate bonus.
"""
import argparse,hashlib,json
from pathlib import Path
import numpy as np
import pandas as pd
from on_off import analyze,contrasts

ROOT=Path(__file__).resolve().parent
THRESHOLDS={'low_p10':-0.0614923455340774,'high_p90':0.1267705429908936,
            'population':'231 observed prior nominee-history appearances in 1982-2008 main Senate training elections, including repeat appearances; computed before House cohort join',
            'unit':'candidate-oriented centered historical vote-share residual'}


def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--root',type=Path,default=ROOT)
 p.add_argument('--historical-audit',type=Path,default=Path('/tmp/coattails_stage3/score/results/historical_election_audit.csv'))
 p.add_argument('--selection',type=Path,default=Path('/tmp/coattails_stage3/score/results/model_selection.json'))
 a=p.parse_args();r=a.root
 old=pd.read_csv(r/'panel.csv')
 history=pd.read_csv(a.historical_audit)
 train=history.loc[history.year.between(1982,2008)]
 reference=pd.concat([train.loc[train[f'history_observed_{side}'].eq(1),f'history_centered_{side}'] for side in ['D','R']])
 assert len(reference)==231
 assert np.allclose(reference.quantile([.1,.9]),[THRESHOLDS['low_p10'],THRESHOLDS['high_p90']])
 keep=['state_abbrev','year','historical_expected_D_share','historical_residual_raw','historical_residual_centered','historical_model_last_year','historical_model_n']
 source=history[keep].rename(columns={'year':'start_year'})
 assert not source.duplicated(['state_abbrev','start_year']).any()
 joined=old.merge(source,on=['state_abbrev','start_year'],how='left',validate='many_to_one')
 joined['legacy_score_own']=joined.score_own
 joined['centered_score_own']=joined.party*joined.historical_residual_centered
 joined['raw_score_own']=joined.party*joined.historical_residual_raw
 matched=joined.loc[joined.centered_score_own.notna()&joined.raw_score_own.notna()].copy()
 assert matched.groupby('event_id').size().eq(3).all()
 assert (matched.historical_model_last_year<matched.start_year).all()
 expected=pd.read_csv(r/'cohort_ledger.csv');matched.to_csv(r/'matched_quality_panel.csv',index=False)
 estimates=[]
 for model,column in [('corrected_centered','centered_score_own'),('corrected_raw','raw_score_own'),('legacy_matched','legacy_score_own')]:
  frame=matched.copy();frame['score_own']=frame[column]
  for phase in [4,6]:frame[f'quality_phase{phase}']=frame.score_own*frame.phase.eq(phase)
  if model=='corrected_raw':
   out=pd.DataFrame(contrasts(frame,'scheduled_ITT',['quality_phase4','quality_phase6'],'quality_phase',10))
  else:
   threshold=THRESHOLDS if model=='corrected_centered' else json.loads((r/'summary.json').read_text())['thresholds']
   frame,out=analyze(frame,threshold)
  out['score_model']=model;estimates.append(out)
  if model=='corrected_centered':frame.to_csv(r/'corrected_panel.csv',index=False)
 result=pd.concat(estimates,ignore_index=True)
 result.to_csv(r/'quality_comparison_estimates.csv',index=False)
 cohort=matched.loc[matched.phase.eq(6)].copy()
 cohort['corrected_high']=cohort.centered_score_own.ge(THRESHOLDS['high_p90'])
 cohort['corrected_low']=cohort.centered_score_own.le(THRESHOLDS['low_p10'])
 cohort.to_csv(r/'matched_quality_cohorts.csv',index=False)
 coverage=cohort.groupby(['start_year','year']).agg(cohorts=('event_id','size'),states=('state_abbrev','nunique'),high=('corrected_high','sum'),low=('corrected_low','sum'),actual_reruns=('actual_rerun','sum'),mean_district_coverage=('district_coverage','mean'),minimum_district_coverage=('district_coverage','min')).reset_index()
 coverage.to_csv(r/'coverage_by_cohort.csv',index=False)
 for side,mask in [('top',cohort.corrected_high),('bottom',cohort.corrected_low)]:
  cohort.loc[mask,['event_id','senator','party','start_year','year','centered_score_own','legacy_score_own','n_house_districts','district_coverage','actual_rerun']].sort_values('centered_score_own',ascending=False).to_csv(r/f'{side}_cohort_ledger.csv',index=False)
 selected=json.loads(a.selection.read_text())
 summary={'primary_score':'corrected_centered','score_label':'Completed term-start Senate vote share minus an earlier-cycles-only expected share, centered on contemporaneous other-state Senate residuals, and oriented to elected senator party',
 'selection_basis':selected['selection'],'selected_own_vote_architecture':selected['selected_model'],
 'timing_note':'The term-start residual is observed before every subsequent House outcome. Its underlying expected-share fit uses strictly earlier elections. Architecture was chosen using 2010-2014 own-vote performance, so architecture is retrospective for earlier cohorts.',
 'scale':'House percentage-point contrast per +10 percentage points of the historical residual; tail contrasts in House percentage points',
 'matched_cohorts':len(cohort),'matched_observations':len(matched),'states':cohort.state_abbrev.nunique(),'first_term_start':int(cohort.start_year.min()),'last_term_start':int(cohort.start_year.max()),'first_house_year':int(matched.year.min()),'last_house_year':int(matched.year.max()),
 'cohort_start_years':sorted(map(int,cohort.start_year.unique())),'scheduled_years':sorted(map(int,cohort.year.unique())),
 'legacy_full_cohorts':old.event_id.nunique(),'lost_for_corrected_score':old.event_id.nunique()-cohort.event_id.nunique(),'top_cohorts':int(cohort.corrected_high.sum()),'bottom_cohorts':int(cohort.corrected_low.sum()),'actual_reruns':int(cohort.actual_rerun.sum()),'thresholds':THRESHOLDS,
 'all_model_estimates':json.loads(result.to_json(orient='records')),
 'source_sha256':{str(path):hashlib.sha256(path.read_bytes()).hexdigest() for path in [a.historical_audit,a.selection,r/'panel.csv']},
 'interpretation':['Scheduled class is predetermined; strength, service and state trends are not randomized. This is an observational offered-incumbent-cycle comparison.','No later rerunning, retirement or winner status is required for the primary cohort.','Off-cycle quality trends undermine a causal interpretation of an unadjusted scheduled-vs-off contrast.','Trend correction extrapolates one off-cycle change; it is a sensitivity, not a demonstrated counterfactual.','Geography-balanced cohorts span identical districts but omit many terms crossing redistricting.','Two-party House share combines turnout and vote choice; it does not identify either mechanism separately.','Tail intervals are secondary and exploratory, with multiple related contrasts.']}
 (r/'quality_comparison_summary.json').write_text(json.dumps(summary,indent=2,allow_nan=False))
 print('Matched cohorts',len(cohort),'states',cohort.state_abbrev.nunique(),'top',cohort.corrected_high.sum(),'bottom',cohort.corrected_low.sum())
 print(result.loc[result['sample'].eq('scheduled_ITT')].to_string(index=False))

if __name__=='__main__':main()
