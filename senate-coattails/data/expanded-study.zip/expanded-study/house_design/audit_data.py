"""Recheck cohort identity, score timing, geography and outcome aggregation."""
import argparse,json
from pathlib import Path
import numpy as np
import pandas as pd
from on_off import load_roster,matches_person
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--root',type=Path,default=Path(__file__).resolve().parent)
p.add_argument('--house-data',type=Path,default=Path('/tmp/coattails_identification/data/house_districts.csv'))
args=p.parse_args();R=args.root
p=pd.read_csv(R/'corrected_panel.csv')
h=pd.read_csv(args.house_data)
h['outcome_D']=h.d2pshare
h.loc[h.cand_d.notna()&h.cand_r.isna(),'outcome_D']=1.
h.loc[h.cand_r.notna()&h.cand_d.isna(),'outcome_D']=0.
h['geography']=h.st_dist_redist_FE.astype(str)
h.loc[h.dist.eq(0),'geography']=h.loc[h.dist.eq(0),'state_abbrev']+'-at-large'
assert not h.duplicated(['state_abbrev','year','geography']).any()
assert p.groupby('event_id').size().eq(3).all()
assert p.groupby('event_id').phase.apply(lambda x:set(x)=={2,4,6}).all()
assert p.groupby('event_id').score_own.nunique().eq(1).all()
assert (p.historical_model_last_year<p.start_year).all()
assert np.allclose(p.score_own,p.party*p.historical_residual_centered)
assert not p.duplicated(['event_id','phase']).any()
assert p.outcome_party_share.between(0,1).all()
roster=load_roster(R)
maxerr=0.;rows=[]
for event,x in p.groupby('event_id'):
 row=x.iloc[0];state=row.state_abbrev;t0=int(row.start_year)
 candidates=roster.loc[roster.bioguide.eq(row.bioguide)&roster.start.ge(f'{t0}-11-01')&roster.start.le(f'{t0+1}-12-31')]
 assert len(candidates)>0
 assert any(matches_person(row.senator,person) for _,person in candidates.iterrows())
 z=h.loc[h.state_abbrev.eq(state)&h.year.isin(x.year)&h.outcome_D.notna()]
 geographies=z.groupby('geography').year.nunique();geographies=set(geographies.index[geographies.eq(3)])
 for _,record in x.iterrows():
  used=z.loc[z.year.eq(record.year)&z.geography.isin(geographies)]
  assert len(used)==record.n_house_districts
  manual=.5+record.party*(used.outcome_D.sum()/len(used)-.5)
  maxerr=max(maxerr,abs(manual-record.outcome_party_share))
  if (record.senator in ['BARACK OBAMA','JOSEPH R. BIDEN JR.','JOHN MCCAIN']) and t0>=2002:
   rows.append({'event_id':event,'senator':record.senator,'start_year':t0,'outcome_year':int(record.year),'phase':int(record.phase),'party':int(record.party),'frozen_centered_score':record.score_own,'source_expected_D_share_at_t0':record.historical_expected_D_share,'score_model_last_training_year':int(record.historical_model_last_year),'same_geography_count':len(used),'sum_D_district_two_party_shares':used.outcome_D.sum(),'manual_same_party_mean':manual,'stored_same_party_mean':record.outcome_party_share,'actual_rerun_at_phase6':bool(record.actual_rerun) if record.phase==6 else None,'geography_ids':' | '.join(sorted(geographies))})
assert maxerr<1e-12
pd.DataFrame(rows).to_csv(R/'hand_audit_examples.csv',index=False)
summary={'cohorts_checked':p.event_id.nunique(),'observations_checked':len(p),'maximum_recalculated_outcome_error':maxerr,'checks':['Exactly three unique phases 2,4,6 per cohort','Score constant within cohort','Quality expected-share model trained strictly earlier than term-start election','Stored score equals party times term-start centered residual','Full given-name plus surname matches a dated beginning-of-term Senate roster record','Each outcome averages exactly the same set of geographic House districts','No duplicate state-year-geography source rows','Manual party-oriented outcome aggregation matches stored outcome to floating-point tolerance'],'identity_corrections':['Biden2008 retained via January6-15,2009 Senate term, despite subsequent VP departure','John Warner1996 distinguished from opposing Mark Warner; cohort then excluded for no stable House geography','Mel Carnahan2000 does not match appointed Jean Carnahan and is excluded as an elected nominee who did not begin Senate service'],'remaining_identity_exclusions':['AK2010 Lisa Murkowski write-in victory outside supplied D/R pair','CT2006 Joe Lieberman independent victory outside D/R pair','ME2012 Angus King independent victory outside D/R pair','MO2000 Mel Carnahan never began Senate service; Jean Carnahan was appointed'],'scope_note':'The source comprises regular elections with identified D/R nominees. Independent winners outside that pair and elected nominees who never serve are not characterized as offered strong incumbents.'}
(R/'data_audit.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2))
