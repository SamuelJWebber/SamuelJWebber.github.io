"""Fixed pre-primary donor nomination comparison. Runs real outcomes once inputs exist."""
from pathlib import Path
import argparse, hashlib, json, warnings
from datetime import datetime, timezone
import numpy as np
import pandas as pd
from scipy import stats

HERE = Path(__file__).resolve().parent
MEASURES = {
    'national_donors': 'National disclosed donor breadth',
    'in_state_donors': 'In-state disclosed donor breadth',
    'national_gt200_donors': 'National donors with a receipt greater than $200',
    'national_gt500_donors': 'National donors with a receipt greater than $500',
}
OUTCOMES = {
    'house_share': ('Same-party House share, contested-district mean', 100, 'percentage points'),
    'senate_share': ('Nominee own Senate share', 100, 'percentage points'),
    'governor_share': ('Same-party concurrent governor share', 100, 'percentage points'),
    'party_house_votes_per100': ('Same-party House votes per 100 prior-census residents', 1, 'votes per 100 residents'),
    'total_house_votes_per100': ('Total House votes per 100 prior-census residents', 1, 'votes per 100 residents'),
}
CONTROLS = ['lag_house_share', 'prior_pres_share', 'democratic_party']

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def truth(s):
    return s.astype(str).str.strip().str.lower().isin(['true','1','1.0','yes'])

def clean_json(value):
    if isinstance(value,dict): return {str(k):clean_json(v) for k,v in value.items()}
    if isinstance(value,list): return [clean_json(v) for v in value]
    if isinstance(value,(np.integer,)): return int(value)
    if isinstance(value,(np.floating,float)):
        return float(value) if np.isfinite(value) else None
    if isinstance(value,(np.bool_,)): return bool(value)
    return value

def fit(sample, outcome, scale, bandwidth, adjusted=False, force_ids=None):
    """CR1 state-cluster WLS with state-cluster t critical value; all units explicit."""
    s=sample.loc[sample.margin_pp.abs()<bandwidth].copy()
    if force_ids is not None: s=s.loc[s.pair_id.isin(force_ids)]
    need=[outcome,'margin_pp','treatment','state']+(CONTROLS if adjusted else [])
    s=s.dropna(subset=need).copy()
    n=len(s); d=s.treatment.to_numpy(dtype=float); m=s.margin_pp.to_numpy(dtype=float)
    states=s.state.astype(str).to_numpy(); unique=np.unique(states); G=len(unique)
    method='mean_difference' if bandwidth==2 else 'local_linear_triangular'
    base={'window_margin_pp':bandwidth,'estimator':method,'adjusted':adjusted,
          'n':n,'treated':int(d.sum()),'control':int(n-d.sum()),'states':G,
          'state_years':len(s[['state','year']].drop_duplicates()),
          'pair_ids':';'.join(map(str,s.pair_id.tolist())),'status':'unidentified',
          'official_primary_verified':int(s.official_primary_verified.sum()),
          'as_of_filing_verified':int(s.as_of_filing_verified.sum())}
    if n==0 or G<3 or len(np.unique(d))<2:
        return base|{'reason':'Empty outcome sample, fewer than three states, or only one nomination side'},s
    w=np.ones(n) if bandwidth==2 else 1-np.abs(m)/bandwidth
    columns=[np.ones(n),d];names=['intercept','treatment']
    if bandwidth!=2:columns += [m,m*d];names += ['margin','treatment_margin']
    dropped=[]
    if adjusted:
        for c in CONTROLS:
            v=s[c].to_numpy(dtype=float)
            if np.ptp(v)<1e-12: dropped.append(c);continue
            columns.append(v-np.average(v,weights=w));names.append(c)
    X=np.column_stack(columns);rank=int(np.linalg.matrix_rank(X));k=X.shape[1]
    ess=float(w.sum()**2/np.sum(w**2))
    base |= {'rank':rank,'parameters':k,'residual_df':n-k,'cluster_df':G-1,
             'weight_ess':ess,'ess_treated':float(w[d==1].sum()**2/np.sum(w[d==1]**2)),
             'ess_control':float(w[d==0].sum()**2/np.sum(w[d==0]**2)),
             'dropped_constant_controls':';'.join(dropped),'model_columns':';'.join(names)}
    if rank<k or n<=k:
        return base|{'reason':'Rank-deficient model or no residual degrees of freedom'},s
    A=X.T@(w[:,None]*X);inv=np.linalg.inv(A)
    y=s[outcome].to_numpy(dtype=float)*scale
    beta=inv@(X.T@(w*y));res=y-X@beta
    U=X*(w*res)[:,None]
    scores=np.vstack([U[states==g].sum(axis=0) for g in unique])
    correction=G/(G-1)*(n-1)/(n-k)
    cov=inv@(scores.T@scores)@inv*correction
    se=float(np.sqrt(max(0.,cov[1,1])));b=float(beta[1]);crit=float(stats.t.ppf(.975,G-1))
    q=float(2*stats.t.sf(abs(b/se),G-1)) if se>0 else float('nan')
    base |= {'status':'estimated','reason':'','estimate':b,'se_state_cluster':se,
             'ci95_low':b-crit*se,'ci95_high':b+crit*se,'p_value':q,
             'mean_treated':float(np.mean(y[d==1])),'mean_control':float(np.mean(y[d==0])),
             'condition_number':float(np.linalg.cond(X*np.sqrt(w[:,None]))),
             'few_clusters_warning':bool(G<10),
             'inference_note':'State-cluster CR1; t(G-1); conditional on specified local linear form',
             'measurement_note':'Receipt-date donor proxy; filing-as-of verification reported separately',
             'causal_status':'Not established by fitting this model; assess balance, source timing and selection'}
    # Independent calculation using square-root weighted least squares checks the point estimate.
    independent=np.linalg.lstsq(X*np.sqrt(w[:,None]),y*np.sqrt(w),rcond=None)[0]
    if not np.allclose(beta,independent,atol=1e-7,rtol=1e-7):
        raise AssertionError('Independent WLS point estimates disagree')
    return base,s

def main(args):
    dest=args.output;dest.mkdir(parents=True,exist_ok=True)
    pair=pd.read_csv(args.pairs).rename(columns={'myers_row':'pair_id'})
    pair=pair.loc[pair.margin_corrected_pp.abs()<10].copy()
    assert pair.pair_id.is_unique
    pair['official_primary_verified']=pair.official_status.eq('verified')
    pair['cohort_eligible']=True
    if args.overrides and args.overrides.exists():
        ov=pd.read_csv(args.overrides)
        assert ov.pair_id.is_unique
        pair=pair.merge(ov.add_prefix('override_'),left_on='pair_id',right_on='override_pair_id',how='left',validate='one_to_one')
        for original,new in [('winner_slot','override_winner_slot'),('margin_corrected_pp','override_margin_pp')]:
            if new in pair:pair[original]=pd.to_numeric(pair[new],errors='coerce').combine_first(pair[original])
        if 'override_eligible' in pair:
            known=pair.override_eligible.notna();pair.loc[known,'cohort_eligible']=truth(pair.loc[known,'override_eligible'])
        if 'override_verification' in pair:
            verified=pair.override_verification.fillna('').str.lower().isin(['verified','official','official_verified','official_corrected'])
            pair.loc[verified,'official_primary_verified']=True
    donor=pd.read_csv(args.donors)
    if 'myers_row' in donor and 'pair_id' not in donor:donor=donor.rename(columns={'myers_row':'pair_id'})
    donor['pair_id']=pd.to_numeric(donor.pair_id,errors='raise').astype(int)
    donor['slot']=pd.to_numeric(donor.slot,errors='raise').astype(int)
    assert not donor.duplicated(['pair_id','slot']).any()
    if 'count_observed' not in donor: raise ValueError('Donor input must explicitly certify count_observed')
    donor['count_observed']=truth(donor.count_observed)
    if 'source_complete' in donor:
        assert (~donor.count_observed|truth(donor.source_complete)).all(), 'Observed count requires complete source'
    dates={c:pd.to_datetime(donor[c],errors='coerce') for c in ['primary_date','cutoff_date','window_start']}
    observed=donor.count_observed
    assert all(v.loc[observed].notna().all() for v in dates.values()), 'Observed count requires valid dates'
    assert (dates['primary_date'].loc[observed]-dates['cutoff_date'].loc[observed]).eq(pd.Timedelta(days=30)).all()
    starts=pd.to_datetime((pd.to_numeric(donor.year)-1).astype(int).astype(str)+'-01-01')
    assert dates['window_start'].loc[observed].eq(starts.loc[observed]).all(), 'Unexpected donor window start'
    if 'filing_asof_verified' in donor and 'as_of_filing_verified' not in donor:
        donor=donor.rename(columns={'filing_asof_verified':'as_of_filing_verified'})
    donor['as_of_filing_verified']=truth(donor.as_of_filing_verified) if 'as_of_filing_verified' in donor else False
    for c in MEASURES:
        if c not in donor:raise ValueError(f'Missing count field {c}')
        donor[c]=pd.to_numeric(donor[c],errors='coerce')
        assert donor.loc[donor[c].notna(),c].ge(0).all()
        assert donor.loc[donor.count_observed,c].notna().all(), 'Observed count cannot be missing'
        assert donor.loc[donor[c].notna(),c].mod(1).eq(0).all(), 'Donor counts must be integers'
    wide=pair.copy()
    for slot in [0,1]:
        a=donor.loc[donor.slot==slot].drop(columns='slot')
        a=a.rename(columns={c:f'{c}_{slot}' for c in a if c!='pair_id'})
        wide=wide.merge(a,on='pair_id',how='left',validate='one_to_one')
    outcome=pd.read_csv(args.outcomes)
    if 'myers_row' in outcome and 'pair_id' not in outcome:outcome=outcome.rename(columns={'myers_row':'pair_id'})
    assert outcome.pair_id.is_unique
    # Pair metadata remains authoritative; the outcome assembler is independent of donor ranking.
    cols=[c for c in outcome if c not in wide or c=='pair_id']
    wide=wide.merge(outcome[cols],on='pair_id',how='left',validate='one_to_one')
    wide['democratic_party']=wide.party.eq('dem').astype(int)
    wide['as_of_filing_verified']=wide.as_of_filing_verified_0.fillna(False)&wide.as_of_filing_verified_1.fillna(False)
    for c in ['house_share','lag_house_share','prior_pres_share','senate_share','governor_share']:
        if c not in wide:wide[c]=np.nan
        good=pd.to_numeric(wide[c],errors='coerce').dropna()
        assert good.between(0,1).all(),f'{c} must be a fraction in [0,1]'
    results=[];balance=[];ledgers=[];coverage=[]
    for measure,label in MEASURES.items():
        s=wide.copy();a=s[f'{measure}_0'];b=s[f'{measure}_1']
        s['measure']=measure;s['measure_label']=label
        observed=s.count_observed_0.fillna(False)&s.count_observed_1.fillna(False)&a.notna()&b.notna()
        s['exclusion_reason']=np.select([~s.cohort_eligible,~observed,a.eq(b),s.margin_corrected_pp.eq(0)],
            ['nomination_or_mapping_exclusion','donor_count_missing_or_unobserved','equal_donor_counts','exact_primary_vote_tie'],default='')
        s['higher_donor_slot']=np.where(a>b,0,np.where(b>a,1,np.nan))
        s['treatment']=np.where(observed & a.ne(b),(s.higher_donor_slot==s.winner_slot).astype(int),np.nan)
        s['margin_pp']=s.margin_corrected_pp.abs()*np.where(s.treatment==1,1,-1)
        s['high_count']=np.maximum(a,b);s['low_count']=np.minimum(a,b)
        s['donor_ratio']=s.high_count/s.low_count.replace(0,np.nan)
        s['both_counts_observed']=observed
        ledger_cols=['pair_id','state','year','party','name0','name1','winner_slot','measure',
            f'{measure}_0',f'{measure}_1','higher_donor_slot','treatment','margin_pp','high_count','low_count',
            'donor_ratio','both_counts_observed','official_primary_verified','as_of_filing_verified','exclusion_reason']
        ledgers.append(s[ledger_cols])
        selected=s.loc[s.exclusion_reason.eq('')].copy()
        for h in [2,5,10]:
            band=selected.loc[selected.margin_pp.abs()<h]
            coverage.append({'measure':measure,'window_margin_pp':h,'n':len(band),
                'treated':int(band.treatment.sum()),'control':int(len(band)-band.treatment.sum()),
                'states':band.state.nunique(),'official_primary_verified':int(band.official_primary_verified.sum()),
                'as_of_filing_verified':int(band.as_of_filing_verified.sum()),
                'median_high_count':band.high_count.median(),
                'median_low_count':band.low_count.median(),
                'median_ratio_when_low_positive':band.donor_ratio.median(),
                'low_count_zero_pairs':int(band.low_count.eq(0).sum())})
            for y in ['prior_pres_share','lag_house_share','democratic_party']:
                bfit,_=fit(selected,y,100,h,False)
                balance.append(bfit|{'measure':measure,'outcome':y,'units':'percentage points','specification':'pretreatment_balance'})
            for y,(name,scale,units) in OUTCOMES.items():
                if y not in selected:selected[y]=np.nan
                ufit,_=fit(selected,y,scale,h,False)
                afit,acase=fit(selected,y,scale,h,True)
                same,_=fit(selected,y,scale,h,False,acase.pair_id)
                for spec,r in [('unadjusted',ufit),('adjusted',afit),('unadjusted_same_adjusted_sample',same)]:
                    results.append(r|{'measure':measure,'outcome':y,'outcome_label':name,'units':units,'specification':spec})
    result=pd.DataFrame(results);bal=pd.DataFrame(balance)
    result.to_csv(dest/'effect_estimates.csv',index=False)
    bal.to_csv(dest/'balance_estimates.csv',index=False)
    pd.concat(ledgers,ignore_index=True).to_csv(dest/'treatment_ledger.csv',index=False)
    pd.DataFrame(coverage).to_csv(dest/'coverage.csv',index=False)
    wide.to_csv(dest/'joined_inputs.csv',index=False)
    main=result.loc[(result.measure=='national_donors')&(result.window_margin_pp==5)]
    input_paths=[args.pairs,args.donors,args.outcomes]
    if args.overrides and args.overrides.exists(): input_paths.append(args.overrides)
    info={'generated_at_utc':datetime.now(timezone.utc).isoformat(),
          'protocol_sha256':sha(HERE/'PROTOCOL.md'),
          'estimator_sha256':sha(Path(__file__)),
          'input_hashes':{str(p):sha(p) for p in input_paths},
          'requested_pair_count':len(pair),
          'donor_candidate_rows':len(donor),
          'donor_candidate_counts_observed':int(donor.count_observed.sum()),
          'main_measure':'national_donors','main_window_pp':5,
          'main_precision_specification':'adjusted','primary_outcome':'house_share',
          'interpretation':'Nomination of broader disclosed-donor contender; not pure charisma or a validated all-star effect.',
          'causal_status':'Not established; read pretreatment balance, timing and coverage diagnostics alongside estimates.',
          'timing_limitation':'Retrospective receipt dates; historical filing-as-of completeness is not assumed.',
          'disclosure_limitation':'Bulk inclusion threshold and aggregation period differ across 1975–1988, 1989–2014 and 2015 onward.',
          'candidate_characteristics_balance':'Unresolved: previous source-coded experience/quality fields have not been validated and are not used.',
          'coverage':coverage,'main_estimates':main.to_dict('records'),
          'all_estimates':result.to_dict('records'),'balance':bal.to_dict('records')}
    (dest/'summary.json').write_text(json.dumps(clean_json(info),indent=2,allow_nan=False)+'\n')
    print(main.reindex(columns=['outcome','specification','status','n','treated','control','states','estimate','ci95_low','ci95_high']).to_string(index=False))
    print('\nMain national-breadth balance:')
    print(bal.loc[(bal.measure=='national_donors')&(bal.window_margin_pp==5)].reindex(columns=['outcome','n','estimate','ci95_low','ci95_high']).to_string(index=False))

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--pairs',type=Path,default=HERE.parent/'cohort/source_nonrunoff_fundraising_cohort.csv')
    p.add_argument('--donors',type=Path,default=HERE.parent/'donors/candidate_donor_counts.csv')
    p.add_argument('--outcomes',type=Path,default=HERE.parent/'outcomes/outcomes.csv')
    p.add_argument('--overrides',type=Path,default=HERE.parent/'cohort/overrides.csv')
    p.add_argument('--output',type=Path,default=HERE/'results')
    main(p.parse_args())
