"""Synthetic numerical verification only; never interpret this output as election evidence."""
import json
import numpy as np
import pandas as pd
from scipy import stats
from estimate import fit, CONTROLS

rng=np.random.default_rng(41085)
n=120
m=rng.uniform(-9.9,9.9,n)
d=(m>0).astype(int)
state=np.array([f'S{i%17}' for i in range(n)])
s=pd.DataFrame(dict(pair_id=np.arange(n),state=state,year=2000+2*(np.arange(n)%11),
 margin_pp=m,treatment=d,official_primary_verified=True,as_of_filing_verified=False,
 lag_house_share=rng.uniform(.3,.7,n),prior_pres_share=rng.uniform(.3,.7,n),
 democratic_party=rng.integers(0,2,n)))
s['y']=(.4+.02*d+.002*m+.001*d*m+.1*s.prior_pres_share
         +rng.normal(0,.03,n))
checks=[]
for h in [2,5,10]:
 for adj in [False,True]:
  r,a=fit(s,'y',100,h,adj)
  w=np.ones(len(a)) if h==2 else 1-a.margin_pp.abs().to_numpy()/h
  treatment=a.treatment.to_numpy()
  z=[np.ones(len(a))]
  if h!=2:z.extend([a.margin_pp.to_numpy(),(a.margin_pp*a.treatment).to_numpy()])
  if adj:z.extend([a[c].to_numpy() for c in CONTROLS])
  Z=np.column_stack(z)
  # Partial out nuisance terms from treatment; calculate scalar coefficient and variance.
  fit_d=np.linalg.lstsq(Z*np.sqrt(w[:,None]),treatment*np.sqrt(w),rcond=None)[0]
  dr=treatment-Z@fit_d
  y=a.y.to_numpy()*100
  b=(w*dr)@y/((w*dr)@dr)
  fit_z=np.linalg.lstsq(Z*np.sqrt(w[:,None]),(y-b*treatment)*np.sqrt(w),rcond=None)[0]
  residual=y-b*treatment-Z@fit_z
  independent_scores=pd.Series(w*dr*residual).groupby(a.state.to_numpy()).sum().to_numpy()
  G=a.state.nunique();k=Z.shape[1]+1
  se=np.sqrt((independent_scores@independent_scores)/((w*dr)@dr)**2
    *G/(G-1)*(len(a)-1)/(len(a)-k))
  assert np.allclose([b,se],[r['estimate'],r['se_state_cluster']],rtol=1e-9,atol=1e-9)
  assert np.isclose(r['ci95_high'],b+stats.t.ppf(.975,G-1)*se)
  checks.append({'window':h,'adjusted':adj,'coefficient_and_cluster_se_match':True})
one=s.copy();one['treatment']=1
assert fit(one,'y',100,5,False)[0]['status']=='unidentified'
rank=s.copy();rank['prior_pres_share']=rank['lag_house_share']
assert fit(rank,'y',100,5,True)[0]['status']=='unidentified'
constant=s.copy();constant['democratic_party']=1
rr=fit(constant,'y',100,5,True)[0]
assert rr['status']=='estimated' and rr['dropped_constant_controls']=='democratic_party'
print(json.dumps({'synthetic_only':True,'checks':checks,
 'single_side_rejected':True,'collinear_control_rejected':True,'constant_nuisance_dropped':True},indent=2))
