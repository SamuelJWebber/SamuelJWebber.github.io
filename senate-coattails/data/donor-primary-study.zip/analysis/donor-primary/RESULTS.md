# Donor breadth and other candidates' results: executed analysis

The specified analysis has now been run on actual donor counts and election returns. It produces an imprecise positive House estimate, not a validated causal estimate of an all-star's coattails.

## Main estimates

The comparison is whether the Senate finalist with more disclosed, distinct donors narrowly won rather than narrowly lost the party nomination. The main window is a top-two primary margin below five percentage points. Positive numbers favor nominating the candidate with broader disclosed donor support.

| General-election outcome | Adjusted estimate, pp (95% interval) | Adjusted nominations / states | Unadjusted estimate, pp (95% interval) |
|---|---:|---:|---:|
| Same-party House share | +3.24 (−3.83, +10.30) | 32 / 19 | +5.14 (−11.52, +21.80) |
| Nominee's own Senate share | +1.58 (−6.87, +10.02) | 32 / 19 | −5.28 (−16.75, +6.19) |
| Same-party governor share | +17.92 (−22.48, +58.31) | 15 / 12 | −0.06 (−27.64, +27.52) |

House share is the unweighted mean of the party's D-versus-R share across regular districts with both major parties receiving observed positive votes. These are percentage-point differences, not relative percentages. The intervals include zero and effects in both directions. The governor comparison is especially unstable and should not be treated as evidence of a large effect.

The adjusted model includes that party's House share two years earlier, its latest strictly earlier presidential share, and a Democratic-party indicator. Unadjusted House/Senate comparisons use 33 nominations in 20 states; unadjusted governor uses 16 nominations in 13 states. The adjusted comparison omits Vermont 2000 because its prior House contest had no Democratic candidate. On the same 32 observations, unadjusted House is +4.25 pp (−12.64, +21.13), so the change after adjustment is not solely a sample change.

## Why this is not yet a causal all-star estimate

- Pretreatment party composition is strongly uneven: Democrats constitute 61.1% of broader-donor winners and 20.0% of broader-donor losers in the five-point sample. The fitted discontinuity is +68.30 percentage points (12.73, 123.88). The local linear diagnostic is not constrained to probability bounds.
- Prior presidential support has a fitted jump of −5.60 pp (−14.29, +3.10); prior House share, +5.21 pp (−7.69, +18.12). Their wide intervals do not establish balance. Adding prior outcomes can improve precision, but does not prove comparable treatment assignment.
- The donor measure is broader **disclosed** support relative to the other primary finalist. It has not validated a nationally exceptional or charismatic candidate. The own-Senate estimate is itself too imprecise to establish that interpretation.
- Counts use pre-primary receipt dates in a retrospective bulk snapshot. Historical filing-as-of completeness is not established. FEC disclosure thresholds and aggregation periods also change across eras.
- The 65-comparison starting cohort came from earlier work requiring money data, not a full census of close primaries. Candidate-characteristic balance remains unresolved because the source experience/quality fields have known coding concerns.
- The House share endpoint covers contested D/R races. Changes in contested districts could themselves reflect nominations. Vermont 2000 also has a dominant independent House candidate, so D/R share covers only 23.6% of all votes there; it remains in the frozen unadjusted comparison.

The fitted model does not separate persuasion from mobilization: both are allowed pathways. It is a local historical nomination comparison, not an estimate for Jon Ossoff or any other individual politician. Runoff-state primaries were excluded from this source cohort.

## Fixed sensitivities

All adjusted House sensitivities below include zero. None was selected because it gave a favorable effect.

| Donor measure | Primary window | Adjusted House estimate, pp (95% interval) |
|---|---:|---:|
| National distinct disclosed donors | 2 pp, mean difference | +0.59 (−5.97, +7.14) |
| National distinct disclosed donors | 10 pp, local linear | +0.92 (−3.93, +5.76) |
| In-state distinct disclosed donors | 5 pp, local linear | +3.60 (−3.42, +10.62) |
| National donors with a receipt >$200 | 5 pp, local linear | +3.68 (−3.45, +10.80) |
| National donors with a receipt >$500 | 5 pp, local linear | +0.82 (−6.83, +8.46) |

The >$500 measure was added before fitting after checking historical disclosure rules. It reduces threshold differences across eras; it does not solve all filing or amendment issues.

## Vote-volume endpoints

| Endpoint | Adjusted difference (95% interval) | N |
|---|---:|---:|
| Same-party House votes per 100 prior-census residents | −2.07 (−12.71, +8.57) | 20 |
| Total House votes per 100 prior-census residents | +2.18 (−14.44, +18.79) | 32 |

These endpoints require complete district coverage under the outcome assembly rules. Residents include people ineligible to vote, so neither is a turnout rate. Same-party votes cannot be silently filled with zero where the source omits an unopposed candidate's vote total.

## Data, inference and reproduction

All 130 candidate counts across 19 election cycles were observed from completed source extracts. All 65 pairs have unequal counts under each of the four specified measures; none was dropped for a donor tie. Within the five-point national sample, the higher-donor candidate won 18 nominations and lost 15. The median higher count is 568 and the median lower count 263; the median within-pair ratio is 2.47. Official counts verify 32 of the 33 main primary margins; Pennsylvania 1980 remains provisional.

The main model uses triangular weights and separate slopes on either side of the nomination cutoff. Intervals use state-cluster CR1 uncertainty with a t reference distribution on states minus one degrees of freedom; they are conditional on this functional form, not bias-corrected RD intervals. The adjusted House weighted effective sample size is 24.51, including 14.23 treated and 10.50 control. No House-to-Senate effect ratio is interpreted causally.

The output includes all 180 specified outcome fits, 36 pretreatment balance fits, the 260-row measure-by-pair treatment ledger, coverage and joined input tables. The protocol was fixed before these fits; its dated amendment is recorded. It is not external preregistration. Numerical verification checks coefficients and state-cluster uncertainty by an independent partial-regression calculation; these numerical tests use explicitly synthetic data and are not election evidence.

Run `python analysis/estimate.py` from the reproduction package after installing NumPy, pandas and SciPy. Inputs live under `cohort`, `donors` and `outcomes`; results are written to `analysis/results`. `summary.json` records exact input, protocol and estimator hashes. `verify_math.py` performs the separate numerical check.
