"""Package only the reviewed public release and necessary public reconstruction inputs."""
from pathlib import Path
import hashlib,json,zipfile
ROOT=Path(__file__).resolve().parents[2]
STUDY=ROOT/'analysis/donor-primary'
EXTRA=['analysis/stage3/inputs/governor_state_returns.csv','analysis/identification/balance/presidential_state_baselines.csv','dist/data/donor-primary.json']
files=[p for p in STUDY.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name!='SHA256.json']+[ROOT/p for p in EXTRA]
for p in files:
 assert not any(x in p.parts for x in ['private','input_snapshot']),p
 assert p.name not in ['joined_inputs.csv','outcomes.csv','house_state_year.csv','H_dist_election_data.tab'],p
hashes={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
manifest=STUDY/'SHA256.json';manifest.write_text(json.dumps(hashes,indent=2)+'\n')
dest=ROOT/'dist/data/donor-primary-study.zip'
with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(files+[manifest]):z.write(p,str(p.relative_to(ROOT)))
with zipfile.ZipFile(dest) as z:
 assert z.testzip() is None
print(json.dumps({'archive':str(dest),'files':len(files)+1,'bytes':dest.stat().st_size,'sha256':hashlib.sha256(dest.read_bytes()).hexdigest()}))
