# Executed donor nomination test

Study author: Samuel Webber. Assembly and independent numerical checks: Codex.

This release runs the actual pre-primary unique-disclosed-donor comparison and current general-election outcomes. It is separate from the earlier dollar-based validity audit and the older observational strength-score studies. Read `RESULTS.md` for all primary estimates and `PROTOCOL.md` for the specification frozen before the new donor ranks and outcomes were combined. This is retrospective research, not external preregistration.

## Main results

National disclosed donor breadth, primary margin below five percentage points, separately sloped local-linear model with triangular weights, prior House/presidential support and party controls:

| Outcome | Estimate, pp | State-cluster 95% interval | Contests |
| --- | ---: | ---: | ---: |
| House teammates | +3.24 | −3.83 to +10.30 | 32 |
| Senate nominee | +1.58 | −6.87 to +10.02 | 32 |
| Governor teammate | +17.92 | −22.48 to +58.31 | 15 |

The donor contrast does not establish greater general-election appeal. Party composition fails the prior-balance check, and receipt-date counts are not reconstructed filing vintages. These fitted differences do not establish causal coattails. All fixed adjusted House sensitivity intervals include zero. The governor estimate is especially imprecise and specification-sensitive. A broad interval is not evidence that coattails do not exist.

## Inputs and validation

The cohort contains 65 selected conventional non-runoff primary pairs, 130 candidate appearances and 19 FEC cycles (1980–2022). Both contenders have verified candidate/committee links and official nomination dates. All 130 counts are observed; 32 of 33 main-window vote margins are independently checked, with Pennsylvania 1980 remaining provisional. The adjusted main sample omits Vermont 2000 because its lagged Democratic House outcome is unavailable, leaving 31 verified margins among 32 rows.

The donor extractor scanned 176,384,441 canonical contribution records. National/in-state breadth and single-gift >$200 / >$500 definitions are separate fixed measures. Identity uses normalized full name plus ZIP5, so it is an approximation to people, not a census of all donors. The sum of candidate counts is not a count of globally unique donors. Bulk disclosure thresholds vary by era. Present-day records may include later amendments or later cumulative disclosure of earlier gifts.

Independent checks cover 36 candidate records × 4 donor definitions; 260 treatment orientations; the estimator's algebra and cluster variance; and a separate raw-input/FWL reproduction of the three main adjusted fits. Independent MIT House comparisons leave main-sample share differences below 0.045 pp after resolving a party-label issue. Wider-sample source discrepancies remain documented in `outcomes/HOUSE_SOURCE_AUDIT.md`; they do not change the frozen main panel.

## Reproduce the outcome estimates

Extract the study ZIP preserving its `analysis/` directory structure. Run from that extracted root. Python requires the packages pinned in `analysis/donor-primary/requirements.txt`. Raw downloaded election sources and the resulting row-level outcome tables must be generated in a separate working directory outside the public repository.

```bash
python -m pip install -r analysis/donor-primary/requirements.txt
python analysis/donor-primary/outcomes/prepare_outcome_inputs.py --repo . --workdir /tmp/donor-primary-rebuild
python analysis/donor-primary/outcomes/build_senate_outcomes.py --out /tmp/donor-primary-rebuild
python analysis/donor-primary/outcomes/build_outcomes.py --repo . --out /tmp/donor-primary-rebuild
python analysis/donor-primary/analysis/estimate.py --outcomes /tmp/donor-primary-rebuild/outcomes.csv --output /tmp/donor-primary-rebuild/results
python analysis/donor-primary/verify_actual.py --outcomes /tmp/donor-primary-rebuild/outcomes.csv --output /tmp/donor-primary-rebuild/actual_verification.json
```

The extractor's `donors/DONOR_METHODS.md` and `donors/README.md` describe the optional raw-FEC reconstruction. It downloads about 13.6 GB of compressed files; source hashes and canonical ZIP-member rules are included. Do not publish raw donor identities. A name/ZIP normalization check is additional measurement validation, not an outcome-selected proxy.

The dashboard can be regenerated from the included aggregate results and candidate counts with:

```bash
python analysis/donor-primary/build_dashboard.py
```

## Distribution boundary

Included: candidate-level FEC count aggregates, public nomination dates and mappings, safe identity-only cohort snapshots, source/hash manifests, code, aggregate effect/balance results and the curated dashboard JSON. Not included: raw individual donors, the DeLuca–Moskowitz–Schneer district source, merged outcome-row derivatives, original research replication archives or downloaded papers. The reconstruction scripts retrieve the pinned sources for local analysis. This boundary is not a legal determination about every derived statistic.

`analysis/results/summary.json` contains the exact input hashes. `actual_verification.json`, donor/nomination audit files and the package `SHA256.json` record verification. The donor filing-date diagnostic covers only retained current bulk records; even complete file-number matching does not recover superseded originals or establish a strict historical vintage.
