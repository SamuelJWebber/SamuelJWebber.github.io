"""Independent raw-input/FWL check of the three main adjusted estimates."""
import argparse,json
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import t
def main():
 p=argparse.ArgumentParser();p.add_argument('--study',type=Path,default=Path(__file__).parent);p.add_argument('--outcomes',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();s=a.study
 donors=pd.read_csv(s/'donors/candidate_donor_counts.csv');out=pd.read_csv(a.outcomes)
 overrides=pd.read_csv(s/'cohort/overrides.csv').set_index('pair_id')
 rows=[]
 for pid,g in donors.groupby('pair_id'):
  assert len(g)==2 and g['count_observed'].all()
  hi=g.loc[g.national_donors.idxmax()];lo=g.loc[g.national_donors.idxmin()]
  if hi.national_donors==lo.national_donors:continue
  treated=int(str(hi.winner).lower()=='true');margin=abs(float(hi.primarymargin_pp))
  if pid in overrides.index:margin=abs(float(overrides.loc[pid,'margin_pp']))
  if margin>=5:continue
  rows.append({'pair_id':pid,'D':treated,'m':margin*(2*treated-1),'dem':int(hi.party=='dem'),'state_key':hi.state})
 z=pd.DataFrame(rows).merge(out,on='pair_id',validate='one_to_one');ref=pd.read_csv(s/'analysis/results/effect_estimates.csv');checks=[]
 for y in ['house_share','senate_share','governor_share']:
  q=z.dropna(subset=[y,'prior_pres_share','lag_house_share']).copy();n=len(q);states=q.state_key.unique();G=len(states);w=1-q.m.abs().to_numpy()/5;sw=np.sqrt(w)
  # Residualize treatment against all nuisance columns in whitened space.
  Z=np.column_stack([np.ones(n),q.m,q.m*q.D,q.lag_house_share,q.prior_pres_share,q.dem]);Z=Z[:,np.array([True]+[np.ptp(Z[:,i])>1e-12 for i in range(1,Z.shape[1])])]
  Zw=Z*sw[:,None];dw=q.D.to_numpy()*sw;yw=q[y].to_numpy()*100*sw
  rd=dw-Zw@np.linalg.lstsq(Zw,dw,rcond=None)[0];ry=yw-Zw@np.linalg.lstsq(Zw,yw,rcond=None)[0]
  estimate=rd@ry/(rd@rd);Xw=np.column_stack([Zw,dw]);res=yw-Xw@np.linalg.lstsq(Xw,yw,rcond=None)[0]
  sums=np.array([(rd*res)[q.state_key.to_numpy()==g].sum() for g in states]);k=Xw.shape[1]
  se=np.sqrt((sums@sums)/(rd@rd)**2*G/(G-1)*(n-1)/(n-k));crit=t.ppf(.975,G-1)
  r=ref[(ref.measure=='national_donors')&(ref.window_margin_pp==5)&(ref.specification=='adjusted')&(ref.outcome==y)].iloc[0]
  assert n==r.n and np.allclose([estimate,se,estimate-crit*se,estimate+crit*se],[r.estimate,r.se_state_cluster,r.ci95_low,r.ci95_high],atol=1e-8,rtol=1e-8)
  checks.append({'outcome':y,'n':n,'states':G,'estimate':estimate,'se':se,'passed':True})
 a.output.write_text(json.dumps({'method':'Independent raw donor orientation, QR residualization and scalar state-cluster scores','checks':checks},indent=2)+'\n');print(json.dumps(checks,indent=2))
if __name__=='__main__':main()
