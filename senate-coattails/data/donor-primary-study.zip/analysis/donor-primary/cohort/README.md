# Senate close-primary nomination cohort

This directory resolves candidate identities, committees, and the date cutoff for the fixed 65 nonrunoff primary pairs with a top-two vote margin below 10 percentage points. The main sample contains 33 pairs below 5 points. No general-election outcomes were used in the mapping or date audit.

## Outputs

- `candidate_roster.csv`: 130 candidate appearances, two per pair. All map to exactly one current-election FEC candidate ID, at least one principal/authorized committee, and an official primary date. `status=matched` describes identity/date mapping, not donor reporting coverage.
- `committee_links.csv`: 150 candidate-to-committee rows, with committee names and official linkage sources.
- `primary_dates.csv`: 63 state-years covering all65 pairs. `cutoff_date` is primary date minus exactly30 calendar days; `window_start` is January1 of the preceding calendar year. The cutoff is inclusive in the donor extractor.
- `overrides.csv` and `additional_official_vote_audits.csv`: seven additional independent official vote verifications. All agree with the inherited winner and margin except numerical rounding. Main sample32/33 now has independently verified official counts; Pennsylvania1980 remains provisional for vote counts only. Its April22 date is official.
- `mapping_decisions.csv`: three explicit name-spelling corrections and the current-election registration choice for Paula Jean Swearengin2020.
- `metadata_manifest.json`: official FEC bulk source URLs, file sizes, SHA256 hashes, and archive member names.
- `dates/`: coverage audit, source URLs and document hash manifest. Raw source documents and OCR are omitted from the public package.
- The vote-audit CSV records official source URLs and the evidence inspected. Raw source documents are omitted from the public package.

## Reproduction

Run `python fetch_metadata.py`, then `python build_roster.py`, then `python audit_cohort.py` from this directory. The inherited cohort snapshot and scalar name normalization rules are included. Primary dates and vote audits are documented manual transcriptions from their cited official sources; rebuilding the roster does not re-scrape them.

## Mapping rules

Filter each cycle candidate master to Senate office, state and party. Match normalized surname and given name, then require the current election-year registration when several same-person registrations exist. Use the principal committee plus P/A Senate committees linked to that candidate and election year in the FEC candidate-committee linkage file (2000 onward), or the current-cycle committee master for earlier cycles. Every chosen candidate master record has the correct election year. No unauthorized PAC or joint-fundraising committee is added merely because its name resembles a candidate.

Swearengin2020 has separate2018 and2020 registrations. The2020 registration S0WV00215 links to C00708891. The2018 registration and old authorized committee C00640219 are excluded. Historical committee masters can retain authorized committees for prior elections; such committees remain included when linked to the active current-cycle candidate registration. The receipt-date window, not committee termination status, determines eligible contributions. The old-cycle authorized committees for Maher1980 are explicitly retained along with his current principal committee.

## Timing and institutional limits

The primary date is the congressional party-primary vote date, not a presidential primary/caucus, earlier party convention, recount completion, or certification date. Utah dates are direct primaries after conventions. No ranked-choice primary case appears in this fixed cohort. Alaska1992 was postponed from August25 to September8; West Virginia2020 was postponed from May12 to June9. Contemporary official calendars are not separately reconciled against all65 state canvasses; retained exceptions were checked against revised calendars/results.

FEC bulk metadata are retrospective current files; they identify entities and committees but do not reconstruct the public availability of every filing as of the cutoff. Contribution receipt date is predetermined; report filing dates and later amendments require separate treatment in the donor extraction audit. The roster alone does not establish that a zero donor count is genuine, that all small donors are itemized, or that a close-primary causal identification assumption holds.

## Independent donor orientation check

`audit_donor_orientation.py` joins all130 donor rows to the roster and checks candidate IDs, committees, dates, windows and winners. It independently constructs260 donor-definition/primary orientations and compares them to the estimator treatment ledger without loading outcomes. All checks passed: the main33 include18 higher-donor winners and15 higher-donor losers. Run it after donor extraction and estimation with `--donors` and `--ledger` paths when directories differ.
