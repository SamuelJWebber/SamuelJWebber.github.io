"""Validate the fixed cohort without loading downstream electoral outcomes."""
from pathlib import Path
import csv, json, datetime, collections, hashlib

P = Path(__file__).resolve().parent
rows = list(csv.DictReader((P / 'candidate_roster.csv').open()))
pairs = collections.defaultdict(list)
for row in rows:
    pairs[row['pair_id']].append(row)
assert len(rows) == 130 and len(pairs) == 65
for pair_id, pair in pairs.items():
    assert {r['slot'] for r in pair} == {'0', '1'}, pair_id
    assert len({r['primary_date'] for r in pair}) == 1, pair_id
    assert len({r['cutoff_date'] for r in pair}) == 1, pair_id
    assert sum(r['winner'] == 'True' for r in pair) == 1, pair_id
    assert pair[0]['fec_id'] != pair[1]['fec_id'], pair_id
    assert not set(pair[0]['committee_ids'].split(';')).intersection(pair[1]['committee_ids'].split(';')), pair_id
    for row in pair:
        primary = datetime.date.fromisoformat(row['primary_date'])
        cutoff = datetime.date.fromisoformat(row['cutoff_date'])
        assert (primary - cutoff).days == 30
        assert row['window_start'] == f"{int(row['year']) - 1}-01-01"
        assert row['fec_election_years'] == row['year']
        assert row['status'] == 'matched'
        assert len(row['fec_id']) == 9 and row['fec_id'].startswith('S')
        assert all(len(c) == 9 and c.startswith('C') for c in row['committee_ids'].split(';'))
        assert 0 < float(row['primarymargin_pp']) < 10
main = [pair for pair in pairs.values() if float(pair[0]['primarymargin_pp']) < 5]
assert len(main) == 33
verified_main = [pair for pair in main if pair[0]['official_votes_status'] == 'verified']
assert len(verified_main) == 32
unverified = [{'pair_id': p[0]['pair_id'], 'year': p[0]['year'], 'state': p[0]['state']} for p in main if p[0]['official_votes_status'] != 'verified']
metadata = json.loads((P / 'metadata_manifest.json').read_text())
assert not [r for r in metadata if 'error' in r]
for entry in metadata:
    path = P / 'raw' / entry['file']
    if path.exists():
        assert hashlib.sha256(path.read_bytes()).hexdigest() == entry['sha256']
summary = dict(candidate_appearances=len(rows), pairs=len(pairs), main_pairs=len(main), main_pairs_official_count_verified=len(verified_main), main_pairs_pending_official_count_verification=unverified, state_years=len({(r['year'], r['state']) for r in rows}), mappings_complete=True, dates_complete=True, metadata_files=len(metadata), assertions='passed')
(P / 'cohort_audit.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
