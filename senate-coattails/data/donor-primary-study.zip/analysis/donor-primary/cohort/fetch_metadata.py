from pathlib import Path
import urllib.request,concurrent.futures,hashlib,json,csv,zipfile
P=Path(__file__).resolve().parent;R=P/'raw';R.mkdir(exist_ok=True)
cohort=list(csv.DictReader((P/'source_nonrunoff_fundraising_cohort.csv').open()))
years=sorted({int(x['year']) for x in cohort if float(x['margin_corrected_pp'])<10})
def get(job):
 y,k=job;n=f'{k}{str(y)[-2:]}.zip';p=R/n;u=f'https://www.fec.gov/files/bulk-downloads/{y}/{n}'
 try:
  if not p.exists():
   req=urllib.request.Request(u,headers={'User-Agent':'Mozilla/5.0'})
   with urllib.request.urlopen(req,timeout=120) as resp:p.write_bytes(resp.read())
  with zipfile.ZipFile(p) as z:members=z.namelist()
  out=dict(year=y,kind=k,file=n,url=u,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size,members=members)
  print(y,k,out['bytes'],flush=True);return out
 except Exception as e: print('ERROR',y,k,str(e),flush=True);return dict(year=y,kind=k,url=u,error=str(e))
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:res=list(pool.map(get,[(y,k)for y in years for k in ['cn','cm']+(['ccl']if y>=2000 else[])]))
(P/'metadata_manifest.json').write_text(json.dumps(res,indent=2))
