from pathlib import Path
import csv,zipfile,json,re,datetime,collections,sys
P=Path(__file__).resolve().parent;R=P/'raw'
SOURCE=P/'source_nonrunoff_fundraising_cohort.csv'
CN=['candidate_id','candidate_name','party','election_year','state','office','district','incumbent_status','status','principal_committee','street1','street2','city','state2','zip']
CM=['committee_id','committee_name','treasurer','street1','street2','city','state','zip','designation','committee_type','party','frequency','org_type','connected','candidate_id']
CCL=['candidate_id','candidate_election_year','cycle','committee_id','committee_type','designation','linkage_id']
from name_rules import parts
def readz(path,cols):
 if not path.exists():return []
 with zipfile.ZipFile(path) as z:
  return [dict(zip(cols,row)) for row in csv.reader((x.decode('latin1') for x in z.open(z.namelist()[0])),delimiter='|')]
cohort=[x for x in csv.DictReader(SOURCE.open()) if float(x['margin_corrected_pp'])<10]
meta={}
for y in sorted({int(x['year']) for x in cohort}):
 s=str(y)[-2:];cn=readz(R/f'cn{s}.zip',CN);cm=readz(R/f'cm{s}.zip',CM);ccl=readz(R/f'ccl{s}.zip',CCL)
 meta[y]=(cn,cm,ccl)
allrows=[];reviews=[]
for c in cohort:
 y=int(c['year']);state=c['state'];party={'dem':'DEM','rep':'REP'}[c['party']];cn,cm,ccl=meta[y]
 pool=[a for a in cn if a.get('office')=='S' and a.get('state')==state and a.get('party') in ([party,'DFL']if party=='DEM' else[party])]
 for slot in [0,1]:
  name=c[f'name{slot}']; key=parts(name,state)
  key={('IL',1980,'NEAL','DAVID'):('ONEAL','DAVID'),('NM',2008,'PEARCE','STEVAN'):('PEARCE','STEVEN'),('VA',2018,'FREITAS','NICOLAS'):('FREITAS','NICHOLAS')}.get((state,y,*key),key)
  cand=[a for a in pool if parts(a['candidate_name'],state)==key]
  # Require current election-year record where several same-person registrations exist.
  current=[a for a in cand if a.get('election_year')==str(y)]
  if current:cand=current
  ids=sorted(set(a['candidate_id'] for a in cand));committees=set()
  for a in cand:
   if a.get('principal_committee','').startswith('C'):committees.add(a['principal_committee'])
  links=ccl if ccl else cm
  for a in links:
   if (not ccl or a.get('candidate_election_year')==str(y)) and a.get('candidate_id') in ids and a.get('designation') in ['P','A'] and a.get('committee_type')=='S':committees.add(a['committee_id'])
  status='matched'if len(ids)==1 and committees else 'multiple_registrations_review'if ids and committees else 'unmatched_or_unlinked'
  out=dict(pair_id=c['myers_row'],year=y,state=state,party=c['party'],name=name,slot=slot,primary_date='',cutoff_date='',window_start=f'{y-1}-01-01',primarymargin_pp=c['margin_corrected_pp'],winner=int(float(c['winner_slot']))==slot,fec_id=ids[0]if len(ids)==1 else'',fec_ids=';'.join(ids),committee_ids=';'.join(sorted(committees)),status=status,source=f'https://www.fec.gov/files/bulk-downloads/{y}/cn{str(y)[-2:]}.zip',fec_names=';'.join(a['candidate_name'] for a in cand),fec_election_years=';'.join(a['election_year'] for a in cand),official_votes_status=c['official_status'])
  allrows.append(out)
  if status!='matched':reviews.append({**out,'surname_candidates':'; '.join(a['candidate_id']+' '+a['candidate_name']+' ['+a.get('election_year','')+']' for a in pool if parts(a['candidate_name'],state)[0]==key[0])})
# Exact dates are separately audited from official calendars.
date_path=P/'primary_dates.csv'
dates={(r['year'],r['state']):r for r in csv.DictReader(date_path.open())}if date_path.exists()else{}
for r in allrows:
 d=dates.get((str(r['year']),r['state']),{})
 r['primary_date']=d.get('primary_date','')
 r['cutoff_date']=(datetime.date.fromisoformat(r['primary_date'])-datetime.timedelta(days=30)).isoformat() if r['primary_date']else''
 r['date_source']=d.get('source','')
 r['date_notes']=d.get('notes','')
 if not r['primary_date']:r['status']+=';primary_date_pending'
# Optional independently audited official count upgrades. No case selection changes.
override_path=P/'overrides.csv'
overrides={x['pair_id']:x for x in csv.DictReader(override_path.open())} if override_path.exists() else {}
for r in allrows:
 o=overrides.get(r['pair_id'])
 r['official_vote_audit_source']=o.get('source','') if o else ''
 if o:
  r['official_votes_status']=o['verification']
  r['primarymargin_pp']=o['margin_pp']
  r['winner']=int(o['winner_slot'])==r['slot']
with (P/'candidate_roster_draft.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(allrows[0]));w.writeheader();w.writerows(allrows)
with (P/'candidate_roster.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(allrows[0]));w.writeheader();w.writerows(allrows)
with (P/'mapping_review.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(reviews[0])if reviews else[]);w.writeheader();w.writerows(reviews)
print('STATUS',dict(collections.Counter(x['status'] for x in allrows)))
for r in reviews:print(r['year'],r['state'],r['name'],r['status'],r['surname_candidates'])

# Public committee-level linkage audit (no contributor identities).
link_rows=[]
for r in allrows:
 cn,cm,ccl=meta[r['year']]
 for cid in r['committee_ids'].split(';'):
  committee=next((x for x in cm if x['committee_id']==cid),{})
  linked=[x for x in (ccl or cm) if x['committee_id']==cid and x['candidate_id']==r['fec_id'] and (not ccl or x.get('candidate_election_year')==str(r['year']))]
  link_rows.append(dict(pair_id=r['pair_id'],year=r['year'],slot=r['slot'],name=r['name'],fec_id=r['fec_id'],committee_id=cid,committee_name=committee.get('committee_name',''),designation=committee.get('designation',''),committee_type=committee.get('committee_type',''),link_basis='candidate principal plus official authorized link' if linked else 'candidate principal',source=f"https://www.fec.gov/files/bulk-downloads/{r['year']}/"+('ccl' if ccl else 'cm')+str(r['year'])[-2:]+'.zip'))
with (P/'committee_links.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(link_rows[0]));w.writeheader();w.writerows(link_rows)
