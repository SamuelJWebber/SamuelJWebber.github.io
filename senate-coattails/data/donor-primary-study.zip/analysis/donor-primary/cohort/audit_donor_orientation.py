"""Independently audit identities and donor-based signed primary margins; no outcomes."""
from pathlib import Path
import csv, json, collections, hashlib, argparse

P = Path(__file__).resolve().parent
ap = argparse.ArgumentParser(description=__doc__)
ap.add_argument('--donors', type=Path, default=P.parent/'donors/candidate_donor_counts.csv')
ap.add_argument('--ledger', type=Path, default=P.parent/'analysis/results/treatment_ledger.csv')
args = ap.parse_args()
roster = list(csv.DictReader((P/'candidate_roster.csv').open()))
donors = list(csv.DictReader(args.donors.open()))
ridx = {(r['pair_id'],r['slot']):r for r in roster}
didx = {(r['pair_id'],r['slot']):r for r in donors}
assert len(donors) == len(didx) == len(ridx) == 130
assert didx.keys() == ridx.keys()
fields = ['fec_id','committee_ids','primary_date','cutoff_date','window_start','winner','year','state','party']
for key, r in ridx.items():
    d = didx[key]
    assert d['count_observed'].lower() == 'true', key
    for field in fields:
        assert r[field] == d[field], (key,field,r[field],d[field])
    assert abs(float(r['primarymargin_pp'])-float(d['primarymargin_pp'])) < 0.00001

measures = ['national_donors','in_state_donors','national_gt200_donors','national_gt500_donors']
expected = []
for pair_id in sorted({r['pair_id'] for r in roster}, key=int):
    r0,r1 = ridx[(pair_id,'0')],ridx[(pair_id,'1')]
    winner = 0 if r0['winner'] == 'True' else 1
    for measure in measures:
        a,b = int(didx[(pair_id,'0')][measure]),int(didx[(pair_id,'1')][measure])
        high = 0 if a>b else 1 if b>a else None
        treatment = int(high==winner) if high is not None else None
        signed = float(r0['primarymargin_pp']) * (1 if treatment else -1) if high is not None else None
        expected.append(dict(pair_id=pair_id,measure=measure,count0=a,count1=b,winner_slot=winner,higher_donor_slot=high,treatment=treatment,signed_margin_pp=signed,tie=(high is None),state=r0['state'],year=r0['year']))
ledger_matches = None
if args.ledger.exists():
    actual = {(r['pair_id'],r['measure']):r for r in csv.DictReader(args.ledger.open())}
    assert len(actual)==len(expected)
    for e in expected:
        a=actual[(e['pair_id'],e['measure'])]
        assert int(float(a['winner_slot']))==e['winner_slot']
        if e['tie']:
            assert a['exclusion_reason']=='equal_donor_counts'
        else:
            assert int(float(a['higher_donor_slot']))==e['higher_donor_slot']
            assert int(float(a['treatment']))==e['treatment']
            assert abs(float(a['margin_pp'])-e['signed_margin_pp']) < 1e-10
    ledger_matches=True
with (P/'independent_donor_orientation.csv').open('w') as f:
    w=csv.DictWriter(f,fieldnames=list(expected[0]));w.writeheader();w.writerows(expected)
main=[r for r in expected if r['measure']=='national_donors' and r['signed_margin_pp'] is not None and abs(r['signed_margin_pp'])<5]
summary=dict(candidate_mapping_rows_checked=130,all_expected_fields_match=True,orientation_rows_checked=len(expected),ledger_matches=ledger_matches,main_pairs=len(main),main_higher_donor_candidate_won=sum(r['treatment'] for r in main),main_higher_donor_candidate_lost=sum(1-r['treatment'] for r in main),donor_sha256=hashlib.sha256(args.donors.read_bytes()).hexdigest(),definition='Positive signed margin exactly when the higher-count contender wins the party primary. All counts and dates independently joined by pair_id+slot.',assertions='passed')
(P/'donor_mapping_orientation_audit.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
