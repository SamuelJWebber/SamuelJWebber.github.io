# Executed pre-primary donor comparison: fixed analysis specification

Written November 5, 2026 before loading the new donor rankings or current general-election outcomes. The wider research program is retrospective; this is not external preregistration.

## Treatment

Use the existing 65 conventional, non-runoff Senate primary comparisons with an absolute top-two primary vote margin below ten percentage points. The source cohort was selected in earlier work for availability of pre-primary money shares; that is a selection limitation, not a complete census of primaries. Keep documented mapping and institutional exclusions and publish every exclusion. The money measure does not define treatment in this analysis.

For both finalists, count distinct identifiable individual donors with receipt dates from January 1 of the preceding calendar year through 30 days before the nomination-determining primary. National normalized-name plus ZIP donor breadth is the main measure. In-state breadth and national breadth among individual receipts strictly greater than $200 are separate sensitivity measures. They must not replace the main measure because their outcome estimates look better. Repeated transactions are not different donors. Disclosed identities are not a census of all contributors.

Pre-fit measurement amendment, November 5, 2026: add national distinct donors with an individual receipt strictly greater than $500 as a fourth, separately labeled measurement sensitivity. This follows checking the source documentation, before loading donor rankings or fitting outcome effects. The FEC bulk inclusion rules differ by era: 1975–1988 reporting-period contributions of $500 or more; 1989–2014 reporting-period contributions of $200 or more; and 2015 onward cycle-to-date contributions exceeding $200. Within a candidate pair the same regime applies, but pooled donor breadth does not have a constant coverage definition over time. The >$500 receipt sensitivity reduces this threshold difference without guaranteeing completeness or resolving amended filings.

Counts built from today's bulk snapshot are retrospective receipt-date counts, not necessarily the set of records publicly available before the primary. If filing-as-of timing is not verified, mark that limitation on every result. Later amendments and cumulative disclosure can affect measurement. A $200-single-receipt sensitivity reduces one source of retrospective itemization but does not remove every reporting risk.

Within each measure, designate H as the finalist with more donors and L as the other finalist. Exclude equal counts and unknown/unmapped counts. Zero is eligible only if the source mapping and coverage establish an observed zero. H is a broader disclosed-support candidate, not automatically a nationally exceptional all-star or intrinsically charismatic politician. Do not condition on either candidate's later performance.

Treatment D is whether H became the party nominee. Signed running variable m is the top-two primary vote margin in H's favor, in percentage points. A 51–49 top-two result has m=+2. Use corrected official vote margins where available, with unresolved source records flagged explicitly.

## Outcomes and units

One row is one state-party-seat nomination decision. The primary outcome is that party's unweighted mean two-party vote share across contemporaneous regular U.S. House districts with both major parties receiving positive, observed votes. The aggregation gives a state nomination one observation irrespective of its number of districts. It is a contested-district endpoint; participation in contested races may itself respond to nominations, so district coverage and contest changes are reported.

Secondary outcomes are the party nominee's own Senate share, concurrent governor share, party House votes per 100 prior-census residents, and total reported House votes per 100 such residents. Volume outcomes require complete expected district coverage and valid constituent totals under the outcome builder's predeclared rule. Resident population includes ineligible residents and must not be called a turnout rate. Missing party votes are not silently zero.

The fixed precision controls are the party's House share two years earlier under the same aggregation rule, its latest presidential share strictly before the nomination cycle, and a Democratic-party indicator. All current outcome shares are converted to percentage points; vote-volume endpoints retain votes per 100 residents. No current spending, turnout, presidential vote or own Senate result enters the teammate model. Mobilization and persuasion are both permitted pathways.

## Estimates

Main window: |m|<5. Fit weighted least squares with intercept, D, m, D*m and triangular weights 1−|m|/5. Show both unadjusted and precision-adjusted estimates; the adjusted result is the main precision specification. The adjusted complete-case set is separate and its size is disclosed. To distinguish adjustment from sample composition, also run the unadjusted model on that adjusted complete-case sample.

Prespecified sensitivities: |m|<2 with an unweighted difference in means, and |m|<10 with the same separately sloped local-linear triangular specification. The narrow-window comparison assumes local randomization across the full two-point window. Do not choose a bandwidth after seeing the outcomes.

Use state-cluster sandwich uncertainty with G/(G−1)*(n−1)/(n−k) correction and a t critical value on G−1 degrees of freedom. Report n, treated/control counts, state and state-year counts, model rank, residual degrees of freedom and weighted effective sample sizes. When a nuisance control has zero variance, omit only that constant column and report it; if rank remains deficient, either side is absent, n≤k or fewer than three state clusters exist, report the model as unidentified and do not invent an interval. Flag fewer than ten state clusters as especially fragile. These are specification-conditional intervals, not automatically bias-corrected RD confidence intervals.

Do not divide the teammate effect by the nominee's own effect to claim a causal vote-transfer multiplier. Both outcomes respond to the nomination package, and its direct campaign pathways are part of the question.

## Diagnostics and interpretation

Run the same fixed-window specifications on strictly prior presidential support, lagged House support and party composition. If candidate-level data permit, describe both finalists' prior characteristics rather than using winner-only characteristics as pretreatment controls. Report balance and density limitations; passing individual significance tests does not establish random assignment.

A failed diagnostic does not stop computation or trigger a favorable respecification. Publish the fitted outcome differences alongside the failed diagnostic, labeled as estimates from a proposed discontinuity comparison whose causal interpretation is not established. A large interval is an imprecise result, not evidence of no coattails. A positive estimate alone does not validate the all-star label. Report the nominee's own result separately as the relevance check and retain all signs and null results.

## Inputs and audit trail

The nomination roster, candidate-to-FEC mapping, primary dates, donor cutoff dates, aggregate donor counts, institutional exclusions, outcome coverage and source hashes accompany the output. No individual donor identities or individual survey records belong in public deliverables. Numerical checks may use synthetic inputs but synthetic results must never be published as election evidence.
