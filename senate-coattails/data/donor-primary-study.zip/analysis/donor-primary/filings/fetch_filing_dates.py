"""Audit the receipt date of retained bulk-record filings; not an original-vintage reconstruction."""
import csv, json, hashlib, time, urllib.request, urllib.parse
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
ROOT=Path(__file__).resolve().parent
IDS=ROOT.parent/'donors'/'filing_ids.csv'
FIELDS=['committee_id','file_number','receipt_date','coverage_start_date','coverage_end_date','report_type','beginning_image_number','most_recent_file_number','previous_file_number','amendment_indicator']
def fetch(batch):
    query=urllib.parse.urlencode([('api_key','DEMO_KEY'),('per_page',100)]+[('file_number',n) for n in batch])
    url='https://api.open.fec.gov/v1/filings/?'+query
    raw=urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Research replication'}),timeout=55).read()
    x=json.loads(raw)
    if x.get('pagination',{}).get('pages',0)>1: raise RuntimeError('Unexpected extra pages')
    rows=[{k:r.get(k) for k in FIELDS} for r in x.get('results',[])]
    return rows,{'requested_ids':batch,'rows':len(rows),'retrieved_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'response_sha256':hashlib.sha256(raw).hexdigest()}
def main():
    ids=sorted({r['file_number'] for r in csv.DictReader(IDS.open()) if r['file_number']})
    prior=json.loads((ROOT/'filing_dates.json').read_text()) if (ROOT/'filing_dates.json').exists() else []
    have={str(r['file_number']) for r in prior}
    todo=[n for n in ids if n not in have]
    logs=[];errors=[]
    with ThreadPoolExecutor(max_workers=2) as pool:
        fs=[pool.submit(fetch,todo[i:i+40]) for i in range(0,len(todo),40)]
        for f in as_completed(fs):
            try:
                rows,log=f.result();prior.extend(rows);logs.append(log);print('Received',len(rows),'filing dates',flush=True)
            except Exception as e: errors.append(str(e));print(type(e).__name__,str(e),flush=True)
    byid={str(r['file_number']):r for r in prior}
    (ROOT/'filing_dates.json').write_text(json.dumps(list(byid.values()),indent=2))
    (ROOT/'retrieval_log.json').write_text(json.dumps({'requests':logs,'errors':errors,'unique_requested':len(ids),'unique_received':len(byid),'unresolved':[n for n in ids if n not in byid]},indent=2))
    with (ROOT/'filing_dates.csv').open('w') as f:
        w=csv.DictWriter(f,fieldnames=FIELDS);w.writeheader();w.writerows(byid.values())
    print('Total',len(byid),'of',len(ids),'requested filing IDs',flush=True)
if __name__=='__main__':main()
