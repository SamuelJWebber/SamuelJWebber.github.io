"""Build blinded general-election outcomes for the frozen close-Senate-primary cohort.

No fundraising, donor-ranking, treatment or donor outcome is read. All shares are
fractions. Run with pandas/numpy installed; --repo points at published source repo.
"""
import argparse, hashlib, json, shutil
from pathlib import Path
import numpy as np
import pandas as pd

STATES='Alabama|Alaska|Arizona|Arkansas|California|Colorado|Connecticut|Delaware|Florida|Georgia|Hawaii|Idaho|Illinois|Indiana|Iowa|Kansas|Kentucky|Louisiana|Maine|Maryland|Massachusetts|Michigan|Minnesota|Mississippi|Missouri|Montana|Nebraska|Nevada|New Hampshire|New Jersey|New Mexico|New York|North Carolina|North Dakota|Ohio|Oklahoma|Oregon|Pennsylvania|Rhode Island|South Carolina|South Dakota|Tennessee|Texas|Utah|Vermont|Virginia|Washington|West Virginia|Wisconsin|Wyoming'.split('|')
ABBR='AL AK AZ AR CA CO CT DE FL GA HI ID IL IN IA KS KY LA ME MD MA MI MN MS MO MT NE NV NH NJ NM NY NC ND OH OK OR PA RI SC SD TN TX UT VT VA WA WV WI WY'.split()

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def orient(x,p): return x if p=='dem' else 1-x

def run(repo,out):
    raw=out/'raw'; raw.mkdir(parents=True,exist_ok=True)
    # Read only identity/design columns, explicitly excluding fundraising and source treatment.
    cols=['myers_row','state','year','party','primary_id0','winner_slot','name0','name1','margin_corrected_pp']
    cohort_path=out/'outcome_cohort_ids.csv'
    if not cohort_path.exists():cohort_path=repo/'analysis/identification/primary/nonrunoff_fundraising_cohort.csv'
    c=pd.read_csv(cohort_path,usecols=cols)
    c=c[c.margin_corrected_pp.lt(10)].copy().sort_values('myers_row')
    assert len(c)==65 and c.myers_row.is_unique
    c['pair_id']=c.myers_row
    c.to_csv(out/'outcome_cohort_ids.csv',index=False)
    copies={
      'governor_state_returns.csv':'analysis/stage3/inputs/governor_state_returns.csv',
      'apportionment.csv':'analysis/stage3/population/apportionment.csv',
      'presidential_state_baselines.csv':'analysis/identification/balance/presidential_state_baselines.csv',
      'presidential_raw.csv':'analysis/identification/balance/presidential_raw.csv'}
    for dst,src in copies.items():
        if not (raw/dst).exists():shutil.copyfile(repo/src,raw/dst)
    pinned={
      'H_dist_election_data.tab':'b229f5c7e42045ff868b75f0502c10365216e3a4f5531faa2e803c38c744da5c',
      'presidential_raw.csv':'9936410a6dd4ecc8be7fe202c6dff5b5f8fee59d88f35ab542ed12879941dcb7',
      'apportionment.csv':'d9be9c833ad936ee309a83fa6428a3ae2f82d5d8e5b2c69c4d6ff1e79ba57fcd',
      'governor_state_returns.csv':'a0d199bd069d695842ae56a9d5d3bed5ad6c8bcd1cbac0fbbb988563e2c748e0'}
    for name,expected in pinned.items():
        assert sha(raw/name)==expected, f'Source version mismatch: {name}'
    census=pd.read_csv(raw/'apportionment.csv')
    census=census[census['Geography Type'].eq('State') & census.Name.isin(STATES)].copy()
    census['state']=census.Name.map(dict(zip(STATES,ABBR)))
    census['population']=pd.to_numeric(census['Resident Population'].str.replace(',',''))
    for yr in range(1970,2030,10):
        z=census[census.Year.eq(yr)]
        assert len(z)==50 and z['Number of Representatives'].sum()==435
    cp=census.set_index(['state','Year'])
    h=pd.read_csv(raw/'H_dist_election_data.tab',sep='\t',low_memory=False)
    assert h.office.eq('H').all() and not h.duplicated(['state_abbrev','year','dist']).any()
    hs=[]
    for (st,yr),g in h.groupby(['state_abbrev','year']):
        yr=int(yr)
        if yr<1976:continue
        expected=int(cp.loc[(st,(yr-2)//10*10),'Number of Representatives'])
        # Unknown counts stay missing; actual zero in a party count is preserved.
        complete_rows=len(g)==expected
        valid_total=g.votes_total.notna() & g.votes_total.gt(0)
        valid_dr=g.votes_d.notna() & g.votes_r.notna() & g.votes_d.ge(0) & g.votes_r.ge(0)
        coherent=valid_total & valid_dr & (g.votes_d+g.votes_r).le(g.votes_total)
        contest=coherent & g.votes_d.gt(0) & g.votes_r.gt(0)
        ng=g[contest]; n=len(ng)
        share=(ng.votes_d/(ng.votes_d+ng.votes_r)).mean() if n else np.nan
        hs.append(dict(state=st,year=yr,house_dem_share=share,
          house_contested_districts=n,house_observed_districts=len(g),house_expected_districts=expected,
          house_contested_coverage=n/expected,house_all_districts_observed=bool(complete_rows),
          house_party_counts_complete=bool(complete_rows and coherent.all()),
          house_total_counts_complete=bool(complete_rows and valid_total.all()),
          house_dem_votes=g.votes_d.sum() if complete_rows and coherent.all() else np.nan,
          house_rep_votes=g.votes_r.sum() if complete_rows and coherent.all() else np.nan,
          house_total_votes=g.votes_total.sum() if complete_rows and valid_total.all() else np.nan,
          house_share_weighted=(ng.votes_d.sum()/(ng.votes_d.sum()+ng.votes_r.sum())) if n else np.nan,
          house_mean_major_party_vote_fraction=((ng.votes_d+ng.votes_r)/ng.votes_total).mean() if n else np.nan,
          house_min_major_party_vote_fraction=((ng.votes_d+ng.votes_r)/ng.votes_total).min() if n else np.nan,
          house_contested_districts_major_fraction_lt80=int((((ng.votes_d+ng.votes_r)/ng.votes_total)<0.8).sum()),
          house_missing_party_districts=int((~valid_dr).sum()),
          house_inconsistent_districts=int((valid_dr & valid_total & ~coherent).sum()),
          house_nonpositive_or_missing_total_districts=int((~valid_total).sum()),
          house_redistricting_flag=int(g.redist.fillna(0).gt(0).any())))
    hs=pd.DataFrame(hs)
    hs.to_csv(out/'house_state_year.csv',index=False)
    hm=hs.set_index(['state','year'])
    gov=pd.read_csv(raw/'governor_state_returns.csv').rename(columns={'state_abbrev':'state'})
    additions=pd.read_csv(out/'governor2022.csv')
    gov=pd.concat([gov,additions],ignore_index=True)
    assert not gov.duplicated(['state','year']).any()
    gov['valid']=gov.election_type.eq('G') & gov.missing_counties.eq(0) & gov.dem_votes.gt(0) & gov.rep_votes.gt(0) & (gov.dem_votes+gov.rep_votes).le(gov.total_votes)
    gov['dem_share']=np.where(gov.valid,gov.dem_votes/(gov.dem_votes+gov.rep_votes),np.nan)
    gov.to_csv(out/'governor_state_year.csv',index=False)
    pr_raw=pd.read_csv(raw/'presidential_raw.csv')
    pr_raw['candidate_key']=pr_raw.candidate.fillna('').str.strip().str.upper()
    major=pr_raw[pr_raw.party_simplified.isin(['DEMOCRAT','REPUBLICAN'])]
    major=major.loc[major.groupby(['state_po','year','party_simplified']).candidatevotes.idxmax()]
    keys=major[['state_po','year','candidate_key','party_simplified']].rename(columns={'party_simplified':'nominee_party'})
    joined=pr_raw.merge(keys,on=['state_po','year','candidate_key'],validate='many_to_one')
    pr_votes=joined.groupby(['state_po','year','nominee_party']).candidatevotes.sum()
    pres=pr_votes.unstack('nominee_party').reset_index()
    pres['dem_share']=pres.DEMOCRAT/(pres.DEMOCRAT+pres.REPUBLICAN)
    cached=pd.read_csv(raw/'presidential_state_baselines.csv')
    check=pres.merge(cached,on=['state_po','year'],suffixes=('_new','_cached'),validate='one_to_one')
    finite=check.dem_share_cached.notna()
    assert len(check)==len(cached) and np.allclose(check.loc[finite,'dem_share_new'],check.loc[finite,'dem_share_cached'],rtol=0,atol=1e-14)
    pres.to_csv(out/'presidential_state_year.csv',index=False)
    assert not pres.duplicated(['state_po','year']).any()
    rows=[]
    for r in c.itertuples(index=False):
        st,yr,party=r.state,int(r.year),r.party
        z={'pair_id':int(r.myers_row),'myers_row':int(r.myers_row),'year':yr,'state':st,'party':party,
           'primary_id':r.primary_id0,'margin_corrected_pp':r.margin_corrected_pp,
           'within_5pp':bool(r.margin_corrected_pp<5),'nominee':getattr(r,'name'+str(int(r.winner_slot)))}
        cy=(yr-1)//10*10; pop=int(cp.loc[(st,cy),'population'])
        z.update(prior_census_year=cy,prior_census_population=pop)
        for lag,y in [('',yr),('lag_',yr-2)]:
            a=hm.loc[(st,y)] if (st,y) in hm.index else None
            z[lag+'house_year']=y
            z[lag+'house_share']=orient(a.house_dem_share,party) if a is not None else np.nan
            for k in ['house_contested_districts','house_observed_districts','house_expected_districts','house_contested_coverage','house_all_districts_observed','house_party_counts_complete','house_total_counts_complete','house_missing_party_districts','house_inconsistent_districts','house_nonpositive_or_missing_total_districts','house_redistricting_flag','house_mean_major_party_vote_fraction','house_min_major_party_vote_fraction','house_contested_districts_major_fraction_lt80']:
                z[lag+k]=a[k] if a is not None else np.nan
            z[lag+'house_share_missing_reason']='' if a is not None and pd.notna(a.house_dem_share) else ('no valid positive-both-party House district' if a is not None else 'state-year absent from source')
            # Both current and lag volume are normalized by the current cycle's strictly prior census.
            z[lag+'party_house_votes_per100']=(a['house_'+party+'_votes']/pop*100) if a is not None else np.nan
            z[lag+'total_house_votes_per100']=(a.house_total_votes/pop*100) if a is not None else np.nan
            z[lag+'house_share_weighted']=orient(a.house_share_weighted,party) if a is not None else np.nan
        z['house_share_change']=z['house_share']-z['lag_house_share']
        z['house_district_composition_may_change']=True
        pp=pres[pres.state_po.eq(st) & pres.year.lt(yr)].sort_values('year')
        assert len(pp)
        pr=pp.iloc[-1]
        z.update(prior_pres_year=int(pr.year),prior_pres_share=orient(pr.dem_share,party))
        for lag,gg in [('',gov[gov.state.eq(st)&gov.year.eq(yr)]),('lag_',gov[gov.state.eq(st)&gov.year.lt(yr)].sort_values('year').tail(1))]:
            z[lag+'governor_share']=orient(gg.iloc[0].dem_share,party) if len(gg) else np.nan
            z[lag+'governor_year']=int(gg.iloc[0].year) if len(gg) else np.nan
            z[lag+'governor_missing_reason']='' if len(gg) and bool(gg.iloc[0].valid) else (('no earlier governor election in source' if lag else 'no concurrent governor election in source') if not len(gg) else 'incomplete county or major-party counts')
        rows.append(z)
    panel=pd.DataFrame(rows)
    sp=out/'senate_outcomes.csv'
    if not sp.exists():raise FileNotFoundError('Run build_senate_outcomes.py first')
    if sp.exists():
        s=pd.read_csv(sp)
        sk=[x for x in s if x not in panel or x=='myers_row']
        panel=panel.merge(s[sk],on='myers_row',how='left',validate='one_to_one')
        if 'senate_party_share_pp' in panel:
            panel['senate_share']=panel.senate_party_share_pp/100
            panel['lag_senate_share']=panel.lag_senate_party_share_pp/100
    assert panel.pair_id.is_unique and len(panel)==65
    assert (panel.prior_pres_year<panel.year).all() and (panel.prior_census_year<panel.year).all()
    assert (panel.lag_house_year<panel.year).all()
    assert (panel.lag_governor_year.dropna()<panel.loc[panel.lag_governor_year.notna(),'year']).all()
    for k in ['house_share','lag_house_share','prior_pres_share','governor_share','lag_governor_share']:
        assert panel[k].dropna().between(0,1).all(),k
    panel.to_csv(out/'outcomes.csv',index=False)
    coverage={}
    outcomes=['house_share','lag_house_share','prior_pres_share','governor_share','lag_governor_share','party_house_votes_per100','total_house_votes_per100']
    if 'senate_share' in panel:outcomes+=['senate_share']
    for label,sub in [('within_10pp',panel),('within_5pp',panel[panel.within_5pp])]:
        coverage[label]={'n_pairs':len(sub),'n_states':sub.state.nunique(),'available':{k:int(sub[k].notna().sum()) for k in outcomes},'house_plus_lag_pres':int(sub[['house_share','lag_house_share','prior_pres_share']].notna().all(axis=1).sum()),'all_house_districts_observed':int(sub.house_all_districts_observed.eq(True).sum()),'mean_contested_district_coverage':float(sub.house_contested_coverage.mean())}
    coverage['units']={'shares':'fractions, 0–1, oriented to the Senate primary party','volumes':'votes per 100 strictly prior decennial-census residents; not eligible-voter turnout','lag_volume_denominator':'same population as current cycle'}
    coverage['selection']='Frozen <10-point conventional nonrunoff cohort; <5-point main subset. No donor fields or treatment read.'
    (out/'coverage.json').write_text(json.dumps(coverage,indent=2)+'\n')
    panel[panel[outcomes].isna().any(axis=1)].to_csv(out/'missingness_ledger.csv',index=False)
    manifest={'retrieved':'2026-11-05','files':{p.name:{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(raw.iterdir()) if p.is_file()},'derived_files':{p.name:sha(p) for p in [out/'outcomes.csv',out/'house_state_year.csv',out/'governor_state_year.csv',out/'governor2022.csv']}}
    manifest['code']={'build_outcomes.py':sha(Path(__file__))}
    (out/'file_hashes.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print(json.dumps(coverage,indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--repo',type=Path,default=Path.cwd(),help='Repository root, used only to seed missing cached historical inputs')
    p.add_argument('--out',type=Path,default=Path(__file__).resolve().parent)
    a=p.parse_args();run(a.repo,a.out)
