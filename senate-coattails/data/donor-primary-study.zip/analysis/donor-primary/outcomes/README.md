# Frozen outcome assembly for close Senate nominations

This assembly was written without reading donor rankings or the donor treatment. It retains the 65 conventional nonrunoff primaries with corrected top-two margin below 10 percentage points in the existing identity cohort, including the 33 below 5 points. A row is a state–party–Senate nomination, keyed by `myers_row` and identical integer `pair_id`.

## Outcome and control definitions

All `*_share` fields are fractions, oriented toward the Senate nomination's party. `house_share` is the unweighted mean of district D/(D+R) shares, flipped for Republican nominations, across observed regular House districts with strictly positive, finite D and R votes and coherent totals. It measures performance among major-party-contested districts; it does not cover uncontested seats as zeroes. All 65 current state-years have the expected number of district records, but only 94.4% of districts per state on average qualify for the contested-share outcome (92.1% in the main 33). `house_contested_coverage`, missing-count flags, and major-party vote fraction diagnostics expose this limitation. The list of eligible districts may change across elections and can itself be affected by candidate entry. Redistricting is flagged, and no district boundary match is claimed.

`lag_house_share` applies exactly the same aggregation to t−2. This is a strictly prior state result, not a comparison restricted to matched district boundaries. VT2000 has no lagged share because Vermont1998 elected independent Bernie Sanders and the source has no Democratic candidate. VT2000's contemporary D/R share excludes Sanders's large independent vote, so its D/R-only outcome represents a small portion of all votes. Third-party vote-fraction diagnostics are retained for sensitivity checks; the main definition was not changed in response to any donor treatment.

`prior_pres_share` uses the most recent presidential election strictly before the nomination cycle. Raw MIT candidate identities identify the major nominees and their same-name fusion-party lines are added; the rebuilt values match every finite prior stored baseline within floating-point tolerance; the raw reconstruction also covers affiliate-party labels omitted from the older baseline cache. Current presidential outcomes are not controls.

`party_house_votes_per100` and `total_house_votes_per100` use the resident population from the latest strictly prior decennial census. They are vote-volume measures, not eligible-voter turnout rates. The party count requires every expected district's two major-party counts to be observed, nonnegative and coherent with its total; unknown unopposed-party counts remain missing, never zero. The total count requires all expected districts and positive observed totals. Both current and lag volume use the current cycle's prior-census denominator, so they are directly comparable. The census count is predetermined but the retrieved historical compilation is not an archived data vintage. Seat expectations use the census allocation in force at the election, beginning at census year+2.

`senate_share` is the actual nominee's two-party general share in the matched seat. The child audit matched all 65 nominees; same-name fusion votes are included. Raw MIT issues for IL2010 special-election metadata and IL2022 detailed Democratic party label are explicitly resolved in `senate_provenance.json`. `lag_senate_share` is the last strictly prior same-seat outcome when available. The six 1980 pairs lack a pre1976 prior same-seat result in this source.

`governor_share` uses concurrent regular governor returns and is missing when there is no concurrent race or the source has incomplete counts. `lag_governor_share` is the most recent earlier regular governor result, including off-year elections. Historical governor returns omit Alaska; the AK1992 pair has no prior governor coverage. Six 2022 concurrent races are added from official sources, documented individually in `governor2022.csv` (NH official returns mirrored by NHPR).

## Files and reproduction

`build_outcomes.py` rebuilds `outcomes.csv`, state-year intermediates, coverage and hash manifests. It reads only the listed identity/design columns from `outcome_cohort_ids.csv`, never fundraising or donor variables. If the identity file is absent, it extracts these columns from the existing repository cohort. The Senate script is run first, then the main script. Python dependencies: pandas and numpy. Source versions are listed in `file_hashes.json`; initial downloads are public and documented in `sources.json`.

Run:

```sh
python prepare_outcome_inputs.py --repo /path/to/senate-coattails --workdir /external/path/to/outcomes
python build_senate_outcomes.py --out /external/path/to/outcomes
python build_outcomes.py --repo /path/to/senate-coattails --out /external/path/to/outcomes
```

Raw House and its row derivatives are local reconstruction artifacts under the existing repository's public-distribution boundary. Do not include `raw/H_dist_election_data.tab`, `house_state_year.csv` or the merged `outcomes.csv` in the public bundle without revisiting that boundary. Public code, source hashes and aggregate analysis outputs can be packaged consistently with the existing project. An independent official MIT House source audit is supplied separately when completed.

This assembly does not estimate a causal effect or test balance. It supplies the outcomes for the separately frozen close-primary donor design. Contemporary turnout, spending and presidential vote are not adjustment covariates.
