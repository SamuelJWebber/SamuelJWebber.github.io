# Independent House source audit

The frozen House outcome was checked against two archived copies of MIT Election Data and Science Lab returns covering all 122 distinct current and lagged state-years. The two MIT versions agree on the relevant state House shares to machine precision. They are public mirrors of earlier MEDSL releases, not claimed to be byte-identical to the current official V15 file. The current Dataverse download required a guestbook; no personal details were submitted.

The principal-nominee comparison selects the highest-vote candidate on each major-party line and includes that candidate's fusion-party votes. A separately reported variant sums all distinct candidates bearing the party label. Before an explicit label correction, seven state-years differ from the frozen source by more than0.01 percentage points under the principal-nominee convention; eight do under the all-candidates convention. Median discrepancy is zero.

The only material main-sample discrepancy before label correction is Indiana1998: MIT labels Republican Daniel Holtz as `RE`, and a strict label parser therefore drops a contested district. His61,041 votes are present. This is a label-handling problem in the audit, not evidence of missing votes in the frozen source. The separately labelled correction restores this candidate's Republican classification. After that explicit correction, the maximum main-sample discrepancy is0.044943 percentage points for current outcomes and0.013083 points for lagged outcomes. The remaining small differences concern Colorado2010, Missouri1994, and the Colorado1978 lag; they do not change the included district set.

Two larger differences affect only the wider10-point sample. Illinois2022 has83 votes for Chad Koppie with an absent party label in MIT, changing which districts qualify for a two-party comparison. Illinois1978 district21 has a frozen-source total of118,527 below the124,527 sum of its Democratic and Republican votes; MIT's124,527 total is coherent. The frozen rule quarantines the incoherent district. This changes the lag for Illinois1980, whose primary margin is9.333 points, and does not affect the main5-point estimate. The original rule and primary outcome were retained.

Maryland2012 illustrates a convention difference: counting a second Democratic write-in alongside the principal Democratic nominee changes the state share by about0.40 points. The difference disappears when both sources use the principal-nominee convention.

Vermont2000 is not a coding error: independent Bernie Sanders dominates that House election, leaving the two major-party candidates with only23.6% of all votes. Its D/R-only share therefore describes a small part of the electorate. Vermont1998 had no Democratic nominee, so the2000 nomination is already absent from the main lag-adjusted House model. No missing party count was turned into zero.

No frozen primary outcome was changed after inspecting these comparisons. The audit does not independently establish random assignment or validate the donor measure. Row-level comparisons and raw DeLuca data remain local under the existing distribution boundary; code, source provenance and these aggregate findings are public.

Optional reproduction, after rebuilding the main outcomes into an external working directory:

```sh
python fetch_mit_house_audit_inputs.py --out /external/path/to/outcomes
python build_mit_house_audit.py --out /external/path/to/outcomes
python mit_house_corrected_re.py --out /external/path/to/outcomes
```
