#!/usr/bin/env python3
"""Donor-blind audit using public mirrors of MEDSL House returns (not exact V15)."""
from pathlib import Path
import argparse
import pandas as pd,numpy as np,re,hashlib,json
arg=argparse.ArgumentParser(description=__doc__)
arg.add_argument('--out',type=Path,default=Path(__file__).resolve().parent)
ROOT=arg.parse_args().out
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
PINNED={'mit_house_huggingface.tab':'b18e4ab04f957b888f2d13f6b66b7c00553293bf952dca8c197de5c466c24377','mit_house_tidytuesday_v12.csv':'5caf4450f5edc0ae17ef566dcb2785cfde3b097df31e6d0b9c51dac3e817f1ba'}
for fn,digest in PINNED.items():
 assert sha(ROOT/'raw'/fn)==digest,('source version mismatch',fn)
c=pd.read_csv(ROOT/'raw/primary_pairs_for_senate.csv',usecols=['myers_row','state','year','party','margin_corrected_pp'])
keys=pd.concat([c[['state','year']],c[['state','year']].assign(year=c.year-2)]).drop_duplicates()
base=pd.read_csv(ROOT/'house_state_year.csv')
# Copy only expected seat counts/keys from the frozen baseline; no votes are used in MIT aggregation.
expected=base[['state','year','house_expected_districts']].merge(keys,on=['state','year'],validate='one_to_one').set_index(['state','year']).house_expected_districts.to_dict()
D={'DEMOCRAT','DEMOCRATIC','DEMOCRATIC-FARMER-LABOR','DEMOCRATIC-FARM-LABOR','DEMOCRATIC-NONPARTISAN LEAGUE','DEMOCRATIC-NPL','WRITE-IN (DEMOCRATIC)'}
R={'REPUBLICAN','INDEPENDENT-REPUBLICAN','WRITE-IN (REPUBLICAN)'}
def build(path,tag,principal=True):
 s=pd.read_csv(path,low_memory=False)
 s=s.merge(keys.rename(columns={'state':'state_po'}),on=['state_po','year'])
 false=lambda x:~x.astype(str).str.lower().eq('true')
 s=s[s.stage.str.upper().eq('GEN')&false(s.special)&false(s.runoff)].copy()
 assert s['mode'].str.upper().eq('TOTAL').all()
 s['key']=s.candidate.fillna('').str.upper().map(lambda x:re.sub('[^A-Z]','',x))
 s['major']=np.where(s.party.isin(D),'D',np.where(s.party.isin(R),'R',''))
 districts=[]
 for (st,yr,dist),g in s.groupby(['state_po','year','district']):
  z=dict(state=st,year=int(yr),district=int(dist),source=tag)
  totals=g.totalvotes.dropna().unique()
  z['total_votes']=float(totals[0]) if len(totals)==1 and totals[0]>0 else np.nan
  major_keys={p:set(g.loc[g.major.eq(p)&g.candidate.notna()&g.key.ne(''),'key']) for p in ['D','R']}
  ambiguous=bool(major_keys['D']&major_keys['R'])
  z['cross_major_candidate_identity']=ambiguous
  z['source_candidate_votes_missing']=bool(g.candidatevotes.isna().any())
  z['candidate_total_sum']=g.candidatevotes.sum(min_count=1)
  z['source_candidate_total_discrepancy']=float(z['candidate_total_sum']-z['total_votes'])
  for p in ['D','R']:
   pg=g[g.major.eq(p)]
   all_pg=pg
   if principal and len(pg):
    leader=pg.sort_values('candidatevotes',ascending=False).iloc[0]['key']
    pg=pg[pg.key.eq(leader)]
   # Include all identified same-party candidates, plus their fusion ballot lines.
   # Generic unnamed/write-in rows retain only their explicit party line.
   generic=pg.key.isin(['','WRITEIN','OTHER','SCATTERING','OTHERS'])
   goodkeys=set(pg.loc[~generic,'key'])
   matched=g[g.key.isin(goodkeys)]
   records=pd.concat([matched,pg[generic]]).drop_duplicates()
   z[p+'_candidate_count']=len(goodkeys)
   z[p+'_all_candidate_count']=all_pg.key.nunique()
   z[p+'_present']=len(pg)>0
   z[p+'_votes']=records.candidatevotes.sum(min_count=1) if len(pg)>0 and not records.candidatevotes.isna().any() and not ambiguous else np.nan
   z[p+'_partyline_votes']=pg.candidatevotes.sum(min_count=1) if len(pg)>0 and not pg.candidatevotes.isna().any() else np.nan
   z[p+'_fusion_votes']=z[p+'_votes']-z[p+'_partyline_votes']
  z['valid_dr']=bool(pd.notna(z['D_votes']) and pd.notna(z['R_votes']) and z['D_votes']>=0 and z['R_votes']>=0)
  z['coherent']=bool(z['valid_dr'] and pd.notna(z['total_votes']) and z['D_votes']+z['R_votes']<=z['total_votes'])
  z['contested']=bool(z['coherent'] and z['D_votes']>0 and z['R_votes']>0)
  z['dem_share']=z['D_votes']/(z['D_votes']+z['R_votes']) if z['contested'] else np.nan
  z['major_party_fraction']=(z['D_votes']+z['R_votes'])/z['total_votes'] if z['contested'] else np.nan
  districts.append(z)
 dd=pd.DataFrame(districts)
 out=[]
 for (st,yr),g in dd.groupby(['state','year']):
  ex=expected[(st,yr)]; ng=g[g.contested]; n=len(ng); complete=len(g)==ex
  counts=bool(complete and g.coherent.all());totalcomplete=bool(complete and g.total_votes.notna().all())
  out.append(dict(state=st,year=int(yr),source=tag,house_dem_share=ng.dem_share.mean(),house_contested_districts=n,house_observed_districts=len(g),house_expected_districts=int(ex),house_contested_coverage=n/ex,
  house_all_districts_observed=complete,house_party_counts_complete=counts,house_total_counts_complete=totalcomplete,
  house_dem_votes=g.D_votes.sum() if counts else np.nan,house_rep_votes=g.R_votes.sum() if counts else np.nan,
  house_total_votes=g.total_votes.sum() if totalcomplete else np.nan,
  house_share_weighted=ng.D_votes.sum()/(ng.D_votes.sum()+ng.R_votes.sum()) if n else np.nan,
  house_mean_major_party_vote_fraction=ng.major_party_fraction.mean(),house_min_major_party_vote_fraction=ng.major_party_fraction.min(),house_contested_districts_major_fraction_lt80=int(ng.major_party_fraction.lt(.8).sum()),
  house_missing_party_districts=int((~g.valid_dr).sum()),house_inconsistent_districts=int((g.valid_dr&~g.coherent).sum()),
  house_nonpositive_or_missing_total_districts=int(g.total_votes.isna().sum()),
  house_source_candidate_votes_missing_districts=int(g.source_candidate_votes_missing.sum()),
  house_cross_major_candidate_identity_districts=int(g.cross_major_candidate_identity.sum()),
  house_candidate_total_discrepancy_districts=int(g.source_candidate_total_discrepancy.ne(0).sum()),
  house_dem_fusion_votes=g.D_fusion_votes.sum(),house_rep_fusion_votes=g.R_fusion_votes.sum()))
 return pd.DataFrame(out),dd

hf,hfd=build(ROOT/'raw/mit_house_huggingface.tab','MEDSL mirrored file, version column 20250910; principal nominees')
all_hf,all_hfd=build(ROOT/'raw/mit_house_huggingface.tab','MEDSL mirrored file, version column 20250910; all party candidates',principal=False)
all_hf.to_csv(ROOT/'mit_house_state_year_all_candidates.csv',index=False)
all_hfd.to_csv(ROOT/'mit_house_district_all_candidates.csv',index=False)
tt,ttd=build(ROOT/'raw/mit_house_tidytuesday_v12.csv','MEDSL V12 via TidyTuesday, version column 20230706')
hf.to_csv(ROOT/'mit_house_state_year.csv',index=False)
hfd.to_csv(ROOT/'mit_house_district_audit.csv',index=False)
base=base.merge(keys,on=['state','year'],validate='one_to_one')
a=hf.merge(base,on=['state','year'],how='outer',suffixes=('_mit','_baseline'),validate='one_to_one')
a['difference_dem_share_pp']=100*(a.house_dem_share_mit-a.house_dem_share_baseline)
a['difference_contested_districts']=a.house_contested_districts_mit-a.house_contested_districts_baseline
a['difference_dem_votes']=a.house_dem_votes_mit-a.house_dem_votes_baseline
a['difference_rep_votes']=a.house_rep_votes_mit-a.house_rep_votes_baseline
a['difference_total_votes']=a.house_total_votes_mit-a.house_total_votes_baseline
a.to_csv(ROOT/'mit_house_audit.csv',index=False)
aa=all_hf.merge(base,on=['state','year'],how='outer',suffixes=('_mit','_baseline'),validate='one_to_one')
aa['difference_dem_share_pp']=100*(aa.house_dem_share_mit-aa.house_dem_share_baseline)
aa['difference_contested_districts']=aa.house_contested_districts_mit-aa.house_contested_districts_baseline
aa.to_csv(ROOT/'mit_house_audit_all_candidates.csv',index=False)
v=hf.merge(tt,on=['state','year'],suffixes=('_20250910','_V12'),validate='one_to_one')
v['difference_dem_share_pp']=100*(v.house_dem_share_20250910-v.house_dem_share_V12)
v.to_csv(ROOT/'mit_house_version_audit.csv',index=False)
meta=json.loads((ROOT/'raw/mit_house_metadata.json').read_text())['data']['latestVersion']
manifest={'analysis':'Independent donor-blind House outcome audit only. Original primary panel remains unchanged.',
 'canonical_source':{'title':'MIT Election Data and Science Lab U.S. House 1976–2024','doi':'10.7910/DVN/IG0UN2','url':'https://dataverse.harvard.edu/api/access/datafile/13592823','version':meta['versionNumber'],'license':meta.get('license'),'download_status':'HTTP 400; guestbook 458 requires name, email, institution, position. No identity fabricated or submitted.', 'expected_file_md5':meta['files'][0]['dataFile']['md5']},
 'audit_source':{'path':'raw/mit_house_huggingface.tab','url':'https://huggingface.co/spaces/My-Name1/MidtermMaps/resolve/main/1976-2024-house%20%281%29.tab','sha256':sha(ROOT/'raw/mit_house_huggingface.tab'),'version_column':20250910,'file_format':'CSV despite .tab extension','limitation':'Public mirror of an earlier MEDSL release. Not claimed to be identical to current official V15.'},
 'crosscheck_source':{'path':'raw/mit_house_tidytuesday_v12.csv','url':'https://raw.githubusercontent.com/rfordatascience/tidytuesday/main/data/2023/2023-11-07/house.csv','sha256':sha(ROOT/'raw/mit_house_tidytuesday_v12.csv'),'citation_version':'V12','version_column':20230706},
 'definition':'Principal-major-party nominee definition is closest to frozen DeLuca candidate-vote definition. Select highest-vote candidate on each major-party line and include all fusion lines for that same identity. Separate all-candidates variant sums every distinct D/R candidate. Mean across regular general-election districts with both major parties positive and D+R<=total. Exclude general runoffs/specials. Missing party lines stay missing, not zero. Statewide party volumes require all expected seats and valid observed D/R counts in every district; total volumes need all seat totals positive.',
 'baseline_source':'house_state_year.csv from frozen DeLuca-derived assembly; used only as comparator and for expected seat counts, never to alter MIT vote data.',
 'coverage':{'state_years':len(hf),'current_pairs':len(c),'available_house_share_current':int(c.merge(hf,on=['state','year']).house_dem_share.notna().sum()),'available_party_volume_current':int(c.merge(hf,on=['state','year']).house_party_counts_complete.sum()),'available_total_volume_current':int(c.merge(hf,on=['state','year']).house_total_counts_complete.sum()),'state_years_different_share_gt_point01_pp':int(a.difference_dem_share_pp.abs().gt(.01).sum()),'state_years_different_contested_count':int(a.difference_contested_districts.ne(0).sum()),'mirror_versions_different_share_gt_point01_pp':int(v.difference_dem_share_pp.abs().gt(.01).sum())},
 'aggregate_discrepancies':{'principal_max_abs_share_difference_pp':float(a.difference_dem_share_pp.abs().max()),'principal_median_abs_share_difference_pp':float(a.difference_dem_share_pp.abs().median()),'all_candidates_max_abs_share_difference_pp':float(aa.difference_dem_share_pp.abs().max()),'all_candidates_median_abs_share_difference_pp':float(aa.difference_dem_share_pp.abs().median()),'all_candidates_state_years_gt_point01_pp':int(aa.difference_dem_share_pp.abs().gt(.01).sum())},
 'party_label_problems':[{'state':'IN','year':1998,'district':3,'candidate':'Daniel A Holtz','source_label':'RE','handling':'Unresolved label; not silently mapped. Democratic-vs-Republican share omitted for this district in audit.'},{'state':'IL','year':2022,'district':7,'candidate':'Chad Koppie','votes':83,'source_label':None,'handling':'Missing party label retained; no zero or Republican label imputed.'}],
 'files':{f:sha(Path(__file__) if f=='build_mit_house_audit.py' else ROOT/f) for f in ['mit_house_state_year.csv','mit_house_district_audit.csv','mit_house_audit.csv','mit_house_version_audit.csv','mit_house_state_year_all_candidates.csv','mit_house_district_all_candidates.csv','mit_house_audit_all_candidates.csv','build_mit_house_audit.py']}}
(ROOT/'mit_house_provenance.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest['coverage'],indent=2))
print(a.loc[a.difference_dem_share_pp.abs().gt(.01)|a.difference_contested_districts.ne(0),['state','year','difference_dem_share_pp','house_dem_share_mit','house_dem_share_baseline','house_contested_districts_mit','house_contested_districts_baseline','house_missing_party_districts_mit','house_missing_party_districts_baseline']].to_string(index=False))
print('VT2000:',hfd[hfd.state.eq('VT')&hfd.year.eq(2000)].to_dict('records'))
