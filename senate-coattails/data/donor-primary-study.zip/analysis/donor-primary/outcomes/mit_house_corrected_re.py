"""Explicit post-hoc source-label sensitivity; does not alter frozen outcomes or original audit."""
from pathlib import Path
import argparse,json,hashlib
import pandas as pd,numpy as np
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--out',type=Path,default=Path(__file__).resolve().parent);ROOT=p.parse_args().out
s=pd.read_csv(ROOT/'raw/mit_house_huggingface.tab',low_memory=False)
x=s[s.state_po.eq('IN')&s.year.eq(1998)&s.district.eq(3)&s.candidate.eq('DANIEL A HOLTZ')]
assert len(x)==1 and x.iloc[0].party=='RE' and x.iloc[0].candidatevotes==61041
m=pd.read_csv(ROOT/'mit_house_district_audit.csv')
ix=m.index[m.state.eq('IN')&m.year.eq(1998)&m.district.eq(3)]
assert len(ix)==1;i=ix[0]
assert m.loc[i,'R_present']==False and pd.isna(m.loc[i,'R_votes'])
m.loc[i,['R_candidate_count','R_all_candidate_count']]=1
m.loc[i,'R_present']=True
m.loc[i,['R_votes','R_partyline_votes']]=61041
m.loc[i,'R_fusion_votes']=0
m.loc[i,['valid_dr','coherent','contested']]=True
m.loc[i,'dem_share']=m.loc[i,'D_votes']/(m.loc[i,'D_votes']+61041)
m.loc[i,'major_party_fraction']=(m.loc[i,'D_votes']+61041)/m.loc[i,'total_votes']
m['posthoc_source_label_correction']=''
m.loc[i,'posthoc_source_label_correction']='Explicitly recognize source party RE as Republican for Daniel A Holtz, IN district 3, 1998 only.'
m.to_csv(ROOT/'mit_house_district_corrected_re.csv',index=False)
h=pd.read_csv(ROOT/'mit_house_state_year.csv')
ix=h.index[h.state.eq('IN')&h.year.eq(1998)];assert len(ix)==1;i=ix[0]
g=m[m.state.eq('IN')&m.year.eq(1998)];ng=g[g.contested]
assert len(g)==h.loc[i,'house_expected_districts'] and g.coherent.all()
replacements=dict(house_dem_share=ng.dem_share.mean(),house_contested_districts=len(ng),house_contested_coverage=len(ng)/len(g),house_party_counts_complete=True,
 house_dem_votes=g.D_votes.sum(),house_rep_votes=g.R_votes.sum(),house_share_weighted=ng.D_votes.sum()/(ng.D_votes.sum()+ng.R_votes.sum()),
 house_mean_major_party_vote_fraction=ng.major_party_fraction.mean(),house_min_major_party_vote_fraction=ng.major_party_fraction.min(),house_contested_districts_major_fraction_lt80=int(ng.major_party_fraction.lt(.8).sum()),house_missing_party_districts=0)
for k,v in replacements.items():h.loc[i,k]=v
h['posthoc_source_label_correction']='';h.loc[i,'posthoc_source_label_correction']='IN1998 district3 RE recognized as Republican'
h.to_csv(ROOT/'mit_house_state_year_corrected_re.csv',index=False)
a=h.merge(pd.read_csv(ROOT/'house_state_year.csv'),on=['state','year'],suffixes=('_mit','_baseline'),validate='one_to_one')
a['difference_dem_share_pp']=100*(a.house_dem_share_mit-a.house_dem_share_baseline)
a.to_csv(ROOT/'mit_house_audit_corrected_re.csv',index=False)
c=pd.read_csv(ROOT/'raw/primary_pairs_for_senate.csv',usecols=['myers_row','state','year','party','margin_corrected_pp'])
summary={'label':'Post-hoc MIT principal-nominee source-label sensitivity, one explicit correction',
'correction':'IN1998 district3 Daniel A Holtz: RE -> Republican; unchanged source vote count 61,041. No correction to missing IL2022 party labels.',
'cohort_results':{}}
for name,cc in [('main33',c[c.margin_corrected_pp<5]),('wider65',c)]:
 z=cc.merge(a,on=['state','year']);q=cc.assign(year=cc.year-2).merge(a,on=['state','year'])
 summary['cohort_results'][name]={'n':len(cc),'current_max_absolute_dem_share_difference_pp':float(z.difference_dem_share_pp.abs().max()),'lag_max_absolute_dem_share_difference_pp':float(q.difference_dem_share_pp.abs().max()),'current_party_volume_available':int(z.house_party_counts_complete_mit.sum()),'current_party_volume_available_baseline':int(z.house_party_counts_complete_baseline.sum())}
summary['files']={f:hashlib.sha256((Path(__file__) if f=='mit_house_corrected_re.py' else ROOT/f).read_bytes()).hexdigest() for f in ['mit_house_corrected_re.py','mit_house_state_year_corrected_re.csv','mit_house_district_corrected_re.csv','mit_house_audit_corrected_re.csv']}
(ROOT/'mit_house_corrected_re_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary['cohort_results'],indent=2))
print(a[a.state.eq('IN')&a.year.eq(1998)][['state','year','difference_dem_share_pp']].to_string(index=False))
