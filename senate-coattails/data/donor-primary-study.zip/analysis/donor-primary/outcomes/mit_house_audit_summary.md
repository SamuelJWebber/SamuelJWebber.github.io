Independent House source audit (donor-blind)

The frozen primary outcome panel was not changed. Two public mirrors of MEDSL House returns were aggregated: TidyTuesday's documented V12 (version column 20230706), and a 1976–2024 mirror with version column 20250910. Their principal-nominee district/state outcomes agree exactly for all 122 required current/lag state-years. The official current V15 file (ID 13592823) could not be downloaded without a required identity guestbook; neither mirror is claimed to be byte-identical to V15. Original source metadata, mirror URLs, and SHA-256 hashes are preserved.

Principal major-party nominee plus same-identity fusion ballot lines is the closest match to the frozen DeLuca candidate-vote definition. Across 122 state-years, 105 are identical within 1e-10 percentage points, and 115 differ by no more than 0.01 percentage points. Maximum absolute difference is 2.581766 percentage points; median is zero. Seven differ by more than 0.01 points. The separate all-candidates party-sum variant has eight such discrepancies, adding Maryland 2012 because it includes a second Democratic write-in candidate.

The three changed district counts come from one internally inconsistent total in the comparison source and two unresolved MIT party labels. No party label was silently repaired and no missing party count became zero. Four New York district-years cross-endorse the same person on both Democratic and Republican lines; these are excluded as distinct-candidate D/R contests.

The MIT mirrors do not improve current-cohort volume completeness. Both sources provide all 65 current state total-vote volumes, but conservative complete-party volumes are available for 44/65 using MIT versus 46/65 in the frozen panel. The difference is caused by the two unresolved party labels. Shares remain available for all 65 current observations.

Vermont 2000 is not a source disagreement: both sources give the Democratic nominee 22.300620% of Democratic-plus-Republican votes. Those two parties captured only 23.607278% of all votes; independent Bernie Sanders dominated the race. This is a limitation of the major-party-share outcome, separately flagged by the major-party vote fraction.

Detailed comparator rows remain local; only aggregate discrepancy counts and this summary should be public. No donor-strength data or treatment assignment was read.


Post-hoc recognized-label sensitivity

A separately exported variant recognizes the exact IN1998 district 3 source label RE as Republican for Daniel A Holtz, keeping all 61,041 source votes unchanged. This restores the omitted district and makes that state-year agree exactly with the frozen panel. No missing label was imputed elsewhere. After this explicit correction, the main 33-observation cohort has maximum absolute current House-share source difference 0.044943 percentage points and maximum lag difference 0.013083 points. Complete-party current volumes are available for 21/33 in both sources. Across the wider 65 observations, MIT provides 45 complete-party volumes versus the frozen panel's 46; unresolved IL2022 party labels explain the remainder.

The additional valid MIT district in IL1978 has a total equal to the sum of the two major nominees, while the comparator's total is lower than that sum. The frozen pipeline correctly quarantines that inconsistent comparator district. This issue affects only a lag in the wider sample, not the main 33. Other small disagreements are source vote-count differences with unchanged district membership; no claim is made that either count is definitive without further official-return adjudication.
