#!/usr/bin/env python3
"""Build donor-blind Senate outcomes. Source-return joins never inspect donor ranks."""
from pathlib import Path
import re,json,hashlib,shutil,argparse
import pandas as pd

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--out',type=Path,default=Path(__file__).resolve().parent,help='External working directory containing raw inputs')
ROOT=parser.parse_args().out.resolve()
COHORT=ROOT/'raw/primary_pairs_for_senate.csv'
MIT=ROOT/'raw/mit_senate.tsv'
cols=['myers_row','state','year','party','name0','name1','winner_slot','primary_id0','margin_corrected_pp','special_election0']
if not COHORT.exists():
    raise FileNotFoundError('Supply the included identity-only raw/primary_pairs_for_senate.csv')
p=pd.read_csv(ROOT/'raw/primary_pairs_for_senate.csv')
assert len(p)==65 and p.myers_row.is_unique
assert hashlib.sha256(MIT.read_bytes()).hexdigest()=='d4492e286046f73b111cf5706ee02be4c305897898317818afd06c0ac8a464e0', 'Senate source version mismatch'
s=pd.read_csv(MIT,sep='\t')
s=s[s.stage.str.lower().eq('gen')].copy()
s['special']=s.special.astype(str).str.lower().eq('true')
s['special_clean']=s.special
# Verified against the official FEC full-term race, not its separate unexpired term.
s.loc[s.state_po.eq('IL')&s.year.eq(2010),'special_clean']=False
norm=lambda x:re.sub('[^A-Z]','',str(x).upper())
s['candidate_key']=s.candidate.map(norm)
s['candidatevotes']=pd.to_numeric(s.candidatevotes,errors='coerce')
s['totalvotes']=pd.to_numeric(s.totalvotes,errors='coerce')
s['party_simplified']=s.party_simplified.str.upper()
# MEDSL has a small number of detailed DEMOCRATIC lines miscoded OTHER.
# Use explicit major-party line labels, never generic substring matching.
demlabels={'DEMOCRAT','DEMOCRATIC','DEMOCRATIC-FARMER-LABOR','DEMOCRATIC-NONPARTISAN LEAGUE','DEMOCRATIC-NPL','DEMOCRATIC/WORKING FAMILIES','DEMOCRAT (NOT IDENTIFIED ON BALLOT)'}
replabels={'REPUBLICAN','REPUBLICAN/CONSERVATIVE','REPUBLICAN (NOT IDENTIFIED ON BALLOT)'}
s.loc[s.party_detailed.str.strip().str.upper().isin(demlabels),'party_simplified']='DEMOCRAT'
s.loc[s.party_detailed.str.strip().str.upper().isin(replabels),'party_simplified']='REPUBLICAN'

def race(g):
    """Major-party nominees chosen on their major-party line; fusion votes follow identity."""
    z={}
    for party in ['DEMOCRAT','REPUBLICAN']:
        v=g[g.party_simplified.eq(party)&g.candidatevotes.gt(0)&g.candidate.notna()]
        if v.empty:
            return None
        v=v.sort_values('candidatevotes',ascending=False)
        key=v.iloc[0].candidate_key
        assert key not in ('OTHER','WRITEIN'),(g.state_po.iloc[0],g.year.iloc[0],party,key)
        nominee=g[g.candidate_key.eq(key)]
        assert nominee['mode'].nunique()==1,nominee
        z[party+'_votes']=float(nominee.candidatevotes.sum())
        z[party+'_candidate']=v.iloc[0].candidate
        z[party+'_key']=key
    totals=g.totalvotes.dropna().unique()
    assert len(totals)==1,totals
    z['total_votes']=float(totals[0])
    z['d_share_pp']=100*z['DEMOCRAT_votes']/(z['DEMOCRAT_votes']+z['REPUBLICAN_votes'])
    return z

out=[]
for a in p.itertuples(index=False):
    party={'dem':'DEMOCRAT','rep':'REPUBLICAN'}[a.party]
    opposite={'dem':'REPUBLICAN','rep':'DEMOCRAT'}[a.party]
    winner=getattr(a,'name'+str(int(a.winner_slot)))
    surname=norm(winner.split(',')[0])
    st=s[s.state_po.eq(a.state)&s.year.eq(a.year)]
    m=st[st.party_simplified.eq(party)&st.candidate_key.str.contains(surname,regex=False)]
    assert len(m)==1,(a.myers_row,winner,m.to_dict('records'))
    m=m.iloc[0]
    g=st[st.special.eq(m.special)&st.district.eq(m.district)]
    z=race(g)
    assert z is not None,(a.myers_row,'one major-party nominee missing')
    assert z[party+'_key']==m.candidate_key,(a.myers_row,winner,z)
    seatclass=re.search(r'Class (III|II|I)\b',a.primary_id0).group(1)
    expected_special=bool(a.special_election0)
    mismatch=bool(m.special)!=expected_special
    assert not mismatch or (a.state=='IL' and a.year==2010)
    row=dict(myers_row=int(a.myers_row),state=a.state,year=int(a.year),party=a.party,
        primary_id=a.primary_id0,seat_class=seatclass,primary_winner=winner,
        senate_candidate=z[party+'_candidate'],senate_opponent_candidate=z[opposite+'_candidate'],
        senate_party_votes=int(z[party+'_votes']),senate_opponent_votes=int(z[opposite+'_votes']),
        senate_total_votes=int(z['total_votes']),
        senate_party_share_pp=z['d_share_pp'] if a.party=='dem' else 100-z['d_share_pp'],
        senate_d_share_pp=z['d_share_pp'],
        senate_party_allvote_share_pp=100*z[party+'_votes']/z['total_votes'],
        senate_election_stage=m.stage,senate_source_special=bool(m.special),
        senate_expected_special=expected_special,
        senate_metadata_note='MIT special=True; official FEC full-term counts verify this is the regular full-term race.' if mismatch else '',
        senate_match_method='unique normalized winner surname within state/year/major-party; verified principal nominee',
        senate_fusion_votes_included=True)
    mod={'I':2,'II':4,'III':0}[seatclass]
    prior=s[s.state_po.eq(a.state)&s.year.lt(a.year)&s.year.mod(6).eq(mod)&~s.special_clean]
    # Choose most recent observed scheduled election before checking major-party availability.
    # Never substitute another seat, current election, or an older contest for a missing-party last election.
    row.update(lag_senate_year=None,lag_senate_party_share_pp=None,lag_senate_status='no prior scheduled same-class race in 1976+ source')
    if not prior.empty:
        prevyear=int(prior.year.max())
        prev=prior[prior.year.eq(prevyear)]
        assert prev.district.nunique()==1,(a.myers_row,prevyear)
        zz=race(prev)
        row['lag_senate_year']=prevyear
        if zz is not None:
            row['lag_senate_party_share_pp']=zz['d_share_pp'] if a.party=='dem' else 100-zz['d_share_pp']
            row['lag_senate_status']='available'
        else:row['lag_senate_status']='prior scheduled election lacks positive votes for one major-party nominee'
    out.append(row)
o=pd.DataFrame(out)
assert o.senate_party_share_pp.between(0,100).all()
assert (o.lag_senate_year.dropna()<o.loc[o.lag_senate_year.notna(),'year']).all()
o.to_csv(ROOT/'senate_outcomes.csv',index=False)
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
manifest={
 'assembly':'Senate outcomes only; preselected 65 close nonrunoff pairs; no donor scores read or used.',
 'source':{'title':'MIT Election Data and Science Lab, U.S. Senate election returns, 1976–2024',
           'url':'https://dataverse.harvard.edu/api/access/datafile/13887039',
           'path':'raw/mit_senate.tsv','sha256':sha(MIT),'bytes':MIT.stat().st_size},
 'cohort':{'path':'raw/primary_pairs_for_senate.csv','sha256':sha(ROOT/'raw/primary_pairs_for_senate.csv'),
           'original_source':str(COHORT),'rule':'margin_corrected_pp < 10; existing nonrunoff cohort; only identity and election metadata retained'},
 'outcome_definition':'100 × same-party major-party nominee votes / (Democratic nominee votes + Republican nominee votes). Candidate fusion lines are summed by normalized candidate identity. General stage only; general-election runoffs excluded. Undefined if either major-party nominee lacks positive votes.',
 'party_label_correction':'Explicit DEMOCRAT/DEMOCRATIC and official state-affiliate line names identify major-party nominees even where party_simplified is OTHER. IL2022 Tammy Duckworth DEMOCRATIC is such a source miscoding.',
 'matching':'Unique normalized primary winner surname in same state, year and party; require match to principal major-party nominee; then use its race special/district group.',
 'special_metadata_correction':{'state':'IL','year':2010,'reason':'MIT special=True row contains full-term regular election counts, verified from FEC S - FULL TERM.',
    'Democratic_nominee':'Giannoulias','Democratic_votes':1719478,'Republican_nominee':'Kirk','Republican_votes':1778698,'total_votes':3704473,
    'source_url':'https://www.fec.gov/documents/1675/federalelections2010.xls',
    'source_sha256':'0ce95daa33e5754221420d463eef7871f742135b5798e1194e1755315f9a9942',
    'verification_csv':'raw/fec2010_illinois_full_term.csv',
    'verification_csv_sha256':sha(ROOT/'raw/fec2010_illinois_full_term.csv')},
 'lag_definition':'Most recent strictly earlier scheduled regular same-seat-class election, inferred from Class I/II/III election-year modulo 6 = 2/4/0. Select last contest before testing availability of both nominees. IL2010 verified regular. No pre-1976 data or imputed missing party.',
 'coverage':{'cohort_rows':len(o),'own_general_available':int(o.senate_party_share_pp.notna().sum()),
             'lag_available':int(o.lag_senate_party_share_pp.notna().sum()),
             'lag_status_counts':o.lag_senate_status.value_counts().to_dict(),
             'source_metadata_mismatches':int(o.senate_metadata_note.ne('').sum()),'bad_or_ambiguous_candidate_matches':0},
 'output':{'path':'senate_outcomes.csv','sha256':sha(ROOT/'senate_outcomes.csv')},
 'code':{'path':'build_senate_outcomes.py','sha256':sha(__file__)}
}
(ROOT/'senate_provenance.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest['coverage'],indent=2))
print(o[o.lag_senate_party_share_pp.isna()][['myers_row','state','year','party','lag_senate_year','lag_senate_status']].to_string(index=False))
