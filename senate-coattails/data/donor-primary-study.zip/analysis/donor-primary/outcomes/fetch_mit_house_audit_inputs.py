"""Fetch pinned public mirrors for the optional, separately labelled House source audit."""
from pathlib import Path
import argparse,hashlib,shutil,urllib.request
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--out',type=Path,required=True)
a=p.parse_args(); raw=a.out.resolve()/'raw';raw.mkdir(parents=True,exist_ok=True)
sources={
 'mit_house_huggingface.tab':('https://huggingface.co/spaces/My-Name1/MidtermMaps/resolve/main/1976-2024-house%20%281%29.tab','b18e4ab04f957b888f2d13f6b66b7c00553293bf952dca8c197de5c466c24377'),
 'mit_house_tidytuesday_v12.csv':('https://raw.githubusercontent.com/rfordatascience/tidytuesday/main/data/2023/2023-11-07/house.csv','5caf4450f5edc0ae17ef566dcb2785cfde3b097df31e6d0b9c51dac3e817f1ba')}
for name,(url,expected) in sources.items():
 target=raw/name
 if not target.exists():
  req=urllib.request.Request(url,headers={'User-Agent':'SenateCoattailsSourceAudit/1.0'})
  with urllib.request.urlopen(req,timeout=120) as response:data=response.read()
  assert hashlib.sha256(data).hexdigest()==expected, f'Source version mismatch: {name}'
  target.write_bytes(data)
 assert hashlib.sha256(target.read_bytes()).hexdigest()==expected, f'Cached source mismatch: {name}'
source=Path(__file__).resolve().parent/'raw/mit_house_metadata.json'
if source.resolve()!=(raw/source.name).resolve():shutil.copyfile(source,raw/source.name)
print('Pinned optional MIT House audit inputs ready')
