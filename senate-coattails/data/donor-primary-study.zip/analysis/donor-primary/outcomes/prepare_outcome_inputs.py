"""Acquire pinned public outcome sources into an external reconstruction directory.
Raw House data and derived row tables must remain outside the public repository.
"""
import argparse,hashlib,shutil,urllib.request
from pathlib import Path
SOURCES={
 'H_dist_election_data.tab':('https://dataverse.harvard.edu/api/access/datafile/11807548','b229f5c7e42045ff868b75f0502c10365216e3a4f5531faa2e803c38c744da5c'),
 'mit_senate.tsv':('https://dataverse.harvard.edu/api/access/datafile/13887039','d4492e286046f73b111cf5706ee02be4c305897898317818afd06c0ac8a464e0'),
 'presidential_raw.csv':('https://dataverse.harvard.edu/api/access/datafile/13887042','9936410a6dd4ecc8be7fe202c6dff5b5f8fee59d88f35ab542ed12879941dcb7'),
 'apportionment.csv':('https://www2.census.gov/programs-surveys/decennial/2020/data/apportionment/apportionment.csv','d9be9c833ad936ee309a83fa6428a3ae2f82d5d8e5b2c69c4d6ff1e79ba57fcd')}
def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--repo',type=Path,required=True)
 p.add_argument('--workdir',type=Path,required=True)
 a=p.parse_args(); repo=a.repo.resolve();out=a.workdir.resolve();src=Path(__file__).resolve().parent
 if out==repo or repo in out.parents:raise ValueError('Use a workdir outside the public repository')
 raw=out/'raw';raw.mkdir(parents=True,exist_ok=True)
 for name,(url,expected) in SOURCES.items():
  target=raw/name
  if not target.exists():
   request=urllib.request.Request(url,headers={'User-Agent':'SenateCoattailsOutcomeReproduction/1.0'})
   with urllib.request.urlopen(request,timeout=120) as response:data=response.read()
   assert hashlib.sha256(data).hexdigest()==expected, f'Source mismatch: {name}'
   target.write_bytes(data)
  assert hashlib.sha256(target.read_bytes()).hexdigest()==expected, f'Cached source mismatch: {name}'
 for name,rel in {
  'governor_state_returns.csv':'analysis/stage3/inputs/governor_state_returns.csv',
  'presidential_state_baselines.csv':'analysis/identification/balance/presidential_state_baselines.csv'}.items():
  shutil.copyfile(repo/rel,raw/name)
 for name in ['governor2022.csv','outcome_cohort_ids.csv']:
  if (src/name).resolve()!=(out/name).resolve():shutil.copyfile(src/name,out/name)
 for name in ['primary_pairs_for_senate.csv','fec2010_illinois_full_term.csv']:
  if (src/'raw'/name).resolve()!=(raw/name).resolve():shutil.copyfile(src/'raw'/name,raw/name)
 print(f'Pinned outcome inputs ready in {out}')
if __name__=='__main__':main()
