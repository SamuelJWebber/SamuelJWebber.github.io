# Actual pre-primary disclosed donor counts

The dataset covers both contenders in the fixed 65 conventional Senate
primaries with a top-two margin below 10 percentage points. The main sample
uses the 33 primaries below 5 points. Neither inclusion nor the donor definition
was chosen using downstream coattail estimates.

## Receipt window and candidate mapping

For every contender, retain receipts dated from January 1 of the calendar year
before the election through exactly 30 days before that state's actual primary,
inclusive. Dates come from the audited cohort roster, including postponed
primaries. Link candidates through the cycle's FEC candidate master and
candidate/committee linkage records, retaining principal and authorized
committees rather than independent expenditure committees or leadership PACs.

The main donor count is a set union across those committees, so a donor giving
more than once, giving to more than one authorized committee, or appearing on
multiple transaction rows contributes one approximate identity per candidate.

## What is counted

Read only `itcont.txt` from each official FEC individual-contribution bulk ZIP.
Some modern ZIPs also contain `by_date` partitions that duplicate the canonical
file; those partitions are not read. The complete canonical file is streamed,
its byte count and ZIP CRC validated, and only campaign records are retained
privately. ZIP SHA256 hashes and extraction coverage are recorded.

Eligible records have transaction type 15 or 15E, a positive finite amount,
entity type IND or blank, a valid receipt date in the window, a nonempty
normalized name, and a five-digit ZIP prefix other than 00000. Known
nonindividual entities and candidate-loan/self-contribution transaction types
are excluded. Blank entity types are retained because older records often do
not populate this field; their counts are reported explicitly.

The main identity key is the complete reported name, uppercased, with
punctuation replaced by spaces and repeated whitespace collapsed, plus ZIP5.
It is an approximate disclosed-donor identity count, not a verified count of
distinct people. Spelling differences or moves can split one person; identical
names within a ZIP can merge people. No nickname or candidate-name alias rules
are applied to donor identities.

The prespecified comparisons use:

- National distinct disclosed donor identities, the main count.
- In-state identities, using the contributor-state field.
- National identities with at least one eligible individual receipt strictly
  greater than $200.
- National identities with at least one eligible individual receipt strictly
  greater than $500, added before outcome estimates to address historical
  reporting thresholds.

Additional normalization checks strip only honorifics/degrees (MR, MRS, MS,
MISS, DR, HON, REV, SENATOR, SEN, PASTOR, SIR, ESQ, MD, PHD), retaining generational
suffixes such as JR/SR. The script also exports the in-state >$200 count.
Within each primary both contenders share the same state population, so
dividing their counts by state population would leave their ranking unchanged.

## Disclosure and availability limitations

These are **disclosed** contributions. The FEC's historical bulk coverage
differs: 1975–1988 includes the reporting-period $500-or-more subset;
1989–2014 the reporting-period $200-or-more subset; and 2015 onward uses the
cycle-to-date over-$200 threshold. Consequently, aggregate counts across eras
are not directly comparable as measures of all donors. Small-dollar supporters
whose identities are not publicly itemized are missing.

The downloaded bulk files are current snapshots. Filtering by receipt date
does **not** reconstruct what was known before the primary: later itemization
and amendments can expose or revise earlier receipts. The main count is
explicitly labeled retrospective. A receipt-level >$200 or >$500 restriction
reduces the cumulative-itemization concern but does not eliminate late filing
or amendment concerns.

Two optional diagnostics narrow current records to those with an 18-digit
image scan date on or before the cutoff, or to those whose retained FILE_NUM
has a verified FEC receipt date on or before the cutoff. The scan date is not
the exact filing date. Current-record filing metadata does not recover
superseded original filings; neither diagnostic constitutes a complete
archival as-of reconstruction. Missing historical filing numbers and image
dates are tracked and are not interpreted as observed zeros.

## Missingness and checks

`count_observed` is true only with a verified candidate/committee mapping,
valid primary-date window, and complete cycle extraction using the exact
committee set. A legitimately observed zero remains zero. Pending, failed,
unmapped, or date-missing records remain missing. Scan/filing diagnostics have
separate observation flags.

Set-containment checks require national counts to be at least in-state counts,
and >$200 counts to be at least >$500 counts. An independent pandas
implementation recomputes all four main count definitions for 1980, 2018,
and 2022 and compares them candidate by candidate. Low-count campaigns were
rechecked against the candidate master and authorized committee links.

These measures operationalize breadth of disclosed financial support. Calling
the higher-count candidate an “all-star” is a substantive interpretation to
test, not an established finding or a direct measure of charisma.

## Reproduction

Run `acquire_individuals.py`, then `filter_targets.py`, then `count_donors.py`
against the included cohort roster. Optional filing metadata can be supplied
with `--filing-dates`. Run `verify_counts.py` for the independent cross-check.
The acquisition manifest gives each official source URL and SHA256 hash;
aggregate count and filter audits document complete coverage. Private raw
receipt files contain donor identities and are not part of a public release.
