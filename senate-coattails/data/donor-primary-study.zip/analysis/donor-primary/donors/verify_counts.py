"""Independent vectorized cross-check against private filtered FEC records."""
import csv,json,sys,argparse
from pathlib import Path
try:
    import pandas as pd
except ModuleNotFoundError:
    # Optional local runtime path; ordinary installations use the import above.
    if Path('/tmp/atlas-deps').exists():
        sys.path.insert(0,'/tmp/atlas-deps')
        import pandas as pd
    else:
        raise SystemExit('Install pandas to run the independent verification.')
parser=argparse.ArgumentParser();parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parent);args=parser.parse_args()
ROOT=args.root
roster=pd.read_csv(ROOT/'candidate_donor_counts.csv',dtype=str).fillna('')
checks=[]
for year in (1980,2018,2022):
    path=ROOT/f'private/campaign_receipts_{year}.txt.gz'
    subset=roster[(roster.year==str(year)) & (roster.count_observed=='True')]
    if subset.empty: continue
    raw=pd.read_csv(path,sep='|',header=None,dtype=str,keep_default_na=False)
    raw['received']=pd.to_datetime(raw[13].str.zfill(8),format='%m%d%Y',errors='coerce')
    raw['amount']=pd.to_numeric(raw[14],errors='coerce')
    raw['name']=raw[7].str.upper().str.replace('[^A-Z0-9 ]',' ',regex=True).str.split().str.join(' ')
    raw['zip5']=raw[10].str.strip().str[:5]
    for _,r in subset.iterrows():
        q=raw[raw[0].isin(r.committee_ids.split(';')) & raw[5].isin(['15','15E']) &
              raw[6].isin(['IND','']) & (raw.amount>0) &
              (raw.received>=pd.Timestamp(r.window_start)) & (raw.received<=pd.Timestamp(r.cutoff_date)) &
              (raw.name!='') & raw.zip5.str.fullmatch('[0-9]{5}') & (raw.zip5!='00000')]
        independent={
            'national_donors':q.drop_duplicates(['name','zip5']).shape[0],
            'in_state_donors':q[q[9].str.strip().str.upper()==r.state].drop_duplicates(['name','zip5']).shape[0],
            'national_gt200_donors':q[q.amount>200].drop_duplicates(['name','zip5']).shape[0],
            'national_gt500_donors':q[q.amount>500].drop_duplicates(['name','zip5']).shape[0]}
        for key,value in independent.items():
            assert value==int(r[key]), (year,r['name'],key,value,r[key])
        checks.append({'year':year,'pair_id':r.pair_id,'slot':r.slot,'all_four_counts_match':True})
result={'independent_pandas_candidate_checks':len(checks),'passed':True,'candidate_checks':checks}
(ROOT/'verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'independent_pandas_candidate_checks':len(checks),'passed':True}))
