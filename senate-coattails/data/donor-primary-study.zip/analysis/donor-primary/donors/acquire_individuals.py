"""Download official FEC bulk individual receipts. No identity-level output is published."""
from pathlib import Path
from datetime import datetime,timezone
import urllib.request,concurrent.futures,hashlib,json,time,zipfile,csv,threading,argparse
parser=argparse.ArgumentParser();parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parent);parser.add_argument('--roster',type=Path);args=parser.parse_args()
HERE=args.root; RAW=HERE/'raw'; RAW.mkdir(parents=True,exist_ok=True)
COHORT=args.roster or (HERE/'candidate_roster.csv' if (HERE/'candidate_roster.csv').exists() else HERE.parent/'cohort/candidate_roster.csv')
years=sorted({int(r['year']) for r in csv.DictReader(COHORT.open())},reverse=True)
lock=threading.Lock(); manifest={}
def save():
 (HERE/'download_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
def get(y):
 url=f'https://www.fec.gov/files/bulk-downloads/{y}/indiv{y%100:02d}.zip'; p=RAW/f'indiv{y%100:02d}.zip';tmp=p.with_suffix('.partial');t=time.time(); h=hashlib.sha256()
 if not p.exists():
  last=0
  for attempt in range(4):
   try:
    # Failed attempts restart, rather than silently append an unsupported Range response.
    with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0'}),timeout=180) as r,tmp.open('wb') as f:
     size=int(r.headers.get('Content-Length','0'));got=0
     print(json.dumps({'year':y,'stage':'download_start','expected_bytes':size}),flush=True)
     while b:=r.read(8*1024*1024):
      f.write(b);got+=len(b)
      if got-last>=512*1024*1024:
       print(json.dumps({'year':y,'stage':'downloading','bytes':got,'seconds':round(time.time()-t)}),flush=True);last=got
    if size and got!=size:raise ValueError(f'Expected {size}; got {got}')
    tmp.rename(p);break
   except Exception as e:
    print(json.dumps({'year':y,'attempt':attempt,'error':str(e)}),flush=True)
    if attempt==3:
     with lock:manifest[str(y)]={'year':y,'url':url,'error':str(e)};save()
     return
 with p.open('rb') as f:
  while b:=f.read(8*1024*1024):h.update(b)
 with zipfile.ZipFile(p) as z:members=[{'name':i.filename,'bytes':i.file_size}for i in z.infolist()]
 rec={'year':y,'url':url,'path':str(p),'bytes':p.stat().st_size,'sha256':h.hexdigest(),'download_completed_utc':datetime.fromtimestamp(p.stat().st_mtime,timezone.utc).isoformat(),'members':members,'elapsed_seconds':round(time.time()-t,2)}
 with lock:manifest[str(y)]=rec;save()
 print(json.dumps({'year':y,'stage':'complete','bytes':rec['bytes'],'seconds':rec['elapsed_seconds']}),flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:list(ex.map(get,years))
print('ALL_DOWNLOADS_FINISHED',flush=True)
