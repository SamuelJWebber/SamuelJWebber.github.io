"""Private streaming filter; only campaign aggregates may be redistributed."""
from pathlib import Path
import csv,json,zipfile,gzip,time,concurrent.futures,hashlib,argparse
parser=argparse.ArgumentParser();parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parent);parser.add_argument('--roster',type=Path);args=parser.parse_args()
HERE=args.root;RAW=HERE/'raw';PRIVATE=HERE/'private';PRIVATE.mkdir(parents=True,exist_ok=True)
ROSTER=args.roster or (HERE/'candidate_roster.csv' if (HERE/'candidate_roster.csv').exists() else HERE.parent/'cohort/candidate_roster.csv')
a=list(csv.DictReader(ROSTER.open())); years=sorted({int(r['year']) for r in a})
targets={y:sorted({c for r in a if int(r['year'])==y for c in r['committee_ids'].split(';') if c})for y in years}
def extract(y):
 cs=targets[y];target={c.encode() for c in cs};out=PRIVATE/f'campaign_receipts_{y}.txt.gz';audit=PRIVATE/f'filter_{y}.json';src=RAW/f'indiv{y%100:02d}.zip';t=time.time();n=nt=nb=0
 if audit.exists():
  prev=json.loads(audit.read_text())
  if prev.get('committee_ids')==cs and out.exists():return prev
 print(json.dumps({'year':y,'stage':'filter_start','committees':len(cs)}),flush=True)
 with zipfile.ZipFile(src) as z:
  members=[i for i in z.infolist() if i.filename=='itcont.txt']
  assert len(members)==1,members
  info=members[0]
  with z.open(info) as f,gzip.open(out.with_suffix('.partial'),'wb',compresslevel=1) as g:
   for line in f:
    n+=1;nb+=len(line)
    if line[:9] in target and line[9:10]==b'|':g.write(line);nt+=1
    if n%5000000==0:print(json.dumps({'year':y,'stage':'filter','raw_records':n,'target_records':nt,'seconds':round(time.time()-t)}),flush=True)
 assert nb==info.file_size,(nb,info.file_size)
 out.with_suffix('.partial').rename(out)
 rec={'year':y,'source_zip':str(src),'source_member':info.filename,'source_member_crc32':info.CRC,'source_member_bytes':nb,'raw_records':n,'target_records':nt,'committee_ids':cs,'complete':True,'targeted_private_gzip_bytes':out.stat().st_size,'seconds':round(time.time()-t,2)}
 audit.write_text(json.dumps(rec,indent=2)+'\n');print(json.dumps(rec),flush=True);return rec
pending=set(years);active={};finished={};errors={}
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:
 while pending or active:
  for y in sorted(pending):
   if len(active)>=2:break
   if (RAW/f'indiv{y%100:02d}.zip').exists():
    active[ex.submit(extract,y)]=y;pending.remove(y)
  for f,y in list(active.items()):
   if f.done():
    try:finished[y]=f.result()
    except Exception as e:errors[y]=str(e);print('ERROR',y,str(e),flush=True)
    del active[f]
  (HERE/'filter_progress.json').write_text(json.dumps({'pending':sorted(pending),'active':list(active.values()),'finished':sorted(finished),'errors':errors},indent=2))
  if pending or active:time.sleep(1)
(HERE/'filter_manifest.json').write_text(json.dumps(finished,indent=2))
print('ALL_FILTERS_FINISHED',flush=True)
if errors:raise SystemExit(str(errors))
