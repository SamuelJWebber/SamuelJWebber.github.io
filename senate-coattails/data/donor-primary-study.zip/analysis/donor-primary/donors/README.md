# Executed pre-primary disclosed-donor extraction

All 130 candidate appearances in 65 fixed close Senate primary pairs are
observed. The main analysis uses the prespecified 33 pairs below a five-point
margin; the wider sample is the 65 pairs below ten points.

The full scan covered **176,384,441** canonical FEC contribution records across
19 cycles, retaining 345,346 campaign records privately. The sum of candidate
identity counts is 71,656; this is not a global distinct-person count. Independent
pandas verification passed for 36 candidate appearances and four definitions.

Read `DONOR_METHODS.md` for the definition, historical disclosure thresholds,
retrospective receipt-date limitation, and observation flags. Candidate quality
is proxied by disclosed financial support, not established as charisma.

## Files

- `candidate_donor_counts.csv`: aggregate candidate counts and coverage diagnostics.
- `candidate_roster.csv`: audited candidate/committee mappings and actual primary dates.
- `donor_count_audit.json`: full-cycle coverage and executed method/roster hashes.
- `download_manifest.json`: official FEC URLs, source ZIP SHA256 hashes, and snapshot times.
- `filter_manifest.json`: canonical member CRCs, byte counts, row counts, and committees.
- `verification.json`: independent checks for 1980, 2018, and 2022.
- `filing_dates.csv`, `filing_ids.csv`, `filing_references.csv`: aggregate filing metadata,
  candidate references, and the 289 relevant FEC filing numbers.
- `filing_diagnostic_audit.json`: coverage and proof that adding filing metadata left
  every frozen main count unchanged.
- `main_counts_frozen.json`: the frozen aggregate count fields used for that comparison.
- Four Python scripts: full download, streaming filter, counting, and independent checking.

No donor names, addresses, ZIPs, or individual transaction records are included.

## Reproduce

Python 3.10+ is sufficient for extraction and counting. Install `requirements.txt`
only for the independent pandas verification. Run these commands in this folder:

```sh
python3 acquire_individuals.py
python3 filter_targets.py
python3 count_donors.py --filing-dates filing_dates.csv
python3 verify_counts.py
```

The download is about 13.61 GB compressed. The filter streams canonical members
without writing their full uncompressed contents; provision roughly 20 GB of
free space. `raw/` and `private/` are generated locally and contain identity-level
source data. Do not add those directories to a public release.

All scripts accept `--root` to select a working/output directory. The first three
also accept `--roster` to select the candidate roster. Counts do not require
filing metadata; `--filing-dates` adds the optional retained-record diagnostic.
The acquisition script obtains current public snapshots, so compare their
SHA256 values with the supplied manifest to detect any later source revision.
Retained FILE_NUM receipt dates do not recover superseded original filings.

The supplied package is aggregate evidence and reproducible method code. It does
not itself establish a causal coattail effect; use the separately reported close
primary estimates, outcome definitions, balance checks, and uncertainty.
