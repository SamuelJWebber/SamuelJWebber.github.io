"""Count approximate disclosed donor identities before each Senate primary.

Only aggregates leave the private input directory. The source is the FEC's
current bulk snapshot; receipt dates do not reconstruct what was filed as-of.
"""
from pathlib import Path
from collections import Counter, defaultdict
from datetime import date, datetime
import argparse, csv, gzip, hashlib, json, math, re, time

P = argparse.ArgumentParser()
P.add_argument('--root', type=Path, default=Path(__file__).resolve().parent)
P.add_argument('--roster', type=Path)
P.add_argument('--filing-dates', type=Path, help='Optional CSV file_number,receipt_date,source')
args = P.parse_args()
ROOT = args.root
ROSTER = args.roster or (ROOT/'candidate_roster.csv' if (ROOT/'candidate_roster.csv').exists() else ROOT.parent/'cohort/candidate_roster.csv')
PRIVATE = ROOT/'private'
roster = list(csv.DictReader(ROSTER.open()))
assert len({(r['pair_id'], r['slot']) for r in roster}) == len(roster)
filing_dates = {}
if args.filing_dates:
    for r in csv.DictReader(args.filing_dates.open()):
        if r['receipt_date']:
            filing_dates[r['file_number']] = date.fromisoformat(r['receipt_date'][:10])

HONORIFICS = {'MR','MRS','MS','MISS','DR','HON','REV','SENATOR','SEN','PASTOR','SIR','ESQ','MD','PHD'}
MEASURES = ['national_donors','in_state_donors','national_gt200_donors','national_gt500_donors',
            'in_state_gt200_donors','national_honorific_donors',
            'in_state_honorific_donors','national_scanned_by_cutoff_donors',
            'in_state_scanned_by_cutoff_donors','national_filed_by_cutoff_donors']

def normalize_name(raw):
    return ' '.join(re.sub(r'[^A-Z0-9 ]',' ',raw.upper()).split())

def parse_date(raw):
    try:
        return datetime.strptime(raw.strip().zfill(8), '%m%d%Y').date()
    except (ValueError, TypeError):
        return None

def scan_date(raw):
    if len(raw) != 18 or not raw.isdigit():
        return None
    try:
        return datetime.strptime(raw[:8], '%Y%m%d').date()
    except ValueError:
        return None

states = []
committee_index = defaultdict(list)
for r in roster:
    row = dict(r)
    row['candidate_id'] = row['fec_id']
    try:
        start, cutoff, primary = (date.fromisoformat(r[k]) for k in ['window_start','cutoff_date','primary_date'])
        assert start <= cutoff < primary
        assert (primary-cutoff).days == 30
        assert start == date(int(r['year'])-1,1,1)
    except (ValueError, AssertionError):
        start = cutoff = primary = None
    state = {'row':row, 'start':start, 'cutoff':cutoff,
             'sets':{m:set() for m in MEASURES},'diag':Counter(),
             'files':defaultdict(Counter), 'scan_min':None, 'scan_max':None}
    states.append(state)
    for committee in r['committee_ids'].split(';'):
        if committee:
            committee_index[(int(r['year']),committee)].append(len(states)-1)

conflicts = {key:ids for key,ids in committee_index.items()
             if len({states[i]['row']['fec_id'] for i in ids}) > 1}
assert not conflicts, f'Committee mapped to different candidates: {conflicts}'
cycle_audits = {}
for year in sorted({int(r['year']) for r in roster}):
    audit_file = PRIVATE/f'filter_{year}.json'
    data_file = PRIVATE/f'campaign_receipts_{year}.txt.gz'
    if not audit_file.exists() or not data_file.exists():
        cycle_audits[year] = {'complete':False,'reason':'source_filter_pending'}
        continue
    audit = json.loads(audit_file.read_text())
    expected = sorted({committee for (y,committee) in committee_index if y == year})
    if audit.get('committee_ids') != expected or not audit.get('complete'):
        cycle_audits[year] = {'complete':False,'reason':'source_mapping_mismatch'}
        continue
    n = 0
    # A person's repeated transactions/amendments collapse into one identity.
    # SUB_ID deduplication is unnecessary for set counts; diagnostics are rows.
    with gzip.open(data_file,'rt',encoding='utf8',errors='replace') as stream:
        for line in stream:
            n += 1
            cols = line.rstrip('\r\n').split('|')
            if len(cols) != 21:
                raise ValueError(f'Malformed row in {year}, {n}: {len(cols)} fields')
            indexes = committee_index.get((year,cols[0]),[])
            for i in indexes:
                s = states[i]; diag = s['diag']; diag['campaign_records'] += 1
                if not s['start']:
                    continue
                if cols[5] not in {'15','15E'}:
                    diag['excluded_transaction_type'] += 1; continue
                if cols[6] not in {'IND',''}:
                    diag['excluded_known_nonindividual_entity'] += 1; continue
                try:
                    amount = float(cols[14])
                except ValueError:
                    diag['excluded_invalid_amount'] += 1; continue
                if not math.isfinite(amount) or amount <= 0:
                    diag['excluded_nonpositive_amount'] += 1; continue
                received = parse_date(cols[13])
                if not received:
                    diag['excluded_invalid_receipt_date'] += 1; continue
                if not s['start'] <= received <= s['cutoff']:
                    diag['excluded_outside_window'] += 1; continue
                diag['window_positive_individual_records'] += 1
                diag['window_entity_ind_records' if cols[6]=='IND' else 'window_entity_blank_records'] += 1
                diag['window_memo_x_records'] += int(cols[18].strip().upper() == 'X')
                if cols[17]:
                    diag['window_records_with_file_number'] += 1
                    s['files'][cols[17]]['window_records'] += 1
                scanned = scan_date(cols[4])
                if scanned:
                    diag['window_records_with_valid_scan_date'] += 1
                    s['scan_min'] = min(s['scan_min'],scanned) if s['scan_min'] else scanned
                    s['scan_max'] = max(s['scan_max'],scanned) if s['scan_max'] else scanned
                    if scanned <= s['cutoff']:
                        diag['window_records_scanned_by_cutoff'] += 1
                    if cols[17]:
                        s['files'][cols[17]]['scanned_by_cutoff_records'] += int(scanned <= s['cutoff'])
                name = normalize_name(cols[7])
                zip_raw = cols[10].strip()
                zip5 = zip_raw[:5] if re.match(r'^[0-9]{5}',zip_raw) else ''
                if zip5 == '00000': zip5 = ''
                if not name or not zip5:
                    diag['excluded_missing_name_or_zip5'] += 1; continue
                diag['counted_identity_records'] += 1
                if scanned:
                    diag['identity_records_with_valid_scan_date'] += 1
                identity = (name,zip5)
                stripped = ' '.join(w for w in name.split() if w not in HONORIFICS)
                alternate = (stripped or name,zip5)
                sets = s['sets']
                in_state = cols[9].strip().upper() == s['row']['state']
                sets['national_donors'].add(identity)
                sets['national_honorific_donors'].add(alternate)
                if amount > 200:
                    sets['national_gt200_donors'].add(identity)
                if amount > 500:
                    sets['national_gt500_donors'].add(identity)
                if in_state:
                    sets['in_state_donors'].add(identity)
                    sets['in_state_honorific_donors'].add(alternate)
                    if amount > 200:
                        sets['in_state_gt200_donors'].add(identity)
                if scanned and scanned <= s['cutoff']:
                    sets['national_scanned_by_cutoff_donors'].add(identity)
                    if in_state:
                        sets['in_state_scanned_by_cutoff_donors'].add(identity)
                filed = filing_dates.get(cols[17])
                if filed:
                    diag['identity_records_with_verified_filing_date'] += 1
                    if filed <= s['cutoff']:
                        diag['identity_records_filed_by_cutoff'] += 1
                        sets['national_filed_by_cutoff_donors'].add(identity)
    assert n == audit['target_records'], (year,n,audit['target_records'])
    cycle_audits[year] = dict(audit, validated_target_rows=n)
    print(json.dumps({'year':year,'counted_target_records':n}),flush=True)

out = []; filing_out = []
diag_keys = sorted({k for s in states for k in s['diag']})
for s in states:
    row,diag,sets = s['row'],s['diag'],s['sets']
    year = int(row['year'])
    complete = bool(cycle_audits[year]['complete'])
    observed = complete and row['status'] == 'matched' and bool(row['committee_ids']) and bool(s['cutoff'])
    row.update({'count_observed':observed,'source_complete':complete,
                'retrospective_receipt_date':True,'filing_asof_verified':False,
                'count_status':'observed' if observed else cycle_audits[year].get('reason','mapping_or_date_missing'),
                'bulk_disclosure_regime':('1975-1988_reporting_period_500plus' if year<=1988 else
                '1989-2014_reporting_period_200plus' if year<=2014 else '2015plus_cycle_to_date_over200'),
                'normalization':'uppercase_punctuation_space_fullname_plus_zip5',
                'scan_date_min':s['scan_min'].isoformat() if s['scan_min'] else '',
                'scan_date_max':s['scan_max'].isoformat() if s['scan_max'] else ''})
    for m in MEASURES:
        row[m] = len(sets[m]) if observed else ''
    row['scanned_count_observed'] = observed and bool(diag['counted_identity_records']) and diag['identity_records_with_valid_scan_date']==diag['counted_identity_records']
    row['filed_count_observed'] = observed and bool(filing_dates) and bool(diag['counted_identity_records']) and diag['identity_records_with_verified_filing_date']==diag['counted_identity_records']
    row['filed_count_is_retained_record_diagnostic'] = True
    if not row['scanned_count_observed']:
        row['national_scanned_by_cutoff_donors'] = row['in_state_scanned_by_cutoff_donors'] = ''
    if not row['filed_count_observed']:
        row['national_filed_by_cutoff_donors'] = ''
    for key in diag_keys:
        row[key] = diag[key] if complete else ''
    if observed:
        assert sets['in_state_donors'] <= sets['national_donors']
        assert sets['national_gt200_donors'] <= sets['national_donors']
        assert sets['national_gt500_donors'] <= sets['national_gt200_donors']
        assert sets['in_state_gt200_donors'] <= sets['in_state_donors']
        assert len(sets['national_honorific_donors']) <= len(sets['national_donors'])
        assert sets['national_scanned_by_cutoff_donors'] <= sets['national_donors']
        assert len(sets['national_donors']) <= diag['counted_identity_records']
    out.append(row)
    for number,counts in sorted(s['files'].items()):
        filing_out.append({'pair_id':row['pair_id'],'slot':row['slot'],'year':year,
                           'candidate_id':row['candidate_id'],'committee_ids':row['committee_ids'],
                           'cutoff_date':row['cutoff_date'],'file_number':number,**counts})

def write_csv(path, rows):
    if not rows: return
    fields = list(dict.fromkeys(k for r in rows for k in r))
    temporary = path.with_suffix('.partial')
    with temporary.open('w',newline='') as f:
        writer = csv.DictWriter(f,fieldnames=fields)
        writer.writeheader();writer.writerows(rows)
    temporary.replace(path)

write_csv(ROOT/'candidate_donor_counts.csv',out)
write_csv(ROOT/'filing_references.csv',filing_out)
write_csv(ROOT/'filing_ids.csv',[{'file_number':n} for n in sorted({r['file_number'] for r in filing_out})])
count_summary = {'candidate_appearances':len(out),'observed_candidate_appearances':sum(r['count_observed'] for r in out),
                 'total_cycles':len(cycle_audits),'complete_cycles':sum(x['complete'] for x in cycle_audits.values()),
                 'source_raw_records':sum(x.get('raw_records',0) for x in cycle_audits.values()),
                 'target_campaign_records':sum(x.get('target_records',0) for x in cycle_audits.values()),
                 'national_identity_sum_not_distinct_across_candidates':sum(r['national_donors'] for r in out if r['count_observed']),
                 'roster_sha256':hashlib.sha256(ROSTER.read_bytes()).hexdigest(),
                 'method_code_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                 'cycles':cycle_audits,
                 'limitations':['Distinct disclosed name+ZIP5 identities approximate donors; missing unitemized small donors cannot be recovered.',
                   'Current bulk receipt-date subset is retrospective, not information as filed by cutoff.',
                   'Historical disclosure regimes differ; older bulk lacks entity type for many records.',
                   'Scan date is an optional conservative availability sensitivity, not exact filing receipt date.',
                   'Repeated contributions collapse; spelling variation and address changes can split one person; shared name+ZIP can merge people.']}
(ROOT/'donor_count_audit.json').write_text(json.dumps(count_summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in count_summary.items() if k!='cycles'},indent=2))
