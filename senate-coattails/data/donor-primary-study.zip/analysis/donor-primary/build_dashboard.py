"""Build the public dashboard from aggregate estimates and FEC candidate counts only."""
from pathlib import Path
import csv,json,argparse,math
def number(s):
    if s is None or s=='':return None
    try:
        n=float(s)
        return int(n) if n.is_integer() else n
    except ValueError:return s
def main():
    p=argparse.ArgumentParser();p.add_argument('--study',type=Path,default=Path(__file__).parent);p.add_argument('--dest',type=Path,default=Path(__file__).resolve().parents[2]/'dist/data/donor-primary.json');a=p.parse_args();s=a.study
    summary=json.loads((s/'analysis/results/summary.json').read_text())
    roster=list(csv.DictReader((s/'donors/candidate_donor_counts.csv').open()))
    dates={int(r['pair_id']):r['cutoff_date'] for r in roster}
    ledger=list(csv.DictReader((s/'analysis/results/treatment_ledger.csv').open()))
    cases=[]
    for r in ledger:
        m=r['measure'];out={k:number(r.get(k)) for k in ['pair_id','year','state','party','name0','name1','higher_donor_slot','treatment','margin_pp','exclusion_reason']}
        out.update(measure=m,count0=number(r.get(m+'_0')),count1=number(r.get(m+'_1')),cutoff_date=dates[int(r['pair_id'])]);cases.append(out)
    measures=[{'id':k,'label':v} for k,v in [('national_donors','National donor breadth · main'),('in_state_donors','In-state donor breadth'),('national_gt200_donors','National · individual gift >$200'),('national_gt500_donors','National · individual gift >$500')]]
    out={'generated_at':summary['generated_at_utc'],'measures':measures,'estimates':summary['all_estimates'],'balance':summary['balance'],'cases':cases,'coverage':summary['coverage']}
    a.dest.parent.mkdir(parents=True,exist_ok=True);a.dest.write_text(json.dumps(out,indent=2,allow_nan=False)+'\n');print(a.dest)
if __name__=='__main__':main()
