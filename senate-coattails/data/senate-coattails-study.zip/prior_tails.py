"""Explore weak and strong returning senators using the rebuilt analysis samples.

Example: python prior_tails.py
Requires pandas, NumPy, and SciPy.
"""
import argparse
from pathlib import Path


import numpy as np
import pandas as pd
from scipy.stats import t

RACE = ["state_abbrev", "year"]
OFFICES = {
    "Senate": ("senate", "senate_dem", []),
    "House": ("house", "house_dem", ["district_lean", "house_incumbency"]),
    "Governor": ("governor", "share", ["prev_lean", "incumbency_G"]),
    "Governor with quality": ("governor", "share", ["prev_lean", "incumbency_G", "news_quality_G"]),
}

def model(frame, office, outcome, terms, controls):
    data = frame.dropna(subset=[outcome, *terms, *controls]).copy()
    predictors = [*terms, "party", *controls]
    design = pd.concat([
        data[predictors], pd.get_dummies(data.year, dtype=float),
        pd.get_dummies(data.state_abbrev, drop_first=True, dtype=float),
    ], axis=1).to_numpy(dtype=float)
    weights = np.ones(len(data))
    if office == "House":
        weights = 1 / data.groupby(RACE)[outcome].transform("size").to_numpy()
    weighted = design * np.sqrt(weights[:, None])
    target = data[outcome].to_numpy(dtype=float)
    beta, _, rank, _ = np.linalg.lstsq(weighted, target * np.sqrt(weights), rcond=None)
    # Some state/year nuisance indicators are collinear in small samples. Require that
    # all target coefficients are individually identified given those nuisance columns.
    nuisance_rank = np.linalg.matrix_rank(weighted[:, len(terms):])
    if rank != nuisance_rank + len(terms):
        raise ValueError(f"{office} has an unidentified exposure contrast")
    residual = target - design @ beta
    bread = np.linalg.pinv(weighted.T @ weighted)
    states, group = np.unique(data.state_abbrev, return_inverse=True)
    state_scores = np.zeros((len(states), design.shape[1]))
    np.add.at(state_scores, group, design * (weights * residual)[:, None])
    correction = len(states)/(len(states)-1) * (len(data)-1)/(len(data)-rank)
    covariance = correction * bread @ (state_scores.T @ state_scores) @ bread
    return data, beta[:len(terms)], covariance[:len(terms), :len(terms)], len(states)

def estimate(frame, office, outcome, spec, terms, controls, contrasts, bins):
    data, beta, cov, n_states = model(frame, office, outcome, terms, controls)
    unique = data.drop_duplicates(RACE)
    counts = {"n_races":len(unique), "n_observations":len(data), "n_states":n_states}
    for group in bins:
        part = unique[unique.bin == group]
        counts[f"{group}_n"] = len(part)
        counts[f"{group}_states"] = part.state_abbrev.nunique()
    results = []
    for contrast, weights in contrasts.items():
        coefficients = np.array(weights, dtype=float)
        center = coefficients @ beta * 100
        se = np.sqrt(coefficients @ cov @ coefficients) * 100
        critical = t.ppf(.975, n_states - 1)
        results.append({"specification":spec, "office":office, "contrast":contrast,
                        **counts, "estimate_pp":center,"se_pp":se,
                        "lower95_pp":center - critical*se, "upper95_pp":center + critical*se,
                        "p_value":2*t.sf(abs(center/se), n_states-1)})
    return results

def run(data_dir, target):
    target.mkdir(parents=True, exist_ok=True)
    house = pd.read_csv(data_dir / "prior_house_sample.csv")
    governors = pd.read_csv(data_dir / "prior_governor_sample.csv")
    house["house_dem"] = .5 + house.party*house.out
    house["district_lean"] = house.party*house.baseline
    house["house_incumbency"] = house.party*house.inc
    senate = house.drop_duplicates(RACE).copy()
    senate["senate_dem"] = senate.party*senate.curr_own
    assert len(senate)==423 and len(house)==3175 and len(governors)==196
    frames = {"house":house,"senate":senate,"governor":governors}
    low, median, high = senate.score.quantile([.1,.5,.9]).to_numpy()
    results = []
    counts = []
    leave_one_state = []
    member = pd.concat([senate[RACE+["candidate","party","score"]],
                        governors[RACE+["candidate","party","score"]]]).drop_duplicates(RACE)
    member["in_senate_sample"] = pd.MultiIndex.from_frame(member[RACE]).isin(pd.MultiIndex.from_frame(senate[RACE]))
    member["in_governor_sample"] = pd.MultiIndex.from_frame(member[RACE]).isin(pd.MultiIndex.from_frame(governors[RACE]))
    member["decile_group"] = np.select([member.score<=low,member.score>=high],["low","high"],default="middle")
    member.to_csv(target / "tail_membership.csv", index=False)
    for office, (source, outcome, controls) in OFFICES.items():
        df = frames[source].dropna(subset=[outcome, *controls]).copy()
        df["bin"] = np.select([df.score<=low, df.score>=high], ["low","high"], default="middle")
        df["signed_low"] = df.party * (df.bin=="low")
        df["signed_high"] = df.party * (df.bin=="high")
        results += estimate(df, office, outcome, "deciles", ["signed_low","signed_high"], controls,
                            {"low_vs_middle":[1,0],"high_vs_middle":[0,1],
                             "high_minus_low":[-1,1],"high_plus_low":[1,1]}, ["low","middle","high"])
        for state in sorted(df.state_abbrev.unique()):
            sub = df[df.state_abbrev != state]
            _, coef, _, _ = model(sub, office, outcome, ["signed_low","signed_high"], controls)
            leave_one_state.append({"office":office, "omitted_state":state,
                                    "low_vs_middle_pp":100*coef[0], "high_vs_middle_pp":100*coef[1]})
        # These continuous terms are scaled so a coefficient is a +10-point change in the score.
        df["left_slope"] = 10*df.party*np.minimum(df.score-median,0)
        df["right_slope"] = 10*df.party*np.maximum(df.score-median,0)
        df["bin"] = np.where(df.score <= median, "left", "right")
        results += estimate(df, office, outcome, "linear_spline_at_median",
                            ["left_slope","right_slope"], controls,
                            {"slope_below_median":[1,0],"slope_above_median":[0,1],
                             "difference_in_slopes":[-1,1]}, ["left","right"])
        for threshold in [.05, .10, .15, .20]:
            df["bin"] = np.select([df.score<=-threshold, df.score>=threshold], ["low","high"], default="middle")
            races = df.drop_duplicates(RACE)
            sizes = {key:int((races.bin == key).sum()) for key in ["low","middle","high"]}
            counts.append({"office":office,"threshold_pp":100*threshold,**sizes})
            if sizes["low"]>=10 and sizes["high"]>=10:
                df["signed_low"] = df.party * (df.bin=="low")
                df["signed_high"] = df.party * (df.bin=="high")
                results += estimate(df, office, outcome, f"absolute_joint_{threshold*100:.0f}",
                                    ["signed_low","signed_high"], controls,
                                    {"low_vs_middle":[1,0],"high_vs_middle":[0,1]},
                                    ["low","middle","high"])
            # These are high vs all other incumbents, not high vs the middle fixed bin.
            if threshold>=.10 and sizes["high"]>=10:
                df["bin"] = np.where(df.score>=threshold, "high", "remainder")
                df["signed_high"] = df.party*(df.bin=="high")
                results += estimate(df, office, outcome, f"upper_only_{threshold*100:.0f}",
                                    ["signed_high"], controls, {"high_vs_everyone_else":[1]},
                                    ["high","remainder"])
    pd.DataFrame(results).to_csv(target/"tail_estimates.csv", index=False, float_format="%.8f")
    pd.DataFrame(leave_one_state).to_csv(target/"leave_one_state_out.csv", index=False, float_format="%.8f")
    pd.DataFrame(counts).to_csv(target/"threshold_counts.csv", index=False)
    pd.DataFrame({"quantile":[.1,.5,.9],"score_share":[low,median,high],
                  "score_points":100*np.array([low,median,high])}).to_csv(target/"cutoffs.csv",index=False)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    base = Path(__file__).resolve().parent
    parser.add_argument("--data-dir", type=Path, default=base / "data")
    parser.add_argument("--output", type=Path, default=base / "results" / "prior_tails")
    options = parser.parse_args()
    run(options.data_dir, options.output)
