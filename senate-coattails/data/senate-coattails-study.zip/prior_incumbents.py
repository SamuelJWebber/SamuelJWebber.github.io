"""Check whether repeating incumbents' performance six years earlier predicts other races."""
import pandas as pd

from replicate import DATA, RESULTS, estimate


def main():
    RESULTS.mkdir(exist_ok=True)
    house = pd.read_csv(DATA / "prior_house_sample.csv")
    governor = pd.read_csv(DATA / "prior_governor_sample.csv")
    senate = house.drop_duplicates(["state_abbrev", "year"]).copy()
    rows = []
    for frame in [house, senate]:
        frame["prior_ten_points"] = 10 * frame.score  # One unit is 0.10 of vote share.
    governor["prior_signed_ten_points"] = 10 * governor.signed_score

    for state_adjustment in [False, True]:
        suffix = "state_party_adjusted" if state_adjustment else "year_party_adjusted"
        fixed = ["ycat", "scat"] if state_adjustment else ["ycat"]
        rows += estimate(senate, "prior_senate_" + suffix, "curr_own",
                         ["prior_ten_points"], fixed, "state_abbrev", ["prior_ten_points"])
        rows += estimate(house, "prior_house_" + suffix, "out",
                         ["prior_ten_points", "baseline", "inc"], fixed, "state_abbrev",
                         ["prior_ten_points"], equal_elections=True)
    fixed = ["state_abbrev", "year"]
    predictors = ["prior_signed_ten_points", "party", "prev_lean", "incumbency_G"]
    rows += estimate(governor, "prior_governor", "share", predictors,
                     fixed, "state_abbrev", ["prior_signed_ten_points"])
    rows += estimate(governor, "prior_governor_quality_adjusted", "share",
                     [*predictors, "news_quality_G"], fixed,
                     "state_abbrev", ["prior_signed_ten_points"])
    # Estimate every outcome on a Democratic orientation using the same signed prior score.
    house["d2pshare"] = house.out * house.party + 0.5
    house["baseline_dem"] = house.baseline * house.party
    house["inc_dem"] = house.inc * house.party
    house["prior_signed_ten_points"] = house.prior_ten_points * house.party
    senate["own_dem"] = senate.curr_own * senate.party
    senate["prior_signed_ten_points"] = senate.prior_ten_points * senate.party
    for frame, outcome, other, office in [
        (senate, "own_dem", [], "senate"),
        (house, "d2pshare", ["baseline_dem", "inc_dem"], "house"),
    ]:
        rows += estimate(frame, "prior_common_" + office, outcome,
                         ["prior_signed_ten_points", "party", *other], fixed, "state_abbrev",
                         ["prior_signed_ten_points"], equal_elections=office == "house")
    for frame, outcome, other, office in [
        (senate, "own_dem", [], "senate"),
        (house, "d2pshare", ["baseline_dem", "inc_dem"], "house"),
        (governor, "share", ["prev_lean", "incumbency_G"], "governor"),
        (governor, "share", ["prev_lean", "incumbency_G", "news_quality_G"], "governor_quality_adjusted"),
    ]:
        frame["signed_top15"] = frame.top15 * frame.party
        rows += estimate(frame, "prior_threshold_" + office, outcome,
                         ["signed_top15", "party", *other], fixed, "state_abbrev",
                         ["signed_top15"], equal_elections=office == "house")
    governor["out"] = governor.party * (governor.share - 0.5)
    governor["inc"] = governor.party * governor.incumbency_G
    governor["baseline"] = governor.party * governor.prev_lean
    governor["prior_ten_points"] = 10 * governor.score
    governor["ycat"] = governor.party.astype(str) + "_" + governor.year.astype(str)
    governor["scat"] = governor.party.astype(str) + "_" + governor.state_abbrev
    for state_adjustment in [False, True]:
        fixed_party = ["ycat", "scat"] if state_adjustment else ["ycat"]
        suffix = "state_party_adjusted" if state_adjustment else "year_party_adjusted"
        rows += estimate(governor, "prior_governor_" + suffix, "out",
                         ["prior_ten_points", "baseline", "inc"], fixed_party, "state_abbrev",
                         ["prior_ten_points"])
        rows += estimate(house, "prior_house_exceptional_" + suffix, "out",
                         ["top15", "baseline", "inc"], fixed_party, "state_abbrev",
                         ["top15"], equal_elections=True)
    pd.DataFrame(rows).to_csv(RESULTS / "prior_incumbent_estimates.csv", index=False,
                              float_format="%.6f")


if __name__ == "__main__":
    main()
