"""Rebuild the published House benchmark and the two exploratory spillover screens."""
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import t

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
RESULTS = ROOT / "results"


def estimate(frame, label, outcome, predictors, fixed_effects, cluster, reported, equal_elections=False):
    """OLS with indicator fixed effects, CR1 inference, and a cluster-t interval."""
    columns = [outcome, *predictors, *fixed_effects, cluster]
    sample = frame.dropna(subset=columns).reset_index(drop=True)
    design = [pd.Series(1.0, index=sample.index, name="intercept"), sample[predictors]]
    for name in fixed_effects:
        indicators = pd.get_dummies(sample[name], prefix=name, drop_first=True, dtype=float)
        design.append(indicators)
    design = pd.concat(design, axis=1)
    x = design.to_numpy(dtype=float)
    y = 100 * sample[outcome].to_numpy()
    weights = np.ones(len(sample))
    if equal_elections:
        weights = 1 / sample.groupby(["state_abbrev", "year"]).year.transform("size").to_numpy()
    weighted_x = np.sqrt(weights[:, None]) * x
    beta, _, rank, _ = np.linalg.lstsq(weighted_x, np.sqrt(weights) * y, rcond=None)
    residuals = y - x @ beta
    groups, group_ids = np.unique(sample[cluster], return_inverse=True)
    count = len(groups)
    cluster_scores = np.zeros((count, x.shape[1]))
    np.add.at(cluster_scores, group_ids, x * (weights * residuals)[:, None])
    bread = np.linalg.pinv(weighted_x.T @ weighted_x)
    factor = (count / (count - 1)) * ((len(sample) - 1) / (len(sample) - rank))
    covariance = factor * bread @ (cluster_scores.T @ cluster_scores) @ bread
    errors = np.sqrt(np.maximum(covariance.diagonal(), 0))
    critical = t.ppf(0.975, count - 1)
    elections = sample.drop_duplicates(["state_abbrev", "year"])
    rows = []
    for term in reported:
        j = design.columns.get_loc(term)
        radius = critical * errors[j]
        rows.append(dict(model=label, term=term, estimate_pp=beta[j],
                         se_pp=errors[j], lower95_pp=beta[j] - radius,
                         upper95_pp=beta[j] + radius, observations=len(sample),
                         state_elections=len(elections), clusters=count,
                         first_year=sample.year.min(), last_year=sample.year.max(),
                         lower_group_elections=elections["low"].sum() if "low" in elections else None,
                         upper_group_elections=elections["high"].sum() if "high" in elections else None))
    return rows


def classify(frame, fraction=0.10):
    elections = frame.drop_duplicates(["state_abbrev", "year"])
    low, high = elections.news_quality_S.quantile([fraction, 1 - fraction])
    return frame.assign(low=frame.news_quality_S.le(low).astype(int),
                        high=frame.news_quality_S.ge(high).astype(int)), low, high


def house_analysis(districts):
    controls = ["normalvote_demean", "incumbency", "news_quality"]
    data = districts.loc[districts.flag_exclude.ne(1)].dropna(subset=controls + ["d2pshare"])
    rows = []
    cases = []

    def add(frame, label, inputs, reported, extra_fixed=()):
        rows.extend(estimate(frame, label, "d2pshare", inputs, ["year", *extra_fixed],
                             "syFE", reported))

    for label, frame in [("published_all", data), ("published_midterms", data[data.presyear.eq(0)])]:
        add(frame, label, ["news_quality_top", *controls], ["news_quality_top"])

    scenarios = [
        ("senate_no_governor", data[data.topticket_race.eq("S")], []),
        ("all_senate", data, []),
        ("concurrent_adjusted", data[data.topticket_race.eq("GS")], ["news_quality_G"]),
    ]
    for name, frame, added_controls in scenarios:
        frame = frame.dropna(subset=["news_quality_S", *added_controls])
        add(frame, name + "_linear", ["news_quality_S", *controls, *added_controls], ["news_quality_S"])
        for fraction in [0.10, 0.05]:
            tagged, low, high = classify(frame, fraction)
            label = f"{name}_tails_{round(100 * fraction)}"
            add(tagged, label, ["high", "low", *controls, *added_controls], ["high", "low"])
            elections = tagged.drop_duplicates(["state_abbrev", "year"])
            cases.append(elections[["state_abbrev", "year", "news_quality_S", "high", "low"]]
                         .assign(model=label, lower_cutoff=low, upper_cutoff=high))
            if fraction != 0.10:
                continue
            if name != "senate_no_governor":
                add(tagged[tagged.presyear.eq(0)], label + "_midterms",
                    ["high", "low", *controls, *added_controls], ["high", "low"])
            else:
                add(tagged, label + "_stateFE", ["high", "low", *controls],
                    ["high", "low"], ["state_abbrev"])
                add(tagged[tagged.year.ge(1990)], label + "_since_1990",
                    ["high", "low", *controls], ["high", "low"])
                district = "st_dist_redist_FE"
                recurrent = tagged[tagged.groupby(district).year.transform("size").gt(1)]
                add(recurrent, label + "_districtFE", ["high", "low", *controls],
                    ["high", "low"], [district])
    pd.DataFrame(rows).to_csv(RESULTS / "house_estimates.csv", index=False, float_format="%.6f")
    pd.concat(cases, ignore_index=True).to_csv(RESULTS / "house_tail_membership.csv", index=False,
                                              float_format="%.6f")


def governor_analysis(districts):
    quality = ["news_quality_S", "news_quality_G"]
    controls = ["incumbency_G", "incumbency_S", "normalvote_demean"]
    # Candidate attributes are statewide. The district mean supplies the state partisan baseline.
    state_year = (districts[districts.topticket_race.eq("GS")]
                  .groupby(["state_abbrev", "year"], as_index=False)[quality + controls].mean())
    votes = pd.read_csv(DATA / "governor_state_returns.csv")
    merged = votes.merge(state_year, on=["state_abbrev", "year"], validate="one_to_one")
    return merged, quality, controls


def governor_models(districts):
    merged, quality, controls = governor_analysis(districts)
    sample = merged.dropna(subset=["share", *quality, *controls]).copy()
    tagged, low, high = classify(sample)
    rows = []

    def add(frame, label, predictors, reported, fixed=("state_abbrev", "year")):
        rows.extend(estimate(frame, label, "share", predictors, fixed, "state_abbrev", reported))

    add(tagged, "governor_linear", [*quality, *controls], quality)
    add(tagged, "governor_linear_yearFE_only", [*quality, *controls], quality, ["year"])
    add(tagged, "governor_tails", ["high", "low", "news_quality_G", *controls], ["high", "low"])
    complete = tagged[tagged.missing_counties.eq(0)]
    add(complete, "governor_linear_complete_counties", [*quality, *controls], quality)
    add(complete, "governor_tails_complete_counties",
        ["high", "low", "news_quality_G", *controls], ["high", "low"])
    tagged.assign(lower_cutoff=low, upper_cutoff=high).to_csv(
        RESULTS / "governor_sample.csv", index=False, float_format="%.8f")
    pd.DataFrame(rows).to_csv(RESULTS / "governor_estimates.csv", index=False, float_format="%.6f")


def major_party_results(votes):
    """Recover a single D/R pair per state-year, including fusion votes for each nominee."""
    keys = ["state_po", "year"]
    eligible = votes[votes.party_simplified.isin(["DEMOCRAT", "REPUBLICAN"])]
    nominees = eligible[keys + ["candidate", "party_simplified"]].dropna().drop_duplicates()
    # Keep only contests with exactly one recorded non-write-in nominee for each major party.
    count = nominees.groupby(keys + ["party_simplified"]).candidate.transform("size")
    nominees = nominees.loc[count.eq(1)]
    totals = votes.groupby(keys + ["candidate"], as_index=False).candidatevotes.sum()
    nominees = nominees.merge(totals, on=keys + ["candidate"])
    wide = nominees.pivot(index=keys, columns="party_simplified", values="candidatevotes").dropna()
    return (wide.DEMOCRAT / (wide.DEMOCRAT + wide.REPUBLICAN)).rename("share").reset_index()


def senate_analysis(districts):
    returns = pd.read_csv(DATA / "mit_senate.tsv", sep="\t")
    keys = ["state_po", "year"]
    pre = returns.loc[returns.stage.eq("pre"), keys].drop_duplicates().assign(has_pre=True)
    returns = returns.merge(pre, on=keys, how="left")
    eligible_stage = (returns.stage.eq("pre") |
                      (returns.stage.str.lower().eq("gen") & returns.has_pre.ne(True)))
    returns = returns.loc[eligible_stage & ~returns.writein.eq(True)].copy()
    special = returns.loc[returns.special.eq(True), keys].drop_duplicates().assign(special_present=True)
    regular = returns.loc[returns.special.eq(False)].merge(special, on=keys, how="left")
    senate = major_party_results(regular.loc[regular.special_present.ne(True)])

    president = pd.read_csv(DATA / "mit_president.csv")
    presidential = (major_party_results(president.loc[~president.writein.eq(True)])
                    .rename(columns={"share": "presidential_share", "year": "presidential_year"}))
    ratings = (districts.dropna(subset=["news_quality_S"])[["state_abbrev", "year", "news_quality_S",
                                                          "incumbency_S"]]
               .drop_duplicates().rename(columns={"state_abbrev": "state_po"}))
    sample = senate.merge(ratings, on=keys, validate="one_to_one")
    sample["presidential_year"] = sample.year // 4 * 4
    sample = sample.merge(presidential, on=["state_po", "presidential_year"],
                          validate="many_to_one").rename(columns={"state_po": "state_abbrev"})
    predictors = ["news_quality_S", "incumbency_S", "presidential_share"]
    estimates = estimate(sample, "senate_own_vote", "share", predictors, ["year"],
                         "state_abbrev", ["news_quality_S"])
    sample = sample.dropna(subset=predictors)
    sample.to_csv(RESULTS / "senate_sample.csv", index=False, float_format="%.8f")
    pd.DataFrame(estimates).to_csv(RESULTS / "senate_estimate.csv", index=False, float_format="%.6f")


def main():
    RESULTS.mkdir(exist_ok=True)
    districts = pd.read_csv(DATA / "house_districts.csv")
    house_analysis(districts)
    governor_models(districts)
    senate_analysis(districts)


if __name__ == "__main__":
    main()
