"""Assess persistent local support in the returning-senator coattails association.

Run after prepare_inputs.py. This extends the public model on a common matched
sample of House districts with unchanged boundaries in the previous election.
"""
import argparse
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import t

ROOT = Path(__file__).resolve().parent
RACE = ["state_abbrev", "year"]
DISTRICT = ["state_abbrev", "year", "dist"]
OUTPUT = ROOT / "results" / "identification"

def regression(data, outcome, controls, label, state_fixed=True):
    v = data.dropna(subset=[outcome,"signed_score10","party",*controls]).copy()
    names = ["signed_score10","party",*controls]
    columns = [v[names], pd.get_dummies(v.year, dtype=float)]
    if state_fixed:
        columns.append(pd.get_dummies(v.state_abbrev, drop_first=True, dtype=float))
    X = pd.concat(columns, axis=1).to_numpy(float)
    y = v[outcome].to_numpy(float)
    w = 1 / v.groupby(RACE)[outcome].transform("size").to_numpy()
    weighted = X*np.sqrt(w[:,None])
    b, _, rank, _ = np.linalg.lstsq(weighted, y*np.sqrt(w), rcond=None)
    if rank != np.linalg.matrix_rank(weighted[:,1:])+1:
        raise ValueError("Prior-score coefficient is not identified.")
    residual = y-X@b
    bread = np.linalg.pinv(weighted.T@weighted)
    states, index = np.unique(v.state_abbrev, return_inverse=True)
    scores = np.zeros((len(states),X.shape[1]))
    np.add.at(scores,index, X*(residual*w)[:,None])
    correction = len(states)/(len(states)-1)*(len(v)-1)/(len(v)-rank)
    covariance = correction*bread@(scores.T@scores)@bread
    se = np.sqrt(covariance[0,0])*100
    effect = b[0]*100
    margin = t.ppf(.975,len(states)-1)*se
    return {"model":label,"outcome":outcome,"n_district_races":len(v),
            "n_senate_elections":len(v.drop_duplicates(RACE)),"states":len(states),
            "first_year":v.year.min(),"last_year":v.year.max(),
            "state_fixed_effects":state_fixed, "estimate_pp_per_10":effect,"lower95":effect-margin,"upper95":effect+margin,
            "se":se, "controls":",".join(controls)}

def matched_sample(study):
    districts = pd.read_csv(study/"data"/"house_districts.csv")
    sample = pd.read_csv(study/"data"/"prior_house_sample.csv")
    current_cols = DISTRICT+["st_dist_redist_FE","d2pshare","incumbency","normalvote_demean","redist"]
    sample = sample.drop(columns=["redist"])
    sample = sample.merge(districts[current_cols],on=DISTRICT,validate="one_to_one")
    prior = districts[districts.flag_exclude.ne(1) & districts.votes_d.gt(0) & districts.votes_r.gt(0)][current_cols].copy()
    prior["year"] += 2
    prior = prior.drop(columns="redist").rename(columns={
        "d2pshare":"house_previous","incumbency":"incumbency_previous",
        "normalvote_demean":"baseline_previous"})
    # Use the authors' redistricting-era identifiers as well as district numbers.
    sample = sample.merge(prior,on=DISTRICT+["st_dist_redist_FE"],validate="one_to_one")
    assert sample.redist.eq(0).all()
    sample["signed_score10"] = 10*sample.party*sample.score
    sample["house_change"] = sample.d2pshare-sample.house_previous
    return sample.dropna(subset=["d2pshare","house_previous","incumbency","incumbency_previous",
                                "normalvote_demean","baseline_previous"]).copy()

def main(study, output):
    output.mkdir(parents=True,exist_ok=True)
    d = matched_sample(study)
    specs = [
        ("Current baseline, same matched sample", "d2pshare",["normalvote_demean","incumbency"]),
        ("Current baseline plus prior House result", "d2pshare",["normalvote_demean","incumbency","house_previous"]),
        ("Pre-election baseline, same matched sample", "d2pshare",["baseline_previous","incumbency"]),
        ("Pre-election baseline plus prior House result", "d2pshare",["baseline_previous","incumbency","house_previous"]),
        ("Previous House election placebo", "house_previous",["baseline_previous","incumbency_previous"]),
        ("Change in House share, pre-election baseline", "house_change",["baseline_previous","incumbency","incumbency_previous"]),
    ]
    rows = [regression(d,outcome,controls,label) for label,outcome,controls in specs]
    # Hold covariates fixed to make the difference in level coefficients algebraically comparable.
    shared_controls = ["baseline_previous","incumbency","incumbency_previous"]
    for label,outcome in [("Current outcome, common controls","d2pshare"),("Previous outcome, common controls","house_previous")]:
        rows.append(regression(d,outcome,shared_controls,label))
    for label,outcome,controls in specs[2:6]:
        rows.append(regression(d,outcome,controls,label+"; year FE only",state_fixed=False))
    results = pd.DataFrame(rows)
    results.to_csv(output/"house_history_estimates.csv",index=False,float_format="%.8f")
    print(results.drop(columns=["controls","se"]).round(3).to_string(index=False))

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--study", type=Path, default=ROOT,
                        help="Extracted public study directory after prepare_inputs.py.")
    parser.add_argument("--output", type=Path, default=OUTPUT,
                        help="Directory for the aggregate estimate table.")
    arguments = parser.parse_args()
    main(arguments.study, arguments.output)
