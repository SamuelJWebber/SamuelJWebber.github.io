# Senate coattails

Samuel Webber

This study estimates **conditional historical associations** between a Senate candidate's prior electoral performance and the votes for their party's House and gubernatorial candidates. It also checks a separate indicator based on newspaper endorsements.

**Causal effects remain unidentified.** State and election-year controls account for stable state differences and common national changes. They leave changing state-party shocks, opponent selection and other confounding possible. The senator's score is taken from the election six years earlier (t−6), and may already contain earlier coattails. Adding the House result from two years earlier (t−2) estimates the additional current association beyond prior recorded support, potentially absorbing a real, persistent effect. The new identification checks compare these specifications on the same sample. Their uncertainty intervals depend on the model and do not incorporate unidentified confounding. Read `IDENTIFICATION.md` before interpreting the coefficients.

## Reproduce from the election returns

Python 3.10 or later is required. Run the following commands from the extracted folder. The verification used Python 3.12, pandas 2.2.3, NumPy 2.3.5, SciPy 1.17.0 and pyreadr 0.5.9. Limiting BLAS threads to one can speed up the modeling on machines with many CPUs.

    python -m pip install numpy pandas scipy pyreadr
    python rebuild_governor_returns.py
    python prepare_inputs.py
    python replicate.py
    python prior_incumbents.py
    python prior_tails.py
    python identification_checks.py

The first command after installation reconstructs 999 statewide gubernatorial returns from the included public county counts. The second fetches the district dataset from Harvard Dataverse, checks its SHA-256 fingerprint, pools candidate vote lines and matches reelection nominees to winners from six years earlier. It prepares 3,175 House rows from 423 Senate elections and a distinct sample of 196 governor elections. The modeling scripts generate the estimate tables and other diagnostic outputs under `results/`. The identification check uses unchanged House district boundaries to match current and preceding results, then compares level, lag-adjusted, prior-outcome and change specifications on the same 2,151 election pairs.

The preparation step requires public internet access to the [source district returns](https://doi.org/10.7910/DVN/J6C26T). If you already have the original `H_dist_election_data.tab`, run `python prepare_inputs.py --district-file /path/to/H_dist_election_data.tab` in place of the second command. Its expected SHA-256 fingerprint is `b229f5c7e42045ff868b75f0502c10365216e3a4f5531faa2e803c38c744da5c`.

## Read the tables

| File | Contents |
|---|---|
| `results/prior_incumbent_estimates.csv` | How prior performance predicts the next Senate, House and governor results, including continuous-score and 15-point threshold estimates |
| `results/prior_tails/tail_estimates.csv` | Top and bottom deciles versus the middle, fixed threshold checks and separate slopes on either side of the median |
| `results/prior_tails/cutoffs.csv`, `threshold_counts.csv`, `leave_one_state_out.csv` | Shared cutoffs, group sizes, and sensitivity to omitting individual states |
| `results/identification/house_history_estimates.csv` | Current and previous House outcomes, lag-adjusted models and changes in support on a common sample |
| `results/house_estimates.csv`, `governor_estimates.csv`, `senate_estimate.csv` | Models using the separate indicator of Senate matchup quality derived from newspaper endorsements |
| `METHODS.md`, `README_tails.md`, `IDENTIFICATION.md` | Model specifications, comparison groups, uncertainty calculations and limitations |

All effects are reported in percentage points. Regressions use two-party vote shares or, for the incumbent's own reelection model, the change relative to the partisan benchmark. The number of congressional district observations exceeds the number of independent Senate election exposures.

## Data provenance

- The MIT Election Data and Science Lab [Senate returns](https://doi.org/10.7910/DVN/PEJ5QU) (version 8.0, file 13887039) and [presidential returns](https://doi.org/10.7910/DVN/42MVDX) (version 10.1, file 13887042) are under CC0 1.0.
- The [Algara and Amlani county election returns](https://doi.org/10.7910/DVN/DGUMFI) (version 1.1, file 5028535) are under CC0 1.0. This package includes governor county returns, the statewide aggregation and the aggregation script.
- The [DeLuca, Moskowitz and Schneer replication dataset](https://doi.org/10.7910/DVN/J6C26T) (version 1.0, file 11807548) provides district returns and election-quality indicators. Harvard Dataverse lists limited-use information and no explicit redistribution license. The preparation script retrieves that file from the source. The archive distributes aggregate estimates from the analysis and builds the intermediate row-level files on the reader's machine. See the [paper](https://doi.org/10.1111/ajps.70025) for the original measurement and research design.
