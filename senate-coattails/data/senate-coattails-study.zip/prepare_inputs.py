"""Fetch the authors' public district input and rebuild election samples from returns."""
import argparse
import hashlib
import io
from pathlib import Path
import re
import urllib.request

import numpy as np
import pandas as pd

BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
DISTRICT_URL = "https://dataverse.harvard.edu/api/access/datafile/11807548"
DISTRICT_SHA256 = "b229f5c7e42045ff868b75f0502c10365216e3a4f5531faa2e803c38c744da5c"
KEY = ["state_po", "year"]
STANDARD_ALIASES = {
    "LOWELL P. WEICHER, JR.": "LOWELL P. WEICKER, JR.",
    "CHARLES H. PEREY": "CHARLES H. PERCY",
    "JOHN H. CHAFFEE": "JOHN H. CHAFEE",
    "SCHATZ, BRIAN": "BRIAN SCHATZ",
    "CORTEZ MASTO, CATHERINE": "CATHERINE CORTEZ MASTO",
}
UNRELATED_SAME_SURNAME = {("AK", 2004), ("OK", 1996), ("RI", 2000)}


def district_file(local_file):
    if local_file:
        content = local_file.read_bytes()
    else:
        request = urllib.request.Request(DISTRICT_URL, headers={"User-Agent": "SenateCoattails-study/1.0"})
        with urllib.request.urlopen(request, timeout=120) as response:
            content = response.read()
    if hashlib.sha256(content).hexdigest() != DISTRICT_SHA256:
        raise ValueError("The district file differs from the published version used by this study.")
    return pd.read_csv(io.BytesIO(content), sep="\t", low_memory=False)


def major_candidates(returns):
    """Assign fusion lines to named candidates, retaining the highest-vote nominee in each party."""
    returns = returns.dropna(subset=["candidate"]).copy()
    returns["candidate"] = returns.candidate.str.upper().str.strip()
    nominee_key = KEY + ["candidate"]
    totals = returns.groupby(nominee_key).candidatevotes.sum().rename("votes")
    major = (returns.loc[returns.party_simplified.isin(["DEMOCRAT", "REPUBLICAN"]),
                         nominee_key + ["party_simplified"]].drop_duplicates())
    nominees = major.merge(totals, on=nominee_key)
    # Ordering matches the treatment of ties in the original public pilot.
    nominees = nominees.sort_values("votes").drop_duplicates(KEY + ["party_simplified"], keep="last")
    wide = nominees.pivot(index=KEY, columns="party_simplified", values=["votes", "candidate"])
    wide.columns = ["_".join(parts) for parts in wide.columns]
    wide = wide.dropna().reset_index()
    d = wide.votes_DEMOCRAT.astype(float)
    r = wide.votes_REPUBLICAN.astype(float)
    return wide.assign(votes_DEMOCRAT=d, votes_REPUBLICAN=r, dshare=d / (d + r))


def presidential_lean():
    president = major_candidates(pd.read_csv(DATA / "mit_president.csv"))
    sums = president.groupby("year")[["votes_DEMOCRAT", "votes_REPUBLICAN"]].sum()
    national = sums.votes_DEMOCRAT / sums.sum(axis=1)
    president["lean"] = president.dshare - president.year.map(national)
    return president[KEY + ["lean"]]


def normalized_surname(name):
    normalized = STANDARD_ALIASES.get(name, name)
    words = re.sub("[^A-Z ]", "", normalized).split()
    return [word for word in words if word not in {"JR", "SR", "II", "III", "IV", "V"}][-1]


def incumbent_matches(lean):
    senate = pd.read_csv(DATA / "mit_senate.tsv", sep="\t")
    senate = senate[senate.year.mod(2).eq(0)].copy()
    senate["stage"] = senate.stage.str.lower()
    specials = senate.loc[senate.special, KEY].drop_duplicates().assign(has_special=True)
    senate = senate.loc[~senate.special]
    first_round = senate.loc[senate.stage.eq("pre"), KEY].drop_duplicates().assign(has_first=True)
    senate = senate.merge(first_round, on=KEY, how="left")
    senate = senate[senate.stage.eq(np.where(senate.has_first.eq(True), "pre", "gen"))]
    elections = major_candidates(senate)
    total_votes = senate.groupby(KEY).totalvotes.max().rename("total")
    elections = elections.merge(total_votes, on=KEY)
    both = elections.votes_DEMOCRAT + elections.votes_REPUBLICAN
    elections = elections[both.ge(.9 * elections.total) & elections.dshare.between(.05, .95)].copy()
    elections["presyr"] = elections.year - elections.year.mod(4)
    elections = elections.merge(lean.rename(columns={"year": "presyr"}), on=["state_po", "presyr"])
    elections["raw"] = elections.dshare - elections.lean
    elections["advantage"] = elections.raw - elections.groupby("year").raw.transform("median")
    elections["party"] = np.where(elections.dshare.gt(.5), 1, -1)
    elections["winner"] = np.where(elections.party.eq(1), elections.candidate_DEMOCRAT,
                                   elections.candidate_REPUBLICAN)
    previous = elections[KEY + ["party", "winner", "advantage"]].copy()
    previous["year"] += 6
    previous = previous.rename(columns={"advantage": "prior_advantage"})
    matches = elections.drop(columns=["party", "winner"]).merge(previous, on=KEY)
    matches["candidate"] = np.where(matches.party.eq(1), matches.candidate_DEMOCRAT,
                                    matches.candidate_REPUBLICAN)
    same_name = matches.candidate.map(normalized_surname).eq(matches.winner.map(normalized_surname))
    same_person = ~pd.MultiIndex.from_frame(matches[KEY]).isin(UNRELATED_SAME_SURNAME)
    matches = matches.loc[same_name & same_person].merge(specials, on=KEY, how="left")
    matches = matches.loc[matches.has_special.ne(True)].copy()
    matches["score"] = matches.party * matches.prior_advantage
    matches["curr_own"] = matches.party * matches.advantage
    matches["top15"] = matches.score.ge(.15).astype(int)
    matches["top10"] = matches.score.ge(.10).astype(int)
    return matches.rename(columns={"state_po": "state_abbrev"})


def house_sample(districts, matches):
    key = ["state_abbrev", "dist", "year"]
    house = districts[districts.flag_exclude.ne(1) & districts.votes_d.gt(0) & districts.votes_r.gt(0)]
    previous = house[key + ["d2pshare"]].copy()
    previous["year"] += 2
    house = house.merge(previous.rename(columns={"d2pshare": "previous"}), on=key, how="left")
    house = house.merge(matches, on=["state_abbrev", "year"])
    house = house[house.incumbency_S.eq(house.party)].copy()
    house["out"] = house.party * (house.d2pshare - .5)
    house["baseline"] = house.party * house.normalvote_demean
    house["inc"] = house.party * house.incumbency
    house["q"] = house.party * house.news_quality
    house["past"] = house.party * (house.previous - .5)
    house["ycat"] = house.party.astype(str) + "_" + house.year.astype(str)
    house["scat"] = house.party.astype(str) + "_" + house.state_abbrev
    columns = ["state_abbrev", "year", "dist", "candidate", "party", "score", "curr_own", "out",
               "baseline", "inc", "q", "past", "ycat", "scat", "top15", "top10", "redist",
               "presyear", "topticket_race"]
    return house.dropna(subset=["out", "baseline", "inc"])[columns]


def governor_sample(districts, matches, lean):
    key = ["state_abbrev", "year"]
    fields = ["news_quality_G", "incumbency_S", "incumbency_G"]
    ratings = (districts[districts.topticket_race.eq("GS")]
               .groupby(key, as_index=False)[fields].mean())
    gov = pd.read_csv(DATA / "governor_state_returns.csv").merge(ratings, on=key).merge(matches, on=key)
    use = (gov.incumbency_S.eq(gov.party) & gov.missing_counties.eq(0) &
           gov.share.between(.05, .95) & gov.major_party_fraction.ge(.8))
    gov = gov.loc[use].copy()
    gov["last_presidential"] = gov.year - 1 - (gov.year - 1).mod(4)
    baseline = lean.rename(columns={"state_po": "state_abbrev", "year": "last_presidential", "lean": "prev_lean"})
    gov = gov.merge(baseline, on=["state_abbrev", "last_presidential"])
    gov["signed_score"] = gov.party * gov.score
    columns = key + ["candidate", "party", "score", "share", "signed_score", "prev_lean",
                     "incumbency_G", "news_quality_G", "top15"]
    return gov[columns]


def prepare(local_file=None):
    district = district_file(local_file)
    district.to_csv(DATA / "house_districts.csv", index=False)
    lean = presidential_lean()
    matches = incumbent_matches(lean)
    house = house_sample(district, matches)
    governor = governor_sample(district, matches, lean)
    house.to_csv(DATA / "prior_house_sample.csv", index=False)
    governor.to_csv(DATA / "prior_governor_sample.csv", index=False)
    print(f"Built {len(house):,} House rows and {len(governor):,} governor rows.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--district-file", type=Path, help="Use a previously downloaded H_dist_election_data.tab.")
    prepare(parser.parse_args().district_file)
