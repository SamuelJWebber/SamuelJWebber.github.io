"""Rebuild the statewide governor file from the bundled CC0 Algara/Amlani county returns."""
from pathlib import Path

import pandas as pd
import pyreadr

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"


def main():
    county = pyreadr.read_r(str(DATA / "governor_county_returns.Rdata"))["gov_elections_release"]
    county = county[county.election_year.ge(1950)].copy()
    vote_fields = ["democratic_raw_votes", "republican_raw_votes", "raw_county_vote_totals"]
    county["missing"] = county[vote_fields].isna().any(axis=1)
    state = (county.groupby(["state", "election_year"], as_index=False)
             .agg(dem_votes=("democratic_raw_votes", "sum"), rep_votes=("republican_raw_votes", "sum"),
                  total_votes=("raw_county_vote_totals", "sum"), counties=("fips", "size"),
                  missing_counties=("missing", "sum"), election_type=("election_type", "first"),
                  seat_status=("seat_status", "first"), dem_nominee=("dem_nominee", "first"),
                  rep_nominee=("rep_nominee", "first"))
             .rename(columns={"state": "state_abbrev", "election_year": "year"}))
    state["year"] = state.year.astype(int)
    major = state.dem_votes + state.rep_votes
    state["share"] = state.dem_votes / major
    state["major_party_fraction"] = major / state.total_votes
    state.to_csv(DATA / "governor_state_returns.csv", index=False)


if __name__ == "__main__":
    main()
