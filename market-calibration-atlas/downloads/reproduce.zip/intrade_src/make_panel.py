"""Convert Imai, Quantitative Social Science, Chapter 4 Intrade daily closes to trade-day observations."""
from pathlib import Path
import pandas as pd
import duckdb
root=Path(__file__).resolve().parent
frames=[]
for yy,vote,challenger in [('08','2008-11-04','McCain'),('12','2012-11-06','Romney')]:
    p=pd.read_csv(root/('intrade'+yy+'.csv'))
    results=pd.read_csv(root/('pres'+yy+'.csv')).set_index('state')
    # Intrade states settle to $10 if the nominee wins the state's popular vote.
    assert not (results.Obama==results[challenger]).any()
    anchor=pd.Timestamp(vote)
    for side in ('D','R'):
        sel=(p['Volume'+side]>0)&p['Price'+side].gt(0)&p['Price'+side].le(100)&(p.day<vote)
        cur=p.loc[sel].copy()
        out=pd.DataFrame({'market_id':'INTRADE-'+yy+'-'+cur.state+'-'+side,
            'event_id':'INTRADE-PRES-'+yy+'-'+cur.state,'topic':'US presidential state winners',
            'broad':'Politics','days':(anchor-pd.to_datetime(cur.day)).dt.days,'price':cur['Price'+side]/100,
            'outcome':cur.state.map(results.Obama>results[challenger]).eq(side=='D').astype('int8'),'anchor':anchor})
        frames.append(out)
panel=pd.concat(frames,ignore_index=True)
assert not panel.duplicated(['market_id','days']).any()
assert panel.groupby('market_id').outcome.nunique().max()==1
assert (panel.groupby('event_id').outcome.nunique() == panel.groupby('event_id').market_id.nunique()).all()
duckdb.sql("copy (select * from panel) to '"+str(root.parent/'intrade.parquet')+"' (format parquet,compression zstd)")
print(len(panel),panel.market_id.nunique(),panel.event_id.nunique(),panel.days.max(),panel.anchor.min(),panel.anchor.max(),panel[panel.days>365].shape)
print(panel.groupby('anchor').agg({'market_id':'nunique','event_id':'nunique','days':'max'}))
