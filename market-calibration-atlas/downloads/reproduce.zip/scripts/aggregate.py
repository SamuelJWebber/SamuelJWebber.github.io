"""Aggregate eligible favorite forecasts from the original contract/horizon panel.

Each day summary is [contracts, distinct events, Brier score, favorite win rate,
signed calibration bias]. Bias is the mean favorite outcome minus forecast,
using every original price directly. Only favorites priced at least 51% qualify.
Per-price rows are [bucket, contracts, events, mean probability, wins]. Day-level
price arrays use alias strings for identical groupings. Topic IDs come from the
full archive taxonomy. Each eligible contract/horizon appears exactly once.
"""
import argparse
import gzip
import json
from pathlib import Path
import duckdb

BENCHMARKS = {1, 7, 30, 90, 180, 365, 730, 1095}
# Match the browser's twelve decimal places on the *percent* scale when
# identifying a displayed price. The underlying p stays unrounded for metrics.
PRICE_DECIMALS = 12


def create_favorites(db):
    db.execute(f"""
        create or replace temp view favorites as
        with folded as (
          select *, greatest(price::double,1-price::double) as fp,
                 case when price >= 0.5 then outcome else 1-outcome end::int as y
          from panel
        )
        select * exclude (fp), fp as p from folded
        where round(fp*100,{PRICE_DECIMALS}) >= 51
    """)


def rounded(value):
    return None if value is None else round(float(value), 6)

def atomic_json(path, obj, compress=False):
    raw = json.dumps(obj, separators=(',', ':'), allow_nan=False, ensure_ascii=False).encode()
    if compress:
        raw = gzip.compress(raw, compresslevel=5, mtime=0)
        if len(raw) >= 15_000_000:
            raise ValueError(f'{path} exceeds the 15 MB shard budget')
    temp = path.with_name(path.name + '.partial')
    temp.write_bytes(raw)
    temp.replace(path)

def build_topic(db, predicate, params):
    db.execute('create or replace temp view selected as select * from base')
    if predicate:
        # Bind the single topic label as data; the column is chosen by the calling code.
        db.execute(f'create or replace temp table subset as select * from base where {predicate} = ?',params)
        db.execute('create or replace temp view selected as select * from subset')
    days = {}
    for d, n, events, brier, hit, bias in db.execute("""
        select days,count(*),count(distinct event_id),avg((p-y)^2),avg(y),avg(y-p)
        from selected group by days order by days
    """).fetchall():
        days[d] = {'s':[n,events,rounded(brier),rounded(hit),rounded(bias)]}
    for key, column, condition in [('b','band',''),('c','cent',''),('x','cent','where exact')]:
        for day in days.values():
            day[key] = []
        for d, bucket, n, events, mean, wins in db.execute(f"""
            select days,{column},count(*),count(distinct event_id),avg(p),sum(y)
            from selected {condition} group by days,{column} order by days,{column}
        """).fetchall():
            days[d][key].append([bucket,n,events,rounded(mean),wins])
    for day in days.values():
        n=day['s'][0]
        assert sum(r[1] for r in day['c'])==sum(r[1] for r in day['b'])==n
        assert sum(r[1] for r in day['x'])<=n
        if day['x']==day['c']:
            day['x']='c'
        day['f']='c'
        day['fx']='c' if day['x']=='c' else 'x'
        day['fb']='b'
    return days

def run(panel, dest):
    venue=panel.stem
    dest=dest/venue
    dest.mkdir(parents=True,exist_ok=True)
    db=duckdb.connect()
    db.execute("set TimeZone='UTC'")
    db.execute("set threads=2")
    db.execute("set memory_limit='1600MB'")
    db.read_parquet(str(panel)).create_view('panel')
    metrics=db.sql("""
        select count(*),count(distinct market_id),count(distinct event_id),max(days),
               min(anchor)::date,max(anchor)::date,count(distinct (market_id,days)),
               count(*) filter(where market_id is null or event_id is null or topic is null or broad is null
                   or not isfinite(price) or price not between 0 and 1 or price is null
                   or outcome not in (0,1) or outcome is null or days is null or days<1 or days!=floor(days)
                   or anchor is null)
        from panel
    """).fetchall()[0]
    total,n,events,max_days,first,last,pairs,bad=metrics
    if bad or pairs!=total or total==0:
        raise ValueError(f'Panel {panel} contains {bad} invalid rows and {total-pairs} duplicate market-days, out of {total}.')
    create_favorites(db)
    db.execute(f"""create temp table base as
        select days::int as days, market_id,event_id,topic,broad,p,y,
               least(100,floor(p*100+0.5+1e-12)::int) cent,
               least(90,floor(p*10+1e-12)::int*10) band,
               round(p*100,{PRICE_DECIMALS})=round(p*100,0) as exact from favorites""")
    elig, contracts, parents, maximum, start, end = db.sql("""
        select count(*),count(distinct market_id),count(distinct event_id),
               coalesce(max(days),0),min(anchor)::date,max(anchor)::date from favorites
    """).fetchall()[0]
    topics=[('all','All topics',None,[],contracts)]
    for kind,col in [('broad','broad'),('detail','topic')]:
        # Retain the original taxonomy even when a topic has zero eligible prices.
        eligible=dict(db.sql(f'select {col},count(distinct market_id) from base group by 1').fetchall())
        for (name,) in db.sql(f'select distinct {col} from panel order by 1').fetchall():
            topics.append((kind,'All '+name if kind=='broad' else name,col,[name],eligible.get(name,0)))
    meta={'id':venue,'topics':[],'contracts':contracts,'events':parents,'observations':elig,'maxDays':maximum,
          'minDate':str(start) if start else None,'maxDate':str(end) if end else None,
          'archiveContracts':n,'archiveEvents':events,'archiveObservations':total,'archiveMaxDays':max_days,
          'archiveMinDate':str(first),'archiveMaxDate':str(last)}
    for idx,(kind,name,predicate,params,count) in enumerate(topics):
        data=build_topic(db,predicate,params)
        atomic_json(dest/f'{idx}.json.gz',data,True)
        meta['topics'].append({'id':str(idx),'name':name,'kind':kind,'n':count,'maxDays':max(data,default=0),
                               'bench':{str(d):data[d]['s'] for d in sorted(BENCHMARKS.intersection(data))}})
        if idx==0:
            print(venue,'all',elig,contracts,parents,maximum,meta['topics'][0]['bench'],flush=True)
        # Publish only complete manifests, after their corresponding shards land.
    atomic_json(dest/'meta.json',meta)
    print(venue,'topics',len(topics),'bytes',sum(p.stat().st_size for p in dest.iterdir()),flush=True)
    db.close()

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('panels',nargs='+',type=Path)
    p.add_argument('--output',type=Path,default=Path(__file__).resolve().parents[1]/'dist'/'data')
    opts=p.parse_args()
    for panel in opts.panels:
        run(panel,opts.output)
