"""Download a reproducible sample of Kalshi one-minute historical candles.

The sampling universe is the Atlas's published Kalshi panel, not all exchange
listings. Contracts are selected in fixed MD5 order independent of outcomes.
No candles are interpolated or forward-filled. `ts` is candle completion time.

Example: python scripts/intraday_kalshi.py --sample-size 1000 --workers 8
Requires duckdb and pandas. The source panel must be in dist/downloads/.
"""
import argparse
import concurrent.futures
import gzip
import hashlib
import json
import math
import time
import urllib.parse
import urllib.request
from urllib.error import HTTPError
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

import duckdb
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
BASE = 'https://api.elections.kalshi.com/trade-api/v2/historical/markets'
DOCS = 'https://docs.kalshi.com/api-reference/historical/get-historical-market-candlesticks'
COLS = ['ts', 'price', 'bid', 'ask', 'volume']


def candidates(panel, count):
    with duckdb.connect() as db:
        db.execute("set TimeZone='UTC'")
        # Distinct records assert the source taxonomy/outcome/clock is stable.
        records = db.execute('''select distinct market_id,event_id,broad,topic,outcome,
            floor(epoch(anchor))::bigint as anchor
            from read_parquet(?)
            order by md5('atlas-intraday-v1|'||market_id),market_id''', [str(panel)]).fetchall()
    assert len(records) == len({r[0] for r in records})
    return records[:count], len(records)


def number(value, probability=False):
    if value is None:
        return None
    try:
        x = float(value)
    except (TypeError, ValueError):
        return None
    if not math.isfinite(x) or x < 0 or (probability and x > 1):
        return None
    return x


def fetch(item, cache, hours):
    market, event, broad, topic, outcome, anchor = item
    start, end = anchor-hours*3600+60, anchor
    path = cache/(urllib.parse.quote(market, safe='')+'_'+str(start)+'_'+str(end)+'.json.gz')
    fresh = False
    if path.exists():
        record = json.loads(gzip.decompress(path.read_bytes()))
    else:
        query = urllib.parse.urlencode(dict(start_ts=start,end_ts=end,period_interval=1))
        url = BASE+'/'+urllib.parse.quote(market,safe='')+'/candlesticks?'+query
        for attempt in range(3):
            try:
                with urllib.request.urlopen(url, timeout=25) as response:
                    raw = response.read()
                data = json.loads(raw)
                if data.get('ticker') != market or not isinstance(data.get('candlesticks'),list):
                    raise ValueError('Unexpected candle response')
                record = dict(retrievedAt=datetime.now(timezone.utc).isoformat(),url=url,
                              responseSha256=hashlib.sha256(raw).hexdigest(),data=data)
                path.write_bytes(gzip.compress(json.dumps(record,separators=(',',':')).encode(),mtime=0))
                fresh = True
                break
            except (OSError, ValueError) as exc:
                if attempt==2:
                    return dict(id=market,event=event,broad=broad,topic=topic,outcome=outcome,
                                anchor=anchor,rows=[],status='unavailable'), None
                delay=1+attempt*2
                if isinstance(exc,HTTPError) and exc.code==429:
                    try:
                        delay=max(2**(attempt+1),min(30,float(exc.headers.get('Retry-After','2'))))
                    except ValueError:
                        delay=2**(attempt+1)
                time.sleep(delay)
    data = record['data']
    rows, seen = [], set()
    for bar in sorted(data['candlesticks'],key=lambda x:x['end_period_ts']):
        ts = bar['end_period_ts']
        if not isinstance(ts,int) or not start <= ts <= end:
            continue
        assert ts not in seen, (market,ts)
        seen.add(ts)
        price=number(bar.get('price',{}).get('close'),True)
        bid=number(bar.get('yes_bid',{}).get('close'),True)
        ask=number(bar.get('yes_ask',{}).get('close'),True)
        volume=number(bar.get('volume'))
        # Retain null trade closes and zero-volume quote observations faithfully.
        # A crossed or malformed quote is unavailable, never silently repaired.
        if bid is None or ask is None or bid > ask:
            bid=ask=None
        if volume is None or volume<=0:
            price=None
        if price is None and bid is None:
            continue
        rows.append([ts,price,bid,ask,volume])
    result=dict(id=market,event=event,broad=broad,topic=topic,outcome=outcome,
                anchor=anchor,rows=rows,status='observed' if rows else 'empty')
    provenance=dict(market=market,retrievedAt=record['retrievedAt'],
                    responseSha256=record['responseSha256'],cached=not fresh)
    return result,provenance


def run(args):
    args.cache.mkdir(parents=True,exist_ok=True)
    selected,universe=candidates(args.panel,args.sample_size)
    started=time.monotonic()
    results,provenance=[],[]
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.workers) as pool:
        futures=[pool.submit(fetch,item,args.cache,args.hours) for item in selected]
        for i,future in enumerate(concurrent.futures.as_completed(futures),1):
            result,source=future.result();results.append(result)
            if source:provenance.append(source)
            if i%25==0 or i==len(selected):
                print(i,'of',len(selected),'markets,',sum(len(r['rows']) for r in results),
                      'candles,',round(time.monotonic()-started,1),'seconds',flush=True)
    results.sort(key=lambda x:x['id']);provenance.sort(key=lambda x:x['market'])
    status=dict(Counter(r['status'] for r in results))
    meta=dict(venue='kalshi',createdAt=datetime.now(timezone.utc).isoformat(),
      intervalMinutes=1,lookbackHours=args.hours,sampleSize=len(selected),sourceUniverse=universe,
      firstAnchor=min(r['anchor'] for r in results),lastAnchor=max(r['anchor'] for r in results),
      sourcePanelSha256=hashlib.sha256(args.panel.read_bytes()).hexdigest(),
      source=DOCS,coverage=status,columns=COLS,
      sampleMethod="First N unique source-panel contracts in ascending MD5('atlas-intraday-v1|' + market_id), with market ID as tie-breaker. The source panel contains resolved binary contracts with at least one eligible trade at a daily horizon. Sampling does not inspect outcome or subsequent price moves.",
      clock="Reported trading close. This is not verified actual event occurrence; prices in this window may have been recorded after the public outcome.",
      priceMethod="Completed one-minute candle closes. Trade closes require positive volume. Nulls are retained; no interpolation or forward-fill. Bid and ask can be recorded in a minute without a trade. Values outside [0,1] and crossed quotes are unavailable. API 'previous' trade values are never used.",
      provenance=provenance)
    output=dict(meta=meta,markets=results)
    args.output.parent.mkdir(parents=True,exist_ok=True)
    packed=gzip.compress(json.dumps(output,separators=(',',':'),allow_nan=False).encode(),mtime=0)
    assert len(packed)<15_000_000,'Split the download before publishing above15MB'
    args.output.write_bytes(packed)
    manifest={k:v for k,v in meta.items() if k!='provenance'}
    manifest.update(normalizedDownload='data/intraday/kalshi-raw.json.gz',
                    normalizedDownloadSha256=hashlib.sha256(packed).hexdigest(),
                    provenanceLocation='meta.provenance in the normalized download',
                    provenanceResponseCount=len(provenance),
                    sampledEvents=len({r['event'] for r in results}),
                    observedContracts=sum(bool(r['rows']) for r in results))
    args.manifest.parent.mkdir(parents=True,exist_ok=True)
    args.manifest.write_text(json.dumps(manifest,separators=(',',':'),allow_nan=False))
    records=[]
    for m in results:
        for ts,price,bid,ask,vol in m['rows']:
            records.append(('kalshi',m['id'],m['event'],m['broad'],m['topic'],m['outcome'],m['anchor'],ts,price,bid,ask,vol))
    frame=pd.DataFrame(records,columns=['venue','market_id','event_id','broad','topic','outcome','anchor','ts','price','bid','ask','volume'])
    args.parquet.parent.mkdir(parents=True,exist_ok=True)
    with duckdb.connect() as db:
        db.register('frame',frame)
        db.execute('copy frame to ? (format parquet,compression zstd)',[str(args.parquet)])
    print(json.dumps(dict(markets=len(results),candles=len(frame),status=status,bytes=len(packed),
                         tradeCandles=int(frame.price.notna().sum()),output=str(args.output),parquet=str(args.parquet))),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--panel',type=Path,default=ROOT/'dist/downloads/kalshi.parquet')
    parser.add_argument('--sample-size',type=int,default=1000)
    parser.add_argument('--hours',type=int,default=72)
    parser.add_argument('--workers',type=int,default=8)
    parser.add_argument('--cache',type=Path,default=Path('/tmp/atlas-intraday-kalshi/candles'))
    parser.add_argument('--output',type=Path,default=ROOT/'dist/data/intraday/kalshi-raw.json.gz')
    parser.add_argument('--parquet',type=Path,default=Path('/tmp/atlas-intraday-kalshi/normalized.parquet'))
    parser.add_argument('--manifest',type=Path,default=Path('/tmp/atlas-intraday-kalshi/manifest.json'))
    args=parser.parse_args()
    assert 1<=args.sample_size<=10000 and 1<=args.workers<=12 and 1<=args.hours<=72
    run(args)
