"""Paired trade-close versus bid/ask-midpoint checks for Kalshi price shocks.

Run offline from the dashboard checkout:
  python scripts/shock_quote_checks.py

Inputs are the public Kalshi minute-bar and shock-candidate downloads. Candidate
selection is unchanged; trade and midpoint metrics use exactly the same episodes
and exact observation times. Requires the intraday analysis dependencies.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import gzip
import hashlib
import json
import math
from pathlib import Path

import pandas as pd

from intraday_analysis import emit, estimate

ROOT = Path(__file__).resolve().parents[1]
OFFSETS = [0, 1, 2, 5, 10, 15, 30, 60]
CHECKS = [
    dict(id='default', label='All qualifying shocks', minimum=.05, volume=0, spread=None),
    dict(id='large20', label='First-bar jump at least 20 points', minimum=.20, volume=0, spread=None),
    dict(id='spread10', label='Endpoint spreads at most 10 cents', minimum=.05, volume=0, spread=.10),
    dict(id='spread5', label='Endpoint spreads at most 5 cents', minimum=.05, volume=0, spread=.05),
    dict(id='spread2', label='Endpoint spreads at most 2 cents', minimum=.05, volume=0, spread=.02),
    dict(id='volume100', label='At least 100 contracts in first bar', minimum=.05, volume=100, spread=None),
    dict(id='volume1000', label='At least 1,000 contracts in first bar', minimum=.05, volume=1000, spread=None),
    dict(id='spread5_volume100', label='Spread at most 5 cents and volume at least 100', minimum=.05, volume=100, spread=.05),
    dict(id='boundary_quotes', label='Include quotes at zero or one', minimum=.05, volume=0, spread=None, inclusive=True),
]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def finite(x):
    return x is not None and math.isfinite(float(x))


def quote(bid, ask, inclusive=False):
    if not finite(bid) or not finite(ask):
        return None
    if not (0 <= bid <= ask <= 1 if inclusive else 0 < bid <= ask < 1):
        return None
    return (bid + ask) / 2


def active(row):
    return row is not None and finite(row[1]) and 0 <= row[1] <= 1 and row[4] > 0


def select(episodes, settings):
    """The only future-dependent operation follows this selection function."""
    last, chosen = {}, []
    for e in episodes:
        jump = e['initial'] - e['before']
        if jump + 1e-9 < max(settings['minimum'], 4 * e['noise']):
            continue
        if e['volume'] < settings['volume']:
            continue
        if settings['spread'] is not None:
            spreads = e['spreads'][:2]
            if any(s is None or s > settings['spread'] + 1e-9 for s in spreads):
                continue
        if e['ts'] < last.get(e['market'], -math.inf) + 21600:
            continue
        chosen.append(e)
        last[e['market']] = e['ts']
    return chosen


def metric_summary(episodes, basis):
    result = {'path': {}}
    for index, name in enumerate(['before'] + [str(x) for x in OFFSETS]):
        records = []
        for e in episodes:
            p = e[basis][index]
            initial = e[basis][1]
            y = e['won']
            records.append(dict(event_id=e['event'], expected=p, observed=y,
                gap=p-y, brier=(p-y)**2, drift=p-initial,
                brierGain=(initial-y)**2-(p-y)**2,
                initialJump=initial-e[basis][0]))
        frame = pd.DataFrame(records)
        names = ['expected','observed','gap','brier','drift','brierGain','initialJump']
        metrics = estimate(frame,names) if records else dict(n=0,events=0,ci={},**{k:None for k in names})
        if name == 'before':
            result['before'] = metrics
        else:
            result['path'][name] = metrics
    return result


def paired_differences(episodes, midpoint_key):
    records = []
    for e in episodes:
        t, m, y = e['trade'], e[midpoint_key], e['won']
        records.append(dict(event_id=e['event'],
            tradeMinusMidpointInitialJump=(t[1]-t[0])-(m[1]-m[0]),
            tradeMinusMidpointInitialGap=t[1]-m[1],
            tradeMinusMidpointDrift=(t[-1]-t[1])-(m[-1]-m[1]),
            midpointMinusTradeBrierGain=((m[1]-y)**2-(m[-1]-y)**2)-((t[1]-y)**2-(t[-1]-y)**2),
            meanEndpointSpread=(e['spreads'][0]+e['spreads'][1])/2
                if e['spreads'][0] is not None and e['spreads'][1] is not None else
                (e['inclusiveSpreads'][0]+e['inclusiveSpreads'][1])/2))
    names=['tradeMinusMidpointInitialJump','tradeMinusMidpointInitialGap',
           'tradeMinusMidpointDrift','midpointMinusTradeBrierGain','meanEndpointSpread']
    return estimate(pd.DataFrame(records),names) if records else dict(n=0,events=0,ci={},**{k:None for k in names})


def analyze(raw_path, candidate_path, output):
    output.mkdir(parents=True,exist_ok=True)
    raw=json.loads(gzip.decompress(raw_path.read_bytes()))
    candidates=json.loads(gzip.decompress(candidate_path.read_bytes()))
    assert raw['meta']['columns']==['ts','price','bid','ask','volume']
    assert candidates['meta']['venue']=='kalshi'
    c={k:i for i,k in enumerate(candidates['columns'])}
    requested={}
    for r in candidates['rows']:
        market=candidates['markets'][r[c['market']]]['id']
        ts=r[c['ts']]
        requested.setdefault(market,set()).update([ts-60]+[ts+x*60 for x in OFFSETS])
    observations={}
    source_markets={}
    for m in raw['markets']:
        if m['id'] not in requested:
            continue
        source_markets[m['id']]=m
        target=requested[m['id']]
        seen={r[0]:r for r in m['rows'] if r[0] in target}
        assert len(seen)==len([r for r in m['rows'] if r[0] in target])
        observations[m['id']]=seen
    episodes=[]
    for r in candidates['rows']:
        market=candidates['markets'][r[c['market']]]
        ticker=market['id'];ts=r[c['ts']];obs=observations[ticker]
        initial, prior=obs[ts],obs[ts-60]
        assert active(initial) and active(prior)
        direction=1 if initial[1]>prior[1] else -1
        orient=lambda p: p if direction==1 else 1-p
        assert market['event']==source_markets[ticker]['event']
        assert market['anchor']==source_markets[ticker]['anchor']
        assert r[c['won']]==(source_markets[ticker]['outcome'] if direction==1 else 1-source_markets[ticker]['outcome'])
        assert abs(orient(prior[1])-r[c['before']])<1e-7
        assert abs(orient(initial[1])-r[c['after']])<1e-7
        series={'trade':[],'midpoint':[],'midpointInclusive':[],
                'spreads':[],'inclusiveSpreads':[]}
        for target in [ts-60]+[ts+x*60 for x in OFFSETS]:
            row=obs.get(target)
            if row is None or target>market['anchor']:
                for values in series.values():values.append(None)
                continue
            t=orient(row[1]) if active(row) else None
            mid=quote(row[2],row[3]);inc=quote(row[2],row[3],inclusive=True)
            series['trade'].append(t)
            series['midpoint'].append(orient(mid) if mid is not None else None)
            series['midpointInclusive'].append(orient(inc) if inc is not None else None)
            series['spreads'].append(row[3]-row[2] if mid is not None else None)
            series['inclusiveSpreads'].append(row[3]-row[2] if inc is not None else None)
        original_indices=[candidates['meta']['offsetMinutes'].index(x) for x in OFFSETS]
        for i,old_i in enumerate(original_indices,1):
            a,b=series['trade'][i],r[c['prices']][old_i]
            assert (a is None)==(b is None)
            assert a is None or abs(a-b)<1e-7
        episodes.append(dict(market=ticker,event=market['event'],broad=market['broad'],topic=market['topic'],
            ts=ts,anchor=market['anchor'],before=r[c['before']],initial=r[c['after']],
            won=r[c['won']],noise=r[c['noise']],volume=r[c['responseVolume']],
            leadHours=r[c['leadHours']],**series))
    assert episodes==sorted(episodes,key=lambda e:(e['market'],e['ts']))
    checks=[]
    for settings in CHECKS:
        chosen=select(episodes,settings)
        trade_complete=[e for e in chosen if all(p is not None for p in e['trade'])]
        midpoint_key='midpointInclusive' if settings.get('inclusive') else 'midpoint'
        paired=[e for e in trade_complete if all(p is not None for p in e[midpoint_key])]
        if settings['id']=='default':
            assert len(chosen)==candidates['meta']['defaultCheck']['selected']
            assert len(trade_complete)==candidates['meta']['defaultCheck']['complete']
        checks.append(dict(id=settings['id'],label=settings['label'],filters=settings,
            selected=len(chosen),selectedEvents=len({e['event'] for e in chosen}),
            completeTrade=len(trade_complete),completeBoth=len(paired),
            contracts=len({e['market'] for e in paired}),events=len({e['event'] for e in paired}),
            quoteExclusions=len(trade_complete)-len(paired),
            categories={k:sum(e['broad']==k for e in paired) for k in sorted({e['broad'] for e in paired})},
            trade=metric_summary(paired,'trade'),midpoint=metric_summary(paired,midpoint_key),
            pairedDifference=paired_differences(paired,midpoint_key)))
    meta=dict(venue='kalshi',generatedDate=datetime.now(timezone.utc).date().isoformat(),
        candidateCount=len(episodes),offsetMinutes=OFFSETS,firstResponseMinutesAfterAssumedNews=2,
        inputs=[{'file':str(raw_path.relative_to(ROOT)) if raw_path.is_relative_to(ROOT) else raw_path.name,'sha256':digest(raw_path)},
                {'file':str(candidate_path.relative_to(ROOT)) if candidate_path.is_relative_to(ROOT) else candidate_path.name,'sha256':digest(candidate_path)}],
        sourceDownload='data/intraday/kalshi-raw.json.gz',candidateDownload='data/intraday/kalshi-shocks.json.gz',
        pairedDownload='data/intraday/shock-quote-pairs.json.gz',
        primaryQuoteRule='Both quotes finite and strictly inside (0,1), with bid <= ask. Midpoint is (bid+ask)/2. Prices and outcomes remain oriented by the original trade-detected jump.',
        boundarySensitivity='A separate sensitivity permits zero and one quotes while still requiring 0 <= bid <= ask <= 1; these may include one-sided or non-executable quotes.',
        selection='Apply size, four-times-prior-noise, minimum first-bar volume and endpoint spread filters before greedy six-hour spacing. Follow-up availability does not choose or replace shocks. The paired cohort then requires exact active trade bars and usable quotes at the prior bar, first response, and every displayed follow-up through 60 minutes.',
        estimand='Conditional trade-close versus midpoint comparison on identical trade-detected shocks, oriented sides and times. Paired differences use the same episodes; this is not a separately midpoint-detected sample.',
        interval='Approximate 95% Student-t intervals cluster by parent event, suppressed below 20 groups or zero variance. These are exploratory pointwise intervals, without multiplicity correction.',
        limitations=['Minute-close quotes and last trades can occur at different moments within the minute; quote age and executable depth are not observed.',
            'A midpoint is a price-noise sensitivity, not an observed true probability. Trade-triggered selection remains endogenous.',
            'Complete paths and valid-quote screening favor active markets. The underlying 1,000-contract Kalshi sample is selected from a daily-history universe and is mostly sports here.',
            'This does not validate the Polymarket reversal estimate: historical bid and ask quotes are absent from its five-minute archive.',
            'Later news and unverified real-world event timing remain unresolved.'])
    payload=dict(meta=meta,checks=checks)
    emit(output/'shock-quote-checks.json',payload)
    emit(output/'shock-quote-pairs.json.gz',dict(meta=meta,episodes=episodes),compressed=True)
    for x in checks:
        print(json.dumps({'id':x['id'],'selected':x['selected'],'trade':x['completeTrade'],'both':x['completeBoth'],
            'events':x['events'],'tradeJump':x['trade']['path']['0']['initialJump'],
            'midJump':x['midpoint']['path']['0']['initialJump'],
            'tradeDrift':x['trade']['path']['60']['drift'],'midDrift':x['midpoint']['path']['60']['drift'],
            'pairedDifference':x['pairedDifference']},separators=(',',':')))
    return payload


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--raw',type=Path,default=ROOT/'dist/data/intraday/kalshi-raw.json.gz')
    p.add_argument('--candidates',type=Path,default=ROOT/'dist/data/intraday/kalshi-shocks.json.gz')
    p.add_argument('--output',type=Path,default=ROOT/'dist/data/intraday')
    a=p.parse_args()
    analyze(a.raw,a.candidates,a.output)
