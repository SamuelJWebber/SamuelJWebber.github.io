"""Recompute the sports-clock audit from a public, frozen replication dataset.

Run: python scripts/expansion_sports.py [--collect]
Requires numpy, pandas and a pandas Parquet engine (pyarrow).
--collect downloads the original deposit, verifies its published MD5, and extracts
only the four numerical input tables. No downloaded analysis code is executed.
Default is an offline rebuild from the public sports-* Parquet downloads.
"""
import argparse, hashlib, io, json, urllib.request, zipfile
from pathlib import Path
from datetime import datetime, timezone
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
URL='https://zenodo.org/records/23491301/files/clock_paper_IJF_replication.zip?download=1'
SOURCE='https://zenodo.org/records/23491301'
MD5='18d8b70a2071a90cac8a988b9c6221f5'
FILES={
 'clocks':('lead_decomposition_sample.parquet','sports-clock-input.parquet'),
 'prices':('f1_price_phase_sample.parquet','sports-price-path-input.parquet'),
 'staleness':('f1_staleness_diagnostic.parquet','sports-staleness-input.parquet'),
 'pairs':('certain_vs_live_pairs.parquet','sports-live-pair-input.parquet')}

def collect():
    raw=urllib.request.urlopen(URL,timeout=90).read()
    assert hashlib.md5(raw).hexdigest()==MD5,'Upstream deposit changed; review before use.'
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        for source,dest in FILES.values():
            (ROOT/'dist/downloads'/dest).write_bytes(z.read('replication/data/'+source))

def boot_median(df,col,seed=20261106,draws=2000):
    groups=[g[col].to_numpy(float) for _,g in df.groupby('gamePk')]
    rng=np.random.default_rng(seed)
    estimates=[np.median(np.concatenate([groups[i] for i in rng.integers(0,len(groups),len(groups))])) for _ in range(draws)]
    return [float(x) for x in np.quantile(estimates,[.025,.975])]

def summary_clock(d):
    return dict(n=len(d),games=int(d.gamePk.nunique()),
        completionMedian=float(d.from_completion.median()),pitchMedian=float(d.from_pitch.median()),
        completionIQR=[float(x) for x in d.from_completion.quantile([.25,.75])],
        pitchIQR=[float(x) for x in d.from_pitch.quantile([.25,.75])],
        fractionBeforeCompletion=float((d.from_completion<0).mean()),
        fractionBeforePitch=float((d.from_pitch<0).mean()),
        completionCI=boot_median(d,'from_completion'),pitchCI=boot_median(d,'from_pitch'))

def run():
    frames={k:pd.read_parquet(ROOT/'dist/downloads'/v[1]) for k,v in FILES.items()}
    c,p,s,pairs=(frames[x] for x in ['clocks','prices','staleness','pairs'])
    for col in ['t0','te','pitch_start']:c[col]=pd.to_datetime(c[col],utc=True)
    assert not c.duplicated(['event','te']).any()
    assert (c.distance==0).all() and c.anchored.all() and (~c.FLAGGED).all()
    c['from_completion']=(c.t0-c.te).dt.total_seconds()
    c['from_pitch']=(c.t0-c.pitch_start).dt.total_seconds()
    assert np.allclose(c.from_pitch-c.from_completion,c.duration)
    pc=['b','p_tp','p_te','p_te_30','p_te_60','p_te_120']
    assert not p[pc].isna().any().any() and p[pc].ge(0).all().all() and p[pc].le(1).all().all()
    clock=summary_clock(c)
    by_play=[]
    for play,g in c.groupby('play'):
        if len(g)>=30:
            by_play.append(dict(label=play.replace('_',' ').title(),n=len(g),games=int(g.gamePk.nunique()),
                completionMedian=float(g.from_completion.median()),pitchMedian=float(g.from_pitch.median())))
    labels=['Earlier baseline','Before pitch start','Before completion stamp','Completion +30s','Completion +60s','Completion +120s']
    path=[dict(label=label,n=len(p),games=int(p.gamePk.nunique()),meanPrice=float(p[col].mean()),
        meanDistanceToPayout=float((1-p[col]).mean()),fractionAtLeast97=float((p[col]>=.97-1e-10).mean())) for col,label in zip(pc,labels)]
    freshness=[]
    for label,d in [('All source 60s diagnostics',s),('Observed post-completion trade',s[s.has_post]),('Terminal trade at most 15s old',s[s.age_w<=15]),('Terminal trade at most 5s old',s[s.age_w<=5])]:
        freshness.append(dict(label=label,n=len(d),games=int(d.gamePk.nunique()),meanPrice=float(d.p_w.mean()),fractionAtLeast97=float((d.p_w>=.97-1e-10).mean()),medianTradeAgeSeconds=float(d.age_w.median())))
    live=pairs[pairs.live_has_base & pairs.det_has_base].copy()
    live_rows=[]
    for seconds in [10,30,60,120,600]:
        live_rows.append(dict(seconds=seconds,n=len(live),events=int(live.event.nunique()),
            determinedObservedFiveCentChange=int((live.det_lat_sust<=seconds).sum()),
            liveObservedFiveCentChange=int((live.live_lat_sust<=seconds).sum())))
    result=dict(
        title='Sports: the event clock changes the apparent reaction',status='limited',
        finding=f"On {len(c):,} selected MLB contract crossings, the same detected move is a median {abs(clock['completionMedian']):.1f} seconds before the recorded completion stamp, but {clock['pitchMedian']:.1f} seconds after the recorded pitch start. Neither timestamp is a verified information-arrival time.",
        scope='Independent recomputation from the published study’s frozen derived observations; not a new raw-data replication or a universal estimate of news-processing speed.',
        metrics=[dict(label='Contract crossings with both clocks',value=len(c)),dict(label='Games in clock sample',value=int(c.gamePk.nunique())),dict(label='Price paths',value=len(p)),dict(label='Games in price-path sample',value=int(p.gamePk.nunique()))],
        period=dict(start=c.te.min().isoformat(),end=c.te.max().isoformat()),
        clock=clock,distinctScoringPlays=int(c[['gamePk','te']].drop_duplicates().shape[0]),clockByPlay=sorted(by_play,key=lambda x:-x['n']),
        charts=[dict(id='clock',title='One price move, two recorded event clocks',kind='interval',unit='seconds',zeroLabel='Recorded event time',rows=[dict(label='Relative to completion stamp',value=clock['completionMedian'],low=clock['completionCI'][0],high=clock['completionCI'][1],n=len(c)),dict(label='Relative to pitch start',value=clock['pitchMedian'],low=clock['pitchCI'][0],high=clock['pitchCI'][1],n=len(c))]),
                dict(id='prices',title='Prices around plays that determine the payout',kind='categorical-line',unit='probability',rows=[dict(label=x['label'],value=x['meanPrice'],n=x['n']) for x in path])],
        pricePath=path,tradeFreshness=freshness,
        liveContractDiagnostic=dict(title='Contracts whose payout remains uncertain',n=len(live),events=int(live.event.nunique()),rows=live_rows,interpretation='Counts of first observed changes of at least 5 cents from the last pre-completion trade. This measures recorded trading activity, not accuracy or complete information incorporation. Some price adjustment already occurs before the completion stamp. Missing detections are not assigned a reaction time.'),
        tables=[dict(title='Clock sensitivity by scoring-play type',columns=['Play type','Crossings','Median seconds from completion','Median seconds from pitch start'],rows=[[x['label'],x['n'],round(x['completionMedian'],2),round(x['pitchMedian'],2)] for x in sorted(by_play,key=lambda x:-x['n'])]),dict(title='Terminal-price sensitivity to stale trades',columns=['Selection','Paths','Games','Mean price','At least 97 cents','Median trade age (seconds)'],rows=[[x['label'],x['n'],x['games'],x['meanPrice'],x['fractionAtLeast97'],x['medianTradeAgeSeconds']] for x in freshness])],
        methods=[
            'Downloaded and MD5-verified the 2.9 MB Zenodo deposit; recomputed aggregates from its numerical observation tables using our own script. The source authors’ raw trade/league archive is not included in that deposit.',
            'Clock sample: source-selected clean, anchored, distance-zero scoring crossings with both league clocks; 1,378 contract crossings on 1,377 distinct game/completion pairs (one play appears in two market ladders). Related crossings cluster by game for 2,000 fixed-seed bootstrap intervals around the median.',
            'The source detector requires a price at least 15 cents above its baseline, supported by at least two trades and a median price holding that level during the following 20 seconds. It searches from 90 seconds before to 300 seconds after the completion stamp. This is retrospective selection, not an online trading rule.',
            'Price sample: 1,215 fixed paths in 644 games, baseline price between 30 and 90 cents. Baseline is the median trade 8 minutes to 90 seconds before pitch start. Other prices are last trades at or before each target; pre-start and pre-completion observations have a one-second guard.',
            'The 60-second staleness table is the source’s slightly narrower 1,213-path subset requiring more than a two-cent total upward move. It separately reports actual post-completion trading and age-limited terminal prices.',
            'Non-resolving paired-rung counts use the nearest still-live total-runs contract after the same scoring play and require pre-completion prices on both sides. They are descriptive activity diagnostics, not fair-probability validation.'
        ],
        limitations=[
            'Pitch start, play completion, broadcast arrival and when traders learn the outcome are different clocks. These results do not establish foresight, insider trading, or a causal reaction time.',
            'The main price paths are contracts whose payout becomes determined by the scoring play, conditional on the play standing; they do not answer whether markets correctly price news that leaves the outcome uncertain.',
            'Source selection requires detectable sustained upward moves and trading coverage. Results are conditional on selected crossings, not representative of all sports markets or all news.',
            'Last-trade prices can be stale, reflect bid–ask effects and differ from executable quotes. The main 30/60/120-second path carries the last observed trade forward; the separate 60-second freshness checks expose this limitation.',
            'A price close to one can still reflect fees, settlement delay and residual event/rule risk. Payout proximity is not a risk-free trading return.',
            'We reanalyzed published derived tables, not independently reconstructed every observation from raw exchange and league feeds. The source reports limited historical trade retention.'
        ],
        sources=[dict(title='Petrov and Davison (2026), Foresight or Reaction? replication data, version 1.0',url=SOURCE,download=URL,md5=MD5)],
        inputs=[dict(path='downloads/'+dest,sourceFile=source,sha256=hashlib.sha256((ROOT/'dist/downloads'/dest).read_bytes()).hexdigest(),bytes=(ROOT/'dist/downloads'/dest).stat().st_size) for source,dest in FILES.values()],
        reproducibility=dict(script='scripts/expansion_sports.py',command='python scripts/expansion_sports.py',dependencies=['numpy','pandas','pyarrow'],bootstrapSeed=20261106,bootstrapReplicates=2000),
        download='data/expansion/sports.json'
    )
    dest=ROOT/'dist/data/expansion/sports.json';dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    print(json.dumps(dict(output=str(dest),clock=clock,pricePath=path,liveRows=live_rows),indent=2))
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--collect',action='store_true');args=parser.parse_args()
    if args.collect:collect()
    run()
