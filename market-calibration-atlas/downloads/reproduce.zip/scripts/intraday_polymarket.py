"""Download a fixed Polymarket five-minute cohort and normalize observed bars.

python scripts/intraday_polymarket.py --cache /tmp/atlas-intraday-poly

Requires DuckDB. The source is Akey, Gregoire, Harvie and Martineau's public
Polymarket Users archive, CC BY 4.0, pinned to its published revision below.
March 1--28, 2026 is the forecast-date cohort. February 28 and March 29 are
downloaded only as surrounding observation context. Bar timestamps mark START;
the output ts is the completed bar time, 300 seconds later. Never forward fills.
"""
import argparse
import concurrent.futures
from datetime import date, timedelta
import hashlib
import io
import json
from pathlib import Path
import time
import urllib.request
import zipfile

import duckdb

REVISION = '91ddb961b090de18fd79e79edd8fa15f36ca11b9'
BASE = 'https://huggingface.co/datasets/vgregoire/polymarket-users/resolve/' + REVISION + '/'
SOURCE = 'https://www.vincentgregoire.com/polymarket-users-data/datasets/ohlcv/'
ROOT = Path(__file__).resolve().parents[1]
FIRST = date(2026, 2, 28)
LAST = date(2026, 3, 29)


def digest(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def fetch(item, cache):
    local, remote = item
    path = cache / local
    if not path.exists():
        partial = path.with_suffix(path.suffix + '.partial')
        for attempt in range(3):
            try:
                with urllib.request.urlopen(BASE + remote, timeout=90) as r:
                    partial.write_bytes(r.read())
                partial.replace(path)
                break
            except OSError:
                if attempt == 2:
                    raise
                time.sleep(1 + attempt)
    # The pinned revision and per-file digest let the exact inputs be audited.
    return dict(local=local, remote=remote, bytes=path.stat().st_size,
                sha256=digest(path))


def build(cache, output, root=ROOT, publish_shards=False):
    cache.mkdir(parents=True, exist_ok=True)
    items = [(name + '.parquet', name + '.parquet') for name in ['markets', 'predictions']]
    for i in range((LAST - FIRST).days + 1):
        d = FIRST + timedelta(days=i)
        items.append((f'five-{d}.parquet',
                      f'ohlcv_5m/year={d.year}/month={d.month:02d}/day={d.day:02d}/data.parquet'))
    with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
        manifest = []
        for n, row in enumerate(pool.map(lambda item: fetch(item, cache), items), 1):
            manifest.append(row)
            print(f'{n}/{len(items)} fetched {row["local"]} ({row["bytes"]:,} bytes)', flush=True)

    # Reuse the existing taxonomy wherever its mapping is available. This is
    # metadata only; no forecast or realized outcome determines a topic label.
    topics = cache / 'poly_topics.csv.gz'
    if not topics.exists():
        with zipfile.ZipFile(root / 'dist/downloads/reproduce.zip') as z:
            with zipfile.ZipFile(io.BytesIO(z.read('polymarket-reproduction.zip'))) as p:
                topics.write_bytes(p.read('poly_topics.csv.gz'))

    db = duckdb.connect(config={'threads': 3, 'memory_limit': '1400MB'})
    db.execute("set TimeZone='UTC'")
    db.read_parquet(str(cache / 'markets.parquet')).create_view('markets')
    db.read_parquet(str(cache / 'predictions.parquet')).create_view('predictions')
    db.read_parquet(str(cache / 'five-*.parquet'), hive_partitioning=False).create_view('bars')
    db.read_csv(str(topics), header=True).create_view('topics')
    db.execute("""create temp table chosen as
      with paired as (
        select market_id from predictions where n_outcomes=2 group by market_id
        having count(*)=2 and count(distinct outcome_idx)=2
          and count(winner)=2 and sum(winner::integer)=1
      ), side as (
        select p.market_id,p.prediction_id,p.outcome as label,p.winner::int as outcome
        from predictions p join paired using(market_id)
        qualify row_number() over(partition by p.market_id order by
          case when lower(trim(p.outcome))='yes' then 0 else 1 end,p.outcome_idx)=1
      )
      select m.market_id,c.prediction_id,c.outcome,
        case when m.category in ('Crypto','Culture','Finance','Politics','Sports','Tech','Weather')
             then m.category else 'Other' end broad,
        coalesce(t.topic,'Unclassified source category') topic,
        coalesce(m.event_id,'solo-'||m.market_id::varchar) event_id,
        c.label, m.question,
        m.market_start_time::timestamptz open_time,
        least(m.close_time,m.expiration_time)::timestamptz anchor
      from side c join markets m using(market_id) left join topics t using(market_id)
      where m.close_time::timestamptz < '2026-03-30'::timestamptz
        and least(m.close_time,m.expiration_time)>m.market_start_time
    """)
    assert db.sql('select count(*)=count(distinct market_id) from chosen').fetchall()[0][0]
    db.execute("""create temp table normalized as
      select 'polymarket' venue, m.market_id::varchar market_id,m.event_id,m.broad,m.topic,
        epoch(b.timestamp::timestamptz)::bigint+300 ts,b.close::double price,m.outcome,
        epoch(m.anchor)::bigint anchor,b.volume::double volume,b.trade_count::bigint trade_count,
        epoch(m.open_time)::bigint open_ts
      from bars b join chosen m on b.market_id::bigint=m.market_id and b.prediction_id=m.prediction_id
      where b.trade_count>0 and isfinite(b.close) and b.close between 0 and 1
        and b.volume>0 and isfinite(b.volume)
        and b.timestamp::timestamptz>=m.open_time
        and b.timestamp::timestamptz+interval '5 minutes'<=m.anchor
    """)
    stats = db.sql("""select count(*),count(distinct market_id),count(distinct event_id),
      min(ts),max(ts), count(*)-count(distinct (market_id,ts)),
      count(*) filter(where ts>anchor or ts-300<open_ts or outcome not in (0,1))
      from normalized""").fetchall()[0]
    assert stats[0] > 0 and stats[5] == stats[6] == 0, stats
    output.parent.mkdir(parents=True, exist_ok=True)
    partial = output.with_suffix(output.suffix + '.partial')
    db.sql('select * from normalized order by market_id,ts').write_parquet(str(partial), compression='zstd')
    partial.replace(output)
    rows_by_day = db.sql("select strftime(to_timestamp(ts-300),'%Y-%m-%d') as bar_day,count(*) bars,count(distinct market_id) contracts from normalized group by 1 order by 1").fetchall()
    counts = db.sql("""select
      count(*) raw_bars,count(distinct b.market_id) raw_contracts,
      count(distinct b.market_id) filter(where m.market_id is not null) selected_resolved_contracts
      from bars b left join chosen m on b.market_id::bigint=m.market_id and b.prediction_id=m.prediction_id""").fetchall()[0]
    resolution_counts = db.sql("""with ids as (
        select distinct market_id::bigint market_id from bars
      ), resolution as (
        select market_id,count(*) tokens,bool_and(n_outcomes=2) all_binary,
          count(distinct outcome_idx) indices,count(winner) settled,sum(winner::int) winners
        from predictions group by market_id
      )
      select count(*) filter(where r.all_binary and tokens=2 and indices=2 and settled<2),
        count(*) filter(where r.all_binary and tokens=2 and indices=2 and settled=2 and winners=1)
      from ids left join resolution r using(market_id)""").fetchall()[0]
    cohort_counts = db.sql("""select count(*),count(distinct market_id),count(distinct event_id)
      from normalized where ts>=epoch('2026-03-01'::timestamptz)
        and ts<epoch('2026-03-29'::timestamptz)""").fetchall()[0]
    metadata = dict(
      venue='polymarket', source=SOURCE, revision=REVISION, files=manifest,
      attribution='Akey, Grégoire, Harvie and Martineau (2026), Polymarket Users Dataset. CC BY 4.0.',
      cohortStart='2026-03-01T00:00:00Z', cohortEndExclusive='2026-03-29T00:00:00Z',
      surroundingContext=['2026-02-28','2026-03-29'], barSeconds=300,
      originalBarTimestamp='start', normalizedTimestamp='end', priceBasis='last trade in a five-minute bar',
      volumeUnit='shares/contracts of the one tracked outcome, not dollar volume or all-outcome market volume',
      rows=stats[0], contracts=stats[1], events=stats[2], firstTs=stats[3], lastTs=stats[4],
      rawBars=counts[0], rawContracts=counts[1], selectedResolvedContracts=counts[2],
      rawBinaryContractsWithMissingOutcome=resolution_counts[0],
      rawResolvedBinaryContractsBeforeClockChecks=resolution_counts[1],
      cohortRows=cohort_counts[0],cohortContracts=cohort_counts[1],cohortEvents=cohort_counts[2],
      dayCoverage=[dict(day=d,bars=n,contracts=m) for d,n,m in rows_by_day],
      outputSha256=digest(output),
      rules=[
        'Binary contracts only: exactly two outcome tokens, both settled, exactly one winner.',
        'One fixed token per contract: YES when labeled, otherwise lowest outcome index. The choice never uses the realized outcome.',
        'Bars require positive trade_count and volume, finite close in [0,1], and completion by the source anchor.',
        'The entire five-minute bucket must be after market opening. No interpolation or carried-forward prices.',
        'The source anchor is the earlier of recorded close and scheduled expiry; actual event occurrence is not independently verified.',
        'Unresolved or conflicting binary outcomes in the source snapshot are excluded, so this is a resolved-contract historical cohort.',
        'Detailed topics reuse the original Atlas mapping when available; unclassified mappings remain explicitly labeled.',
        'Context days are not part of the forecast-date cohort and must only be used for backward or forward observations.'
      ])
    if publish_shards:
        downloads = []
        for shard in range(3):
            dest = root / 'dist/downloads' / f'intraday-polymarket-{shard}.parquet'
            dest.parent.mkdir(parents=True, exist_ok=True)
            subset = db.sql(f'select * from normalized where market_id::bigint%3={shard} order by market_id,ts')
            subset.write_parquet(str(dest), compression='zstd')
            assert dest.stat().st_size < 15_000_000, f'{dest} exceeds static file budget'
            downloads.append(dict(path='downloads/'+dest.name, bytes=dest.stat().st_size,
                                  rows=db.sql(f'select count(*) from normalized where market_id::bigint%3={shard}').fetchall()[0][0],
                                  sha256=digest(dest)))
        assert sum(d['rows'] for d in downloads) == stats[0]
        metadata['normalizedDownloads'] = downloads
        metadata['normalizedSharding'] = 'Numeric market_id modulo 3. Each contract is wholly in one shard. Union all three shards without deduplicating.'
        public_meta = root / 'dist/data/intraday/polymarket-source.json'
        public_meta.parent.mkdir(parents=True, exist_ok=True)
        public_meta.write_text(json.dumps(metadata,separators=(',',':')))
    (cache / 'polymarket-intraday-manifest.json').write_text(json.dumps(metadata, separators=(',',':')))
    db.sql('select market_id::varchar market_id,event_id,broad,topic,label,question,epoch(anchor)::bigint anchor from chosen order by market_id').write_parquet(str(cache/'polymarket-intraday-markets.parquet'),compression='zstd')
    print(json.dumps({k:metadata[k] for k in ['rows','contracts','events','rawBars','rawContracts','selectedResolvedContracts','outputSha256']}),flush=True)


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--cache', type=Path, required=True)
    p.add_argument('--output', type=Path)
    p.add_argument('--root', type=Path, default=ROOT)
    p.add_argument('--publish-shards', action='store_true', help='Write three <15 MB normalized downloads and the source manifest into the dashboard.')
    args=p.parse_args()
    build(args.cache,args.output or args.cache/'polymarket-bars.parquet',args.root,args.publish_shards)
