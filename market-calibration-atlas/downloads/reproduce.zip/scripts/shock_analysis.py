"""Detect price-shock onsets using only contemporaneous and past observations.

Offline inputs are the same downloadable normalized histories as the intraday
analysis. No news timestamps are fetched: the assumed news time is one minute
before the moving bar starts. That is an explicit alignment assumption, not an
independently identified announcement. Prices are last trades, not efficient
prices or trading returns. Requires duckdb, numpy, pandas, scipy.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
import math
from pathlib import Path

import duckdb
import numpy as np
import pandas as pd

from intraday_analysis import register_source, emit, estimate

ROOT = Path(__file__).resolve().parents[1]
COLUMNS = ['market', 'ts', 'before', 'after', 'won', 'noise', 'leadHours',
           'responseVolume', 'spreadBefore', 'spreadAfter', 'quietRange',
           'historyN', 'quietN', 'prices', 'priceAges']


def rounded(value, digits=8):
    return None if value is None or not math.isfinite(float(value)) else round(float(value), digits)


def spread(bid, ask):
    return float(ask-bid) if bid is not None and ask is not None and 0 < bid <= ask < 1 else None


def selected(rows, minimum=.05, multiplier=4, lead=0, volume=0):
    """Filters and chronological spacing precede any future-price screening."""
    last, result = {}, []
    for row in rows:
        market, ts, before, after, _, noise, lead_hours, size = row[:8]
        change = after-before
        if change+1e-9 < minimum or change+1e-9 < multiplier*noise or lead_hours+1e-9 < lead or size < volume:
            continue
        if ts < last.get(market, -math.inf)+21600:
            continue
        last[market] = ts
        result.append(row)
    return result


def check_summary(rows, markets, offsets, endpoint=60):
    chosen = selected(rows)
    columns = [i for i, m in enumerate(offsets) if m <= endpoint]
    complete = [r for r in chosen if all(r[13][i] is not None for i in columns)]
    result = {'selected':len(chosen), 'selectedEvents':len({markets[r[0]]['event'] for r in chosen}),
              'complete':len(complete), 'completeEvents':len({markets[r[0]]['event'] for r in complete}),
              'endpointMinutes':endpoint, 'path':{}}
    if not complete:
        return result
    before = pd.DataFrame({'event_id':[markets[r[0]]['event'] for r in complete],
                           'expected':[r[2] for r in complete], 'observed':[r[4] for r in complete]})
    before['bias'] = before.observed-before.expected
    before['brier'] = (before.expected-before.observed)**2
    result['before'] = estimate(before)
    initial = np.array([r[3] for r in complete])
    outcome = np.array([r[4] for r in complete])
    for i in columns:
        prices = np.array([r[13][i] for r in complete])
        frame = pd.DataFrame({'event_id':before.event_id, 'expected':prices, 'observed':outcome,
            'bias':outcome-prices, 'brier':(prices-outcome)**2,
            'drift':prices-initial, 'brierGain':(initial-outcome)**2-(prices-outcome)**2})
        result['path'][str(offsets[i])] = estimate(frame,
            ['expected','observed','bias','brier','drift','brierGain'])
    return result


def analyze(venue, specification, output, cohort_start=None, cohort_end=None):
    output.mkdir(parents=True, exist_ok=True)
    bm = 5 if venue == 'polymarket' else 1
    seconds = bm*60
    minimum_returns, minimum_quiet = (6,3) if bm == 5 else (12,6)
    offsets = [0,5,10,15,30,60,180,360,1440] if bm == 5 else [0,1,2,5,10,15,30,60,180,360,1440]
    db = duckdb.connect(config={'threads':3, 'memory_limit':'1800MB'})
    combined_hash, hashes = register_source(db, specification)
    columns = {x[0] for x in db.execute('describe source').fetchall()}
    quote_columns = 'bid,ask' if {'bid','ask'} <= columns else 'NULL::double bid,NULL::double ask'
    db.execute(f'''create temp table active as select market_id,event_id,broad,topic,
        ts,price,outcome,anchor,volume,{quote_columns} from source
        where price between 0 and 1 and volume>0 and ts<=anchor''')
    active_count = db.execute('select count(*) from active').fetchone()[0]
    if bm == 5:
        cohort_start = cohort_start or '2026-03-01T00:00:00Z'
        cohort_end = cohort_end or '2026-03-29T00:00:00Z'
    def cutoff_epoch(value):
        if isinstance(value, (int, float)):
            return int(value)
        parsed = datetime.fromisoformat(str(value).replace('Z', '+00:00'))
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=timezone.utc)
        return int(parsed.timestamp())
    start_epoch = cutoff_epoch(cohort_start) if cohort_start is not None else None
    end_epoch = cutoff_epoch(cohort_end) if cohort_end is not None else None
    if start_epoch is not None and end_epoch is not None and start_epoch >= end_epoch:
        raise ValueError('Cohort start must precede its exclusive end')
    core_filter = ''.join([
        f'and ts>={start_epoch} ' if start_epoch is not None else '',
        f'and ts<{end_epoch} ' if end_epoch is not None else ''])
    # The MAD is calculated relative to THIS observation's lagged return median,
    # not a median previously calculated separately for each lagged observation.
    # Current-return selection and quiet/history availability use no future data.
    db.execute(f'''create temp table candidates as
      with a as (select *, lag(ts) over w prev_ts, lag(price) over w prev_price,
          lag(bid) over w prev_bid, lag(ask) over w prev_ask
          from active window w as (partition by market_id order by ts)),
      b as (select *, case when ts-prev_ts={seconds} then price-prev_price end delta from a),
      c as (select *, list(delta) filter(where delta is not null) over history returns,
          count(*) over quiet quiet_n, min(ts) over quiet quiet_first,
          max(price) over quiet-min(price) over quiet quiet_range
          from b window history as (partition by market_id order by ts range between 3600 preceding and 1 preceding),
          quiet as (partition by market_id order by ts range between 900 preceding and 1 preceding)),
      d as (select *,len(returns) history_n,
          1.4826*list_median(list_transform(returns,lambda x:abs(x-list_median(returns)))) noise
          from c where abs(delta)>=.05-1e-10 and quiet_n>={minimum_quiet}
          and prev_ts-quiet_first>=600 and quiet_range<=.05+1e-10 {core_filter})
      select * exclude(returns) from d where history_n>={minimum_returns}
      order by market_id,ts''')
    candidates = db.execute('select * from candidates').fetchdf()
    print(f'{venue}: {active_count:,} active source bars, {len(candidates):,} quiet-onset candidates',flush=True)
    # Only price paths for markets with a candidate are needed after detection.
    paths = db.execute('''select market_id,ts,price from active
        where market_id in (select distinct market_id from candidates)
        order by market_id,ts''').fetchdf()
    by_market = {m:(g.ts.to_numpy(np.int64),g.price.to_numpy(float))
                 for m,g in paths.groupby('market_id',sort=False)}
    markets, rows = [], []
    for market_id, group in candidates.groupby('market_id',sort=False):
        first = group.iloc[0]
        market_index = len(markets)
        markets.append(dict(id=str(market_id),event=str(first.event_id),broad=first.broad,
                            topic=first.topic,anchor=int(first.anchor)))
        times, prices = by_market[market_id]
        for r in group.itertuples(index=False):
            rising = r.delta>0
            orient = (lambda x:x) if rising else (lambda x:1-x)
            before, after = orient(r.prev_price), orient(r.price)
            outcome = int(r.outcome) if rising else 1-int(r.outcome)
            future, ages = [rounded(after)], [0]
            for minute in offsets[1:]:
                target = int(r.ts)+minute*60
                i = int(np.searchsorted(times,target,side='right'))-1
                valid = target<=r.anchor and i>=0 and times[i]>r.ts and times[i]==target
                future.append(rounded(orient(prices[i])) if valid else None)
                ages.append(rounded((target-times[i])/60) if valid else None)
            assert r.ts-r.prev_ts == seconds and after-before >= .05-1e-9
            assert r.history_n>=minimum_returns and r.quiet_n>=minimum_quiet
            assert r.prev_ts-r.quiet_first>=600 and r.quiet_range<=.05+1e-9
            assert all(p is None or 0<=p<=1 for p in future)
            assert r.noise>=0
            rows.append([market_index,int(r.ts),rounded(before),rounded(after),outcome,
                         rounded(r.noise),rounded((r.anchor-r.ts)/3600),rounded(r.volume),
                         rounded(spread(r.prev_bid,r.prev_ask)),rounded(spread(r.bid,r.ask)),
                         rounded(r.quiet_range),int(r.history_n),int(r.quiet_n),future,ages])
    assert len(rows)==len(candidates)
    assert rows==sorted(rows,key=lambda r:(r[0],r[1]))
    metadata = dict(venue=venue, generatedDate=datetime.now(timezone.utc).date().isoformat(),
        barMinutes=bm,offsetMinutes=offsets,assumedNewsLeadMinutes=1,
        firstResponseMinutesAfterAssumedNews=bm+1, minimumCandidateJump=.05,
        defaultMinimumJump=.05,defaultNoiseMultiple=4,defaultLeadHours=0,
        cooldownHours=6,quietLookbackMinutes=15,quietMaximumRange=.05,
        historyLookbackMinutes=60,minimumAdjacentReturns=minimum_returns,
        minimumQuietBars=minimum_quiet,minimumQuietSpanMinutes=10,
        maxFutureBarAgeMinutes=0,defaultComparisonMinutes=60,
        cohortStart=datetime.fromtimestamp(start_epoch, timezone.utc).isoformat() if start_epoch is not None else None,
        cohortEndExclusive=datetime.fromtimestamp(end_epoch, timezone.utc).isoformat() if end_epoch is not None else None,
        inputSha256=combined_hash,inputFiles=hashes,
        sourceBars=active_count,candidates=len(rows),candidateContracts=len(markets),
        candidateEvents=len({m['event'] for m in markets}),
        volumeUnit='shares of tracked token' if bm==5 else 'contracts',
        priceBasis='last trade in an active completed bar',
        source='data/intraday/'+venue+'-analysis.json',
        detector='Current and previous active bars must be adjacent. The preceding 15 minutes must contain at least the required number of active bars spanning at least 10 minutes, with a price range no greater than five percentage points. The preceding hour must contain enough adjacent-active-bar returns. Robust noise is 1.4826 times the median absolute deviation of those returns from their median. The current jump is excluded from that estimate. Candidates have an absolute one-bar move of at least five percentage points; the UI additionally requires the chosen minimum jump and noise multiple.',
        selection='Apply only current/past move-size, noise, source-cutoff, volume and spread filters, then keep the earliest qualifying endpoint and require six hours before another in the same contract. Select complete follow-up paths only after that spacing. Categories are metadata. Never select future maxima, largest moves, or eventual reversals.',
        timing='Assumed news time is one minute before the moving bar starts (the preceding active bar end). The first observed response is the moving bar close: six minutes after assumed news on Polymarket and two minutes on Kalshi. Actual within-bar onset and trade time are not observed. This assumption aligns price paths; it does not establish that news caused them.',
        followup='At each grid time after the first response, require an active completed bar ending exactly at that target, strictly after the first response, and only when the target is at or before recorded close. There is no interpolation or reuse of an earlier bar. The actual last trade inside that bar can precede its end by up to one bar duration. A complete path requires every displayed point through the selected endpoint.',
        interpretation='Post-shock drift is descriptive continuation or reversal; an efficient later price is not observed. Later prices can incorporate further news, not just adjustment to the initial shock. Compare the same shocks across time using signed outcome calibration and paired Brier changes. Final binary outcomes identify cohort calibration, not an individual event\'s true probability. Complete-path selection favors active markets. Announcement timestamps and actual event times are unverified; delayed close can include post-event/dispute trading. Conditioning on price shocks can select bid-ask bounce and temporary noise, so a reversal is not automatically behavioral overreaction.')
    metadata['defaultCheck'] = check_summary(rows,markets,offsets)
    payload = dict(meta=metadata,columns=COLUMNS,markets=markets,rows=rows)
    destination=output/f'{venue}-shocks.json.gz'
    size = emit(destination,payload,compressed=True)
    print(json.dumps(dict(venue=venue,output=str(destination),bytes=size,
         default=metadata['defaultCheck']),separators=(',',':')),flush=True)
    return payload


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--venue',required=True,choices=['polymarket','kalshi'])
    parser.add_argument('--bars',required=True,help='Normalized Parquet path/glob or public Kalshi JSON.gz')
    parser.add_argument('--output',type=Path,default=ROOT/'dist/data/intraday')
    parser.add_argument('--cohort-start',help='Optional inclusive UTC timestamp; Polymarket defaults to March 1, 2026')
    parser.add_argument('--cohort-end',help='Optional exclusive UTC timestamp; Polymarket defaults to March 29, 2026')
    args=parser.parse_args()
    analyze(args.venue,args.bars,args.output,args.cohort_start,args.cohort_end)
