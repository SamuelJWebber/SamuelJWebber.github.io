"""Sum contracts traded in all retained sessions up to and including each forecast date."""
import argparse
import csv
from pathlib import Path
import tempfile
import duckdb
from election_volume import iem_rows, predictit_rows, csvdict

def sessions(venue,panels,src):
    if venue=='iem':
        for market,day,_,_,volume in iem_rows(panels):
            yield market,day,0,volume
    elif venue=='intrade':
        for year in ['08','12']:
            for row in csvdict(panels/'intrade_src'/f'intrade{year}.csv'):
                for side in ['D','R']:
                    vol=row['Volume'+side]
                    if vol and vol!='NA' and float(vol)>0:
                        # A zero closing price cannot supply a forecast but the volume still counts.
                        yield f"INTRADE-{year}-{row['state']}-{side}",row['day'],0,float(vol)
    else:
        for market,day,source,_,volume in predictit_rows(src):
            # Exchange daily quotes have priority over the partial hourly recording on the same day.
            rank=0 if source=='PredictIt hourly archive 2020' else 1
            yield market,day,rank,volume
        # Read daily replication directly as well. The normalized quote file can truncate on
        # general election day for a race whose actual decision date was the January runoff.
        eligible={r['Market_ID'] for r in csvdict(src/'pi_alt'/'master_with_actuals.csv') if r['Year'] in ['2020','2022']}
        for r in csvdict(src/'pi_alt'/'market_timeseries_data.csv'):
            qty=float(r['tradeVolume'] or 0)
            if r['market_id'] in eligible and r['contract_name']=='Democratic' and qty>0:
                yield f"PI-{r['market_id']}-dem",r['date'],1,qty

def build(venue,panels,src,dest):
    with duckdb.connect(config={'threads':2}) as db,tempfile.TemporaryDirectory() as tmp:
        file=Path(tmp)/'sessions.csv'
        with file.open('w',newline='') as f:
            w=csv.writer(f);w.writerow(['market_id','day','precedence','volume']);w.writerows(sessions(venue,panels,src))
        db.read_parquet(str(panels/(venue+'.parquet'))).create_view('panel')
        db.execute('create temp table sessions as select distinct * from read_csv_auto(?)',[str(file)])
        db.execute("""create temp table daily as select market_id,day,volume from sessions qualify
                     rank() over (partition by market_id,day order by precedence desc)=1""")
        conflicts=db.sql("select count(*)-count(distinct (market_id,day)) from daily").fetchall()[0][0]
        if conflicts:raise ValueError(f'{venue} {conflicts} cases of conflicting equal-source daily volume')
        db.execute("""create temp table cumulative as select market_id,day,sum(volume) over
                     (partition by market_id order by day rows between unbounded preceding and current row)::double as volume from daily""")
        date_col="p.traded_at::date" if venue=='predictit' else "p.anchor::date-p.days::int"
        db.execute(f"""create temp table forecast_volume as select p.market_id,p.days::int as days,c.volume
                  from panel p left join cumulative c on c.market_id=p.market_id and c.day={date_col}""")
        n,bad=db.sql("select count(*),count(*) filter(where volume is null or not isfinite(volume) or volume<=0) from forecast_volume").fetchall()[0]
        assert not bad
        bad=db.sql("""select count(*) from (select volume,lag(volume) over (partition by market_id order by days desc) as prior
                      from forecast_volume) where prior>volume""").fetchall()[0][0]
        assert not bad
        out=dest/(venue+'.parquet')
        db.sql("select * from forecast_volume order by market_id,days").to_parquet(str(out)+'.partial',compression='zstd')
        Path(str(out)+'.partial').replace(out)
        print(venue,n,flush=True)
if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('venues',nargs='*',default=['iem','intrade','predictit'])
    parser.add_argument('--panels',type=Path,default=Path('/tmp/market_dash'))
    parser.add_argument('--source-root',type=Path,default=Path('/tmp'))
    parser.add_argument('--output',type=Path,default=Path('/tmp/markvol/cumulative'))
    args=parser.parse_args();args.output.mkdir(parents=True,exist_ok=True)
    for v in args.venues:build(v,args.panels,args.source_root,args.output)
