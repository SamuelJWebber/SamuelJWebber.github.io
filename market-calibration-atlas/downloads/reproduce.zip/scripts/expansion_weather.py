#!/usr/bin/env python3
"""Reproduce an NYC market/public-weather benchmark from archived inputs.

python scripts/expansion_weather.py --cache /tmp/atlas-exp-weather
Requires numpy, pandas, duckdb and lxml. No forecast is fitted on its own outcome.
Downloads are cached with SHA256 provenance in the output. This is deliberately a
limited empirical-error NBM benchmark, not the full NBM predictive distribution.
"""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timedelta, timezone
import hashlib
import json
from pathlib import Path
import time
import urllib.request

import duckdb
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
NY = 'America/New_York'
SEED = 64119


def acquire(cache, name, url):
    path = cache / name
    if not path.exists():
        for attempt in range(4):
            try:
                req = urllib.request.Request(url, headers={'User-Agent': 'MarketCalibrationAtlas/1.0 research'})
                data = urllib.request.urlopen(req, timeout=120).read()
                path.write_bytes(data)
                break
            except Exception:
                if attempt == 3:
                    raise
                time.sleep(3 * (attempt + 1))
    return path, {'file': name, 'url': url, 'bytes': path.stat().st_size,
                  'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


def forecast_days(nbm, cli, publication_hours=3):
    """One forecast per civil-midnight comparison cutoff, before the CLI day.

    CLI outcomes use midnight local STANDARD time (05Z year round), whereas
    this comparison cutoff follows civil time (04Z during daylight saving).
    Consequently the DST comparison precedes the CLI observation day by 1h.
    """
    runtimes = pd.DatetimeIndex(sorted(nbm.runtime.unique()))
    grouped = {rt: g for rt, g in nbm.groupby('runtime')}
    records = []
    for d in pd.date_range('2024-01-02', '2025-12-31', freq='D'):
        cutoff = d.tz_localize(NY).tz_convert('UTC')
        next_cutoff = (d + pd.Timedelta(days=1)).tz_localize(NY).tz_convert('UTC')
        # Buffer is a defensible sensitivity assumption, not an archived release time.
        prior = runtimes[runtimes <= cutoff - pd.Timedelta(hours=publication_hours)]
        if len(prior) == 0:
            continue
        rt = prior[-1]
        if (cutoff - rt).total_seconds() > 24 * 3600:
            continue
        g = grouped[rt]
        # NOAA: TXN maxima cover 12Z–06Z, recorded at next-day 00Z.
        # Use TMP maxima within the civil day to partially cover early hours.
        # This remains an approximation to the fixed-05Z CLI observation window.
        max_time = (d + pd.Timedelta(days=1)).tz_localize('UTC')
        tx = g.loc[(g.ftime == max_time) & g.txn.notna(), 'txn']
        hourly = g.loc[(g.ftime >= cutoff) & (g.ftime < next_cutoff), 'tmp'].dropna()
        if len(tx) != 1 or len(hourly) < 6:
            continue
        day = d.strftime('%Y-%m-%d')
        observed = cli.get(day)
        if observed is None or not np.isfinite(observed):
            continue
        point = float(max(tx.iloc[0], hourly.max()))
        records.append({'date': day, 'day': d, 'cutoff': cutoff, 'runtime': rt,
                        'nbm_txn': float(tx.iloc[0]), 'nbm_point': point,
                        'obs': float(observed), 'error': float(observed - point)})
    return {r['date']: r for r in records}


def parse_ladder(g):
    """Validate the standard complete four-interval/two-tail NYC ladder."""
    bins = []
    tails = []
    for row in g.to_dict('records'):
        suffix = row['market_id'].rsplit('-', 1)[1]
        if suffix.startswith('B'):
            middle = float(suffix[1:])
            if middle % 1 != .5:
                return None
            row.update(lo=int(middle - .5), hi=int(middle + .5))
            bins.append(row)
        elif suffix.startswith('T'):
            tails.append((float(suffix[1:]), row))
        else:
            return None
    if len(bins) != 4 or len(tails) != 2:
        return None
    bins.sort(key=lambda x: x['lo'])
    tails.sort(key=lambda x: x[0])
    if any(bins[i]['hi'] + 1 != bins[i+1]['lo'] for i in range(3)):
        return None
    if tails[0][0] != bins[0]['lo'] or tails[1][0] != bins[-1]['hi']:
        return None
    low, high = tails[0][1], tails[1][1]
    low.update(lo=None, hi=bins[0]['lo'] - 1)
    high.update(lo=bins[-1]['hi'] + 1, hi=None)
    return [low, *bins, high]


def inside(x, row):
    return ((row['lo'] is None) | (x >= (-np.inf if row['lo'] is None else row['lo']))) & ((row['hi'] is None) | (x <= (np.inf if row['hi'] is None else row['hi'])))


def paired_events(panel, forecasts, freshness_hours=6):
    accepted, exclusions = [], Counter()
    history = sorted(forecasts.values(), key=lambda r: r['date'])
    for event, g in panel.groupby('event_id', sort=True):
        try:
            day = datetime.strptime(event.split('-')[1], '%y%b%d').strftime('%Y-%m-%d')
        except ValueError:
            exclusions['unparsed_event_date'] += 1
            continue
        forecast = forecasts.get(day)
        if forecast is None:
            exclusions['missing_asof_forecast_or_cli'] += 1
            continue
        ladder = parse_ladder(g)
        if ladder is None:
            exclusions['incomplete_or_unrecognized_six_contract_ladder'] += 1
            continue
        ages = np.array([(forecast['cutoff'] - r['completed_at']).total_seconds()/3600 for r in ladder])
        if np.any(ages < 0):
            exclusions['one_or_more_prices_after_midnight_cutoff'] += 1
            continue
        if np.any(ages > freshness_hours):
            exclusions['one_or_more_prices_older_than_freshness_limit'] += 1
            continue
        raw = np.array([r['price'] for r in ladder], dtype=float)
        if np.any(~np.isfinite(raw)) or np.any(raw < 0) or np.any(raw > 1) or not (.7 <= raw.sum() <= 1.3):
            exclusions['invalid_price_or_ladder_sum_outside_0.7_to_1.3'] += 1
            continue
        y = np.array([r['outcome'] for r in ladder], dtype=int)
        if y.sum() != 1 or not np.isin(y, [0, 1]).all():
            exclusions['invalid_resolved_outcome_vector'] += 1
            continue
        # Prior 180 calendar days; skip the preceding day to allow CLI publication.
        # Final archived CLI values may still contain later corrections (disclosed).
        past = [r for r in history if forecast['day'] - pd.Timedelta(days=180) <= r['day'] <= forecast['day'] - pd.Timedelta(days=2)]
        if len(past) < 60:
            exclusions['fewer_than_60_prior_residual_days'] += 1
            continue
        samples = np.floor(forecast['nbm_point'] + np.array([r['error'] for r in past]) + .5)
        public = np.array([inside(samples, r).mean() for r in ladder])
        market = raw / raw.sum()
        obs_bin = [i for i, r in enumerate(ladder) if inside(forecast['obs'], r)]
        assert len(obs_bin) == 1 and abs(public.sum() - 1) < 1e-10
        # Outcome disagreement is kept and reported, never used as an exclusion.
        accepted.append({'date': day, 'event_id': event, 'forecast_runtime': forecast['runtime'].isoformat(),
                         'cutoff': forecast['cutoff'].isoformat(), 'nbm_point_f': forecast['nbm_point'],
                         'nbm_txn_f': forecast['nbm_txn'], 'cli_high_f': forecast['obs'],
                         'residual_days': len(past), 'training_last_date': past[-1]['date'],
                         'raw_price_sum': float(raw.sum()), 'max_price_age_hours': float(ages.max()),
                         'outcome_matches_cli': int(np.argmax(y)) == obs_bin[0],
                         'y': y, 'market': market, 'raw': raw, 'public': public,
                         'contracts': [{'market_id':r['market_id'], 'low_f':r['lo'], 'high_f':r['hi'],
                                        'last_trade':r['completed_at'].isoformat()} for r in ladder]})
    return sorted(accepted, key=lambda r: r['date']), dict(exclusions)


def fit_blend(rows):
    train = [r for r in rows if r['date'] < '2025-07-01']
    a = np.concatenate([r['market'] - r['public'] for r in train])
    b = np.concatenate([r['y'] - r['public'] for r in train])
    return float(np.clip(np.dot(a, b) / np.dot(a, a), 0, 1)), len(train)


def add_scores(rows, weight):
    for r in rows:
        r['blend'] = weight * r['market'] + (1-weight)*r['public']
        for name in ['market', 'public', 'blend', 'raw']:
            r[name + '_brier'] = float(np.mean((r[name] - r['y'])**2))


def block_ci(rows, key, other=None):
    # Fixed calendar-week clusters preserve within-week weather dependence.
    groups = {}
    for r in rows:
        k = datetime.fromisoformat(r['date']).toordinal() // 7
        groups.setdefault(k, []).append(r[key] - (r[other] if other else 0))
    totals = np.array([sum(x) for x in groups.values()]); counts = np.array([len(x) for x in groups.values()])
    rng = np.random.default_rng(SEED)
    idx = rng.integers(0, len(totals), size=(5000, len(totals)))
    boot = totals[idx].sum(axis=1)/counts[idx].sum(axis=1)
    return [float(x) for x in np.quantile(boot, [.025,.975])], len(groups)


def score_summary(rows):
    return {k: float(np.mean([r[k + '_brier'] for r in rows])) for k in ['market','public','blend','raw']}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--cache', type=Path, default=Path('/tmp/atlas-exp-weather'))
    parser.add_argument('--out', type=Path, default=ROOT/'dist/data/expansion/weather.json')
    args = parser.parse_args(); args.cache.mkdir(parents=True, exist_ok=True)
    manifest, nbms, cli = [], [], {}
    for year in [2024, 2025]:
        url = f'https://mesonet.agron.iastate.edu/cgi-bin/request/mos.py?station=KNYC&model=NBS&year1={year}&month1=1&day1=1&hour1=0&year2={year+1}&month2=1&day2=1&hour2=0'
        p, source = acquire(args.cache, f'nbm-{year}.csv', url); manifest.append(source)
        nbms.append(pd.read_csv(p, low_memory=False))
        url = f'https://mesonet.agron.iastate.edu/nws/clitable.php?station=KNYC&year={year}'
        p, source = acquire(args.cache, f'cli{year}.html', url); manifest.append(source)
        t = pd.read_html(p)[0]
        dates = pd.to_datetime(t[('Date','Date')], format='%b%d,%y', errors='coerce')
        highs = pd.to_numeric(t[('Maximum Temperature °F','Ob')], errors='coerce')
        cli.update({d.strftime('%Y-%m-%d'):float(h) for d,h in zip(dates, highs) if not pd.isna(d) and np.isfinite(h)})
    nbm = pd.concat(nbms, ignore_index=True).drop_duplicates(['runtime','ftime','station','model'])
    for c in ['runtime','ftime']: nbm[c] = pd.to_datetime(nbm[c], utc=True)
    assert set(nbm.station) == {'KNYC'} and set(nbm.model) == {'NBS'}
    # Official metadata validates the ladder interpretation and settlement station.
    examples = [('kalshi-market.json','KXHIGHNY-25NOV02-B59.5','between'),
                ('kalshi-tail.json','KXHIGHNY-25NOV02-T55','less'),
                ('kalshi-upper.json','KXHIGHNY-25NOV02-T62','greater')]
    for name, ticker, kind in examples:
        p, source = acquire(args.cache, name, f'https://api.elections.kalshi.com/trade-api/v2/historical/markets/{ticker}'); manifest.append(source)
        m = json.loads(p.read_text())['market']
        assert m['strike_type'] == kind and 'Central Park' in m['rules_primary']
    conn = duckdb.connect(); conn.execute("SET timezone='UTC'")
    panelpath = ROOT/'dist/downloads/kalshi.parquet'
    panel = conn.execute("SELECT * FROM read_parquet(?) WHERE event_id LIKE 'KXHIGHNY-25%' AND days=1", [str(panelpath)]).df()
    manifest.append({'file':'kalshi.parquet','url':'/downloads/kalshi.parquet','bytes':panelpath.stat().st_size,
                     'sha256':hashlib.sha256(panelpath.read_bytes()).hexdigest(),
                     'origin':'Existing Atlas finalized-market panel; last actual YES trade at least one day before close, from rhinot/Kalshi archive.'})
    forecasts = forecast_days(nbm, cli, 3)
    rows, exclusions = paired_events(panel, forecasts, 6)
    weight, train_n = fit_blend(rows); add_scores(rows, weight)
    test = [r for r in rows if r['date'] >= '2025-07-01']
    assert len(test) >= 30 and all(r['training_last_date'] < r['date'] for r in rows)
    means = score_summary(test)
    delta_ci, n_blocks = block_ci(test,'market_brier','public_brier')
    blend_ci, _ = block_ci(test,'blend_brier','market_brier')
    delta = means['market']-means['public']
    improvement = 1-means['market']/means['public']
    chart_rows = []
    for name, label in [('public','Public NBM baseline'),('market','Market, normalized'),('blend','Combination, weight fitted Jan–Jun')]:
        ci, _ = block_ci(test, name+'_brier')
        chart_rows.append({'label':label,'value':means[name],'lower':ci[0],'upper':ci[1],'n':len(test)})
    monthly = []
    for month in sorted(set(r['date'][:7] for r in test)):
        subset = [r for r in test if r['date'].startswith(month)]
        monthly.append({'month':month,'events':len(subset), **score_summary(subset)})
    sensitivities = []
    for buffer, freshness in [(3,2),(6,6)]:
        fr = forecast_days(nbm,cli,buffer)
        sr, _ = paired_events(panel, fr, freshness)
        sw, sn = fit_blend(sr); add_scores(sr, sw)
        st = [r for r in sr if r['date'] >= '2025-07-01']
        sensitivities.append({'forecast_buffer_hours':buffer,'max_trade_age_hours':freshness,'train_events':sn,
                              'test_events':len(st),'market_weight':sw, **score_summary(st)})
    mismatch = [r['event_id'] for r in rows if not r['outcome_matches_cli']]
    payload = {
        'title':'Weather: does the market add to a public forecast?', 'status':'limited',
        'generated_at':datetime.now(timezone.utc).isoformat(),
        'finding':f"On {len(test)} held-out NYC days in July–December 2025, normalized Kalshi prices had {abs(improvement)*100:.1f}% {'lower' if improvement>0 else 'higher'} mean binary Brier error than a simple prior-error-calibrated NBM baseline. The training-fitted combination did not clearly improve on the market. This is one city and one deliberately limited public benchmark.",
        'metrics':[{'label':'Held-out NYC days','value':len(test),'format':'integer'},
                   {'label':'Market Brier','value':means['market'],'format':'decimal'},
                   {'label':'Public baseline Brier','value':means['public'],'format':'decimal'},
                   {'label':'Combination Brier','value':means['blend'],'format':'decimal'},
                   {'label':'Training market weight','value':weight,'format':'percent'},
                   {'label':'Market minus public, 95% CI','value':f'{delta:+.4f} [{delta_ci[0]:+.4f}, {delta_ci[1]:+.4f}]','format':'text'}],
        'chart':{'type':'bar','title':'Held-out probability accuracy · July–December 2025','yLabel':'Mean binary Brier · lower is better','rows':chart_rows},
        'tables':[{'title':'Held-out months, identical event sets per row','columns':['month','events','market','public','blend'],'rows':monthly},
                  {'title':'Timing and freshness sensitivity, separately fitted on Jan–Jun','columns':['forecast_buffer_hours','max_trade_age_hours','train_events','test_events','market','public','blend'],'rows':sensitivities}],
        'methods':[
            'Unit: a complete six-contract Kalshi NYC daily-high ladder, equal weight per day. The daily score is the average of six binary Brier scores, (p − outcome)². Lower is better; this is not temperature RMSE or percent-correct.',
            'Comparison cutoff: civil midnight America/New_York on the event date derived from the ticker (04Z during daylight saving time; 05Z otherwise), not administrative settlement time. All retained price observations precede that cutoff and are no more than six hours old. NWS CLI outcomes instead cover midnight-to-midnight local STANDARD time: 05Z to next-day 05Z year round in NYC. Thus the comparison is one hour before the CLI day starts during daylight saving time, and at its start otherwise; it does not include observations from the target CLI day.',
            'Require four contiguous two-degree interior intervals and two complementary tails; retain ladders with price sums from 0.7 to 1.3 and one winning outcome. Normalize all six YES trade prices by their sum. This removes ladder incoherence, not a proven fee or bid/ask adjustment.',
            'Public input: archived as-issued NOAA NBM NBS guidance at KNYC, accessed through Iowa Environmental Mesonet. Select the latest model runtime at least three hours before the comparison cutoff; actual dissemination timestamps are unavailable.',
            'NBM point approximation is the larger of its TXN maximum (12Z through 06Z, labeled at 00Z) and three-hourly TMP forecasts inside the civil calendar day. The settlement target is the NWS CLI local-standard-time day (05Z to next-day 05Z), not the civil day; this forecast construction only approximates that target window.',
            'Convert that point forecast to six probabilities using its empirical errors on the preceding 180 calendar days, excluding the immediately preceding day and requiring at least 60 observations. Errors use archived NWS Central Park CLI highs. No current or future outcome enters a forecast.',
            'Fit one convex market/public mixing weight by minimizing Brier error on January–June 2025 only. Freeze the weight and score July–December 2025. Residual calibration updates with prior available days; there is no test-period weight tuning.',
            f'Uncertainty: 5,000 bootstrap resamples of {n_blocks} fixed seven-day calendar clusters in the held-out sample; this preserves dependence within a week, not all longer weather patterns. Seed {SEED}.',
            'Official sample rule checks confirm Central Park NWS daily climatological settlement, B59.5 = 59–60°F, T55 = below 55°F, and T62 = above 62°F. All retained ladders must follow the same contiguous suffix geometry. Outcome-vs-CLI disagreements are retained and disclosed.'
        ],
        'limitations':[
            'One city, 2025 only, and a simple empirical-error NBM model. It is not the full NBM distribution or a best-of-public-model ensemble, and cannot establish superiority over the best public forecasting system.',
            'The NBM TXN window extends one hour beyond the CLI day ending at 05Z and omits early hours; three-hourly TMP cannot reconstruct every hourly extreme. Civil-midnight comparison time is additionally one hour before the CLI observation day starts during daylight saving time. A forecast ensemble matched exactly to the 05Z–05Z observation window is the next stronger benchmark.',
            'The three-hour availability buffer is an assumption; archived model runtime is not archived public posting time. The six-hour-buffer sensitivity uses older guidance and does not identify minute-by-minute price discovery.',
            'Prices are last trades from the existing one-day panel, not simultaneous quotes, executable prices, or forecast-time snapshots. Freshness screening can favor active markets, and normalizing a ladder is not a transaction-cost estimate.',
            'Residual calibration uses the currently archived CLI reports with a two-day delay. Later corrections to old reports are not reconstructed as initially published.',
            'The temporal holdout is a reproducible development/test split, not a preregistered prospective study. Fixed-week bootstrap intervals do not remove all seasonal dependence or model-selection risk.',
            'The related 2026 preprint already studies a broader multi-city/public-model comparison; this addition is an independently computed, narrower probability-score benchmark, not a claim of novel discovery.'
        ],
        'sources':[{'label':'IEM NBM/MOS archive and field definitions','url':'https://mesonet.agron.iastate.edu/mos/fe.phtml'},
                   {'label':'NOAA NBM v4.2 text-card definitions (TXN / TMP windows)','url':'https://vlab.noaa.gov/web/mdl/nbm-textcard-v4.2'},
                   {'label':'NWS observation FAQ: CLI days use local standard time','url':'https://www.weather.gov/lot/weather_observations_faq'},
                   {'label':'NWS climate report explanation: standard-time calendar day','url':'https://www.weather.gov/phi/f6explain'},
                   {'label':'Central Park NWS CLI observations, 2025','url':'https://mesonet.agron.iastate.edu/nws/clitable.php?station=KNYC&year=2025'},
                   {'label':'Official historical Kalshi contract rule example','url':'https://api.elections.kalshi.com/trade-api/v2/historical/markets/KXHIGHNY-25NOV02-B59.5'},
                   {'label':'Related preprint: Prediction Markets Beat the Weather Forecast on Tomorrow’s High Temperature','url':'https://arxiv.org/html/2609.23969v1'}],
        'coverage':{'candidate_events':int(panel.event_id.nunique()),'candidate_contract_rows':len(panel),
                    'accepted_events':len(rows),'training_events':train_n,'heldout_events':len(test),
                    'heldout_contracts':6*len(test),'first_date':rows[0]['date'],'last_date':rows[-1]['date'],
                    'forecast_rows_downloaded':len(nbm),'cli_days':len(cli),'exclusions':exclusions,
                    'cli_outcome_mismatch_events':mismatch},
        'paired_differences':{'market_minus_public':delta,'market_minus_public_ci95':delta_ci,
                              'blend_minus_market':means['blend']-means['market'],'blend_minus_market_ci95':blend_ci},
        'source_manifest':manifest,
        'download':{'label':'All paired forecast, price and outcome rows','url':'/data/expansion/weather.json','format':'JSON',
                    'reproduction':'python scripts/expansion_weather.py --cache /tmp/atlas-exp-weather'},
        'paired_rows':[]
    }
    for r in rows:
        record = {k:v for k,v in r.items() if k not in ['y','market','raw','public','blend','contracts']}
        record['split'] = 'train' if r['date'] < '2025-07-01' else 'test'
        record['contracts'] = [{**c, 'outcome':int(r['y'][i]),'raw_price':float(r['raw'][i]),
                                'market_probability':float(r['market'][i]),'public_probability':float(r['public'][i]),
                                'blend_probability':float(r['blend'][i])} for i,c in enumerate(r['contracts'])]
        payload['paired_rows'].append(record)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(payload, indent=2, ensure_ascii=False, allow_nan=False)+'\n')
    print(json.dumps({k:payload[k] for k in ['finding','metrics','coverage','paired_differences']},indent=2))


if __name__ == '__main__':
    main()
