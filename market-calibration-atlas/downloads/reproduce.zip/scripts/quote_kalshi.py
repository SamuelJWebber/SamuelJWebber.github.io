"""Rebuild the Atlas historical Kalshi quote sample from the original Kalshi panel.

Usage: python quote_kalshi.py kalshi.parquet output.json --cache cached-responses/
Install DuckDB first. Only successful candle responses are cached.
"""
import argparse
import collections
import concurrent.futures
import hashlib
import json
import math
import time
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

import duckdb


DAYS = (1, 7, 30, 90, 180, 365)
BASE = "https://api.elections.kalshi.com/trade-api/v2/historical/markets"
DOCS = "https://docs.kalshi.com/api-reference/historical/get-historical-market-candlesticks"
COLUMNS = ["market", "event", "category", "days", "yesBid", "yesAsk", "yesTrade",
           "outcome", "quoteTime", "anchor", "topic"]


def sample(panel, sample_size):
    db = duckdb.connect(config={"threads": 2, "memory_limit": "400MB"})
    db.read_parquet(str(panel)).create_view("panel")
    return db.execute("""
        select market_id, event_id, broad, days, outcome, floor(epoch(anchor))::bigint, topic,
               count(*) over (partition by days) as universe
        from panel where days in (select unnest(?))
        qualify row_number() over (partition by days order by
                 md5('atlas-quote-v1|' || market_id), market_id) <= ?
        order by md5(market_id || days::varchar)
    """, [list(DAYS), sample_size]).fetchall()


def candles(market, days, anchor, cache):
    cutoff = anchor - 86400 * days
    start = cutoff - 86400 + 3600
    query = urllib.parse.urlencode({"start_ts": start, "end_ts": cutoff, "period_interval": 60})
    url = f"{BASE}/{urllib.parse.quote(market, safe='')}/candlesticks?{query}"
    path = cache / f"{urllib.parse.quote(market, safe='')}_{days}_{cutoff}.json"
    if path.exists():
        return json.loads(path.read_bytes()), start, cutoff
    for attempt in range(3):
        try:
            with urllib.request.urlopen(url, timeout=18) as response:
                result = json.load(response)
            if not isinstance(result.get("candlesticks"), list) or result.get("ticker") != market:
                raise ValueError("Invalid candle response")
            path.write_text(json.dumps(result, separators=(",", ":")))
            return result, start, cutoff
        except (OSError, ValueError):
            if attempt == 2:
                raise
            time.sleep(1 + attempt * 2)


def process(item, cache, prior=None):
    market, event, category, days, outcome, anchor, topic, universe = item
    old = (prior or {}).get((market, days))
    if old is not None:
        assert old[1:4] == [event, category, days] and old[7] == outcome and old[9:] == [anchor, topic]
        assert 0 <= anchor - days * 86400 - old[8] < 86400
        return days, universe, "observed", old
    try:
        source, start, cutoff = candles(market, days, anchor, cache)
    except (OSError, ValueError):
        return days, universe, "request failed", None
    for c in sorted(source["candlesticks"], key=lambda b: b["end_period_ts"], reverse=True):
        end = c["end_period_ts"]
        if not start <= end <= cutoff:
            continue
        try:
            bid, ask, trade = (float(c[key]["close"]) for key in ("yes_bid", "yes_ask", "price"))
            volume = float(c["volume"])
        except (TypeError, KeyError, ValueError):
            continue
        # 0 and 1 may stand for an empty side. Never assume an order exists there.
        if 0 < bid <= ask < 1 and 0 <= trade <= 1 and volume > 0 and math.isfinite(volume):
            return days, universe, "observed", [
                market, event, category, days, bid, ask, trade, outcome, end, anchor, topic
            ]
    return days, universe, "no qualifying candle", None


def run(panel, output, cache, sample_size, workers, prior_sample=None):
    cache.mkdir(parents=True, exist_ok=True)
    counts = collections.defaultdict(collections.Counter)
    rows = []
    items = sample(panel, sample_size)
    prior = {}
    if prior_sample:
        previous = json.loads(prior_sample.read_text())
        assert previous['columns'] == COLUMNS
        prior = {(r[0], r[3]): r for r in previous['rows']}
        assert len(prior) == len(previous['rows'])
    reused = sum((item[0],item[3]) in prior for item in items)
    print(f"{len(items)} market-horizons", flush=True)
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
        futures = [pool.submit(process, item, cache, prior) for item in items]
        for number, future in enumerate(concurrent.futures.as_completed(futures), 1):
            days, universe, status, row = future.result()
            counts[days]["universe"] = universe
            counts[days]["attempted"] += 1
            counts[days][status] += 1
            if row is not None:
                rows.append(row)
            if number % 100 == 0:
                print(f"{number}/{len(items)} checked, {len(rows)} observed", flush=True)
    rows.sort(key=lambda row: (row[3], row[0]))
    result = {
        "refreshedAt": datetime.now(timezone.utc).isoformat(),
        "reusedObservations": reused,
        "sampleSizePerHorizon": sample_size,
        "candidateCount": len(items),
        "panelSha256": hashlib.sha256(panel.read_bytes()).hexdigest(),
        "columns": COLUMNS,
        "rows": rows,
        "coverage": {str(d): dict(counts[d]) for d in DAYS},
        "method": (
            f"Sampled up to {sample_size} Kalshi contracts per horizon from the published trade panel, "
            "in a fixed hash order independent of the outcome. For each sampled contract, "
            "selected the latest completed hourly candle fully within the 24 hours preceding "
            "that cutoff with trading volume, a YES trade close and both YES quotes strictly "
            "inside 0 and 1. Trade and quote closes are from the same hour and may be minutes "
            "apart. Spread is ask minus bid. The archive does not report size at these prices. "
            "Market close is the event-time anchor. Coverage favors active markets with a two-sided book. "
            "Each horizon has its own cohort. Sample sizes vary by horizon and filter."
            " Previously validated historical rows may be reused; the refresh date marks "
            "the sample rebuild, not when every quote was first retrieved."
        ),
        "source": DOCS,
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    tmp = output.with_suffix(".tmp")
    tmp.write_text(json.dumps(result, separators=(",", ":"), ensure_ascii=False) + "\n")
    tmp.replace(output)
    print(result["coverage"], flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("panel", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--cache", type=Path, required=True)
    parser.add_argument("--sample-size", type=int, default=250)
    parser.add_argument("--workers", type=int, default=10)
    parser.add_argument("--prior-sample", type=Path, help="Reuse validated historical observations from an earlier deterministic sample.")
    args = parser.parse_args()
    run(args.panel, args.output, args.cache, args.sample_size, args.workers, args.prior_sample)
