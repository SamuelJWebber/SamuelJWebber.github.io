"""Make compact topic-by-day summaries for the dashboard comparison matrix."""
import gzip
import json
from pathlib import Path
import sys
dist=Path(__file__).resolve().parents[1]/'dist'/'data'
for v in (sys.argv[1:] or sorted(p.name for p in dist.iterdir() if p.is_dir())):
    p=dist/v
    mp=p/'meta.json'
    if not mp.exists(): continue
    meta=json.loads(mp.read_text())
    days={}
    for t in meta['topics']:
        rows=json.loads(gzip.decompress((p/(t['id']+'.json.gz')).read_bytes()))
        for day,r in rows.items():
            days.setdefault(day,{})[t['id']]=r['s']
    encoded=json.dumps(days,separators=(',',':')).encode('utf8')
    file=p/'matrix.json.gz'
    temp=p/'matrix.json.gz.tmp'
    temp.write_bytes(gzip.compress(encoded,compresslevel=6,mtime=0))
    temp.replace(file)
    print(v,len(days),file.stat().st_size)
