"""Audit price adjustment around independently verified, resolving announcements.

Collect pinned five-minute bars and official contract-rule snapshots:
  python scripts/shock_verified_news.py --collect --cache /tmp/atlas-intraday-poly
Rebuild completely offline from the public compact downloads:
  python scripts/shock_verified_news.py

No price-jump or future-price condition determines the 31-contract scope.
Requires duckdb, pandas, numpy. Government release clocks/results below were
checked against the linked original releases, and the contract rules against
Polymarket's public Gamma API. No news is inferred from price movements.
"""
from __future__ import annotations
import argparse
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import urllib.request

import duckdb
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
REVISION = '91ddb961b090de18fd79e79edd8fa15f36ca11b9'
ANNOUNCEMENTS = [
    dict(id='jobs', title='February employment report', releaseUtc='2026-03-06T13:30:00Z',
         localTime='March 6, 2026, 8:30 a.m. EST',
         sourceUrl='https://www.bls.gov/news.release/archives/empsit_03062026.htm',
         result='Nonfarm payroll employment fell 92,000; unemployment was 4.4%.',
         officialValues={'payrollChangeThousands':-92,'unemploymentPercent':4.4}),
    dict(id='cpi', title='February consumer price report', releaseUtc='2026-03-11T12:30:00Z',
         localTime='March 11, 2026, 8:30 a.m. EDT',
         sourceUrl='https://www.bls.gov/news.release/archives/cpi_03112026.htm',
         result='Headline CPI rose 0.3% month over month and 2.4% year over year.',
         officialValues={'headlineMonthlyPercent':.3,'headlineAnnualPercent':2.4}),
    dict(id='fed', title='March FOMC rate decision', releaseUtc='2026-03-18T18:00:00Z',
         localTime='March 18, 2026, 2:00 p.m. EDT',
         sourceUrl='https://www.federalreserve.gov/newsevents/pressreleases/monetary20260318a.htm',
         result='The target range was maintained at 3.50–3.75%; no change.',
         officialValues={'upperBoundPercent':3.75,'changeBasisPoints':0}),
]
FAMILIES = [
    dict(id='payroll',announcement='jobs',event='205139',title='Nonfarm payroll change',
         marketIds=list(range(1366274,1366282)),winningYesMarket='1366274',
         rule='The BLS payroll estimate released March 6 for February 2026.',
         verifiedResult='−92,000 is below the lowest 25,000-job threshold.'),
    dict(id='unemployment',announcement='jobs',event='205145',title='Unemployment rate',
         marketIds=list(range(1366299,1366306)),winningYesMarket='1366303',
         rule='Seasonally adjusted U-3 unemployment for February 2026; first release only.',
         verifiedResult='4.4% equals the winning 4.4% bucket.'),
    dict(id='annual-cpi',announcement='cpi',event='207936',title='Annual headline CPI',
         marketIds=list(range(1373473,1373480)),winningYesMarket='1373476',
         rule='The February 2026 headline CPI 12-month change before seasonal adjustment.',
         verifiedResult='2.4% equals the winning 2.4% bucket.'),
    dict(id='monthly-cpi',announcement='cpi',event='207993',title='Monthly headline CPI',
         marketIds=list(range(1373674,1373679)),winningYesMarket='1373677',
         rule='The February 2026 one-month seasonally adjusted headline CPI-U change.',
         verifiedResult='0.3% equals the winning 0.3% bucket.'),
    dict(id='fed-decision',announcement='fed',event='67284',title='March FOMC rate change',
         marketIds=list(range(654412,654416)),winningYesMarket='654414',
         rule='Change in the upper bound of the target range at the March 2026 FOMC meeting.',
         verifiedResult='The official statement maintained the range: the no-change bucket wins.'),
]
GRID = [-10,-5,0,5,10,15,30,60]

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def epoch(value):
    return int(datetime.fromisoformat(value.replace('Z','+00:00')).timestamp())

def write_json(path, value):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,ensure_ascii=False,separators=(',',':'),allow_nan=False))

def collect(cache, output, bars_path):
    db=duckdb.connect(config={'threads':2,'memory_limit':'1000MB'})
    db.execute("set TimeZone='UTC'")
    markets=db.execute('select * from read_parquet(?)',[str(cache/'markets.parquet')]).fetchdf()
    selected_ids={mid for family in FAMILIES for mid in family['marketIds']}
    selected=markets[markets.market_id.isin(selected_ids)].copy()
    assert len(selected)==31 and selected.market_id.nunique()==31
    records=[]
    for family in FAMILIES:
        for row in selected[selected.market_id.isin(family['marketIds'])].itertuples():
            expected=str(row.market_id)==family['winningYesMarket']
            assert str(row.event_id)==family['event'] and bool(row.outcome_yes)==expected
            records.append(dict(marketId=str(row.market_id),family=family['id'],
                announcement=family['announcement'],event=family['event'],question=row.question,
                outcomeYes=int(expected),closeTime=row.close_time.isoformat(),
                expirationTime=row.expiration_time.isoformat(),openTime=row.market_start_time.isoformat()))
    # Rule snapshots are captured for every member of the frozen families.
    rule_dir=cache/'verified-news-rules';rule_dir.mkdir(exist_ok=True)
    def fetch_rule(item):
        mid=item['marketId']; path=rule_dir/(mid+'.json')
        if not path.exists():
            with urllib.request.urlopen('https://gamma-api.polymarket.com/markets/'+mid,timeout=45) as response:
                data=json.load(response)
            keep={k:data.get(k) for k in ['id','question','slug','description','resolutionSource','outcomes','outcomePrices']}
            write_json(path,keep)
        data=json.loads(path.read_text())
        assert data['question']==item['question']
        assert '2026' in data['description'] and ('BLS' in data['description'] or 'FOMC' in data['description'])
        return {**item,'ruleUrl':'https://gamma-api.polymarket.com/markets/'+mid,
                'marketUrl':'https://polymarket.com/market/'+data['slug'],
                'description':data['description'],'ruleSnapshotSha256':digest(path)}
    with ThreadPoolExecutor(max_workers=8) as pool:
        records=list(pool.map(fetch_rule,records))
    db.register('selected',pd.DataFrame(records))
    predictions=cache/'predictions.parquet'
    tokens=db.execute('''select s.marketId,p.prediction_id,p.winner from selected s
        join read_parquet(?) p on p.market_id::varchar=s.marketId
        where lower(p.outcome)='yes' and p.n_outcomes=2''',[str(predictions)]).fetchdf()
    assert len(tokens)==31 and tokens.marketId.nunique()==31
    token_lookup={r.marketId:r for r in tokens.itertuples()}
    for item in records:
        token=token_lookup[item['marketId']]
        assert int(token.winner)==item['outcomeYes']
        item['yesPredictionId']=token.prediction_id
    db.register('selected',pd.DataFrame(records))
    files=[cache/('five-'+a['releaseUtc'][:10]+'.parquet') for a in ANNOUNCEMENTS]
    assert all(p.exists() for p in files)
    data=db.execute('''select s.marketId as market_id,s.announcement,s.family,
        epoch(b.timestamp::timestamptz)::bigint+300 ts,b.close price,b.volume,b.trade_count,
        s.outcomeYes outcome
        from read_parquet(?) b join selected s on b.prediction_id=s.yesPredictionId
        where b.volume>0 and b.trade_count>0 and b.close between 0 and 1
        and b.timestamp::timestamptz>=s.openTime::timestamptz
        and b.timestamp::timestamptz+interval 5 minute<=s.closeTime::timestamptz
        order by s.marketId,ts''',[[str(p) for p in files]]).fetchdf()
    assert not data.duplicated(['market_id','ts']).any()
    bars_path.parent.mkdir(parents=True,exist_ok=True)
    db.register('download',data)
    db.execute('copy download to ? (format parquet,compression zstd)',[str(bars_path)])
    manifest=dict(venue='polymarket',createdDate=datetime.now(timezone.utc).date().isoformat(),
        revision=REVISION,announcements=ANNOUNCEMENTS,families=FAMILIES,contracts=records,
        sourceFiles=[{'file':p.name,'sha256':digest(p)} for p in [cache/'markets.parquet',predictions,*files]],
        download=str(bars_path.relative_to(ROOT/'dist')),downloadSha256=digest(bars_path),
        auditCounts={'officiallyVerifiedContracts':31,'archiveOutcomeMismatches':0,'scheduledExpirationsBeforeRelease':31},
        eligibility='All 31 binary contracts in the five frozen immediate-release numeric families; selected by contract definitions and the independently verified announcement, without conditioning on a price jump, later price, or speed of adjustment. Cumulative rate-cut-by-date and future-period questions are excluded.',
        sourceCredit='Akey, Grégoire, Harvie and Martineau (2026), Polymarket Users Dataset. CC BY 4.0.',
        sourceUrl='https://www.vincentgregoire.com/polymarket-users-data/datasets/ohlcv/',
        clockRepair='All 31 recorded scheduled expirations precede the verified release. This audit therefore uses observed raw bars until the recorded actual close, rather than the main study’s earlier-expiry-or-close proxy. It never extends prices after the actual close or fills missing observations.')
    for item in records:
        release=epoch(next(a['releaseUtc'] for a in ANNOUNCEMENTS if a['id']==item['announcement']))
        assert epoch(item['expirationTime'])<release<epoch(item['closeTime'])
    write_json(output/'shock-verified-news-manifest.json',manifest)
    print('Collected',len(data),'bars for',len(records),'contracts',flush=True)
    return manifest

def metric(contracts, minute):
    known=[c for c in contracts if c['prices'].get(str(minute)) is not None]
    if not known:return dict(minute=minute,n=0,meanAbsError=None,meanWinnerPrice=None,brier=None,within1pp=None,within5pp=None)
    errors=np.array([abs(c['prices'][str(minute)]-c['outcomeYes']) for c in known])
    return dict(minute=minute,n=len(known),meanAbsError=float(errors.mean()),
        meanWinnerPrice=float(1-errors.mean()),brier=float(np.mean(errors**2)),
        within1pp=float(np.mean(errors<=.01+1e-10)),within5pp=float(np.mean(errors<=.05+1e-10)))

def analyze(bars_path,manifest,output):
    db=duckdb.connect(); frame=db.execute('select * from read_parquet(?)',[str(bars_path)]).fetchdf()
    assert digest(bars_path)==manifest['downloadSha256']
    paths={str(mid):dict(zip(g.ts.astype(int),g.price)) for mid,g in frame.groupby('market_id')}
    contracts=[]
    for c in manifest['contracts']:
        ann=next(a for a in manifest['announcements'] if a['id']==c['announcement'])
        release=epoch(ann['releaseUtc']); path=paths.get(c['marketId'],{})
        prices={str(m):float(path[release+60*m]) if release+60*m in path else None for m in GRID}
        dense=[float(path[release+60*m]) if release+60*m in path else None for m in range(5,61,5)]
        timing={}
        for threshold in [.01,.05]:
            within=[p is not None and abs(p-c['outcomeYes'])<=threshold+1e-10 for p in dense]
            first=next((5*(i+1) for i,v in enumerate(within) if v),None)
            confirmed=next((5*(i+1) for i in range(11) if within[i] and within[i+1]),None)
            # Full suffix must be observed; an absent later trade is not stability.
            sustained=next((5*(i+1) for i in range(11) if all(within[i:])),None)
            timing[str(int(threshold*100))]=dict(firstObservedMinute=first,
                twoAdjacentBarsMinute=confirmed,confirmationMinute=confirmed+5 if confirmed is not None else None,
                sustainedObservedThrough60Minute=sustained)
        contracts.append({**{k:c[k] for k in ['marketId','family','announcement','question','outcomeYes','marketUrl']},
            'releaseUtc':ann['releaseUtc'],'prices':prices,'postFiveMinuteGrid':dense,
            'completeFiveMinuteGridThrough60':all(p is not None for p in dense),'arrival':timing})
    def group(items):
        cohorts={}
        for horizon,grid in [(5,[0,5]),(15,[0,5,10,15]),(60,[0,5,10,15,30,60])]:
            complete=[c for c in items if all(c['prices'][str(m)] is not None for m in grid)]
            cohorts[str(horizon)]={'n':len(complete),'marketIds':[c['marketId'] for c in complete],
                'path':[metric(complete,m) for m in grid]}
        return dict(eligibleContracts=len(items),availablePath=[metric(items,m) for m in GRID],
            cohorts=cohorts,winningYesContracts=[c['marketId'] for c in items if c['outcomeYes']==1],
            winningYesPath=[metric([c for c in items if c['outcomeYes']==1],m) for m in GRID])
    announcements=[{**a,**group([c for c in contracts if c['announcement']==a['id']])} for a in manifest['announcements']]
    families=[{**f,**group([c for c in contracts if c['family']==f['id']])} for f in manifest['families']]
    payload=dict(meta=dict(venue='polymarket',generatedDate=datetime.now(timezone.utc).date().isoformat(),
        independentAnnouncements=3,contractFamilies=5,eligibleContracts=31,
        scope='Three independently timed, resolving US macroeconomic announcements in March 2026.',
        interpretation='After these specific releases, the contract answer is publicly determined. Distance to its independently verified 0-or-1 answer measures residual price error, not calibration of uncertain future events. This narrow case audit does not estimate a general news-processing delay.',
        priceMethod='One YES token per binary contract; active five-minute close at the exact target timestamp. No interpolation. A bar ending at release time contains pre-release trades; the first fully post-release bar ends five minutes later. Actual trade time inside a bar is unknown.',
        matching='Matched 5-, 15- and 60-minute curves keep the same contracts at every point. Complete cases select contracts with continued observed trading and need not represent all 31 eligible contracts. The separate availability table changes its denominator and must not be read as a fixed-cohort time series.',
        uncertainty='Only three independent announcements. No confidence intervals or significance claims are reported. Multiple binary buckets and two statistics in one release are not independent news events.',
        economicLimit='The 0-or-1 benchmark ignores fees, settlement delay, dispute/platform risk and financing costs. Small residual distances from the payout are not automatically informational mistakes.',
        timingLimit='Arrival times are observed bar-end bounds, not second-level latency. Two-bar confirmation requires adjacent observed closes and occurs five minutes after the first qualifying close. Sustained-through-60 requires at least two closes and every remaining five-minute bar; missing trades never count as stability. Trading can stop because the answer is known: absent bars are unobserved, not failures or slow reactions.',
        sourceCredit=manifest['sourceCredit'],clockRepair=manifest['clockRepair'],auditCounts=manifest['auditCounts'],
        manifest='data/intraday/shock-verified-news-manifest.json',bars=manifest['download'],
        inputSha256=digest(bars_path)),announcements=announcements,families=families,
        overall=group(contracts),contracts=contracts)
    write_json(output/'shock-verified-news.json',payload)
    print(json.dumps({'announcements':[{k:a[k] for k in ['id','eligibleContracts','cohorts','winningYesPath']} for a in announcements]},ensure_ascii=False))
    return payload

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--collect',action='store_true');p.add_argument('--cache',type=Path,default=Path('/tmp/atlas-intraday-poly'))
    p.add_argument('--bars',type=Path,default=ROOT/'dist/downloads/verified-news-bars.parquet')
    p.add_argument('--manifest',type=Path,default=ROOT/'dist/data/intraday/shock-verified-news-manifest.json')
    p.add_argument('--output',type=Path,default=ROOT/'dist/data/intraday');args=p.parse_args()
    manifest=collect(args.cache,args.output,args.bars) if args.collect else json.loads(args.manifest.read_text())
    analyze(args.bars,manifest,args.output)
