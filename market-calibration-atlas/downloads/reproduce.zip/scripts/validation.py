"""Reproducible robustness checks for the shipped Polymarket and Kalshi panels.

Run: PYTHONPATH=/tmp/atlas-deps python scripts/validation.py
Dependencies: duckdb, numpy, pandas, scipy. No network calls.

This is an archive analysis, not a trading backtest. Actual event-occurrence and
settlement-publication times are absent. Cluster intervals describe variation
across archive-defined venue-events and do not cover source/timestamp error.
"""
from pathlib import Path
import argparse
import hashlib
import json
import math

import duckdb
import numpy as np
import pandas as pd
from scipy.special import expit, logit
from scipy.optimize import brentq
from scipy.stats import t as student_t

ROOT = Path(__file__).resolve().parents[1]
HORIZONS = [1, 7, 30, 90, 180, 365, 730, 1095]
PAIRS = [(7,1),(30,7),(30,1),(90,30),(180,30),(365,30),(730,30),(1095,30)]
METRICS = ['expected','observed','bias','brier']
SPLIT = pd.Timestamp('2025-01-01', tz='UTC')
TRAIN_END = pd.Timestamp('2024-12-01', tz='UTC')


def number(x):
    return None if x is None or not np.isfinite(x) else round(float(x), 8)


def ci_of(mean, variance, groups, bound=None):
    # Avoid reporting a misleading zero-width interval when a rare outcome was
    # never observed. No uncertainty is inferred from fewer than 20 clusters.
    if groups < 20 or not np.isfinite(variance) or variance <= 1e-20:
        return None
    margin = float(student_t.ppf(.975, groups-1))*math.sqrt(variance)
    lo,hi = mean-margin,mean+margin
    if bound is not None:
        lo,hi=max(bound[0],lo),min(bound[1],hi)
    return [number(lo),number(hi)]


def estimate(frame, names=METRICS, weight='contract'):
    n=len(frame)
    if not n:
        return {'n':0,'events':0,**{k:None for k in names},'ci':{k:None for k in names}}
    grouped=frame.groupby('eid',sort=False)[names].agg(['sum','count'])
    counts=grouped[(names[0],'count')].to_numpy(float)
    g=len(counts)
    sums=np.column_stack([grouped[(k,'sum')].to_numpy(float) for k in names])
    if weight=='event':
        means=sums/counts[:,None]
        theta=means.mean(axis=0)
        variance=means.var(axis=0,ddof=1)/g if g>1 else np.full(len(names),np.nan)
    else:
        theta=sums.sum(axis=0)/n
        residual=sums-counts[:,None]*theta
        variance=(g/(g-1))*np.sum(residual**2,axis=0)/n**2 if g>1 else np.full(len(names),np.nan)
    out={'n':n,'events':g,'ci':{}}
    for k,m,v in zip(names,theta,variance):
        out[k]=number(m)
        bounds=(0,1) if k in ['expected','observed','brier'] else None
        out['ci'][k]=ci_of(m,v,g,bounds)
    return out


def both(frame,names=METRICS):
    return {w:estimate(frame,names,w) for w in ['contract','event']}


def quote_age(frame):
    ages=frame.age.to_numpy(float)
    ages=ages[np.isfinite(ages)]
    return {'validCount':len(ages),'median':number(np.median(ages)) if len(ages) else None,
            'p95':number(np.quantile(ages,.95)) if len(ages) else None,
            'max':number(np.max(ages)) if len(ages) else None}


def date_stats(frame):
    return {'n':len(frame),'events':int(frame.eid.nunique()),
            'firstDate':frame.completed_at.min().isoformat() if len(frame) else None,
            'lastDate':frame.completed_at.max().isoformat() if len(frame) else None,
            'firstAnchor':frame.anchor.min().isoformat() if len(frame) else None,
            'lastAnchor':frame.anchor.max().isoformat() if len(frame) else None}


def holdout(frame):
    train=frame[frame.event_end<TRAIN_END].copy()
    test=frame[frame.completed_at>=SPLIT].copy()
    assert not set(train.eid).intersection(test.eid), 'event leakage across held-out split'
    result={'status':'insufficient','splitDate':SPLIT.date().isoformat(),
            'trainingAnchorBefore':TRAIN_END.date().isoformat(),'embargoDays':31,
            'train':date_stats(train),'test':date_stats(test),
            'weight':'event','settlementAvailabilityVerified':False}
    if train.eid.nunique()<50 or test.eid.nunique()<50 or train.observed.nunique()<2 or test.observed.nunique()<2:
        result['reason']='Requires at least 50 distinct venue-events and both outcomes in each split.'
        return result
    train_counts=train.groupby('eid').eid.transform('size').to_numpy(float)
    w=1/train_counts
    z=logit(np.clip(train.expected.to_numpy(float),1e-6,1-1e-6))
    y=train.observed.to_numpy(float)
    # An intercept-only logistic recalibration; no bins, category search,
    # hyperparameter tuning, or information from the holdout are used to fit.
    shift=brentq(lambda a:np.sum(w*(expit(z+a)-y)), -30,30)
    raw=estimate(test,weight='event')
    adjusted=test.copy()
    adjusted['expected']=expit(logit(np.clip(test.expected.to_numpy(float),1e-6,1-1e-6))+shift)
    adjusted['bias']=adjusted.observed-adjusted.expected
    adjusted['brier']=adjusted.bias**2
    delta=pd.DataFrame({'eid':test.eid,'brierGain':test.brier.to_numpy()-adjusted.brier.to_numpy()})
    gain=estimate(delta,['brierGain'],'event')
    result.update(status='ok',correction={'logitShift':number(shift),'method':'Intercept-only logistic recalibration, fit with equal weight per venue-event. Probabilities are clipped to [0.000001, 0.999999] for the logit transform.'},
                  raw=raw,adjusted=estimate(adjusted,weight='event'),brierGain=gain['brierGain'],ci=gain['ci']['brierGain'])
    return result


def standardized_calendar(frame):
    """Fixed common venue-category strata in two complete calendar years.

    An event is an exchange's grouping, not necessarily independent in fact.
    Equal weight per common stratum; equal weight per venue-event within it.
    Intervals condition on the selected set of strata and their fixed weights.
    """
    f=frame[frame.completed_at.dt.year.isin([2024,2025])].copy()
    f['year']=f.completed_at.dt.year
    counts=f.groupby(['venue','broad','year']).eid.nunique().unstack(fill_value=0)
    if 2024 not in counts or 2025 not in counts:
        return {'status':'insufficient','reason':'Both complete years need at least one common venue/category stratum with 20 events per year.'}
    common=counts.index[(counts[2024]>=20)&(counts[2025]>=20)].tolist()
    if not common:
        return {'status':'insufficient','reason':'No venue/category stratum has 20 events in each of 2024 and 2025.'}
    results=[]
    influence_by_year={}
    smallest_cell=min(int(counts.loc[(v,c),year]) for v,c in common for year in [2024,2025])
    for year in [2024,2025]:
        cells=[]
        for v,c in common:
            cell=f[(f.venue==v)&(f.broad==c)&(f.year==year)]
            cells.append(cell)
        sub=pd.concat(cells)
        n,events=len(sub),int(sub.eid.nunique())
        entry={'year':year,'n':n,'events':events,'ci':{}}
        influences={}
        for key in METRICS:
            means=[]; pieces=[]
            for cell in cells:
                em=cell.groupby('eid')[key].mean()
                means.append(em.mean())
                smallest_cell=min(smallest_cell,len(em))
                pieces.append((em-em.mean())/(len(em)*len(common)))
            influence=pd.concat(pieces).groupby(level=0).sum()
            theta=float(np.mean(means))
            g=len(influence)
            var=float(np.sum(influence.to_numpy()**2)*g/(g-1))
            bounds=(0,1) if key in ['expected','observed','brier'] else None
            entry[key]=number(theta);entry['ci'][key]=ci_of(theta,var,smallest_cell,bounds)
            influences[key]=influence
        results.append(entry)
        influence_by_year[year]=influences
    changes={'ci':{}}
    for key,name in [('expected','expectedChange'),('observed','hitChange'),('bias','biasChange'),('brier','brierChange')]:
        influence=influence_by_year[2025][key].subtract(influence_by_year[2024][key],fill_value=0)
        g=len(influence)
        variance=float(np.sum(influence.to_numpy()**2)*g/(g-1))
        delta=results[1][key]-results[0][key]
        changes[name]=number(delta)
        changes['ci'][name]=ci_of(delta,variance,smallest_cell)
    return {'status':'ok','strata':[{'venue':v,'category':c,'weight':number(1/len(common))} for v,c in common],
            'years':results,'changes':changes,'excluded2024':int(sum(f.year==2024)-results[0]['n']),
            'excluded2025':int(sum(f.year==2025)-results[1]['n'])}



def scope(frame):
    result={'days':{},'pairs':{},'heldOut':{'days':{}},'calendar':{'days':{}}}
    for d in HORIZONS:
        f=frame[frame.days==d]
        if not len(f):
            continue
        result['days'][str(d)]={**both(f),'quoteAgeHours':quote_age(f)}
        result['heldOut']['days'][str(d)]=holdout(f)
        result['calendar']['days'][str(d)]=standardized_calendar(f)
    for far,near in PAIRS:
        a=frame[frame.days==far];b=frame[frame.days==near]
        paired=a.merge(b,on=['venue','market_id'],suffixes=('_far','_near'),validate='one_to_one')
        if not len(paired):
            continue
        assert (paired.eid_far==paired.eid_near).all()
        diffs=pd.DataFrame({'eid':paired.eid_far,'brierChange':paired.brier_near-paired.brier_far,
                            'biasChange':paired.bias_near-paired.bias_far,'hitChange':paired.observed_near-paired.observed_far,
                            'expectedChange':paired.expected_near-paired.expected_far})
        result['pairs'][f'{far}/{near}']=both(diffs,['brierChange','biasChange','hitChange','expectedChange'])
    return result


def load_panel(path):
    v=path.stem
    with duckdb.connect() as db:
        db.execute("set TimeZone='UTC'")
        db.execute('set threads=2')
        db.read_parquet(str(path)).create_view('panel')
        stats=db.execute('select count(*),count(distinct (market_id,days)),count(*) filter(where outcome not in (0,1) or price not between 0 and 1 or price is null or event_id is null or anchor is null or completed_at is null),min(anchor),max(anchor) from panel').fetchone()
        assert stats[0]==stats[1] and stats[2]==0
        frame=db.execute('''select ?,cast(market_id as varchar) market_id,event_id,broad,days,price,outcome,
              anchor,completed_at,max(anchor) over (partition by event_id) event_end
              from panel where days in ('''+','.join(map(str,HORIZONS))+')',[v]).df()
    frame=frame.rename(columns={'$1':'venue'})
    assert 'venue' in frame
    frame['eid']=v+':'+frame.event_id.astype(str)
    frame['expected']=np.maximum(frame.price,1-frame.price)
    frame['observed']=np.where(frame.price>=.5,frame.outcome,1-frame.outcome)
    frame=frame[np.round(frame.expected*100,12)>=51].copy()
    frame['bias']=frame.observed-frame.expected
    frame['brier']=frame.bias**2
    frame['age']=(frame.anchor-pd.to_timedelta(frame.days,unit='d')-frame.completed_at).dt.total_seconds()/3600
    assert frame.age.min()>=-1e-8 and frame.age.max()<=24+1e-8
    # Ensure event end is calculated from every source row, not merely selected
    # horizons: events sometimes contain contracts with different close times.
    with duckdb.connect() as db:
        db.execute("set TimeZone='UTC'")
        event_ends=db.execute('select event_id,max(anchor) event_end from read_parquet(?) group by event_id',[str(path)]).df()
    frame=frame.drop(columns=['event_end']).merge(event_ends,on='event_id',validate='many_to_one')
    return frame,{'file':f'downloads/{path.name}','sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
                  'archiveRows':stats[0],'firstAnchor':stats[3].isoformat(),'lastAnchor':stats[4].isoformat(),
                  'selectedRows':len(frame),'selectedEvents':int(frame.eid.nunique())}


def validate_existing(frame,root):
    for v in ['polymarket','kalshi']:
        meta=json.loads((root/'dist/data'/v/'meta.json').read_text())
        for topic in meta['topics']:
            if topic['kind'] not in ['all','broad']:
                continue
            f=frame[frame.venue==v]
            if topic['kind']=='broad': f=f[f.broad==topic['name'].removeprefix('All ')]
            for d in HORIZONS:
                expected=topic['bench'].get(str(d))
                if expected is None: continue
                row=estimate(f[f.days==d])
                assert row['n']==expected[0] and row['events']==expected[1],(v,topic['name'],d,row,expected)
                for k,x in zip(['brier','observed','bias'],expected[2:]):
                    assert abs(row[k]-x)<.000001,(v,topic['name'],d,k,row[k],x)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',type=Path,default=ROOT)
    args=p.parse_args();root=args.root
    frames=[];sources={}
    for v in ['polymarket','kalshi']:
        f,source=load_panel(root/'dist/downloads'/f'{v}.parquet');frames.append(f);sources[v]=source
    all_frame=pd.concat(frames,ignore_index=True)
    validate_existing(all_frame,root)
    result={'meta':{
      'title':'Archive robustness checks','generatedDate':'2026-11-05','sources':sources,
      'coverage':'Polymarket and Kalshi only; other venues are excluded because the shipped row-level panels needed for these checks are unavailable. Pooled results here do not mean all six dashboard venues.',
      'clockNote':'Horizon = days before the source-reported anchor, not independently verified actual event occurrence. Polymarket uses the earlier archived scheduled expiry/close; Kalshi uses recorded trading close, which can follow the public result. Quote age is cutoff minus selected completed bar/trade timestamp; all observations are within the preceding 24 hours.',
      'intervalNote':'Approximate 95% Student-t intervals, clustering by archive-defined venue-event. Contract weights use a cluster-robust ratio-mean variance; event weights average contracts within each venue-event and give those events equal weight. Intervals are suppressed below 20 events or at zero estimated variance. They do not account for related events, overlapping real-world events across venues, source omissions, or timing errors.',
      'biasNote':'Signed gap = observed win rate minus mean probability. Positive means favorites won more often than priced. Opposing errors can cancel: a small signed gap is not proof of full calibration. Brier score evaluates every original probability; lower is better.',
      'heldOutNote':'A single fixed chronological split, 1 January 2025. Training includes only venue-events whose latest source anchor is before 1 December 2024; test quotes occur on/after 1 January 2025. No venue-event appears in both. One logit intercept is fitted separately for each displayed venue/category/horizon, with equal event weights, and then held fixed. The favored side is selected using the original quote and remains fixed after correction. Settlement publication times are unavailable, so this is retrospective out-of-time evidence, not a claim that training labels were available then or a tradable strategy. Test intervals condition on the fitted correction; inspecting many slices is exploratory.',
      'calendarNote':'Calendar comparison uses quote dates in complete years 2024 and 2025. Retain only venue×broad-category strata with at least 20 venue-events in each year. Give each common stratum equal weight, and each venue-event equal weight within a stratum. This holds those mix weights constant but cannot hold event difficulty or within-category composition constant. Intervals condition on strata and weights, cluster by venue-event across strata, and preserve overlapping event clusters between years when estimating changes. The t critical value uses the smallest retained stratum event count.',
      'scopeNote':'Original favorites must be at least 51%. Every eligible contract/horizon occurs once. Pooled event IDs are namespaced by venue; the same real-world event listed on two venues remains two clusters. No probability bins are used in these checks.',
      'eventClocksIndependentlyVerified':False,
      'trainingSplit':'2025-01-01','trainingAnchorBefore':'2024-12-01'},
      'horizons':HORIZONS,'pairs':[f'{a}/{b}' for a,b in PAIRS],'venues':{}}
    for v in ['polymarket','kalshi','all']:
        f=all_frame if v=='all' else all_frame[all_frame.venue==v]
        categories={'All':scope(f)}
        for cat in sorted(f.broad.unique()):
            categories[cat]=scope(f[f.broad==cat])
        result['venues'][v]={'categories':categories}
        print(v, 'complete',len(f),'rows',flush=True)
    target=root/'dist/data/validation.json'
    target.write_text(json.dumps(result,separators=(',',':'),allow_nan=False))
    print('wrote',target,target.stat().st_size,flush=True)
    for v in result['venues']:
        for d,h in result['venues'][v]['categories']['All']['heldOut']['days'].items():
            print(v,d,h['status'],h.get('brierGain'),h.get('ci'),h['train']['events'],h['test']['events'])

if __name__=='__main__':main()
