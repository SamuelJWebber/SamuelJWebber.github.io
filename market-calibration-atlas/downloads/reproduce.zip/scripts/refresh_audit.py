"""Audit and summarize the independent PredictDesks October 2026 CSV.

This is a separate high-volume benchmark, not a refresh or extension of Atlas's
trade-price panels. Source: PredictDesks Research (2026), CC BY 4.0.
Run: python scripts/refresh_audit.py --cache /tmp/atlas-research
"""
import argparse
import csv
import gzip
import hashlib
import io
import json
import math
import urllib.request
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

SOURCE = 'https://www.predictdesks.com/blog/research/prediction-market-accuracy'
BASE = 'https://www.predictdesks.com/research/'
NAME = 'prediction-market-accuracy-2026.csv'
DAYS = (30, 7, 1)


def observation(row, day):
    raw = row[f'price_{day}d']
    if raw == '':
        return None
    p = float(raw)
    y = int(row['resolved_yes'])
    assert y in (0, 1)
    if not math.isfinite(p) or not 0 <= p <= 1:
        return None
    if p < 0.5:
        p, y = 1-p, 1-y
    return (p, y) if p >= 0.51-1e-12 else None


def stats(values):
    n = len(values)
    if not n:
        return None
    expected = sum(p for p, y in values) / n
    actual = sum(y for p, y in values) / n
    return dict(n=n, expected=expected, actual=actual, gap=actual-expected,
                brier=sum((p-y)**2 for p, y in values)/n)


def run(cache, output):
    cache.mkdir(parents=True, exist_ok=True)
    path = cache/NAME
    if not path.exists():
        req = urllib.request.Request(BASE+NAME, headers={'User-Agent': 'Mozilla/5.0'})
        path.write_bytes(urllib.request.urlopen(req, timeout=45).read())
    raw = path.read_bytes()
    source_rows = list(csv.DictReader(io.StringIO(raw.decode())))
    unique = {}
    duplicates = 0
    for row in source_rows:
        key = (row['platform'], row['market_id'])
        assert row['platform'] in ('polymarket', 'kalshi')
        assert float(row['volume']) >= 100000
        if key in unique:
            assert unique[key] == row, f'Conflicting duplicate: {key}'
            duplicates += 1
        unique[key] = row
    rows = list(unique.values())
    invalid = []
    for r in rows:
        for day in DAYS:
            raw_price = r[f'price_{day}d']
            if raw_price and not (math.isfinite(float(raw_price)) and 0 <= float(raw_price) <= 1):
                invalid.append({'venue':r['platform'], 'market':r['market_id'], 'days':day, 'price':raw_price})
    categories = sorted({r['category'] for r in rows})
    tables = {}
    for venue in ('both', 'polymarket', 'kalshi'):
        venue_rows = [r for r in rows if venue == 'both' or r['platform'] == venue]
        tables[venue] = {}
        for category in ['All categories', *categories]:
            cohort = [r for r in venue_rows if category == 'All categories' or r['category'] == category]
            if not cohort:
                continue
            result = {'horizons': {}, 'matched': {}}
            for day in DAYS:
                result['horizons'][str(day)] = stats([o for r in cohort if (o := observation(r, day)) is not None])
            for far, near in ((30, 7), (7, 1), (30, 1)):
                pairs = [(a,b) for r in cohort if (a := observation(r,far)) is not None and (b := observation(r,near)) is not None]
                result['matched'][f'{far}/{near}'] = {'far': stats([a for a,b in pairs]), 'near': stats([b for a,b in pairs])}
            tables[venue][category] = result
    data = {
        'auditedAt': datetime.now(timezone.utc).isoformat(),
        'title': 'Independent October 2026 high-volume benchmark',
        'source': SOURCE,
        'download': BASE+NAME,
        'localDownload': 'downloads/predictdesks-2026.csv.gz',
        'attribution': 'PredictDesks Research, How accurate are prediction markets? A study of resolved Polymarket and Kalshi markets (October 2026). Recalculated by Market Calibration Atlas.',
        'license': 'https://creativecommons.org/licenses/by/4.0/',
        'sha256': hashlib.sha256(raw).hexdigest(),
        'sourcePulledOn': '2026-10-25',
        'sourceRows': len(source_rows), 'exactDuplicatesRemoved': duplicates,
        'invalidForecastsExcluded': invalid,
        'uniqueContracts': len(rows),
        'contractsByVenue': dict(Counter(r['platform'] for r in rows)),
        'referenceStart': min(r['reference_time_utc'] for r in rows),
        'referenceEnd': max(r['reference_time_utc'] for r in rows),
        'method': 'Atlas removes identical duplicate venue/market IDs and evaluates favorites priced at least 51%. Each contract counts equally. Missing and out-of-range prices are excluded separately at each horizon. Matched comparisons require a qualifying favorite at both dates; the favored side may change.',
        'limits': [
            'Only contracts with at least 100,000 final volume: dollars on Polymarket, contracts on Kalshi. This is not the complete 358,236-contract article sample.',
            'Separate price basis: Polymarket history prices; Kalshi midpoint, replaced by last trade when the spread exceeds 20 cents. Do not pool with the Atlas trade-price archives.',
            'The source uses scheduled end or market close, not independently verified occurrence time. Short-horizon leakage remains possible.',
            'The source reports a maximum price age of 6 hours, or 12 hours at 30 days. Individual quote timestamps are absent, so Atlas cannot verify this.',
            'Event IDs are absent. These tables have no event-clustered uncertainty estimates and related contracts may dominate.',
            'The source excludes short-lived crypto Up or Down contracts, parlays, voids and nonbinary settlements. Kalshi series are sampled; coverage differs from Atlas.',
        ],
        'tables': tables,
        'clockResearch': {
            'source': 'https://kalshi.com/research/publications/calibration',
            'paper': 'https://kalshi.com/research/kalshi-research-calibration.pdf',
            'published': '2026-08',
            'finding': 'The study compares actual occurrence clocks with administrative close clocks for sports and elections. Election close can follow the election by weeks. The occurrence-time mapping is not included in the downloadable Atlas panels.',
            'atlasStatus': 'Not independently occurrence-verified; no verified-clock filter can be inferred from a closing timestamp alone.',
        },
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(data, separators=(',', ':'))+'\n')
    download = output.parents[1]/'downloads'/'predictdesks-2026.csv.gz'
    download.parent.mkdir(parents=True, exist_ok=True)
    with download.open('wb') as file:
        with gzip.GzipFile(fileobj=file, mode='wb', mtime=0) as stream:
            stream.write(raw)
    print(json.dumps({k:data[k] for k in ('sourceRows','exactDuplicatesRemoved','uniqueContracts','contractsByVenue','referenceEnd')}))
    print(json.dumps(tables['both']['All categories']))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--cache', type=Path, required=True)
    parser.add_argument('--output', type=Path, default=Path('dist/data/research-audit.json'))
    args = parser.parse_args()
    run(args.cache, args.output)
