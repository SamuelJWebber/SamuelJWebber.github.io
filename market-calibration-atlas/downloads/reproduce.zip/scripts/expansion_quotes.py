"""Quote disagreement and paired forecast-score audit. Python 3 + duckdb/numpy/scipy.

Offline: python scripts/expansion_quotes.py
The public quote-watch.parquet is a pinned third-party recording, not an exchange-verified tape.
The Kalshi rows are the already validated deterministic historical candle sample.
"""
import argparse
import hashlib
import json
from pathlib import Path
import duckdb
import numpy as np
from scipy.stats import t

ROOT = Path(__file__).resolve().parents[1]
REVISION = '3030329b2a7a58fdf93c9b2aa3c68a0848d63137'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def interval(values, groups):
    values = np.asarray(values, float)
    if not len(values):
        return None
    mean = float(values.mean())
    gs = sorted(set(groups))
    if len(gs) < 20:
        return None
    residuals = np.array([sum(v - mean for v, g in zip(values, groups) if g == group) for group in gs])
    se = np.sqrt(len(gs)/(len(gs)-1) * np.sum(residuals**2)) / len(values)
    if se == 0:
        return None
    radius = float(t.ppf(.975, len(gs)-1) * se)
    return [mean-radius, mean+radius]


def score(rows, label):
    if not rows:
        return {'label':label,'n':0,'events':0}
    y = np.array([r['outcome'] for r in rows], float)
    ps = {name:np.array([r[col] for r in rows], float) for name,col in
          [('trade','yesTrade'),('midpoint','midpoint'),('bid','yesBid'),('ask','yesAsk')]}
    gs = [r['event'] for r in rows]
    scores = {}
    for name, p in ps.items():
        err = (p-y)**2
        scores[name] = {'meanPrice':float(p.mean()),'brier':float(err.mean()),
                        'signedBias':float((y-p).mean()),'brierCI':interval(err,gs)}
    gain = (ps['trade']-y)**2-(ps['midpoint']-y)**2
    outside = [r['outside'] for r in rows]
    return {'label':label,'n':len(rows),'events':len(set(gs)),
            'outcomeRate':float(y.mean()),'meanSpread':float(np.mean(ps['ask']-ps['bid'])),
            'meanAbsoluteTradeMidpointGap':float(np.mean(abs(ps['trade']-ps['midpoint']))),
            'outsideSpreadRate':float(np.mean(outside)), 'prices':scores,
            'midpointBrierImprovement':float(gain.mean()), 'improvementCI':interval(gain,gs)}


def run(watch, kalshi, audit, output):
    source = json.loads(kalshi.read_text())
    rows = [dict(zip(source['columns'],r)) for r in source['rows']]
    for r in rows:
        r['midpoint'] = (r['yesBid']+r['yesAsk'])/2
        r['outside'] = r['yesTrade'] < r['yesBid']-1e-8 or r['yesTrade'] > r['yesAsk']+1e-8
    horizons = []
    for days in [1,7,30,90,180,365]:
        sample = [r for r in rows if r['days']==days]
        horizons.append({'days':days,'all':score(sample,'All paired observations'),
            'withinSpread':score([r for r in sample if not r['outside']],'Trade inside quote spread'),
            'outsideSpread':score([r for r in sample if r['outside']],'Trade outside quote spread')})
    primary = horizons[0]['all']
    db = duckdb.connect(config={'threads':2,'memory_limit':'600MB'})
    db.read_parquet(str(watch)).create_view('watch')
    total = db.execute('select count(*), count(distinct slug), min(ts)::varchar, max(ts)::varchar from watch').fetchone()
    db.execute('''create temp view valid as select *, (bid+ask)/2 midpoint,
        (last_traded<bid-1e-8 or last_traded>ask+1e-8)::integer outside,
        abs(last_traded-(bid+ask)/2) gap, ask-bid spread
        from watch where bid>0 and ask<1 and ask>=bid and last_traded between 0 and 1
        and isfinite(bid) and isfinite(ask) and isfinite(last_traded)''')
    result = db.execute('select count(*),count(distinct slug),avg(outside),avg(gap),avg(spread) from valid').fetchone()
    contract = db.execute('select avg(outside),avg(gap),avg(spread) from (select slug,avg(outside) outside,avg(gap) gap,avg(spread) spread from valid group by slug)').fetchone()
    daily = db.execute('''select cast(ts as date)::varchar date,count(*) n,count(distinct slug) contracts,
        avg(outside) outsideRate,avg(gap) meanGap,avg(spread) meanSpread from valid group by cast(ts as date) order by 1''').fetchall()
    validation = json.loads(audit.read_text())
    matched = sum(isinstance(v,list) and any(m.get('slug')==slug for m in v) for slug,v in validation.items())
    out = {
      'title':'Which price should we trust?', 'status':'limited',
      'finding': 'A midpoint is not automatically a more accurate probability. In the paired one-day Kalshi sample, the midpoint-versus-trade score difference is small and uncertain. The newly downloaded quote archive is useful for a disagreement diagnostic, but its identifiers and event clocks could not be validated for forecast scoring.',
      'metrics':[{'label':'Paired one-day Kalshi contracts','value':primary['n']},
                 {'label':'One-day parent events','value':primary['events']},
                 {'label':'Trade Brier score','value':primary['prices']['trade']['brier']},
                 {'label':'Midpoint Brier score','value':primary['prices']['midpoint']['brier']},
                 {'label':'Midpoint Brier improvement','value':primary['midpointBrierImprovement'],'ci':primary['improvementCI']}],
      'primary':primary,'horizons':horizons,
      'chart': {'title':'Midpoint improvement over last trade on the same observations',
          'xLabel':'Days before recorded close','yLabel':'Trade Brier minus midpoint Brier; positive favors midpoint',
          'rows':[{'x':h['days'],'y':h['all']['midpointBrierImprovement'],'ci':h['all']['improvementCI'],
                   'n':h['all']['n'],'events':h['all']['events']} for h in horizons]},
      'table': [{'days':h['days'],'contracts':h['all']['n'],'events':h['all']['events'],
                 'tradeBrier':h['all']['prices']['trade']['brier'],'midpointBrier':h['all']['prices']['midpoint']['brier'],
                 'midpointImprovement':h['all']['midpointBrierImprovement'],'outsideSpreadRate':h['all']['outsideSpreadRate']} for h in horizons],
      'downloadedArchiveAudit':{
          'status':'Not accepted as exchange-verified forecast evidence',
          'totalSnapshots':total[0],'totalContracts':total[1],'start':total[2],'end':total[3],
          'pairedSnapshots':result[0],'pairedContracts':result[1],
          'snapshotWeightedOutsideSpreadRate':result[2],'snapshotWeightedAbsoluteGap':result[3],
          'snapshotWeightedSpread':result[4],
          'equalContractOutsideSpreadRate':contract[0],'equalContractAbsoluteGap':contract[1],
          'equalContractSpread':contract[2],
          'officialSlugLookups':len(validation),'officialSlugMatches':matched,
          'lookupSelection':'First 12 contracts in md5(slug || atlas-exp-quote-v1) order among authoritative-label watchlist matches; selected without examining scores.',
          'daily': [dict(zip(['date','n','contracts','outsideRate','meanGap','meanSpread'],r)) for r in daily],
          'note':'These are descriptions of the downloaded third-party recording. A last trade outside a later quote spread need not be wrong or stale: quote/trade timestamps can differ. No prediction accuracy, latency, or venue-wide behavior is inferred from this unvalidated archive.'},
      'methods':[
          'Primary comparison fixed at one day before recorded close. Original Kalshi sample selected up to 250 contracts per horizon in a deterministic hash order independent of outcomes.',
          'All price measures use exactly the same contract/horizon observations and original YES outcome; no favorite threshold or probability bins.',
          'The source chooses the last active hourly candle within the preceding 24 hours with a two-sided quote strictly between zero and one.',
          'Brier improvement = mean squared error of trade minus mean squared error of midpoint. Positive values favor midpoint. Approximate 95% Student-t intervals cluster paired residuals by parent event.',
          'One-day analysis is primary. Other horizons and inside/outside-spread comparisons are descriptive sensitivity checks, not independent confirmations.',
          'Bid and ask are included as quote-side diagnostic comparisons, not asserted fair probabilities or achievable net returns.',
          'New third-party archive pinned to a repository revision; downloaded bytes hashed. Excluded missing trades, crossed books and boundary quotes. Snapshots have unique contract/time keys. No convergence-inferred labels are used to score forecasts.'
      ],
      'limitations':[
          'Trade and bid/ask closes are from the same hour, not necessarily the same second. This is not a true simultaneous executable-price experiment.',
          'Recorded close is only a proxy for the time the outcome became known. Prices can still include already-known information.',
          'The Kalshi sample favors active markets with two-sided quotes and is small. Horizon cohorts differ. It cannot establish that spread causes forecast errors.',
          'The third-party archive lacks event clocks and canonical parent IDs. Zero of the fixed sample of official exact-slug lookups matched; that does not prove the data false, but prevents reliable linkage.',
          'The third-party watchlist deliberately selected active markets and rotated; observations are highly repeated and not independent. Its outcome labels are time-censored, and some were inferred from prices.',
          'No fees, order size, slippage, fills, settlement delay or trading profitability are modeled.'
      ],
      'sources':[
          {'title':'Kalshi validated historical quote sample','url':'data/quotes/kalshi.json','sha256':digest(kalshi)},
          {'title':'Kalshi historical candle documentation','url':source['source']},
          {'title':'Third-party Polymarket Order Book Dataset — Dinesh Gopalakrishnan, CC BY 4.0','url':'https://github.com/DineshKumar8399/polymarket-orderbook-dataset'},
          {'title':'Pinned third-party watchlist recording','url':f'https://huggingface.co/datasets/DineshKumar8399/polymarket-orderbook-dataset/resolve/{REVISION}/watch_quotes.parquet','sha256':digest(watch),'revision':REVISION},
          {'title':'Pinned labels downloaded for identifier-audit sampling only; not used as forecast targets','url':f'https://huggingface.co/datasets/DineshKumar8399/polymarket-orderbook-dataset/resolve/{REVISION}/labels.parquet','sha256':'d8c509016fd15ba0ac346c9b9eedd5febcaf660703093ea4a3886b87cb979dbc'},
          {'title':'Pinned metadata inspected for event-clock availability','url':f'https://huggingface.co/datasets/DineshKumar8399/polymarket-orderbook-dataset/resolve/{REVISION}/markets.parquet','sha256':'9469b844297763fc9259a902b53df6100e0d1dd9ac95e9cdeef7dcc7e6f487c2'},
          {'title':'Official market identity API','url':'https://gamma-api.polymarket.com/docs'},
          {'title':'Official exact-slug lookup audit','url':'data/expansion/quote-identifier-audit.json','sha256':digest(audit)}
      ],
      'downloads':[{'title':'Pinned watchlist recording (8.2 MB)','url':'downloads/quote-watch.parquet'},
                   {'title':'Official identifier lookup audit','url':'data/expansion/quote-identifier-audit.json'}]
    }
    output.parent.mkdir(exist_ok=True,parents=True)
    output.write_text(json.dumps(out,separators=(',',':'),ensure_ascii=False,allow_nan=False)+'\n')
    print(json.dumps({'primary':primary,'archive':{k:v for k,v in out['downloadedArchiveAudit'].items() if k!='daily'}},indent=2))


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--watch',type=Path,default=ROOT/'dist/downloads/quote-watch.parquet')
    p.add_argument('--kalshi',type=Path,default=ROOT/'dist/data/quotes/kalshi.json')
    p.add_argument('--audit',type=Path,default=ROOT/'dist/data/expansion/quote-identifier-audit.json')
    p.add_argument('--output',type=Path,default=ROOT/'dist/data/expansion/quotes.json')
    a=p.parse_args();run(a.watch,a.kalshi,a.audit,a.output)
