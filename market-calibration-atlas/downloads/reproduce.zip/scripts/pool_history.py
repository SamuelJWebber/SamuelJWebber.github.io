"""Combine venue-level calendar and volume statistics at a fixed topic and horizon.

Each eligible contract forecast contributes once. Events are scoped to the
exchange. Volume medians belong to the source venue, topic, and horizon.
Requires the pooled topic taxonomy in all/meta.json and per-venue history shards.
"""
import argparse
import gzip
import json
from collections import defaultdict
from pathlib import Path

from aggregate import atomic_json


def read_json(path):
    if path.suffix == '.gz':
        with gzip.open(path, 'rt', encoding='utf-8') as stream:
            return json.load(stream)
    return json.loads(path.read_text(encoding='utf-8'))


def combine(rows):
    if not rows:
        return None
    contracts = sum(row[0] for row in rows)
    events = sum(row[1] for row in rows)
    return [contracts, events, *(
        round(sum(row[0] * row[index] for row in rows) / contracts, 6)
        for index in (2, 3, 4)
    )]


def calendar(days, period):
    groups = defaultdict(list)
    for record in days.values():
        for label, *metrics in record[period]:
            groups[label].append(metrics)
    return [[label, *combine(rows)] for label, rows in sorted(groups.items())]


def volume(days, key):
    cohorts = {venue: day[key] for venue, day in days.items() if day.get(key)}
    if not cohorts:
        return None
    result = {
        'cut': None,
        'cuts': {venue: data['cut'] for venue, data in cohorts.items()},
        'n': sum(data['n'] for data in cohorts.values()),
    }
    for group in ('low', 'high'):
        result[group] = combine([data[group] for data in cohorts.values() if data[group]])
    if result['n'] != sum(result[group][0] for group in ('low', 'high') if result[group]):
        raise ValueError(f'Incomplete volume cohorts in {key}')
    return result


def build(data_root):
    venues = [venue['id'] for venue in read_json(data_root/'index.json')['venues'] if venue['id'] != 'all']
    base = data_root/'all'
    dest = base/'history'
    dest.mkdir(parents=True, exist_ok=True)
    histories = defaultdict(dict)
    infos = {}
    for venue in venues:
        src = data_root/venue
        infos[venue] = read_json(src/'history'/'info.json')
        for topic in read_json(src/'meta.json')['topics']:
            histories[topic['kind'], topic['name']][venue] = src/'history'/f"{topic['id']}.json.gz"

    observations = sum(info['total'] for info in infos.values())
    meta = read_json(base/'meta.json')
    if observations != meta['observations']:
        raise ValueError('Venue and pooled archive totals disagree')
    for topic in meta['topics']:
        paths = histories[topic['kind'], topic['name']]
        if not paths:
            raise ValueError(f"Unknown pooled topic {topic['name']}")
        days = defaultdict(dict)
        for venue, path in paths.items():
            for day, row in read_json(path).items():
                days[day][venue] = row
        pooled = {}
        for day, inputs in days.items():
            record = {period: calendar(inputs, period) for period in ('years','quarters')}
            for key in ('volume', 'volumeCumulative'):
                record[key] = volume(inputs, key)
            pooled[day] = record
        atomic_json(dest/f"{topic['id']}.json.gz", pooled, True)

    info = {
        'unit': 'venue-specific units',
        'units': {venue: s['unit'] for venue,s in infos.items()},
        'cumulativeUnit': 'venue-specific units',
        'cumulativeUnits': {venue: s['cumulativeUnit'] for venue,s in infos.items()},
        'method': 'Each venue measures trading volume in its forecast window. Contracts are split at their own venue’s median for the selected event type and horizon, then combined across venues.',
        'cumulativeMethod': 'Each venue sums recorded trading volume through the forecast cutoff. Contracts are split at their own venue’s median for the selected event type and horizon, then combined across venues.',
        'periodMethod': 'Calendar periods follow the source venue’s recorded forecast date. Multiple exchanges can list contracts on the same event.',
        'total': observations,
        'eligible': sum(s['eligible'] for s in infos.values()),
        'cumulativeEligible': sum(s['cumulativeEligible'] for s in infos.values()),
        'firstDate': min(s['firstDate'] for s in infos.values()),
        'lastDate': max(s['lastDate'] for s in infos.values()),
    }
    for count, status in [('eligible','status'),('cumulativeEligible','cumulativeStatus')]:
        info[status] = 'available' if info[count] else 'unavailable'
    atomic_json(dest/'info.json', info)
    print(f"Pooled {len(meta['topics'])} history shards across {len(venues)} venues and {observations:,} observations.")


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data-root', type=Path, default=Path(__file__).resolve().parents[1]/'dist'/'data')
    build(parser.parse_args().data_root)
