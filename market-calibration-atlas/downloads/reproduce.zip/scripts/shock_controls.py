"""Frozen matched quiet-window benchmarks for the March Polymarket shock study.

Offline: python scripts/shock_controls.py --bars 'dist/downloads/intraday-polymarket-*.parquet'
Requires the published polymarket-shocks.json.gz and intraday_analysis.py.
No outcomes or future prices determine matching. This is descriptive matching,
not a randomized or causally identified effect of news.
"""
from __future__ import annotations
import argparse
import gzip
import json
import math
from collections import Counter
from pathlib import Path
from datetime import datetime, timezone

import duckdb
import numpy as np
import pandas as pd

from intraday_analysis import register_source, emit, estimate
from shock_analysis import selected

ROOT=Path(__file__).resolve().parents[1]
OFFSETS=[0,5,10,15,30,60]
START,END=1772323200,1774742400


def scalar(value):
    return None if not np.isfinite(value) else round(float(value),8)


def stats(values):
    a=np.array(values,dtype=float)
    if not len(a):return {'mean':None,'meanAbsolute':None,'p95Absolute':None,'maxAbsolute':None}
    return dict(mean=scalar(a.mean()),meanAbsolute=scalar(np.abs(a).mean()),
                p95Absolute=scalar(np.quantile(np.abs(a),.95)),maxAbsolute=scalar(np.abs(a).max()))


def balance(matches):
    return dict(n=len(matches),priceDifference=stats([x['shockPrice']-x['controlPrice'] for x in matches]),
       logLeadRatio=stats([math.log(x['controlLeadHours']/x['shockLeadHours']) for x in matches]),
       noiseDifference=stats([x['shockNoise']-x['controlNoise'] for x in matches]),
       activeReturnCountDifference=stats([x['shockHistoryN']-x['controlHistoryN'] for x in matches]),
       logVolumeDifference=stats([math.log1p(x['shockVolume'])-math.log1p(x['controlVolume']) for x in matches]),
       meanShockLeadHours=scalar(np.mean([x['shockLeadHours'] for x in matches])) if matches else None,
       meanControlLeadHours=scalar(np.mean([x['controlLeadHours'] for x in matches])) if matches else None)


def prepare(db,specification):
    source_hash,inputs=register_source(db,specification)
    db.execute('''create temp table active as select market_id,event_id,broad,topic,
       ts,price,outcome,anchor,volume from source
       where price between 0 and 1 and volume>0 and ts<=anchor''')
    # Every feature is measured at, or strictly before, this bar end. Current
    # price and volume are allowed matching variables; future paths are absent.
    db.execute('''create temp table features as
      with a as (select *,lag(ts) over w prev_ts,lag(price) over w prev_price
        from active window w as (partition by market_id order by ts)),
      b as (select *,case when ts-prev_ts=300 then price-prev_price end delta from a),
      c as (select *,list(delta) filter(where delta is not null) over history returns,
        count(*) over quiet quiet_n,min(ts) over quiet quiet_first,
        max(price) over quiet-min(price) over quiet quiet_range
        from b window history as(partition by market_id order by ts range between 3600 preceding and 1 preceding),
        quiet as(partition by market_id order by ts range between 900 preceding and 1 preceding)),
      d as (select *,len(returns) history_n,
        1.4826*list_median(list_transform(returns,lambda x:abs(x-list_median(returns)))) noise
        from c),
      e as (select * exclude(returns),
        delta is not null and quiet_n>=3 and prev_ts-quiet_first>=600
        and quiet_range<=.05+1e-10 and history_n>=6 valid_history
        from d),
      f as (select *,valid_history and abs(delta)>=.05-1e-10
        and abs(delta)>=4*noise-1e-10 is_shock from e)
      select *,max(case when is_shock then ts end) over(partition by market_id order by ts
        rows between unbounded preceding and 1 preceding) previous_shock_ts from f''')
    # Controls do not look forward to ask if another jump occurs later.
    controls=db.execute('''select market_id,event_id,broad,topic,ts,price,outcome,
        anchor,volume,history_n,noise,delta from features where valid_history
        and abs(delta)<=.01+1e-10 and (previous_shock_ts is null or ts-previous_shock_ts>=21600)
        and ts>=? and ts<? order by market_id,ts''',[START,END]).fetchdf()
    current=db.execute('''select market_id,ts,price,delta,history_n from features
        where is_shock and ts>=? and ts<?''',[START,END]).fetchdf()
    print(f'{len(controls):,} quiet control candidates; {len(current):,} sharp candidates before spacing',flush=True)
    return source_hash,inputs,controls,current


def metric(frame,name):
    if not len(frame):return dict(n=0,events=0,mean=None,ci=None)
    x=estimate(frame,[''+name])
    return dict(n=x['n'],events=x['events'],mean=x[name],ci=x['ci'][name])


def cluster_pairs(matches):
    # An event appearing as either shock or control ties those pairs together.
    # Reused parent events therefore cannot increase apparent independence.
    parents={}
    def find(x):
        if x not in parents:parents[x]=x
        if parents[x]!=x:parents[x]=find(parents[x])
        return parents[x]
    for m in matches:
        a,b=find(m['shockEvent']),find(m['controlEvent'])
        if a!=b:parents[b]=a
    return [find(m['shockEvent']) for m in matches]


def match_windows(shocks,controls,lookup,mode):
    by_market={k:v for k,v in controls.groupby('market_id',sort=False)}
    by_time_topic={k:v for k,v in controls.groupby(['ts','topic'],sort=False)} if mode=='contemporaneous' else {}
    used=set();matches=[]
    for s in sorted(shocks,key=lambda s:(s['ts'],s['market'])):
        if s['lead']<=0:continue
        if mode=='same_contract':
            pool=by_market.get(s['market'])
            if pool is None:continue
            # Its full hour ends at least 15 min before this first-response bar.
            pool=pool[(pool.ts<=s['ts']-4500)&(pool.ts>=s['ts']-7*86400)]
            direction=s['direction']
            prices=pool.price.to_numpy(float)
            prices=prices if direction==1 else 1-prices
            directions=np.full(len(pool),direction,dtype=np.int8)
        else:
            pool=by_time_topic.get((s['ts'],s['topic']))
            if pool is None:continue
            pool=pool[pool.event_id.astype(str)!=s['event']]
            raw=pool.price.to_numpy(float)
            # Orientation is selected only by current-price proximity. Ties use
            # the tracked side. No final outcome enters this decision.
            directions=np.where(np.abs(raw-s['after'])<=np.abs(1-raw-s['after']),1,-1)
            prices=np.where(directions==1,raw,1-raw)
        if not len(pool):continue
        leads=(pool.anchor.to_numpy(float)-pool.ts.to_numpy(float))/3600
        ratio=leads/s['lead']
        valid=(np.abs(prices-s['after'])<=.05+1e-9)&(ratio>=.5-1e-9)&(ratio<=2+1e-9)&(leads>0)
        ids=pool.market_id.astype(str).to_numpy();times=pool.ts.to_numpy(np.int64)
        valid &= np.array([(m,int(t)) not in used for m,t in zip(ids,times)])
        ix=np.flatnonzero(valid)
        if not len(ix):continue
        noise=pool.noise.to_numpy(float);history=pool.history_n.to_numpy(float);volume=pool.volume.to_numpy(float)
        distance=(np.abs(prices-s['after'])/.05+np.abs(np.log(np.maximum(ratio,1e-12)))/math.log(2)
            +np.abs(noise-s['noise'])/.025+np.abs(history-s['historyN'])/6
            +np.abs(np.log1p(volume)-math.log1p(s['volume']))/math.log(10))
        # Deterministic greedy minimum distance; time/market break exact ties.
        i=min(ix,key=lambda i:(distance[i],abs(int(times[i])-s['ts']),int(times[i]),ids[i]))
        control=pool.iloc[i];used.add((ids[i],int(times[i])))
        cdir=int(directions[i]);control_won=int(control.outcome) if cdir==1 else 1-int(control.outcome)
        matches.append(dict(shockMarket=s['market'],controlMarket=ids[i],shockEvent=s['event'],
            controlEvent=str(control.event_id),topic=s['topic'],broad=s['broad'],
            shockTs=s['ts'],controlTs=int(times[i]),shockDirection=s['direction'],controlDirection=cdir,
            shockPrice=s['after'],controlPrice=float(prices[i]),shockWon=s['won'],controlWon=control_won,
            shockLeadHours=s['lead'],controlLeadHours=float(leads[i]),
            shockNoise=s['noise'],controlNoise=float(noise[i]),shockHistoryN=s['historyN'],
            controlHistoryN=int(history[i]),shockVolume=s['volume'],controlVolume=float(volume[i]),
            matchDistance=float(distance[i])))
    return matches


def add_paths(db,matches):
    queries=[]
    for i,m in enumerate(matches):
        for side in ['shock','control']:
            for j,minute in enumerate(OFFSETS):
                queries.append((i,side,j,m[side+'Market'],m[side+'Ts']+minute*60,m[side+'Direction']))
        m['shockPrices']=[None]*len(OFFSETS);m['controlPrices']=[None]*len(OFFSETS)
    if not queries:return
    frame=pd.DataFrame(queries,columns=['pair','side','step','market_id','ts','direction'])
    db.register('path_queries',frame)
    results=db.execute('''select q.pair,q.side,q.step,
        case when q.direction=1 then a.price else 1-a.price end p
        from path_queries q left join active a on q.market_id=a.market_id and q.ts=a.ts
        and q.ts<=a.anchor order by q.pair,q.side,q.step''').fetchall()
    for i,side,step,p in results:matches[i][side+'Prices'][step]=scalar(p) if p is not None else None
    for m in matches:
        assert abs(m['shockPrices'][0]-m['shockPrice'])<1e-7
        assert abs(m['controlPrices'][0]-m['controlPrice'])<1e-7


def summarize(shocks,matches,mode,threshold):
    complete=[m for m in matches if all(p is not None for p in m['shockPrices']+m['controlPrices'])]
    groups=cluster_pairs(complete)
    paths=[]
    for i,minute in enumerate(OFFSETS):
        data=[]
        for m,cluster in zip(complete,groups):
            sp,cp=m['shockPrices'][i],m['controlPrices'][i]
            sd,cd=sp-m['shockPrice'],cp-m['controlPrice']
            sg=(m['shockPrice']-m['shockWon'])**2-(sp-m['shockWon'])**2
            cg=(m['controlPrice']-m['controlWon'])**2-(cp-m['controlWon'])**2
            data.append(dict(event_id=cluster,shockPrice=sp,controlPrice=cp,shockDrift=sd,controlDrift=cd,
                excessDrift=sd-cd,shockBrierGain=sg,controlBrierGain=cg,excessBrierGain=sg-cg))
        frame=pd.DataFrame(data)
        names=['shockPrice','controlPrice','shockDrift','controlDrift','excessDrift',
               'shockBrierGain','controlBrierGain','excessBrierGain']
        paths.append(dict(offsetMinutes=minute,**{name:metric(frame,name) for name in names}))
    result=dict(id=f'{mode}_{threshold}',comparison=mode,minimumJumpPoints=threshold,
      label=('Earlier quiet period in the same contract' if mode=='same_contract' else 'Contemporaneous quiet contract in the same event type'),
      counts=dict(selectedShocks=len(shocks),shockCompleteBeforeMatching=sum(s['complete'] for s in shocks),
        matchedBeforeFollowup=len(matches),completePairs=len(complete),unmatchedShocks=len(shocks)-len(matches),
        matchedMissingFollowup=len(matches)-len(complete),clusterGroups=len(set(groups)),
        shockParentEvents=len({m['shockEvent'] for m in complete}),
        controlParentEvents=len({m['controlEvent'] for m in complete})),
      metrics={k:v for k,v in paths[-1].items() if k!='offsetMinutes'},paths=paths,
      categoryCounts=dict(Counter(m['broad'] for m in complete)),
      balance=dict(matchedBeforeFollowup=balance(matches),completePairs=balance(complete)),
      limitations=[
        'Matches are selected without future prices or outcomes; complete paths are then required on both sides.',
        'Observable matching does not make news arrivals random and does not identify a causal news effect.',
        'Sparse support means these pairs may not represent the full shock sample.',
        'Only starting price and time-to-close have hard matching calipers. Noise, recent activity and volume affect distance but can remain imbalanced; inspect balance before interpreting differences.',
        'Trade-price noise, unobserved information and later news can differ between shocks and quiet controls.',
        ('Earlier controls may be in a different stage of the event. Matching their price to the later post-shock price can select fall-and-rebound histories; full follow-up ends at least 15 minutes before the shock bar.' if mode=='same_contract' else 'Contemporaneous controls share a detailed topic and timestamp, but remain different questions and events; outcomes can differ.')])
    return result,complete


def analyze(specification,output,shock_path):
    output.mkdir(parents=True,exist_ok=True)
    payload=json.load(gzip.open(shock_path,'rt'))
    db=duckdb.connect(config={'threads':2,'memory_limit':'850MB'})
    source_hash,inputs,controls,current=prepare(db,specification)
    lookup={(str(r.market_id),int(r.ts)):r for r in current.itertuples(index=False)}
    cases=[];export=[]
    for threshold in [5,20]:
        shocks=[]
        for row in selected(payload['rows'],minimum=threshold/100):
            market=payload['markets'][row[0]];actual=lookup[(market['id'],row[1])]
            direction=1 if actual.delta>0 else -1
            shocks.append(dict(market=market['id'],event=market['event'],broad=market['broad'],topic=market['topic'],
                ts=row[1],after=row[3],won=row[4],noise=row[5],lead=row[6],volume=row[7],
                historyN=row[11],direction=direction,complete=all(row[13][i] is not None for i,t in enumerate(payload['meta']['offsetMinutes']) if t<=60)))
        for mode in ['same_contract','contemporaneous']:
            matches=match_windows(shocks,controls,lookup,mode)
            add_paths(db,matches)
            result,complete=summarize(shocks,matches,mode,threshold)
            cases.append(result)
            for m in matches:export.append(dict(case=result['id'],complete=all(p is not None for p in m['shockPrices']+m['controlPrices']),**m))
            print(json.dumps(dict(case=result['id'],counts=result['counts'],metrics=result['metrics']),separators=(',',':')),flush=True)
    metadata=dict(venue='polymarket',generatedDate=datetime.now(timezone.utc).date().isoformat(),
        sourceHash=source_hash,inputFiles=inputs,sourceShocks=str(shock_path.name),
        studyPeriod='March 1–28, 2026',thresholdsPoints=[5,20],noiseMultiple=4,offsetMinutes=OFFSETS,
        quietControlCount=len(controls),priceCaliper=.05,leadRatioCaliper=[.5,2],
        controlMaximumCurrentMove=.01,controlPriorShockExclusionHours=6,
        sameContractMaximumDaysEarlier=7,sameContractMinimumMinutesEarlier=75,
        contemporaneousTimestampToleranceSeconds=0,
        matching='Greedy chronological matching without reuse of a control market/timestamp. Match price after the shock to current quiet price within five percentage points and remaining time to close within a factor of two. Minimize the sum of absolute differences scaled by 5pp price, log(2) remaining-time ratio, 2.5pp noise, six prior adjacent returns and log(10) first-bar volume ratio. No final outcome or future price enters matching. Quiet controls satisfy the same pre-period history and quietness rules, have a current absolute move no greater than one point, and no detected 5pp/four-noise shock in the prior six hours.',
        sameContract='Same contract and outcome orientation, earlier by at least 75 minutes and no more than seven days. Its entire follow-up ends at least 15 minutes before the shock response bar.',
        contemporaneous='Exact same bar timestamp and detailed topic, different parent event. Track the original token or its complement, whichever current price is nearer the shocked rising-side price; ties use the tracked side. This choice does not use outcomes.',
        uncertainty='Approximate 95% Student-t intervals on paired differences. Cluster connected components of parent-event IDs occurring as either shock or control, so shared events cannot count as independent evidence. Suppress intervals below 20 components or at zero variance. These exploratory intervals are not multiplicity adjusted.',
        interpretation='Excess drift is shock drift minus matched quiet-control drift. A negative value is additional reversal relative to these controls, not a causal effect of news. Common support, balance and complete-path retention matter. Matching can select a narrow subset of shocks.',
        download='data/intraday/shock-control-pairs.json.gz')
    emit(output/'shock-controls.json',dict(meta=metadata,cases=cases))
    emit(output/'shock-control-pairs.json.gz',dict(meta=metadata,pairs=export),compressed=True)
    return cases


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--bars',required=True)
    p.add_argument('--output',type=Path,default=ROOT/'dist/data/intraday')
    p.add_argument('--shocks',type=Path,default=ROOT/'dist/data/intraday/polymarket-shocks.json.gz')
    a=p.parse_args();analyze(a.bars,a.output,a.shocks)
