"""Compare the same contracts at two observed horizons.

The output is keyed by topic ID and long/short day pair. Each value contains
the number of matched contracts, number of events, long and short Brier scores,
and long and short favorite hit rates. The final two values are signed calibration
bias (favorite outcome minus forecast), computed over the same eligible sample.
The favored side can change between dates; a contract must qualify at both.
"""
import argparse
import json
from pathlib import Path

import duckdb

from aggregate import atomic_json, rounded, create_favorites


PAIRS = ((7, 1), (30, 7), (30, 1), (90, 30), (180, 30), (365, 30),
         (730, 30), (1095, 30))


def build(panel, output):
    dest = output / panel.stem
    meta = json.loads((dest / 'meta.json').read_text())
    topic_ids = {}
    result = {}
    for topic in meta['topics']:
        name = topic['name'].removeprefix('All ') if topic['kind'] == 'broad' else topic['name']
        topic_ids[topic['kind'], name] = topic['id']
        result[topic['id']] = {f'{a}/{b}': [0, 0, None, None, None, None, None, None] for a, b in PAIRS}

    with duckdb.connect() as db:
        db.execute('set threads=2')
        db.read_parquet(str(panel)).create_view('panel')
        create_favorites(db)
        db.execute('create temp table horizons (long_day integer, short_day integer)')
        db.executemany('insert into horizons values (?, ?)', PAIRS)
        db.execute("""
            create temp table paired as
              select h.long_day, h.short_day, l.market_id, l.event_id, l.topic, l.broad,
                     l.y as y1,s.y as y2,l.p as p1,s.p as p2
              from horizons h
              join favorites l on l.days=h.long_day
              join favorites s on s.market_id=l.market_id and s.days=h.short_day
        """)
        rows = db.execute("""
            select long_day, short_day, broad, topic, count(*), count(distinct event_id),
                   avg((p1-y1)^2), avg((p2-y2)^2), avg(y1),avg(y2),
                   avg(y1-p1),avg(y2-p2)
            from paired
            group by grouping sets ((long_day,short_day), (long_day,short_day,broad),
                                    (long_day,short_day,topic))
        """).fetchall()

    def pair_result(a,b,broad,detail):
        key = ('detail', detail) if detail is not None else (
            ('broad', broad) if broad is not None else ('all', 'All topics'))
        return result[topic_ids[key]][f'{a}/{b}']

    for a, b, broad, detail, n, events, *values in rows:
        pair_result(a,b,broad,detail)[:] = [n,events,*map(rounded,values)]

    for topic in meta['topics']:
        for pair, values in result[topic['id']].items():
            a, b = pair.split('/')
            if values[0] > min(topic['bench'].get(a, [0])[0], topic['bench'].get(b, [0])[0]):
                raise ValueError(f'{panel.stem} topic {topic["id"]} pair {pair} exceeds observed samples')
    atomic_json(dest / 'matched.json', result)
    print(panel.stem, result['0'], flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('panels', nargs='+', type=Path)
    parser.add_argument('--output', type=Path, default=Path(__file__).resolve().parents[1] / 'dist' / 'data')
    args = parser.parse_args()
    for path in args.panels:
        build(path, args.output)
