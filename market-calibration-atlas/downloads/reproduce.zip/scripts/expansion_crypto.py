#!/usr/bin/env python3
"""Descriptive collector-clock BTC shock/Polymarket quote-response audit.

Requires duckdb, numpy, pandas. Offline: python scripts/expansion_crypto.py
  --cache /tmp/atlas-exp-crypto
With --collect, download the fixed source files listed by the committed manifest.
No fitted model, true-probability estimate, execution claim, or outcome inference.
"""
from pathlib import Path
import argparse, json, hashlib, urllib.request, concurrent.futures, gzip, re
import numpy as np
import pandas as pd
import duckdb
ROOT=Path(__file__).resolve().parents[1]
START=int(pd.Timestamp('2026-02-12',tz='UTC').timestamp()*1000)
END=int(pd.Timestamp('2026-02-19',tz='UTC').timestamp()*1000)
HORIZONS=[0,100,250,500,1000,2000,5000]
FLOORS=[2,5,10]
URL='https://huggingface.co/datasets/gregyoung14/openmarket-btc-polymarket'

def collect(cache,manifest):
 def one(f):
  p=cache/f['path'];p.parent.mkdir(parents=True,exist_ok=True)
  if not p.exists():
   u=URL+'/resolve/'+manifest['revision']+'/'+f['path']+'?download=true'
   with urllib.request.urlopen(u,timeout=180) as r,p.open('wb') as out:
    while block:=r.read(1<<20):out.write(block)
  assert hashlib.sha256(p.read_bytes()).hexdigest()==f['sha256'],str(p)
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:list(ex.map(one,manifest['files']))

def run(cache,manifest):
 c=duckdb.connect();c.execute("SET threads=2")
 b=c.sql(f"SELECT ingest_ts_ms t,source_ts_ms source_t,price,id FROM read_parquet('{cache}/unified/binance_ticks_ms/**/*.parquet') WHERE ingest_ts_ms >= {START} AND ingest_ts_ms < {END} ORDER BY ingest_ts_ms,id").df().drop_duplicates('t',keep='last')
 p=c.sql(f"SELECT market_slug,ingest_ts_ms t,source_ts_ms source_t,best_bid,best_ask,id FROM read_parquet('{cache}/unified/polymarket_ticks_ms/**/*.parquet') WHERE ingest_ts_ms >= {START} AND ingest_ts_ms < {END} AND upper(side_label)='UP' ORDER BY market_slug,ingest_ts_ms,id").df().drop_duplicates(['market_slug','t'],keep='last')
 # Last listed price is a price-change payload, not necessarily the midpoint.
 p['mid']=(p.best_bid+p.best_ask)/2
 valid=(p.best_bid>0)&(p.best_ask<1)&(p.best_bid<=p.best_ask)&((p.best_ask-p.best_bid)<=.100000001)
 p.loc[~valid,'mid']=np.nan
 groups={}
 for slug,g in p.groupby('market_slug',sort=False):
  m=re.fullmatch(r'btc-updown-15m-(\d+)',slug)
  if m:groups[int(m[1])*1000]=(slug,g.t.to_numpy(),g.mid.to_numpy(),g.source_t.to_numpy())
 bt=b.t.to_numpy();bp=b.price.to_numpy();idx=np.searchsorted(bt,bt-1000,side='right')-1
 ok=idx>=0;old=np.maximum(idx,0);ok&=(bt-bt[old]<=1250)&(bt-bt[old]>=1000)&np.isfinite(bp)&(bp>0)&(bp[old]>0)
 ret=np.full(len(b),np.nan);ret[ok]=10000*np.log(bp[ok]/bp[old[ok]])
 all_rows=[];summaries=[]
 for floor in FLOORS:
  candidates=np.flatnonzero(np.abs(ret)>=floor);spaced=[];last=-np.inf
  for k in candidates:
   if bt[k]-last>=10000:spaced.append(k);last=bt[k]
  before=0;complete=0;rows=[]
  exclusions={'noActiveRecorded15MinuteMarket':0,'nearNominalClose':0,'missingOrWideOrStaleInitialQuote':0,'initialPriceOutside5to95Percent':0,'missingOrWideOrStaleFollowup':0}
  for k in spaced:
   t=int(bt[k]);ms=t//900000*900000
   if ms not in groups:exclusions['noActiveRecorded15MinuteMarket']+=1;continue
   if ms+900000-t<30000:exclusions['nearNominalClose']+=1;continue
   slug,pt,pm,ps=groups[ms];j=np.searchsorted(pt,t,side='left')-1
   if j<0 or t-pt[j]>1000 or not np.isfinite(pm[j]):exclusions['missingOrWideOrStaleInitialQuote']+=1;continue
   base=float(pm[j])
   if base<.05 or base>.95:exclusions['initialPriceOutside5to95Percent']+=1;continue
   before+=1;js=np.searchsorted(pt,t+np.array(HORIZONS),side='right')-1
   if np.any(js<0) or np.any(t+np.array(HORIZONS)-pt[np.maximum(js,0)]>1000) or not np.all(np.isfinite(pm[np.maximum(js,0)])):
    exclusions['missingOrWideOrStaleFollowup']+=1;continue
   sign=1 if ret[k]>0 else -1;path=sign*(pm[js]-base)
   end=np.searchsorted(pt,t+5000,side='right');q=np.arange(j+1,end);q=q[pt[q]>=t]
   hit=q[np.isfinite(pm[q])&(sign*(pm[q]-base)>=.01-1e-9)]
   first=int(pt[hit[0]]-t) if len(hit) else None
   opposite=q[np.isfinite(pm[q])&(sign*(pm[q]-base)<=-.01+1e-9)]
   opposite_first=int(pt[opposite[0]]-t) if len(opposite) else None
   row={'thresholdBps':floor,'market':slug,'utc':pd.Timestamp(t,unit='ms',tz='UTC').isoformat(),'timestampMs':t,'spotReturnBps':float(ret[k]),'initialUpMidpoint':base,'initialQuoteAgeMs':int(t-pt[j]),'firstOnePointResponseMs':first,'responseWithinFiveSeconds':first is not None,'firstOppositeOnePointResponseMs':opposite_first,'path':{str(h):float(v) for h,v in zip(HORIZONS,path)}}
   rows.append(row)
  all_rows+=rows
  def summarize(rr):
   delays=[r['firstOnePointResponseMs'] for r in rr if r['firstOnePointResponseMs'] is not None]
   return {'n':len(rr),'markets':len(set(r['market'] for r in rr)),'responders':len(delays),'responseShare':len(delays)/len(rr) if rr else None,'oppositeDirectionShare':sum(r['firstOppositeOnePointResponseMs'] is not None for r in rr)/len(rr) if rr else None,'medianDelayAmongRespondersMs':float(np.median(delays)) if delays else None,'meanFiveSecondDriftPp':float(np.mean([r['path']['5000'] for r in rr])*100) if rr else None}
  dayrows=[]
  for day in sorted(set(r['utc'][:10] for r in rows)):
   dayrows.append({'date':day,**summarize([r for r in rows if r['utc'].startswith(day)])})
  path=[]
  for h in HORIZONS:
   path.append({'milliseconds':h,'meanSignedMidpointChangePp':float(np.mean([r['path'][str(h)] for r in rows])*100) if rows else None,'shareReachedOnePoint':sum(r['firstOnePointResponseMs'] is not None and r['firstOnePointResponseMs']<=h for r in rows)/len(rows) if rows else None,'shareReachedOppositeOnePoint':sum(r['firstOppositeOnePointResponseMs'] is not None and r['firstOppositeOnePointResponseMs']<=h for r in rows)/len(rows) if rows else None,'n':len(rows)})
  summaries.append({'thresholdBps':floor,'selectedSpotMoves':len(spaced),'eligibleInitialQuotes':before,'completePaths':len(rows),'exclusions':exclusions,**summarize(rows),'path':path,'days':dayrows})
 primary=next(x for x in summaries if x['thresholdBps']==5)
 source_rows={'binanceTicksAfterTimestampFilterAndDedup':len(b),'upQuotesAfterTimestampFilterAndDedup':len(p),'recorded15MinuteMarkets':len(groups),'actualUtcDays':sorted(set(pd.to_datetime(b.t,unit='ms',utc=True).dt.strftime('%Y-%m-%d')))}
 out={'id':'crypto','title':'How quickly do Bitcoin contracts follow a spot-price jump?','status':'limited','finding':f"In the fixed early-archive cohort, {primary['responders']} of {primary['n']} qualifying 5-basis-point spot moves were followed by a same-direction midpoint change of at least 1 percentage point within five seconds. This is observed response timing, not a measure of correct pricing or a profitable edge.",
 'metrics':[{'label':'Qualifying spot moves','value':primary['n']},{'label':'Distinct 15-minute contracts','value':primary['markets']},{'label':'Reached 1-point response within 5 seconds','value':primary['responseShare'],'format':'percent'},{'label':'Median among responders only','value':primary['medianDelayAmongRespondersMs'],'unit':'ms'}],
 'chart':{'title':'Fraction reaching a 1-point same-direction quote change','xLabel':'Milliseconds after spot threshold crossing','yLabel':'Share of complete observed episodes','rows':primary['path']},
 'table':primary['days'],'analyses':summaries,'cohort':{'startUtc':'2026-02-12T00:00:00Z','endExclusiveUtc':'2026-02-19T00:00:00Z','selectionRule':manifest['selectionRule'],'sourceRows':source_rows,'downloadedFiles':len(manifest['files']),'downloadedBytes':sum(f['sizeBytes'] for f in manifest['files'])},
 'methods':['The first seven calendar days from the earliest common archive date were fixed before examining response results. Actual collector timestamps define inclusion; partition date labels are not assumed to be UTC.','A spot shock is a Binance recorded trade-price log change of at least 5 basis points over the preceding 1 second (lookback observation at most 250 ms older). The 2- and 10-basis-point floors are declared sensitivities. Keep the earliest candidate and then wait 10 seconds before selecting another, without inspecting future quotes.','Match only the UP side of the active BTC 15-minute contract; nominal start/end are encoded by its archive slug. Require at least 30 seconds before nominal end and an initial midpoint between 5% and 95%.','Use (best bid + best ask)/2, not the price-change payload price. At every sampled time require 0 < bid <= ask < 1, spread <=10 percentage points, and a latest quote no more than 1 second old. Invalid quotes reset availability rather than being silently skipped.','The baseline is the last valid recorded midpoint strictly before the spot threshold crossing. A response means its signed change first reaches +1 percentage point by 5 seconds. Crossing fractions count all complete eligible paths; median delay is conditional on responding and separately labeled.','Follow-up grid is 0, 100, 250, 500, 1000, 2000 and 5000 ms. Missing/stale paths are excluded and counted. No interpolation or zero-movement imputation.','The opposite-direction diagnostic uses the same episodes and records whether the midpoint ever moves at least 1 point against the spot shock; both directions can be reached within the same window. It is descriptive, not a randomized placebo.','No statistical interval is presented from this short, incomplete historical cohort. Day-by-day results expose variation; episodes and adjacent contracts share Bitcoin information.'],
 'limitations':['Collector-clock delays combine exchange reaction, feed transport and collection latency. They are not end-to-end trader reaction times.','Spot threshold crossing occurs after a move has begun; Polymarket can already have reacted before the chosen zero. First quote response does not mean full information absorption.','Complete fresh-price paths select active observed periods. Archive gaps and the tiny February 13 recording limit representativeness.','A spot-price move is a continuous information proxy, not an independently identified news announcement. Further spot movement can drive the follow-up.','The actual downloaded market_meta table has no authoritative resolved-outcome field despite the README reference schema. We do not infer outcomes from prices; forecast calibration or added predictive value versus spot is not established by this audit.','This is a new descriptive calculation on one fixed week, not a reproduction of the paper’s published 347 ms figure, and no execution/fee or profitability claim is made.'],
 'sources':[{'label':'OpenMarket public dataset, fixed revision','url':URL+'/tree/'+manifest['revision']},{'label':'OpenMarket methodology paper','url':'https://arxiv.org/abs/2607.26245'}],
 'validation':['Every downloaded file was matched to its published LFS SHA-256.','All 27 primary episodes were independently recomputed with raw DuckDB SQL: spot log return, baseline midpoint, first same-direction and opposite-direction response.','Actual data schemas were inspected; missing outcome labels were not fabricated.'],'downloads':[{'label':'Episode-level observations (gzip JSON)','url':'downloads/crypto-response-episodes.json.gz'},{'label':'Pinned input manifest','url':'data/expansion/crypto-source-manifest.json'}],
 'reproduction':'python scripts/expansion_crypto.py --collect --cache /tmp/atlas-exp-crypto; then rerun without --collect for offline reproduction.'}
 return out,all_rows

def main():
 p=argparse.ArgumentParser();p.add_argument('--cache',type=Path,default=Path('/tmp/atlas-exp-crypto'));p.add_argument('--collect',action='store_true');args=p.parse_args()
 manifest=json.loads((ROOT/'dist/data/expansion/crypto-source-manifest.json').read_text())
 if args.collect:collect(args.cache,manifest)
 for f in manifest['files']:
  assert hashlib.sha256((args.cache/f['path']).read_bytes()).hexdigest()==f['sha256']
 out,rows=run(args.cache,manifest)
 (ROOT/'dist/data/expansion/crypto.json').write_text(json.dumps(out,indent=2,allow_nan=False)+'\n')
 (ROOT/'dist/downloads/crypto-response-episodes.json.gz').write_bytes(gzip.compress(json.dumps(rows,separators=(',',':'),allow_nan=False).encode(),mtime=0))
 print(json.dumps({'metrics':out['metrics'],'analyses':[{k:x[k] for k in ['thresholdBps','selectedSpotMoves','eligibleInitialQuotes','n','responders','responseShare','medianDelayAmongRespondersMs','days','exclusions']} for x in out['analyses']]},indent=2))
if __name__=='__main__':main()
