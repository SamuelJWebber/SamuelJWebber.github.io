"""Build anonymous sufficient statistics for custom probability ranges.

A venue's windows/K.json.gz maps observed day -> rows, where K=(day-1)//7.
Each row is [detail_topic_id, broad_topic_id, day_local_event_id, listed_price,
contract_count, listed_wins]. A null event id represents contract_count different
events which each occur only once on the entire day. Repeated event ids must be
deduplicated in the browser. IDs are never stable across days or venues. No text,
market identifiers or trade timestamps are exported.
"""
import argparse
import gzip
import itertools
import json
from pathlib import Path

import duckdb


def build(panel, source):
    dest = source / panel.stem
    meta = json.loads((dest / "meta.json").read_text())
    windows = dest / "windows"
    windows.mkdir(exist_ok=True)
    with duckdb.connect() as db:
        db.execute("set threads=2")
        db.read_parquet(str(panel)).create_view("panel")
        db.execute("create temp table topics(kind varchar, label varchar, id integer)")
        db.executemany("insert into topics values(?,?,?)", [
            (t["kind"], t["name"].removeprefix("All ") if t["kind"] == "broad" else t["name"], int(t["id"]))
            for t in meta["topics"] if t["kind"] != "all"
        ])
        # Strip singleton event IDs completely so these records can aggregate. All
        # others get a different day-local pseudonym unrelated to the source ID.
        query = """
          with events as (
            select days, event_id, row_number() over
              (partition by days order by hash(days, event_id),event_id) as local_id
            from panel group by days,event_id having count(*) > 1
          )
          select p.days, d.id detail, b.id broad, e.local_id, p.price::double listed,
                 count(*) n, sum(p.outcome)::bigint wins
          from panel p
          join topics d on d.kind='detail' and d.label=p.topic
          join topics b on b.kind='broad' and b.label=p.broad
          left join events e on p.days=e.days and p.event_id=e.event_id
          group by p.days, d.id, b.id, e.local_id, p.price
          order by p.days, d.id, b.id, e.local_id, p.price
        """
        cursor = db.execute(query)
        records = (row for batch in iter(lambda: cursor.fetchmany(8192), []) for row in batch)
        blocks = itertools.groupby(records, key=lambda row: (row[0] - 1) // 7)
        n_total = 0
        written = set()
        for block, group in blocks:
            payload = {}
            for day, day_rows in itertools.groupby(group, key=lambda row: row[0]):
                rows = [row[1:] for row in day_rows]
                n_total += sum(row[4] for row in rows)
                payload[day] = rows
            put(windows / f"{block}.json.gz", payload)
            written.add(block)
        for block in range((meta.get("archiveMaxDays", meta["maxDays"]) - 1) // 7 + 1):
            if block not in written:
                put(windows / f"{block}.json.gz", {})
        expected = meta.get("archiveObservations", meta["observations"])
        if n_total != expected:
            raise ValueError(f"{panel.stem}: {n_total} source observations expected {expected}")
        print(panel.stem, n_total, "observations in", len(written), "nonempty weekly blocks", flush=True)


def put(path, value):
    raw = json.dumps(value, ensure_ascii=False, separators=(",", ":"), allow_nan=False).encode()
    data = gzip.compress(raw, compresslevel=5, mtime=0)
    if len(data) > 10_000_000:
        raise ValueError(f"{path} exceeds 10 MB")
    temporary = path.with_suffix(".tmp")
    temporary.write_bytes(data)
    temporary.replace(path)


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("panels", nargs="+", type=Path)
    p.add_argument("--output", type=Path, default=Path(__file__).resolve().parents[1] / "dist" / "data")
    args = p.parse_args()
    for filename in args.panels:
        build(filename, args.output)
