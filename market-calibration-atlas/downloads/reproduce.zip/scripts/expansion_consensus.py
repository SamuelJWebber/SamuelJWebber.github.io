"""Same-target, common-cutoff cross-exchange election case study.

Collect: python scripts/expansion_consensus.py --collect
Recompute the bundled evidence: python scripts/expansion_consensus.py
Requires duckdb only for collection. Default recomputation uses standard Python.
"""
import argparse, concurrent.futures, datetime as dt, hashlib, json, re, urllib.request
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'dist/data/expansion/consensus.json'
CACHE=Path('/tmp/atlas-exp-consensus')
UTC=dt.timezone.utc
BASE=dt.datetime(2024,11,5,tzinfo=UTC)
STATES=dict(x.split(':') for x in 'AK:Alaska|AL:Alabama|AR:Arkansas|AZ:Arizona|CA:California|CO:Colorado|CT:Connecticut|DC:District of Columbia|DE:Delaware|FL:Florida|GA:Georgia|HI:Hawaii|IA:Iowa|ID:Idaho|IL:Illinois|IN:Indiana|KS:Kansas|KY:Kentucky|LA:Louisiana|MA:Massachusetts|MD:Maryland|MI:Michigan|MN:Minnesota|MO:Missouri|MS:Mississippi|MT:Montana|NC:North Carolina|ND:North Dakota|NH:New Hampshire|NJ:New Jersey|NM:New Mexico|NV:Nevada|NY:New York|OH:Ohio|OK:Oklahoma|OR:Oregon|PA:Pennsylvania|RI:Rhode Island|SC:South Carolina|SD:South Dakota|TN:Tennessee|TX:Texas|UT:Utah|VA:Virginia|VT:Vermont|WA:Washington|WI:Wisconsin|WV:West Virginia|WY:Wyoming'.split('|'))
HORIZONS=[1,7,14]

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def get(url,name):
    path=CACHE/name
    if not path.exists():
        with urllib.request.urlopen(url,timeout=45) as r: path.write_bytes(r.read())
    return json.loads(path.read_text()),sha(path)

def collect():
    import duckdb
    CACHE.mkdir(parents=True,exist_ok=True)
    metadata=CACHE/'poly-markets.parquet'
    source='https://huggingface.co/datasets/vgregoire/polymarket-users/resolve/91ddb961b090de18fd79e79edd8fa15f36ca11b9/markets.parquet'
    if not metadata.exists():
        with urllib.request.urlopen(source,timeout=120) as r: metadata.write_bytes(r.read())
    db=duckdb.connect(config={'threads':2});db.execute("SET TimeZone='UTC'")
    raw=db.sql("select market_id,question from read_parquet(?) where expiration_time >= '2024-11-01' and expiration_time < '2024-12-01'",params=[str(metadata)]).fetchall()
    bytitle={}
    for mid,q in raw: bytitle.setdefault(q.lower(),[]).append(mid)
    candidates=[];excluded=[]
    for state,name in STATES.items():
        mids=bytitle.get(f'Will a Republican win {name} Presidential Election?'.lower(),[])
        if len(mids)!=1:excluded.append({'state':state,'reason':'No unique exact Republican state-winner title in the November 2024 archive','matches':mids});continue
        candidates.append((state,name,mids[0],f'PRESPARTY{state}-24-R'))
    def rules(row):
        state,name,mid,ticker=row
        purl=f'https://gamma-api.polymarket.com/markets/{mid}'
        kurl=f'https://api.elections.kalshi.com/trade-api/v2/historical/markets/{ticker}'
        try:
            p,ph=get(purl,f'poly-{mid}.json');k,kh=get(kurl,f'kalshi-{ticker}.json');k=k['market']
            desc=p.get('description','');kr=k.get('rules_primary','')
            assert '2024' in desc and name.lower() in desc.lower() and 'Republican candidate wins the popular vote' in desc, 'Polymarket target text did not pass exact state/year/party check'
            # Explicitly audited official-source typo, not fuzzy matching.
            party_ok='Republican' in kr or (state=='SD' and 'Republicn party' in kr and k.get('subtitle')==':: or another Republican' and k.get('custom_strike',{}).get('Candidate')=='Donald Trump')
            assert f'wins {name} in the 2024 presidential election' in kr and party_ok, 'Kalshi target text did not pass exact state/year/party check'
            assert k['result'] in ['yes','no'], 'Kalshi did not report a binary settled result'
            return dict(state=state,name=name,polyMarket=mid,kalshiMarket=ticker,polyRules=desc,kalshiRules=kr,
                kalshiEarlyClose=k.get('early_close_condition'),polyURL='https://polymarket.com/event/'+p['slug'],
                kalshiURL=f'https://kalshi.com/markets/presparty{state.lower()}',
                apiSources=[dict(url=purl,sha256=ph),dict(url=kurl,sha256=kh)],outcome=int(k['result']=='yes'),
                matchBasis='Exact state, 2024 election, Republican statewide winner; settlement source/timing differs',
                ruleNote='Official Kalshi text misspells Republican as Republicn; subtitle explicitly says Republican and custom strike names Donald Trump' if state=='SD' else None)
        except Exception as e:return dict(state=state,reason='Rule retrieval/verification failed: '+str(e))
    matches=[]
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        for x in pool.map(rules,candidates):
            (excluded if 'reason' in x else matches).append(x)
            print(x['state'],x.get('reason','rules verified'),flush=True)
    panels={}
    for venue in ['kalshi','polymarket']:
        ids=[m['kalshiMarket' if venue=='kalshi' else 'polyMarket'] for m in matches]
        rows=db.sql('select market_id,price,outcome,completed_at from read_parquet(?) where market_id in (select unnest(?))',params=[str(ROOT/f'dist/downloads/{venue}.parquet'),ids]).fetchall()
        d={}
        for mid,p,y,t in rows:d.setdefault(str(mid),{})[t]=(float(p),int(y))
        panels[venue]=d
    observations=[];snapshot_exclusions=[]
    for m in matches:
        for horizon in HORIZONS:
            target=BASE-dt.timedelta(days=horizon)
            row=dict(state=m['state'],horizon=horizon,cutoff=target.isoformat(),outcome=m['outcome'])
            good=True
            for venue,key in [('kalshi','kalshiMarket'),('polymarket','polyMarket')]:
                elig=[(t,p,y) for t,(p,y) in panels[venue].get(str(m[key]),{}).items() if target-dt.timedelta(hours=24)<=t<=target]
                if not elig:
                    good=False
                    snapshot_exclusions.append(dict(state=m['state'],horizon=horizon,cutoff=target.isoformat(),venue=venue,reason='No retained source-panel observation in the preceding 24 hours'))
                    continue
                t,p,y=max(elig)
                assert y==m['outcome'],(m,venue,y)
                row[venue]=p;row[venue+'ObservedAt']=t.isoformat();row[venue+'AgeHours']=(target-t).total_seconds()/3600
            if good:
                row['consensus']=(row['kalshi']+row['polymarket'])/2
                observations.append(row)
    return dict(matches=matches,excluded=excluded,observations=observations,snapshotExclusions=snapshot_exclusions,
        protocolExclusions=[dict(state=s,reason='District electoral-vote rules create a target ambiguity; excluded before scoring') for s in ['ME','NE']],
        panelHashes={v:sha(ROOT/f'dist/downloads/{v}.parquet') for v in panels},metadataSource=dict(url=source,sha256=sha(metadata)))

def summarize(audit):
    table=[]
    for h in HORIZONS:
        for maxage in [24,12,6]:
            rs=[r for r in audit['observations'] if r['horizon']==h and max(r['kalshiAgeHours'],r['polymarketAgeHours'])<=maxage]
            if not rs:continue
            b={v:sum((r[v]-r['outcome'])**2 for r in rs)/len(rs) for v in ['kalshi','polymarket','consensus']}
            table.append(dict(days=h,maxQuoteAgeHours=maxage,n=len(rs),**{v+'Brier':x for v,x in b.items()},
                consensusMinusKalshi=b['consensus']-b['kalshi'],consensusMinusPolymarket=b['consensus']-b['polymarket'],
                meanDisagreementPoints=100*sum(abs(r['kalshi']-r['polymarket']) for r in rs)/len(rs),
                maxActualQuoteAgeHours=max(max(r['kalshiAgeHours'],r['polymarketAgeHours']) for r in rs),
                maxBetweenVenueQuoteTimeGapHours=max(abs(r['kalshiAgeHours']-r['polymarketAgeHours']) for r in rs)))
    primary=next((r for r in table if r['days']==7 and r['maxQuoteAgeHours']==24),None)
    common=set.intersection(*(set(r['state'] for r in audit['observations'] if r['horizon']==h) for h in HORIZONS))
    balanced=[]
    for h in HORIZONS:
        rs=[r for r in audit['observations'] if r['horizon']==h and r['state'] in common]
        if rs:balanced.append(dict(days=h,n=len(rs),**{v+'Brier':sum((r[v]-r['outcome'])**2 for r in rs)/len(rs) for v in ['kalshi','polymarket','consensus']}))
    columns=[{'key':'days','label':'Days before election','format':'integer'},{'key':'n','label':'Matched states','format':'integer'},{'key':'kalshiBrier','label':'Kalshi Brier','format':'number'},{'key':'polymarketBrier','label':'Polymarket Brier','format':'number'},{'key':'consensusBrier','label':'50/50 Brier','format':'number'}]
    if primary:
        beating=primary['consensusMinusKalshi']<0 and primary['consensusMinusPolymarket']<0
        finding=f"Across {primary['n']} matched state contests seven days out, the equal-weight forecast {'beat both venues' if beating else 'did not beat both venues'} on Brier score. These are correlated contests within one election, so this is a case study rather than a general platform ranking."
    else:finding='The strict timestamp and rule checks produced no matched seven-day sample.'
    return dict(id='consensus',title='Does combining two exchanges improve the forecast?',status='limited',
      finding=finding,primaryComparison=primary,
      metrics=([{'label':'Matched states at 7 days','value':primary['n'],'format':'integer'},{'label':'National election clusters','value':1,'format':'integer'},
        {'label':'Kalshi Brier at 7 days','value':primary['kalshiBrier'],'format':'number'},{'label':'Polymarket Brier at 7 days','value':primary['polymarketBrier'],'format':'number'},
        {'label':'50/50 Brier at 7 days','value':primary['consensusBrier'],'format':'number'}] if primary else []),
      table=table,balancedTable=balanced,
      chart={'type':'grouped-bars','title':f'Brier by horizon: the same {len(common)} states at all three dates',
        'subtitle':f"This chart holds the cohort fixed at {len(common)} states. The headline seven-day comparison uses all {primary['n'] if primary else 0} available matched states. Lower Brier is better; one national election provides no estimate of performance across election cycles.",
        'x':'days','series':[{'key':v+'Brier','label':label} for v,label in [('kalshi','Kalshi'),('polymarket','Polymarket'),('consensus','50/50 consensus')]],'rows':balanced,'lowerIsBetter':True},
      tables=[{'title':'Common-state cohort across horizons (lower Brier is better)','columns':columns,'rows':balanced},
        {'title':'All available matched states and timestamp-age sensitivities','columns':columns[:2]+[{'key':'maxQuoteAgeHours','label':'Maximum age allowed (hours)','format':'integer'}]+columns[2:]+[{'key':'maxActualQuoteAgeHours','label':'Oldest observation (hours)','format':'number'},{'key':'maxBetweenVenueQuoteTimeGapHours','label':'Largest venue time gap (hours)','format':'number'}],'rows':table}],
      methods=[
       'Fixed target: Republican statewide winner in the 2024 US presidential election. Include every uniquely identified matching jurisdiction in the source panels; exclude Maine and Nebraska before looking at scores because of district electoral-vote rules.',
       'Verify the exact party, state and election year against both official market rule records. No title-fuzzy matching and no winning-side selection. Both binary outcome directions are retained as original Republican YES prices, including below 51%.',
       'Primary comparison: seven calendar days before election date, anchored to 2024-11-05 00:00 UTC. For horizon h use 2024-11-05 00:00 UTC minus h days (seven-day cutoff: October 29 00:00 UTC). Choose the latest retained source-panel observation no later than that common target, at most 24 hours old. The 1- and 14-day comparisons and 12-/6-hour age caps are declared sensitivities.',
       'This uses actual completed_at timestamps, not each venue’s resolution date or the panel’s original days label. It therefore excludes the post-election January Kalshi settlement period.',
       'The combination is fixed at 50% Kalshi plus 50% Polymarket before scoring. Report Brier scores on precisely the same state rows for all three forecasts.',
       'The horizon chart holds the state cohort fixed across all three horizons. The primary seven-day comparison and timestamp-age sensitivities use every qualifying pair at their stated horizon; their sample sizes therefore differ.',
       'No confidence interval or significance test is supplied: every state belongs to one shared national-election cluster. A reduction relative to the average component score is algebraically guaranteed for squared error; beating both components is the more demanding reported comparison.'
      ],
      limitations=[
       'Forecast target is matched but settlement mechanics are not identical: Polymarket permits three-network race calls with official certification as fallback; Kalshi closes after state certification. The prices need not be fungible or support arbitrage.',
       'Common forecast cutoffs do not mean simultaneous transactions. Actual quote ages and cross-venue time gaps are reported, with stricter-age sensitivities. Prices are the latest available retained panel observation, not necessarily the latest exchange trade.',
       'Only one election cycle. States are correlated and many safe states are easy; no general claim about which exchange is superior follows.',
       'Trade prices include spreads and settlement timing/risk. This is forecast scoring, not after-fee trading profitability.',
       'Current official metadata verifies targets and outcomes, but does not establish that contract wording never changed historically.'
      ],
      sources=[{'name':'Polymarket Users archive; pinned revision','url':audit['metadataSource']['url']},{'name':'Atlas Kalshi forecast panel','url':'https://market-calibration-atlas.smartgoldfish.chatgpt.site/downloads/kalshi.parquet'},{'name':'Atlas Polymarket forecast panel','url':'https://market-calibration-atlas.smartgoldfish.chatgpt.site/downloads/polymarket.parquet'},{'name':'Kalshi historical market API','url':'https://docs.kalshi.com/api-reference/historical/get-historical-market'}],
      downloads=[{'label':'Matched questions, complete rule text and forecast audit (JSON)','url':'data/expansion/consensus.json'}],
      coverage={'matchedTargets':len(audit['matches']),'excludedTargets':len(audit['excluded']),'nationalElectionClusters':1,'candidateJurisdictions':len(STATES),'snapshotRows':len(audit['observations']),'balancedStates':len(common)},
      audit=audit)

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--collect',action='store_true');a=p.parse_args()
    audit=collect() if a.collect else json.loads(OUT.read_text())['audit']
    result=summarize(audit);OUT.parent.mkdir(parents=True,exist_ok=True);OUT.write_text(json.dumps(result,separators=(',',':'),allow_nan=False)+'\n')
    print(json.dumps({k:result[k] for k in ['finding','metrics','coverage']},indent=2))
if __name__=='__main__':main()
