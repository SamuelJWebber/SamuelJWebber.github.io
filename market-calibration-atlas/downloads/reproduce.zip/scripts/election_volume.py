"""Recover trading-date volume for the exact contract, date and price source selected in the atlas.
Run after price-panel reproduction. Paths can be overridden with --panels and --source-root.
"""
import argparse
import csv
from collections import defaultdict
from datetime import datetime
import io
from pathlib import Path
import tempfile
from zoneinfo import ZoneInfo
import zipfile
import duckdb

def csvdict(path, **kwargs):
    with path.open(encoding='utf-8-sig',newline='') as f:
        yield from csv.DictReader(f,**kwargs)

def iem_rows(panels):
    for file in sorted((panels/'iem_src').glob('raw_*.csv')):
        mid=file.name.split('_')[1]
        with file.open(newline='') as f:
            for day,code,quantity,_,_,_,price in csv.reader(f):
                if float(quantity)>0:
                    yield f'IEM-{mid}-{code}',day,'',float(price),float(quantity)

def intrade_rows(panels):
    for year in ['08','12']:
        for row in csvdict(panels/'intrade_src'/f'intrade{year}.csv'):
            for side in ['D','R']:
                qty=float(row['Volume'+side] or 0)
                if qty>0 and float(row['Price'+side] or 0)>0:
                    yield f"INTRADE-{year}-{row['state']}-{side}",row['day'],'',float(row['Price'+side])/100,qty

def predictit_rows(src):
    base=src/'pi_data'
    academic16='PredictIt academic archive 2016'
    academic18='PredictIt academic archive 2018'
    hourly='PredictIt hourly archive 2020'
    with zipfile.ZipFile(base/'2016.zip') as zf, zf.open('DailyMarketData.csv') as f:
        for r in csv.DictReader(io.TextIOWrapper(f,encoding='utf16'),delimiter='|'):
            qty=float(r['Volume'] or 0)
            if qty<=0:continue
            label=r['ContractName']
            if label=='n/a' or (r['MarketId']=='2210' and label=='Kamala Harris'): leg='candidate'
            elif label=='Democratic': leg='dem'
            else:continue
            yield f"PI-{r['MarketId']}-{leg}",r['Date'],academic16,float(r['ClosePrice']),qty
    other=src/'pi_alternate'
    for r in csvdict(other/'DailyMarketData.csv',delimiter='|'):
        qty=float(r['Volume'] or 0)
        if qty<=0 or not r['ClosePrice']:continue
        label=r['ContractName']
        if label=='n/a':leg='candidate'
        elif label in ('Democratic','Democratic or DFL'):leg='dem'
        else:continue
        yield f"PI-{r['MarketId']}-{leg}",r['Date'],academic18,float(r['ClosePrice']),qty
    for r in csvdict(other/'Market_ME02.csv'):
        if r['LongName'].startswith('Will a Dem ') and float(r['Volume'] or 0)>0:
            yield 'PI-4945-dem',datetime.strptime(r['Date'],'%m/%d/%Y').date().isoformat(),academic18,float(r['Close']),float(r['Volume'])
    info={r['race']:r['mid'] for f in (base/'data').glob('*markets.csv') for r in csvdict(f)}
    bars=defaultdict(dict)
    zone=ZoneInfo('America/New_York')
    def add(mid, ts, p, qty):
        if not qty or float(qty)<=0:return
        ts=datetime.fromisoformat(ts).astimezone(zone)
        key=(mid,ts.date().isoformat())
        bar=(float(p),float(qty))
        if ts in bars[key] and bars[key][ts]!=bar:
            raise ValueError(f'Conflicting hourly volume/close for {key} at {ts}')
        bars[key][ts]=bar
    for file in sorted((base/'data'/'races').glob('*.csv')):
        if file.stem not in info:continue
        for r in csvdict(file):
            if r['contract']=='Democratic' and str(r['volume'] or '').replace('.','').isdigit():add(info[file.stem],r['time'],r['close'],r['volume'])
    for file,mid in [('potus_party','2721'),('house_party','4365')]:
        with (base/'data'/'extra'/(file+'.csv')).open(newline='') as f:
            for r in csv.reader(f):
                if len(r)==10 and r[4]=='Democratic':add(mid,r[0],r[8],r[9])
                elif len(r)==8 and r[2]=='Democratic':add(mid,r[0],r[6],r[7])
    for (mid,day),session in bars.items():
        yield 'PI-'+mid+'-dem',day,hourly,session[max(session)][0],sum(bar[1] for bar in session.values())
    for r in csvdict(src/'pi_alt'/'predictit_20_22.csv'):
        if r['contract']=='Democratic' and float(r['volume'])>0:
            yield 'PI-'+r['source_market_id']+'-dem',r['price_date'],'PredictIt election replication 2020/22',float(r['price']),float(r['volume'])
    for r in csvdict(base/'pi745690'):
        qty=float(r['TradeVolume'] or 0)
        if r['ContractName']=='Harris' and qty>0:
            day=datetime.strptime(r['Date'],'%m/%d/%Y %I:%M:%S %p').date().isoformat()
            yield 'PI-7456-harris',day,'PredictIt 90-day public chart archive 2024',float(r['CloseSharePrice'].lstrip('$')),qty

def build(venue,panels,src,dest):
    generator={'iem':lambda:iem_rows(panels),'intrade':lambda:intrade_rows(panels),'predictit':lambda:predictit_rows(src)}[venue]
    with duckdb.connect(config={"threads":2}) as db, tempfile.TemporaryDirectory() as tmp:
        tmpfile=Path(tmp)/'vol.csv'
        with tmpfile.open('w',newline='') as f:
            w=csv.writer(f);w.writerow(['market_id','day','src','price','volume']);w.writerows(generator())
        db.read_parquet(str(panels/(venue+'.parquet'))).create_view('panel')
        db.execute('create temp table obs as select * from read_csv_auto(?)',[str(tmpfile)])
        trade="p.traded_at::date" if venue=='predictit' else "p.anchor::date - p.days::int"
        source="p.source=o.src" if venue=='predictit' else "true"
        db.execute(f"""create temp view checked as select p.market_id,p.days,p.price p,o.price source_price,o.volume::double volume
                    from panel p left join obs o on o.market_id=p.market_id and o.day={trade} and {source}""")
        n,unique,missing,mismatch=db.sql("""select count(*),count(distinct(market_id,days)),count(*) filter(where volume is null or volume<=0),
                                           count(*) filter(where abs(p-source_price)>1e-9) from checked""").fetchall()[0]
        if n!=unique or missing or mismatch:
            print(db.sql("select * from checked where volume is null or abs(source_price-p)>1e-9 limit 10").fetchall(),flush=True)
            raise ValueError(f'{venue}: rows={n} unique={unique} missing={missing} price mismatch={mismatch}')
        output=dest/(venue+'.parquet')
        db.sql("select market_id, days::int as days,volume from checked order by market_id,days").to_parquet(str(output)+'.tmp',compression='zstd')
        Path(str(output)+'.tmp').replace(output)
        print(venue,n,unique,'observations matched to exact selected price.',flush=True)
if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('venues',nargs='*',default=['iem','intrade','predictit'])
    ap.add_argument('--panels',type=Path,default=Path('/tmp/market_dash'))
    ap.add_argument('--source-root',type=Path,default=Path('/tmp'))
    ap.add_argument('--output',type=Path,default=Path('/tmp/markvol'))
    args=ap.parse_args();args.output.mkdir(exist_ok=True,parents=True)
    for v in args.venues:build(v,args.panels,args.source_root,args.output)
