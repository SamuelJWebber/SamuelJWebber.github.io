"""Retrospective robustness audit of the March Polymarket shock study.

python scripts/shock_robustness.py
Requires numpy, pandas and scipy. Input is the public shock-candidate download;
no network access or outcome-dependent selection is needed. This audit does not
turn already inspected data into an untouched holdout.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import t

ROOT = Path(__file__).resolve().parents[1]
THRESHOLDS = [5, 10, 20, 30]
HORIZONS = [5, 15, 30, 60]
METRICS = ['beforePrice', 'initialPrice', 'outcomeRate', 'initialGap',
           'brierInitial', 'price60', 'gap60', 'brier60', 'drift60',
           'brierGain60', 'meanJump']
PROBABILITY_METRICS = {'beforePrice', 'initialPrice', 'outcomeRate',
                       'brierInitial', 'price60', 'brier60'}


def number(value):
    return round(float(value), 10) if value is not None and np.isfinite(value) else None


def cluster_estimate(frame, metric, alpha=.05):
    """Intercept-only CR1 sandwich variance, t(df = event groups minus one)."""
    valid = frame[['event', metric]].dropna()
    n = len(valid)
    grouped = valid.groupby('event')[metric].agg(['sum', 'count'])
    g = len(grouped)
    mean = float(valid[metric].mean()) if n else None
    result = dict(mean=number(mean), ci=None, p=None, se=None, n=n, groups=g)
    if g < 20 or n == 0:
        return result
    scores = grouped['sum'].to_numpy() - grouped['count'].to_numpy()*mean
    variance = g/(g-1)*float(scores@scores)/n**2
    if variance <= 1e-20:
        return result
    se = variance**.5
    margin = float(t.ppf(1-alpha/2, g-1))*se
    low, high = mean-margin, mean+margin
    if metric in PROBABILITY_METRICS:
        low, high = max(0, low), min(1, high)
    result.update(ci=[number(low), number(high)], se=number(se),
                  p=number(2*t.sf(abs(mean/se), g-1)))
    return result


def summary(frame, event_equal=False):
    original = frame
    if event_equal:
        frame = frame.groupby('event')[METRICS].mean().reset_index()
    metrics={}
    for metric in METRICS:
        if frame[metric].isna().any():
            metrics[metric]=dict(mean=None,ci=None,p=None,se=None,
                n=int(frame[metric].notna().sum()),groups=None,
                reason='Missing future prices: no complete-cohort mean is reported. See endpointOnly and missingBounds.')
        else:
            metrics[metric]=cluster_estimate(frame,metric)
    return dict(n=len(original), events=original.event.nunique(),
        contracts=original.market.nunique(), days=original.day.nunique(),
        weighting='equal parent event' if event_equal else 'equal episode',
        metrics=metrics)


def selected_frame(payload, threshold):
    c = {name:i for i, name in enumerate(payload['columns'])}
    offsets = payload['meta']['offsetMinutes']
    grid = [i for i, minute in enumerate(offsets) if minute <= 60]
    end_index = offsets.index(60)
    previous, records = {}, []
    for row in payload['rows']:
        index, ts = row[c['market']], row[c['ts']]
        before, after, noise = row[c['before']], row[c['after']], row[c['noise']]
        if after-before+1e-9 < threshold/100 or after-before+1e-9 < 4*noise:
            continue
        if ts < previous.get(index, -np.inf)+21600:
            continue
        previous[index] = ts
        market = payload['markets'][index]
        prices, outcome = row[c['prices']], row[c['won']]
        p60 = prices[end_index]
        record = dict(market=market['id'], event=market['event'],
            category=market['broad'], topic=market['topic'], ts=ts,
            day=datetime.fromtimestamp(ts, timezone.utc).date().isoformat(),
            beforePrice=before, initialPrice=after, outcomeRate=outcome,
            initialGap=after-outcome, brierInitial=(after-outcome)**2,
            price60=p60, gap60=p60-outcome if p60 is not None else np.nan,
            brier60=(p60-outcome)**2 if p60 is not None else np.nan,
            drift60=p60-after if p60 is not None else np.nan,
            brierGain60=(after-outcome)**2-(p60-outcome)**2 if p60 is not None else np.nan,
            meanJump=after-before,
            complete=all(prices[i] is not None for i in grid),
            eligible60=market['anchor']-ts >= 3600)
        for minute in HORIZONS:
            price = prices[offsets.index(minute)]
            record[f'drift{minute}'] = price-after if price is not None else np.nan
        records.append(record)
    frame = pd.DataFrame(records)
    assert frame.market.nunique() <= len(frame)
    spacings=frame.groupby('market').ts.diff().dropna()
    assert spacings.empty or spacings.min() >= 21600
    assert (frame.loc[frame.price60.notna(), 'eligible60']).all()
    return frame


def day_bootstrap(frame, replicates, seed):
    """Resample complete UTC days, preserving all within-day observations."""
    metrics = ['initialGap', 'drift60', 'brierGain60']
    sums = frame.groupby('day')[metrics].sum()
    counts = frame.groupby('day').size().reindex(sums.index).to_numpy()
    g = len(sums)
    means = frame[metrics].mean()
    result = dict(days=g, replicates=replicates, seed=seed, metrics={})
    if g < 20:
        result['reason'] = 'Fewer than 20 observed calendar-day groups.'
    draws = None
    if g >= 20:
        choices = np.random.default_rng(seed).integers(0, g, size=(replicates, g))
        draws = sums.to_numpy()[choices].sum(axis=1)/counts[choices].sum(axis=1)[:,None]
    for index, metric in enumerate(metrics):
        ci = np.quantile(draws[:,index], [.025,.975]) if draws is not None else None
        result['metrics'][metric] = dict(mean=number(means[metric]),
            ci=[number(x) for x in ci] if ci is not None else None)
    return result


def influence(frame):
    grouped = frame.groupby('event').agg(n=('event', 'size'),
        driftSum=('drift60', 'sum'), gainSum=('brierGain60', 'sum'))
    n, total_drift, total_gain = len(frame), frame.drift60.sum(), frame.brierGain60.sum()
    rows = []
    for event, item in grouped.iterrows():
        if n == item.n:
            continue
        drift = (total_drift-item.driftSum)/(n-item.n)
        gain = (total_gain-item.gainSum)/(n-item.n)
        rows.append(dict(event=str(event), removedN=int(item.n),
            drift60=number(drift), driftChange=number(drift-total_drift/n),
            brierGain60=number(gain), gainChange=number(gain-total_gain/n)))
    largest = grouped['n'].idxmax()
    return dict(largestEvent=str(largest), largestEventN=int(grouped.loc[largest,'n']),
        largestEventShare=number(grouped.loc[largest,'n']/n),
        greatestDriftInfluence=max(rows, key=lambda r:abs(r['driftChange'])),
        greatestGainInfluence=max(rows, key=lambda r:abs(r['gainChange'])),
        leaveOneEventDriftRange=[min(r['drift60'] for r in rows),max(r['drift60'] for r in rows)],
        leaveOneEventGainRange=[min(r['brierGain60'] for r in rows),max(r['brierGain60'] for r in rows)])


def missing_bounds(selected):
    eligible = selected[selected.eligible60]
    known = eligible[eligible.price60.notna()]
    missing = eligible[eligible.price60.isna()]
    n = len(eligible)
    # Unobserved prices can be anywhere in [0,1]. These are logical bounds,
    # not uncertainty intervals. Quotes after recorded close are undefined.
    low_drift = (known.drift60.sum()-missing.initialPrice.sum())/n
    high_drift = (known.drift60.sum()+(1-missing.initialPrice).sum())/n
    low_gain = (known.brierGain60.sum()+(missing.brierInitial-1).sum())/n
    high_gain = (known.brierGain60.sum()+missing.brierInitial.sum())/n
    return dict(allSelectedN=len(selected),eligibleThrough60N=n,
        observedEndN=len(known),missingEligibleN=len(missing),
        excludedCloseN=len(selected)-n,
        drift60=[number(low_drift),number(high_drift)],
        brierGain60=[number(low_gain),number(high_gain)],
        interpretation='Logical bounds for episodes whose recorded close permits a 60-minute quote, assigning missing prices any value in [0,1]. These are not confidence intervals. Episodes closing sooner are outside this 60-minute price estimand.')


def scenario(selected, threshold, replicates):
    complete = selected[selected.complete]
    endpoint = selected[selected.price60.notna()]
    splits = []
    for label, mask in [('March 1–14', complete.day<'2026-03-15'),
                        ('March 15–28', complete.day>='2026-03-15')]:
        splits.append(dict(label=label, **summary(complete[mask])))
    categories = []
    for category in sorted(complete.category.unique()):
        excluded = complete[complete.category!=category]
        categories.append(dict(excluded=category, removedN=int((complete.category==category).sum()),
                               **summary(excluded)))
    return dict(thresholdPoints=threshold,
        selected=dict(n=len(selected),events=selected.event.nunique()),
        cohorts={'allSelected':summary(selected), 'completePath':summary(complete),
                 'endpointOnly':summary(endpoint)},
        weights={'episode':summary(complete), 'eventEqual':summary(complete, True)},
        dayBootstrap=day_bootstrap(complete,replicates,20261105+threshold),
        leaveCategoryOut=categories,eventInfluence=influence(complete),
        timeSplits=splits,missingBounds=missing_bounds(selected),
        categoryMix=[dict(category=category,n=len(group),events=group.event.nunique())
                     for category,group in complete.groupby('category')])


def multiplicity(frames):
    rows=[]
    family_size=len(THRESHOLDS)*len(HORIZONS)
    for threshold in THRESHOLDS:
        frame=frames[threshold]
        complete=frame[frame.complete]
        for minute in HORIZONS:
            metric=f'drift{minute}'
            estimate=cluster_estimate(complete, metric)
            simultaneous=cluster_estimate(complete,metric,alpha=.05/family_size)
            rows.append(dict(thresholdPoints=threshold,minutes=minute,n=len(complete),
                events=complete.event.nunique(),drift=estimate['mean'],ci=estimate['ci'],
                simultaneousCI=simultaneous['ci'],p=estimate['p'],holmP=None,
                passesHolm=False))
    # Holm step-down adjusted p values, retaining all 16 declared tests.
    # Unestimable p values are treated as 1 in the correction, never dropped.
    order=sorted(range(len(rows)),key=lambda i: rows[i]['p'] if rows[i]['p'] is not None else 1)
    running=0
    for rank,index in enumerate(order):
        p=rows[index]['p'] if rows[index]['p'] is not None else 1
        running=max(running,min(1,(family_size-rank)*p))
        if rows[index]['p'] is not None:
            rows[index]['holmP']=number(running)
            rows[index]['passesHolm']=bool(running<.05)
    return dict(familySize=family_size,rows=rows,
        method='Two-sided event-cluster Student-t p-values with Holm step-down correction across 4 thresholds × 4 follow-up times. Simultaneous intervals use Bonferroni 1−0.05/16 marginal coverage, not Holm confidence intervals.',
        limitation='This adjusts this explicit family only. These data and several thresholds were already inspected; it cannot erase prior exploration, all dashboard comparisons, model uncertainty, or outcome-clock errors.')


def run(source,output,replicates):
    raw=source.read_bytes()
    payload=json.loads(gzip.decompress(raw))
    assert payload['meta']['venue']=='polymarket'
    frames={threshold:selected_frame(payload,threshold) for threshold in THRESHOLDS}
    assert len(frames[5])==payload['meta']['defaultCheck']['selected']
    assert int(frames[5].complete.sum())==payload['meta']['defaultCheck']['complete']
    result=dict(meta=dict(venue='polymarket',generatedDate=datetime.now(timezone.utc).date().isoformat(),
        period='March 1–28, 2026',source='data/intraday/polymarket-shocks.json.gz',
        sourceSha256=hashlib.sha256(raw).hexdigest(),noiseMultiple=4,cooldownHours=6,
        minimumLeadHours=0,minimumVolume=0,comparisonMinutes=60,allTopics=True,
        bootstrapReplicates=replicates,
        interpretation='Fixed retrospective audit cohorts, independent of the dashboard’s interactive filters. Prices and final outcomes describe conditional prediction performance, not causally identified news effects.',
        methods={
            'eventEqual':'Average the episode-level metric within each parent event, then give each parent event equal weight. Student-t intervals treat parent-event means as independent groups.',
            'dayBootstrap':'Resample whole observed UTC calendar days with replacement, recomputing episode-weighted means. Percentile 95% intervals with a fixed random seed and at least 20 day groups. This preserves within-day dependence but does not solve dependence from one event spanning days or other cross-day information.',
            'influence':'Remove one entire category or parent event at a time from the fixed complete-path cohort. This changes the represented population and is a sensitivity check, not a causal adjustment.',
            'missingness':'Onset filters and six-hour spacing happen before any future-price availability restriction. Compare all selected, complete-path and endpoint-only sets; missing-price logical bounds are limited to episodes still before recorded close at 60 minutes.',
            'timeSplit':'March 1–14 versus March 15–28 are stability checks on already examined data. They are not an untouched out-of-time validation set.'},
        references=[{'label':'Holm step-down correction','url':'https://www.statsmodels.org/stable/generated/statsmodels.stats.multitest.multipletests.html'},
                    {'label':'Cluster covariance and degrees-of-freedom corrections','url':'https://github.com/statsmodels/statsmodels/blob/main/statsmodels/base/covtype.py'}]),
        scenarios={str(threshold):scenario(frames[threshold],threshold,replicates) for threshold in [5,20]},
        multiplicity=multiplicity(frames))
    output.parent.mkdir(parents=True,exist_ok=True)
    temporary=output.with_suffix('.tmp')
    temporary.write_text(json.dumps(result,separators=(',',':'),allow_nan=False))
    temporary.replace(output)
    print(json.dumps({'output':str(output),'bytes':output.stat().st_size,
        'scenarios':{key:{'n':value['weights']['episode']['n'],
            'episodeDrift':value['weights']['episode']['metrics']['drift60'],
            'eventEqualDrift':value['weights']['eventEqual']['metrics']['drift60'],
            'dayBootstrapDrift':value['dayBootstrap']['metrics']['drift60'],
            'missingBounds':value['missingBounds']} for key,value in result['scenarios'].items()},
        'holmDiscoveries':sum(row['passesHolm'] for row in result['multiplicity']['rows'])},indent=2))
    return result


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source',type=Path,default=ROOT/'dist/data/intraday/polymarket-shocks.json.gz')
    parser.add_argument('--output',type=Path,default=ROOT/'dist/data/intraday/shock-robustness.json')
    parser.add_argument('--bootstrap-replicates',type=int,default=10000)
    args=parser.parse_args()
    run(args.source,args.output,args.bootstrap_replicates)
