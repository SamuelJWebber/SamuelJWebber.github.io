# Reproducing the six additional Market Calibration Atlas studies

This package contains our analysis code, compact results, source provenance and
selected frozen inputs. Run commands from the extracted package root so the
`scripts/` and `dist/` paths remain siblings. The historical dashboard data are a
snapshot, not a live feed. The findings and important selection limits are in
each study's JSON; a successful script run is not proof of a general market law.

## Environment

Use Python 3.11 or later. Install the packages needed across the six scripts:

```sh
python -m pip install duckdb numpy pandas scipy pyarrow lxml
```

`duckdb`, `numpy`, `pandas` and `scipy` support the statistical studies. `pyarrow`
is the pandas Parquet engine used by the sports study. `lxml` reads the archived
weather HTML tables. Consensus recomputation alone uses the Python standard
library; its collection path also requires DuckDB. The scripts do not run code
downloaded from any research repository.

## Inputs supplied separately

The large original venue panels and the 8.2 MB third-party quote recording are
not duplicated in this ZIP. Restore these paths when running the corresponding
study:

| Path under the extracted package | Needed for | Download |
| --- | --- | --- |
| `dist/downloads/kalshi.parquet` | Weather, recalibration; consensus collection | <https://market-calibration-atlas.smartgoldfish.chatgpt.site/downloads/kalshi.parquet> |
| `dist/downloads/polymarket.parquet` | Consensus collection only | <https://market-calibration-atlas.smartgoldfish.chatgpt.site/downloads/polymarket.parquet> |
| `dist/downloads/quote-watch.parquet` | Quote-quality recomputation | <https://market-calibration-atlas.smartgoldfish.chatgpt.site/downloads/quote-watch.parquet> |

The original Kalshi panel SHA-256 is
`4a6a355263f8ec853a590d66aaf18ac45b12ccbe180a390a1a54314a2612238a`.
The third-party watchlist SHA-256 is
`181ed3064c7471ee7a3b40daba7e078e3fed163a79128d6821df8f13c6c13ab2`.
Other hashes and pinned upstream URLs are in the individual result manifests.
The live download URLs can change after later dashboard updates; verify hashes
against this package before claiming an exact reproduction.

Crypto's larger raw inputs are downloaded by its collection command below.
The bundled episode observations allow inspection of the reported sample, but
cannot reconstruct raw-event detection without those raw inputs.

## 1. Weather: market versus a public forecast benchmark

```sh
python scripts/expansion_weather.py --cache inputs/expansion_weather
```

Requires the separate Kalshi panel. Seven frozen cache files are included under
`inputs/expansion_weather/`: `nbm-2024.csv`, `nbm-2025.csv`, `cli2024.html`,
`cli2025.html`, `kalshi-market.json`, `kalshi-tail.json`, and
`kalshi-upper.json`. Their URLs, retrieval byte sizes and SHA-256 values are in
`dist/data/expansion/weather.json` under `source_manifest`.

The command uses the included inputs without network access. The script fetches
any missing cache file from its documented public source, so missing files can
silently change a rerun from offline to online. `--out PATH` chooses another
output location. Results normally replace `dist/data/expansion/weather.json`.

This is a Central Park temperature case study. The public probabilities are
constructed from an archived NBM point forecast and earlier empirical forecast
errors, not the full official NBM predictive distribution. Forecast publication
buffers are assumptions with sensitivity checks; initialization time is not a
verified release time. The methods explain settlement-day alignment, complete
market ladders, normalization and the train/test split. The output includes all
paired contract observations, not only aggregate scores. Generated timestamps
may differ on a rerun even when numerical findings match.

## 2. Sports: sensitivity to the event clock and trade freshness

```sh
python scripts/expansion_sports.py
```

This is offline using the four included Parquet inputs:

- `dist/downloads/sports-clock-input.parquet`
- `dist/downloads/sports-price-path-input.parquet`
- `dist/downloads/sports-staleness-input.parquet`
- `dist/downloads/sports-live-pair-input.parquet`

To download the original numerical tables again:

```sh
python scripts/expansion_sports.py --collect
```

Collection verifies the original Zenodo deposit's MD5 before extracting the
four tables. It does not execute the source authors' scripts. The source is
Petrov and Davison's *Foresight or Reaction?* replication deposit, version 1.0:
<https://zenodo.org/records/23491301>. Individual input SHA-256 values are in
`dist/data/expansion/sports.json`.

This independently recomputes aggregates from frozen **derived** observations;
it is not a reconstruction from all original exchange and league files. The
main paths are retrospectively selected payout-determining plays. Pitch start
and logged completion are different clocks, neither verified as the moment all
traders receive the information. The source carries some last trades forward;
the separate freshness checks expose that limitation.

## 3. Crypto: collector-clock quote response to spot moves

First obtain the fixed raw inputs:

```sh
python scripts/expansion_crypto.py --collect --cache inputs/expansion_crypto
```

Subsequent offline recomputation:

```sh
python scripts/expansion_crypto.py --cache inputs/expansion_crypto
```

The included `dist/data/expansion/crypto-source-manifest.json` lists the exact
source revision, eleven input paths, sizes and SHA-256 hashes. Collection
preserves their directory layout below the chosen cache and verifies every
hash. Existing files are reused and rechecked. The raw inputs are approximately
82 MB and are not embedded in this ZIP. The compact
`dist/downloads/crypto-response-episodes.json.gz` is included, together with
`dist/data/expansion/crypto.json`.

Credit Gregory Young's OpenMarket corpus (`v0.4.3-unified`, source tag `v0.5.2`),
pinned Hugging Face revision `74502466d1a7cef56395bfd8d0b465fbebc849cf`:
<https://huggingface.co/datasets/gregyoung14/openmarket-btc-polymarket>.
The dataset card identifies Apache-2.0 licensing; retain upstream attribution
and inspect the source license for any reuse beyond the supplied analysis.

The script uses collector timestamps and actual bid/ask midpoints. It measures
observed responses to a specified spot-price threshold. It does not supply
true event probabilities, independently validated outcomes, a latency guarantee,
or a profitable trading backtest. Missing/inactive quotes and complete-path
selection are explicitly counted. The median among responding cases is not an
unconditional market-wide response time.

## 4. Quote quality: last trade, midpoint and quote-side diagnostics

```sh
python scripts/expansion_quotes.py
```

Requires the separately restored `dist/downloads/quote-watch.parquet`. The
validated Kalshi input `dist/data/quotes/kalshi.json` and official identifier
audit `dist/data/expansion/quote-identifier-audit.json` are included. Overrides
are available through `--watch`, `--kalshi`, `--audit` and `--output`.

The Kalshi comparison uses identical observations across price measures, with
one day before recorded close as primary and other nominal horizons as
descriptive sensitivities. The source's hourly trade and quote closes need not
be simultaneous. The paired confidence intervals cluster by parent event.

The additional third-party recording is credited to Dinesh Gopalakrishnan,
*Polymarket Order Book Dataset*, CC BY 4.0, pinned revision
`3030329b2a7a58fdf93c9b2aa3c68a0848d63137`:
<https://github.com/DineshKumar8399/polymarket-orderbook-dataset>.
Its watchlist recording is used only for a price-disagreement diagnostic.
Event clocks are missing and the fixed sample of official exact-slug lookups
did not match. **Do not use its convergence-inferred labels, or treat this
diagnostic as exchange-verified forecast accuracy.** The JSON preserves this
failed-linkage audit and the separate authoritative Kalshi comparison.

## 5. Can an earlier correction improve later forecasts?

```sh
python scripts/expansion_recalibration.py --cache inputs/recalibration-empty-cache
```

Requires the separate Kalshi panel. Choose a cache with no `label-gate.json` to
use the frozen settlement metadata bundled inside
`dist/data/expansion/recalibration.json`. The script otherwise prefers an
existing cache's label gate. The included result JSON is therefore also an
input; keep a copy if comparing original and rebuilt output.

To deliberately retrieve current official metadata instead:

```sh
python scripts/expansion_recalibration.py --collect --cache inputs/recalibration-refreshed
```

That collection run may not reproduce the frozen source snapshot if the API
has changed. The model trains only on outcome labels verified available before
the fixed split and tests on later observations with training parent events
removed. The mapping and regularization are fixed, not tuned to test scores.
The reported seven-/thirty-day labels are the archive's nominal horizons;
actual observation-age ranges are reported separately. This remains a
retrospective test, not a prospective preregistration or an after-cost strategy.

## 6. Does a fixed combination beat both exchanges?

```sh
python scripts/expansion_consensus.py
```

Default recomputation uses the exact matched rules, observations and outcomes
already embedded in `dist/data/expansion/consensus.json`; it needs no external
panel or network connection. This JSON is both the audit input and output.

To recollect the case study, restore both original venue panels first, then:

```sh
python scripts/expansion_consensus.py --collect
```

Collection also retrieves pinned Polymarket metadata and current official
Kalshi/Polymarket rule records into `/tmp/atlas-exp-consensus`. Inspect the
reported exclusion reasons and hashes when comparing refreshed output.

This is one 2024 US presidential-election case study. State contests share a
national information shock and are not independent elections. The rule check
matches the outcome target but does not make the contracts fungible; settlement
mechanics differ. Prices share a cutoff but may have different ages. The
combination weight is fixed at one half for each venue. Beating the average
component Brier score is mathematically expected; beating **both** component
scores is the more demanding comparison reported here.

## Provenance, source terms and verification

All six results retain methods, coverage, limitations and source references.
The included `expansion_manifest.json` records hashes of the added files at
packaging time. This does not guarantee that an upstream source will remain
available or that refreshing it will reproduce the same snapshot.

NOAA/IEM observations and archived forecast products and official exchange API
records retain their original provenance. No affiliation or source endorsement
is implied. We do not invent a blanket reuse license for third-party tables:
the sports deposit's license was not established by this audit, so consult the
deposit and source terms before redistributing or repurposing those tables.
Existing venue archives and methods in this ZIP retain their own credits and
license conditions. Quoting our findings should carry the sample and timing
limits, especially where a study is marked `limited`.

These modules report forecast scores and descriptive timing. They do not
establish causal information-processing speed, demonstrate insider trading,
or promise executable profits after fees, spreads and settlement risk.
