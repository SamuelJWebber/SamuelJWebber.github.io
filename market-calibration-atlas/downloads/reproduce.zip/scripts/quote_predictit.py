"""Build the 2022 PredictIt hourly quote sample. Pass --cache with numbered <days>.csv files to run offline."""

import argparse
import csv
import hashlib
import io
import json
import urllib.request
from datetime import datetime
from pathlib import Path

ARCHIVE = "https://github.com/dcadata/fivethirtyeight-vs-predictit"
BASE = "https://raw.githubusercontent.com/dcadata/fivethirtyeight-vs-predictit/"
ANCHOR = int(datetime.fromisoformat("2022-11-09T00:00:00+00:00").timestamp())
COLUMNS = ["market", "event", "category", "days", "yesBid", "yesAsk", "yesTrade", "outcome", "quoteTime", "anchor", "topic"]
# The archive stored a UTC timestamp in each refresh commit. Each capture predates the specified cutoff.
CAPTURES = [
    (1, "5535527b6ce8b51dc20eed2926b4374dd36abfc0", "2022-11-07T23:22:01Z", "ffbb324340aede6baf01d812162937dcbd09848682ba887f5ead2c656d312eab"),
    (3, "9520129eeee44f81e0ab9388398ae8e808c51d7f", "2022-11-05T23:18:29Z", "9f33732f5a301ce488ced207c9b902fd034ec616e7ae73130a376a9863484284"),
    (7, "dd6607d4294abc37ae52188fee4165e323ad71e1", "2022-11-01T23:21:33Z", "243a8ae8c42ccb2ac34304711748ce9899b160c87de5c28ebd9967c9927f0c3d"),
    (14, "4c63aa9e0b933187ac57a65fd46b81d7254a9c1a", "2022-10-25T23:06:41Z", "e5cff3b300612f6f1c5079f3c9ffe6e9a84b117c38d10ed4ae1e1f6fc7e4ef89"),
    (21, "4048a230e9390e412d481e034e96251d49bd562b", "2022-10-18T23:00:51Z", "26d8a6003db66537d5514555408c685c5eec73ec63382b061ef8a9290e0db46c"),
    (30, "ca9f70b86f9c3efebed44e6ed1f9af0e6251a0ca", "2022-10-09T23:14:42Z", "2c80420ca8ecd0294a2400a87d73aaa48c60a080ae174e7db42e55de75f4fa88"),
    (45, "a1576c9201ccf5e57396437c36578ad1c330a990", "2022-09-24T23:12:46Z", "32534d3ea6f674e0f45c11ad7791b8f005c72517b21fac992e0c2a53a9521150"),
]
# Winners of each election. The pass below selects the Democratic contract before inspecting its outcome.
# Utah had no Democratic nominee. The November Georgia Senate election did not elect an outright winner.
WINNERS = {
    "AZ-SEN": "D", "NV-SEN": "D", "NH-SEN": "D", "NC-SEN": "R", "PA-SEN": "D",
    "OH-SEN": "R", "WI-SEN": "R", "WA-SEN": "D", "NV-GOV": "R", "NY-GOV": "D",
    "AZ-GOV": "D", "MI-GOV": "D", "WI-GOV": "D", "PA-GOV": "D", "KS-GOV": "D",
    "MN-GOV": "D", "ME-GOV": "D", "NM-GOV": "D", "CT-GOV": "D",
}


def build(cache):
    rows = []
    for days, commit, time, checksum in CAPTURES:
        path = cache / f"{days}.csv" if cache else None
        if path and path.exists():
            content = path.read_bytes()
        else:
            with urllib.request.urlopen(f"{BASE}{commit}/data/opportunities.csv", timeout=45) as response:
                content = response.read()
        if hashlib.sha256(content).hexdigest() != checksum:
            raise ValueError(f"Archive checksum mismatch for {days} days")
        stamp = int(datetime.fromisoformat(time.replace("Z", "+00:00")).timestamp())
        cutoff = ANCHOR - days * 86400
        assert 0 <= cutoff - stamp < 3600
        seen = {}
        for data in csv.DictReader(io.StringIO(content.decode())):
            seat = data["seat"]
            if seat in ("UT-SEN", "GA-SEN"):
                continue
            result = int(WINNERS[seat] == "D")
            fields = ["bestSellYesCostD", "bestBuyYesCostD", "bestSellNoCostD", "bestBuyNoCostD"]
            if any(not data[field] for field in fields):
                continue
            bid, ask, no_bid, no_ask = (float(data[key]) for key in fields)
            if not (0 < bid <= ask < 1 and 0 < no_bid <= no_ask < 1):
                continue
            assert abs(no_bid + ask - 1) < 1e-8 and abs(no_ask + bid - 1) < 1e-8
            market_id = data["murl"].split("/detail/")[1].split("/")[0]
            topic = "U.S. Senate elections" if seat.endswith("-SEN") else "U.S. governor elections"
            entry = [f"predictit-{market_id}-D", seat, "Politics", days, bid, ask, None, result, stamp, ANCHOR, topic]
            if seat in seen and seen[seat] != entry:
                raise ValueError(f"Duplicated race with conflicting quotes: {seat}")
            seen[seat] = entry
        rows.extend(seen[seat] for seat in sorted(seen))
    markets = len({row[0] for row in rows})
    return {
        "venue": "predictit", "columns": COLUMNS, "rows": rows,
        "coverage": {"contracts": markets, "events": len({r[1] for r in rows}), "observations": len(rows),
                     "horizons": [c[0] for c in CAPTURES], "years": [2022]},
        "method": ("Selected U.S. Senate and governor races in 2022. The archive kept races where a "
                   "FiveThirtyEight forecast disagreed with an available PredictIt buy or sell price by at least "
                   "7.5¢. Each row uses the Democratic contract. The hourly archive refresh preceded the cutoff "
                   "by under one hour, measured from 7 p.m. Eastern on Election Day. The NO quotes were verified "
                   "against the YES quotes. The extracts contain no contemporaneous last trade. "
                   "Outcomes come from the FEC and National Governors Association."),
        "source": ARCHIVE, "outcomeSources": ["https://www.fec.gov/resources/cms-content/documents/federalelections2022.pdf",
                                             "https://www.nga.org/governors/elections/"],
        "captures": [{"days": days, "source": f"{ARCHIVE}/blob/{commit}/data/opportunities.csv", "archived": time}
                     for days, commit, time, _ in CAPTURES],
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cache", type=Path)
    parser.add_argument("--output", type=Path, default=Path("dist/data/quotes/predictit.json"))
    options = parser.parse_args()
    result = build(options.cache)
    options.output.parent.mkdir(parents=True, exist_ok=True)
    options.output.write_text(json.dumps(result, separators=(",", ":")))
    print(result["coverage"])
