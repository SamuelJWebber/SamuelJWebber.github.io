"""Event-clustered 95% confidence intervals for exact 99% favorite forecasts.

For a topic/day, let n and G be the total contracts and events and q the
observed favorite win rate. Inclusion uses the same price tolerance as aggregate.py.
An event has n_g contracts and w_g wins. The variance estimate is
 G/(G-1) * sum_g (w_g - n_g*q)^2 / n^2.
Bounds are q +/- t(.975, G-1) times the square root of this estimate, clipped to
[0,1]. Suppress when G<20, all contracts have the same outcome, or the observed
event-level variance is zero. This describes observed sampling variation under
independence across event IDs; venue composition and cross-event dependence are
outside the interval. Missing keys or null pairs mean unavailable, not zero.
"""
import argparse
import gzip
import json
import math
from functools import lru_cache
from pathlib import Path

import duckdb
from scipy.stats import t
from aggregate import atomic_json, create_favorites, PRICE_DECIMALS

@lru_cache(maxsize=None)
def critical_value(groups):
    return t.ppf(.975,groups-1)

def run(panel, dest):
    folder=dest/panel.stem
    meta=json.loads((folder/'meta.json').read_text())
    # Topic labels can repeat across levels, so keep separate ID namespaces.
    ids={(item['kind'],item['name']):item['id'] for item in meta['topics']}
    result={}
    db=duckdb.connect()
    db.execute("set threads=2")
    db.read_parquet(str(panel)).create_view('panel')
    create_favorites(db)
    stats=db.execute(f"""
    with featured as (
        select days,event_id,topic,broad,99 as cent,y
        from favorites where round(p*100,{PRICE_DECIMALS})=99
    ), by_event as (
        select days,cent,event_id,level.kind,level.name,count(*) as n,sum(y) as w
        from featured cross join lateral (values ('all','All topics'),('broad','All '||broad),('detail',topic)) level(kind,name)
        group by all
    ), summary as (
        select *, sum(w) over grp / sum(n) over grp as rate
        from by_event window grp as (partition by days,cent,kind,name)
    )
    select kind,name,days,cent,sum(n),sum(w),count(*) as groups,sum((w-n*rate)^2)
    from summary group by 1,2,3,4
    """).fetchall()
    db.close()
    for kind,name,day,cent,n,w,g,ss in stats:
        rates=result.setdefault(f'{ids[kind,name]}/{day}',[None,None,None,None])
        if g<20 or w in (0,n) or ss<=1e-18:
            continue
        q=w/n
        margin=critical_value(g)*math.sqrt(ss*g/(g-1))/n
        rates[2:4]=[round(max(0,q-margin),6),round(min(1,q+margin),6)]
    # Read the shipped main shards and independently reconcile n/G/w for each
    # computed group. This also catches price or folding changes in either pipeline.
    by_topic={}
    for kind,name,day,cent,n,w,g,_ in stats:
        by_topic.setdefault(ids[kind,name],[]).append((day,cent,n,w,g))
    for topic,checks in by_topic.items():
        with gzip.open(folder/(topic+'.json.gz'),'rt') as f:
            shard=json.load(f)
        for day,cent,n,w,g in checks:
            block=shard[str(day)]
            fx=block['fx']
            while isinstance(fx,str):
                fx=block[fx]
            row=next(r for r in fx if r[0]==cent)
            assert (row[1],row[4],row[2])==(n,w,g),(panel.stem,topic,day,cent,row,(n,w,g))
    atomic_json(folder/'intervals.json.gz',result,True)
    print(panel.stem,'supported 99% intervals',sum(row[2] is not None for row in result.values()),flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('panels',nargs='+',type=Path)
    p.add_argument('--output',type=Path,default=Path(__file__).resolve().parents[1]/'dist'/'data')
    args=p.parse_args()
    for panel in args.panels:
        run(panel,args.output)
