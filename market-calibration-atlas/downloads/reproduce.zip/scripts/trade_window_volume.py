"""Build cutoff-safe trading volume for the Atlas from the original exchange archives.

Use the local raw directories created by the Atlas reproduction bundle and its
one-row-per-contract-and-horizon panel. Volumes use both outcome sides; trading
size is positive. Output is one market_id, days, volume record per observed price.
"""
import argparse
from pathlib import Path
import duckdb

def forecast_volumes(venue, panel, raw, output, cumulative=False):
    db = duckdb.connect()
    db.execute("set TimeZone='UTC'")
    db.execute("set threads=2")
    db.execute("set memory_limit='800MB'")
    db.execute("set preserve_insertion_order=false")
    db.read_parquet(str(panel)).create_view("panel")
    # Every observed contract has a single anchor and market opening.
    db.execute("create temp table eligible as select market_id, min(anchor) anchor from panel group by market_id")
    if venue=='polymarket':
        db.read_parquet(str(raw/'markets.parquet')).create_view('market_meta')
        db.read_parquet(str(raw/'hourly'/'*.parquet')).create_view('bars')
        source="""
        with traded as (
          select e.market_id, e.anchor, b.timestamp::timestamptz as start_time,
                 floor(epoch(e.anchor-(b.timestamp::timestamptz+interval '1 hour'))/86400)::int as days,
                 b.volume
          from bars b join eligible e on b.market_id::bigint=e.market_id
          join market_meta m on m.market_id=e.market_id
          where b.trade_count>0 and b.timestamp::timestamptz>=m.market_start_time::timestamptz
            and b.close between 0 and 1 and b.volume>=0 and isfinite(b.volume))
        select market_id,days,sum(volume)::double as volume
        from traded where days>=1 and start_time>=anchor-(days+1)*interval '1 day'
        group by market_id,days
        """
    elif venue=='kalshi':
        db.read_parquet(str(raw/'markets*.parquet')).create_view('market_meta')
        db.read_parquet(str(raw/'trades*.parquet')).create_view('trades')
        db.execute("""create temp table eligible_meta as
          select e.market_id, e.anchor, m.open_time from market_meta m
          join eligible e on m.ticker=e.market_id""")
        source="""
        select e.market_id, floor(epoch(e.anchor-t.created_time)/86400)::int as days,
               sum(t.count)::double as volume
        from trades t join eligible_meta e on e.market_id=t.ticker
        where t.created_time>=e.open_time and t.created_time<=e.anchor-interval '1 day'
          and t.yes_price between 0 and 100 and t.count>0
        group by e.market_id,days
        """
    else:
        db.read_csv(str(raw/'meta.csv'),header=True).create_view('market_meta')
        db.execute("""create temp table eligible_meta as
          select e.market_id, m.anchor_ms, m.start_ms
          from market_meta m join eligible e using(market_id)""")
        bets=str(raw/'bets.json').replace("'","''")
        source=f"""
        select e.market_id, ((e.anchor_ms-b.createdTime)//86400000)::int as days,
               sum(abs(b.amount))::double as volume
        from read_json('{bets}',format='array',columns={{
          'contractId':'VARCHAR','probAfter':'DOUBLE','createdTime':'BIGINT','outcome':'VARCHAR',
          'amount':'DOUBLE','shares':'DOUBLE','isAnte':'BOOLEAN','isRedemption':'BOOLEAN',
          'isLiquidityProvision':'BOOLEAN'}}) b join eligible_meta e on e.market_id=b.contractId
        where b.createdTime>=e.start_ms and b.createdTime<=e.anchor_ms-86400000
          and b.outcome in ('YES','NO') and b.amount<>0 and b.shares<>0
          and not coalesce(b.isAnte,false) and not coalesce(b.isRedemption,false)
          and not coalesce(b.isLiquidityProvision,false) and b.probAfter between 0 and 1
        group by e.market_id,days
        """
    if cumulative:
        # A fully closed Polymarket hour remains eligible for cumulative volume
        # even if it straddles the start of its last 24-hour sample window.
        if venue=='polymarket':
            source = source.replace("and start_time>=anchor-(days+1)*interval '1 day'","")
        source = """with section as ("""+source+""") select market_id,days,
                    sum(volume) over (partition by market_id order by days desc
                    rows between unbounded preceding and current row)::double as volume
                    from section"""
    db.execute("create temp table daily as "+source)
    db.execute("""create temp view output as select p.market_id,p.days,d.volume
                  from panel p left join daily d using(market_id,days)""")
    n,good,unique,n_zero,missing=db.execute("""
      select count(*), count_if(volume>0 and isfinite(volume)),count(distinct (market_id,days)),
       count_if(volume=0),count(*) filter(where volume is null) from output""").fetchall()[0]
    print(venue,"rows, valid positive volumes, distinct keys, zero rows, unmatched rows",
          n,good,unique,n_zero,missing,flush=True)
    assert n==unique and n==good and missing==0, (n,good,unique,n_zero,missing)
    print("Day 1 statistics",db.execute("""select count(*),min(volume),median(volume),max(volume)
               from output where days=1""").fetchall()[0],flush=True)
    output.parent.mkdir(parents=True,exist_ok=True)
    temp=output.with_suffix('.partial')
    db.sql("select * from output order by days,market_id").write_parquet(str(temp),compression='zstd')
    temp.replace(output)

if __name__=='__main__':
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument('venue',choices=['polymarket','kalshi','manifold'])
    cli.add_argument('--panel-dir',type=Path,default=Path('/tmp/market_dash'))
    cli.add_argument('--raw',type=Path,help='Polymarket archive root, Kalshi raw shards folder, or Manifold extracted dump folder')
    cli.add_argument('--output-dir',type=Path,default=Path('/tmp/markvol'))
    cli.add_argument('--cumulative',action='store_true',help='Use all archived executed volume from opening through cutoff; write beneath cumulative/')
    args=cli.parse_args()
    roots={'polymarket':'/tmp/mkt_althunt','kalshi':'/tmp/kaldata/raw','manifold':'/tmp/manidata'}
    forecast_volumes(args.venue,args.panel_dir/(args.venue+'.parquet'),args.raw or Path(roots[args.venue]),
                     args.output_dir/('cumulative' if args.cumulative else '')/(args.venue+'.parquet'), args.cumulative)
