"""Build time and volume views using observed contract-horizon quotes.

Reads a venue's normalized Parquet panel and an optional Parquet sidecar with
market_id, days, volume. A sidecar must have positive, as-of-cutoff trading
volume, and unique contract/day rows. Each topic/horizon's own empirical
continuous median defines the volume groups. The event and calibration
statistics are recomputed separately for each calendar period and volume group.
Only favorites priced at least 51% enter. Bias is the signed favorite win share
minus the average favorite price. All groups give each contract equal weight.
"""
import argparse
import json
from pathlib import Path

import duckdb

from aggregate import atomic_json, rounded

CALENDAR = {
    'polymarket': ('cast(completed_at as date)', 'Periods use the UTC date on which the selected hourly price bar ended.'),
    'kalshi': ('cast(completed_at as date)', 'Periods use the UTC date of the selected trade.'),
    'manifold': ('cast(completed_at as date)', 'Periods use the UTC date of the selected bet.'),
    'predictit': ('traded_at', 'Periods use the reported trading date. Intraday observations are assigned to the New York trading date.'),
    'iem': ('cast(anchor as date) - cast(days as integer)', 'Periods use the reported trading-session date.'),
    'intrade': ('cast(anchor as date) - cast(days as integer)', 'Periods use the reported trading-session date.'),
}

VOLUME = {
    'polymarket': ('shares', 'Executed share volume across both outcome tokens in fully completed hourly bars within the 24 hours before the forecast cutoff.'),
    'kalshi': ('contracts', 'Number of contracts exchanged in executions during the 24 hours ending at the forecast cutoff.'),
    'manifold': ('Mana', 'Total absolute Mana exchanged on executed buys and sells in the 24 hours ending at the forecast cutoff.'),
    'predictit': ('shares', 'Contract shares traded in the session used for the forecast. For hourly archives, volume sums the observed trading hours on that New York date. Partially archived dates can understate activity.'),
    'iem': ('contracts', 'Contracts traded during the reported session used for the selected forecast.'),
    'intrade': ('contracts', 'Contracts traded during the reported session used for the selected forecast.'),
}

def summarize(db, group):
    """Use favorite-aligned prices and settlement indicators after eligibility screening."""
    query = f"""
        with sample as ({group})
        select days,cohort,count(*),count(distinct event_id),avg((price-outcome)^2),
               avg(outcome),avg(outcome-price)
        from sample group by days,cohort order by days,cohort
    """
    return db.execute(query).fetchall()


def metric_row(row):
    n, events, brier, hit, bias = row
    return [n, events, rounded(brier), rounded(hit), rounded(bias)]


def volume_input(db, path, alias):
    """Ensure each source observation can match at most one published horizon observation."""
    db.read_parquet(str(path)).create_view(alias)
    duplicates, invalid, count = db.execute(f"""
        select count(*)-count(distinct (market_id,days)),
               count(*) filter(where volume is null or volume<=0 or not isfinite(volume)
                               or market_id is null or days is null), count(*)
        from {alias}""").fetchall()[0]
    if duplicates or invalid:
        raise ValueError(f'{alias} has duplicate keys or invalid volume')
    extra=db.execute(f'select count(*) from {alias} anti join panel using(market_id,days)').fetchall()[0][0]
    if extra:
        raise ValueError(f'{alias} has {extra} unexpected volume keys')
    return count


CUMULATIVE_METHOD = {
    'polymarket': 'Recorded volume from both outcome tokens in fully completed hourly bars from the start of available trading history through the forecast cutoff.',
    'kalshi': 'Contracts exchanged in all recorded trades through the forecast cutoff, beginning with the first trade in the archive.',
    'manifold': 'Absolute Mana turnover from all recorded executed buys and sells through the forecast cutoff, beginning with the first bet in the archive.',
    'iem': 'Total recorded contracts across trading sessions through and including the forecast session, beginning with the first available trading date.',
    'intrade': 'Total recorded contracts across trading sessions through and including the forecast session, beginning with the first available trading date.',
    'predictit': 'Sum of recorded same-contract trading-session volumes through the forecast date. Source windows vary; missing sessions, including incomplete hourly archives, can understate trading since listing.',
}


def build(panel, vol, cumulative, dest):
    venue = panel.stem
    date_expr, period_method = CALENDAR[venue]
    unit, volume_method = VOLUME[venue]
    metadata = json.loads((dest / venue / 'meta.json').read_text())
    out_dir = dest / venue / 'history'
    out_dir.mkdir(parents=True,exist_ok=True)
    db = duckdb.connect()
    db.execute("set TimeZone='UTC'")
    db.execute("set threads=2")
    db.execute("set memory_limit='1500MB'")
    db.read_parquet(str(panel)).create_view('panel')
    volume_inputs = [('volume',vol),('volumeCumulative',cumulative)]
    columns, joins = [], []
    for key,path in volume_inputs:
        if path is not None:
            alias=key+'_source'
            volume_input(db,path,alias)
            columns.append(f'{alias}.volume::double as {key}')
            joins.append(f'left join {alias} using(market_id,days)')
        else:
            columns.append(f'null::double as {key}')
    db.execute(f"""create temp table base as select event_id, days,
        greatest(price::double,1-price::double) as price,
        (case when panel.price>=.5 then outcome else 1-outcome end)::int as outcome,
        broad, topic, {','.join(columns)}, {date_expr} forecast_date,
        year({date_expr}) as yr, quarter({date_expr}) as quarter
        from panel {' '.join(joins)}
        where greatest(panel.price::double,1-panel.price::double) >= .51-1e-14""")
    if db.execute("select count(*) from base where forecast_date is null").fetchall()[0][0]:
        raise ValueError(f'{venue} is missing forecast dates')
    first,last,total,nvolume,ncumul=db.execute(
        'select min(forecast_date),max(forecast_date),count(*),count(volume),count(volumeCumulative) from base').fetchall()[0]
    independent_total=db.execute('select count(*) from panel where greatest(price::double,1-price::double)>=.51-1e-14').fetchall()[0][0]
    if total!=independent_total:
        raise ValueError(f'{venue}: sidecar join unexpectedly changed eligible panel size')
    for topic in metadata['topics']:
        kind=topic['kind']
        if kind=='all':
            db.execute('create or replace temp view selected as select * from base')
        else:
            col, name=('topic',topic['name']) if kind=='detail' else ('broad',topic['name'].removeprefix('All '))
            db.execute(f'create or replace temp table sub as select * from base where {col}=?',[name])
            db.execute('create or replace temp view selected as select * from sub')
        result={}
        for period, expression in [('years','yr'),('quarters',"yr::varchar || ' Q' || quarter::varchar")]:
            source=f'select days, {expression} cohort, event_id, price,outcome from selected'
            for d,cohort,*metrics in summarize(db,source):
                day=result.setdefault(d,{'years':[],'quarters':[],'volume':None,'volumeCumulative':None})
                day[period].append([cohort,*metric_row(metrics)])
        for key,path in volume_inputs:
            if path is None:
                continue
            db.execute(f"""create or replace temp table cuts as select days,
                    median({key}) cut, count({key}) n from selected where {key} is not null group by days""")
            for d,cut,n in db.execute('from cuts').fetchall():
                result[d][key]={'cut':cut,'n':n,'low':None,'high':None}
            source=f"""select days,case when {key}<=cut then 'low' else 'high' end cohort,
                      event_id,price,outcome from selected join cuts using(days) where {key} is not null"""
            for d,group,*metrics in summarize(db,source):
                result[d][key][group]=metric_row(metrics)
        for d,day in result.items():
            ysum=sum(r[1] for r in day['years'])
            if ysum != sum(r[1] for r in day['quarters']):
                raise ValueError(f'Inconsistent period counts on day {d}')
            for key, _ in volume_inputs:
                v=day[key]
                if v and (v['n']>ysum or v['n']!=sum(v[k][0] for k in ['low','high'] if v[k])):
                    raise ValueError(f'Inconsistent {key} groups on day {d}')
        atomic_json(out_dir/(topic['id']+'.json.gz'),result,True)
    info={'unit':unit,'method':volume_method,'periodMethod':period_method,
          'status':'available' if nvolume else 'unavailable','eligible':nvolume,'total':total,
          'cumulativeStatus':'available' if ncumul else 'unavailable','cumulativeEligible':ncumul,
          'cumulativeMethod':CUMULATIVE_METHOD[venue],'cumulativeUnit':unit,
          'firstDate':str(first),'lastDate':str(last)}
    atomic_json(out_dir/'info.json',info)
    print(venue,info,'topics',len(metadata['topics']),flush=True)
    db.close()


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('panels',nargs='+',type=Path)
    parser.add_argument('--volumes',type=Path,help='Folder of venue-named as-of volume Parquet sidecars')
    parser.add_argument('--output',type=Path,default=Path(__file__).resolve().parents[1]/'dist'/'data')
    args=parser.parse_args()
    for panel in args.panels:
        vp=args.volumes/(panel.stem+'.parquet') if args.volumes else None
        cp=(args.volumes/'cumulative'/(panel.stem+'.parquet')) if args.volumes else None
        build(panel,vp if vp and vp.exists() else None,cp if cp and cp.exists() else None,args.output)
