"""Frozen, settlement-gated Kalshi recalibration experiment.

python scripts/expansion_recalibration.py --collect
python scripts/expansion_recalibration.py  # offline using deposited label gate

Requires duckdb, numpy, pandas, scipy. The fixed July 1, 2025 split, the
7-day primary / 30-day secondary horizons, and the two-parameter monotone
logistic mapping were set before evaluation. This is retrospective validation,
not a prospectively preregistered experiment or evidence of tradable returns.
"""
import argparse
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import time
import urllib.parse
import urllib.request

import duckdb
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.special import expit
from scipy.stats import t

ROOT=Path(__file__).resolve().parents[1]
SPLIT=pd.Timestamp('2025-07-01T00:00:00Z')
HORIZONS=[7,30]
API='https://api.elections.kalshi.com/trade-api/v2/historical/markets'
OUT=ROOT/'dist/data/expansion/recalibration.json'

def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def collect(ids, cache):
    cache.mkdir(parents=True,exist_ok=True)
    chunks=[ids[i:i+80] for i in range(0,len(ids),80)]
    def one(ids):
        key=hashlib.sha256(','.join(ids).encode()).hexdigest()[:20]
        path=cache/f'labels-{key}.json'
        url=API+'?'+urllib.parse.urlencode({'limit':1000,'tickers':','.join(ids)})
        error=None
        if not path.exists():
            for attempt in range(3):
                try:
                    req=urllib.request.Request(url,headers={'User-Agent':'MarketCalibrationAtlas/1.0'})
                    data=urllib.request.urlopen(req,timeout=45).read()
                    j=json.loads(data)
                    if j.get('cursor'): raise ValueError('Unexpected pagination in a ticker batch')
                    if not isinstance(j.get('markets'),list): raise ValueError('Missing markets array')
                    path.write_bytes(data)
                    break
                except Exception as e:
                    error=str(e)
                    if attempt<2: time.sleep(1+attempt)
        if not path.exists(): return [],{'batch':key,'requested':len(ids),'error':error}
        j=json.loads(path.read_bytes())
        rows=[dict(market_id=m['ticker'],result=m.get('result'),settlement_ts=m.get('settlement_ts'),status=m.get('status')) for m in j['markets'] if m['ticker'] in ids]
        return rows,dict(batch=key,requested=len(ids),returned=len(rows),sha256=sha(path),url=url)
    records=[];manifest=[]
    with ThreadPoolExecutor(max_workers=4) as pool:
        for i,(rows,entry) in enumerate(pool.map(one,chunks)):
            records.extend(rows);manifest.append(entry)
            print(f'label batch {i+1}/{len(chunks)}: {len(rows)} records',flush=True)
    return records,manifest

def clustered_mean(values, groups):
    values=np.asarray(values,float)
    code,_=pd.factorize(groups)
    g=int(code.max()+1) if len(code) else 0
    if not len(values):return {'mean':None,'ci':None,'groups':0,'n':0}
    mean=float(values.mean())
    if g<20:return dict(mean=mean,ci=None,groups=g,n=len(values))
    residual=np.bincount(code,weights=values-mean)
    se=np.sqrt((g/(g-1))*np.sum(residual**2))/len(values)
    z=float(t.ppf(.975,g-1))
    return dict(mean=mean,ci=[float(mean-z*se),float(mean+z*se)],groups=g,n=len(values))

def losses(y,p):
    bounded=np.clip(p,1e-6,1-1e-6)
    return (p-y)**2, -(y*np.log(bounded)+(1-y)*np.log1p(-bounded))

def fit(train):
    p=train.p.to_numpy();y=train.y.to_numpy()
    x=np.log(np.clip(p,1e-6,1-1e-6)/(1-np.clip(p,1e-6,1-1e-6)))
    w=(1/train.groupby('event_id').event_id.transform('size')).to_numpy();w=w/w.sum()
    def obj(ab):
        a,b=ab;z=a*x+b;q=expit(z)
        penalty=.001/2*((a-1)**2+b*b)
        value=np.sum(w*(np.logaddexp(0,z)-y*z))+penalty
        grad=np.array([np.sum(w*(q-y)*x)+.001*(a-1),np.sum(w*(q-y))+.001*b])
        return value,grad
    res=minimize(obj,[1,0],jac=True,method='L-BFGS-B',bounds=[(0,5),(-10,10)],options={'ftol':1e-13,'gtol':1e-10,'maxiter':500})
    if not res.success: raise RuntimeError(res.message)
    return res.x

def timing_range(frame,horizon):
    lead=(frame.anchor-frame.completed_at).dt.total_seconds()/86400
    age=(lead-horizon)*24
    return dict(actualLeadDays=[float(lead.min()),float(lead.max())],
                quoteAgeHoursRelativeToNominalTarget=[float(age.min()),float(age.max())])

def evaluate(test,ab):
    p=test.p.to_numpy();y=test.y.to_numpy()
    x=np.log(np.clip(p,1e-6,1-1e-6)/(1-np.clip(p,1e-6,1-1e-6)))
    q=expit(ab[0]*x+ab[1]);rb,rl=losses(y,p);cb,cl=losses(y,q)
    difference=rb-cb
    event_equal=pd.DataFrame({'g':test.event_id.to_numpy(),'d':difference}).groupby('g').d.mean()
    return dict(n=len(test),events=int(test.event_id.nunique()),rawBrier=float(rb.mean()),calibratedBrier=float(cb.mean()),brierImprovement=clustered_mean(difference,test.event_id),
      rawLogLoss=float(rl.mean()),calibratedLogLoss=float(cl.mean()),logLossImprovement=clustered_mean(rl-cl,test.event_id),
      rawMeanPrice=float(p.mean()),calibratedMeanPrice=float(q.mean()),outcomeRate=float(y.mean()),
      eventWeightedImprovement=clustered_mean(event_equal.to_numpy(),event_equal.index),
      calendarDayImprovement=clustered_mean(difference,test.completed_at.dt.strftime('%Y-%m-%d')),
      firstForecast=test.completed_at.min().isoformat(),lastForecast=test.completed_at.max().isoformat())

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--collect',action='store_true');parser.add_argument('--cache',type=Path,default=Path('/tmp/atlas-exp-recalibration'));args=parser.parse_args()
    db=duckdb.connect();db.execute("set timezone='UTC'")
    panel=ROOT/'dist/downloads/kalshi.parquet'
    df=db.sql("select * from read_parquet(?) where days in(7,30) and price between 0 and 1 and outcome in(0,1) and greatest(price,1-price)>=.51",params=[str(panel)]).df()
    df['completed_at']=pd.to_datetime(df.completed_at,utc=True);df['anchor']=pd.to_datetime(df.anchor,utc=True)
    df['p']=np.maximum(df.price,1-df.price);df['y']=np.where(df.price>=.5,df.outcome,1-df.outcome)
    if df.duplicated(['market_id','days']).any(): raise ValueError('Duplicate contract/horizon rows')
    candidates=df[(df.anchor<SPLIT)&(df.completed_at<SPLIT)].copy()
    ids=sorted(candidates.market_id.unique())
    if args.collect:
        records,manifest=collect(ids,args.cache)
        (args.cache/'label-gate.json').write_text(json.dumps({'records':records,'manifest':manifest}))
    elif (args.cache/'label-gate.json').exists():
        src=json.loads((args.cache/'label-gate.json').read_text());records,manifest=src['records'],src['manifest']
    else:
        src=json.loads(OUT.read_text())['labelVerification'];records,manifest=src['records'],src['manifest']
    labels=pd.DataFrame(records).drop_duplicates('market_id')
    labels['settlement']=pd.to_datetime(labels.settlement_ts,utc=True,errors='coerce')
    candidates=candidates.merge(labels,on='market_id',how='left',validate='many_to_one')
    candidates['matches']=np.where(candidates.result=='yes',1,np.where(candidates.result=='no',0,-1))==candidates.outcome
    train_all=candidates[(candidates.settlement<SPLIT)&candidates.matches&(candidates.completed_at<candidates.settlement)].copy()
    train_events=set(train_all.event_id)
    test_candidates=df[df.completed_at>=SPLIT].copy()
    test_all=test_candidates[~test_candidates.event_id.isin(train_events)].copy()
    assert not set(train_all.event_id)&set(test_all.event_id)
    assert train_all.settlement.max()<test_all.completed_at.min()
    rows=[];categories=[];models=[];curves=[]
    for horizon in HORIZONS:
        train=train_all[train_all.days==horizon];test=test_all[test_all.days==horizon]
        if len(train)<100 or train.event_id.nunique()<30 or len(test)<100:continue
        ab=fit(train);e=evaluate(test,ab)
        e.update(horizonDays=horizon,label=f'Nominal {horizon}-day bin',trainN=len(train),trainEvents=int(train.event_id.nunique()),slope=float(ab[0]),intercept=float(ab[1]),trainTiming=timing_range(train,horizon),testTiming=timing_range(test,horizon))
        rows.append(e);models.append(dict(horizonDays=horizon,slope=float(ab[0]),intercept=float(ab[1]),trainingLastSettlement=train.settlement.max().isoformat()))
        for broad,sub in test.groupby('broad'):
            if len(sub)>=100 and sub.event_id.nunique()>=20:
                categories.append(dict(horizonDays=horizon,category=broad,**evaluate(sub,ab)))
        for p in np.linspace(.51,.99,49):curves.append(dict(horizonDays=horizon,marketProbability=float(p),recalibratedProbability=float(expit(ab[0]*np.log(p/(1-p))+ab[1]))))
    primary=rows[0]
    delta=primary['brierImprovement'];ci=delta['ci']
    if ci and ci[1]<0: finding='The frozen correction worsened forecasts in the nominal seven-day bin of the later Kalshi sample.'
    elif ci and ci[0]>0:finding='The frozen correction improved forecasts in the nominal seven-day bin of the later Kalshi sample.'
    else:finding='The later Kalshi sample does not establish a clear improvement from the frozen correction.'
    result=dict(title='Can earlier market errors improve later forecasts?',status='complete',finding=finding,
      metrics=[dict(label='Nominal 7-day test contracts',value=primary['n']),dict(label='Nominal 7-day test events',value=primary['events']),dict(label='Raw Brier score',value=primary['rawBrier']),dict(label='Recalibrated Brier score',value=primary['calibratedBrier'])],
      chart=dict(type='paired-bars',title='Forecast error on later, distinct events',x='horizonDays',series=[dict(key='rawBrier',label='Recorded market price'),dict(key='calibratedBrier',label='Frozen correction')],rows=rows),
      rows=rows,table=rows,categories=categories,probabilityMapping=curves,models=models,
      scope=dict(venue='Kalshi',split=SPLIT.isoformat(),primaryHorizonDays=7,secondaryHorizonDays=30,eligibleTrainingContracts=len(ids),trainingContractsWithMetadata=int(candidates.market_id[candidates.settlement.notna()].nunique()),trainingRowsBeforeSettlementGate=len(candidates),trainingRowsAfterSettlementGate=len(train_all),trainingRowsMissingSettlement=int(candidates.settlement.isna().sum()),trainingRowsSettledTooLate=int((candidates.settlement>=SPLIT).sum()),trainingRowsOutcomeMismatch=int((~candidates.matches&candidates.result.notna()).sum()),testRowsBeforeEventPurge=len(test_candidates),testRowsAfterEventPurge=len(test_all),eventOverlap=0),
      methods=[
        'Freeze July 1, 2025 UTC, primary horizon 7 days and secondary horizon 30 days before evaluating results. The eligible universe is the existing resolved Kalshi archive; quote side is flipped to the favorite only when its probability is at least 51%.',
        'Horizons are nominal archive bins, not prices observed at exactly 7 or 30 elapsed days. Each result reports actual lead in elapsed UTC days and quote age in hours relative to anchor minus the nominal day count. A negative relative quote age means the observation follows that nominal target. Stored timestamps, not the nominal bin label, determine train/test eligibility.',
        'Verify training outcomes against the official historical market API. Require settlement_ts strictly before the cutoff and price observation strictly before settlement. Exclude missing settlement timestamps and mismatched outcomes. Test quote timestamps must be at or after the cutoff.',
        'Remove every test parent event appearing in either training horizon. Each contract contributes only once per horizon. No test outcomes choose the mapping or hyperparameters.',
        'Fit a two-parameter monotone logistic mapping sigmoid(a*logit(p)+b), a in [0,5], b in [-10,10]. Minimize event-equal-weighted training log loss plus fixed 0.0005*((a-1)^2+b^2). No category-specific fitting or model selection.',
        'Main scores weight contracts equally; paired improvements are raw loss minus corrected loss, so positive is better. Approximate 95% Student-t intervals cluster by parent event. Separate calendar-day and equal-event sensitivity estimates are reported. Secondary horizon/category intervals are descriptive, not multiplicity-adjusted.',
        'Clip probabilities to [0.000001,0.999999] for logit and log loss only; Brier scores use original raw prices and corrected probabilities.'
      ],
      limitations=[
        'This is a retrospective test designed after the overall archive had already been explored, not a pristine prospective preregistration.',
        'Official settlement timestamps gate the training labels, but current API records do not reconstruct every historical revision of an outcome or rule.',
        'The source close is still not verified real-world occurrence time. Some prices may follow publicly known outcomes. This experiment evaluates the archived forecasting task, not pure information discovery.',
        'Nominal horizon labels include within-bin quote age of up to nearly 24 hours. Do not interpret the 7-day or 30-day comparison as an exact elapsed-time forecast. Reported train/test timing ranges use elapsed UTC time rather than local-calendar interval arithmetic.',
        'The source includes only resolved contracts with eligible trades and does not represent every listed market. Topic mix changes between training and test.',
        'Only Kalshi has verified training-label availability here; this does not establish that the correction transfers to Polymarket or other venues.',
        'Uncertainty intervals condition on the fitted mapping. They describe test-sample variation, not uncertainty from repeatedly choosing different training periods or model families.',
        'Improved probability scores do not imply executable profits after spreads, fees, size limits or settlement delay. Parent events and calendar-day checks do not cover every shared-information dependency.'
      ],
      sources=[dict(name='Atlas Kalshi forecast panel',url='https://market-calibration-atlas.smartgoldfish.chatgpt.site/downloads/kalshi.parquet',sha256=sha(panel)),dict(name='TrevorJS Kalshi trade archive',url='https://huggingface.co/datasets/TrevorJS/kalshi-trades'),dict(name='Official settlement metadata',url=API),dict(name='Historical market API specification',url='https://docs.kalshi.com/api-reference/historical/get-historical-markets')],
      labelVerification=dict(records=records,manifest=manifest),scriptSha256=sha(__file__))
    OUT.parent.mkdir(parents=True,exist_ok=True)
    OUT.write_text(json.dumps(result,separators=(',',':'),allow_nan=False))
    print(json.dumps({'finding':finding,'scope':result['scope'],'rows':rows},indent=2),flush=True)

if __name__=='__main__':main()
