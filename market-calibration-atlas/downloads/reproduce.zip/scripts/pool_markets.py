"""Build contract-weighted All markets summaries from the six normalized venue panels.

The temporary combined panel namespaces contracts and events by venue. A contract
listed on two venues therefore contributes one forecast on each. Topic matching
uses shared names at the same taxonomy level. Original venue cutoffs are kept.
Run after generating the six Parquet panels; publish only the summary shards.
"""
import argparse
import subprocess
import sys
from pathlib import Path
from tempfile import TemporaryDirectory

import duckdb

import aggregate
import matched


VENUES = ('polymarket', 'kalshi', 'predictit', 'iem', 'intrade', 'manifold')


def build(panel_dir):
    scripts = Path(__file__).resolve().parent
    output = scripts.parent / 'dist' / 'data'
    with TemporaryDirectory(prefix='atlas-pooled-') as temp:
        panel = Path(temp) / 'all.parquet'
        with duckdb.connect() as db:
            db.execute("set TimeZone='UTC'")
            db.execute("set threads=2")
            selected, params = [], []
            for venue in VENUES:
                selected.append("""
                    select ? || ':' || market_id::varchar as market_id,
                           ? || ':' || event_id::varchar as event_id,
                           broad, topic, days::int as days, price::double as price,
                           outcome::int as outcome, anchor::timestamptz as anchor
                    from read_parquet(?)
                """)
                params.extend((venue, venue, str(panel_dir / (venue + '.parquet'))))
            db.sql(' union all '.join(selected), params=params).write_parquet(
                str(panel), compression='zstd')
        aggregate.run(panel, output)
        matched.build(panel, output)
    subprocess.run([sys.executable, str(scripts / 'make_compare_summaries.py'), 'all'], check=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('panel_directory', type=Path)
    build(parser.parse_args().panel_directory)
