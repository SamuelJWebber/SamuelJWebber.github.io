"""Fixed-rule earlier-month replication of the Atlas price-shock study.

Collect and analyze:
  python scripts/shock_replication.py --collect --cache /tmp/atlas-replication
Rebuild offline from the public downloads:
  python scripts/shock_replication.py --bars 'dist/downloads/replication-polymarket-*.parquet'

The rules below were fixed before reading February prices. February is an
untouched earlier period, not a prospective future holdout or randomized test.
The event-disjoint analysis removes every parent event observed in the March
core archive, not merely the events that happened to produce March shocks.
"""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import date, datetime, timezone
import glob
import gzip
import hashlib
import json
import math
from pathlib import Path
import shutil

import duckdb
import numpy as np
import pandas as pd

import intraday_polymarket as collector
from intraday_analysis import estimate
from shock_analysis import analyze, selected

ROOT = Path(__file__).resolve().parents[1]
START = '2026-02-01T00:00:00Z'
END = '2026-03-01T00:00:00Z'
MARCH_START = 1772323200
MARCH_END = 1774742400
OFFSETS = [0, 5, 10, 15, 30, 60]
RULES = {
    'frozenBeforeFebruaryFetch': True,
    'primaryMinimumMove': .05,
    'secondaryMinimumMove': .20,
    'noiseMultiple': 4,
    'quietLookbackMinutes': 15,
    'quietMaximumRange': .05,
    'quietMinimumBars': 3,
    'quietMinimumSpanMinutes': 10,
    'historyMinutes': 60,
    'minimumPriorAdjacentReturns': 6,
    'cooldownHours': 6,
    'followupMinutes': OFFSETS,
    'minimumHoursBeforeRecordedClose': 0,
    'minimumVolume': 0,
    'futureBarToleranceMinutes': 0,
    'selection': 'Apply size and noise filters, then six-hour spacing, then require every exact follow-up bar through sixty minutes.'
}


def epoch(value):
    return int(datetime.fromisoformat(value.replace('Z', '+00:00')).timestamp())


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def collect(cache, metadata_cache):
    cache.mkdir(parents=True, exist_ok=True)
    # The source metadata and nearby context already downloaded for the March
    # study can be reused without changing the pinned source revision.
    for name in ['markets.parquet', 'predictions.parquet', 'poly_topics.csv.gz',
                 'five-2026-02-28.parquet', 'five-2026-03-01.parquet']:
        src, dst = metadata_cache/name, cache/name
        if src.exists() and not dst.exists():
            shutil.copyfile(src, dst)
    (cache/'frozen-rules.json').write_text(json.dumps(RULES, indent=2))
    collector.FIRST = date(2026, 1, 31)
    collector.LAST = date(2026, 3, 1)
    output = cache/'february-bars.parquet'
    collector.build(cache, output, root=ROOT, publish_shards=False)
    # The existing normalization is identical across periods. Correct its
    # March-specific cohort labels/counts; all source rules and hashes persist.
    metadata = json.loads((cache/'polymarket-intraday-manifest.json').read_text())
    db = duckdb.connect(config={'threads': 2, 'memory_limit': '1200MB'})
    db.read_parquet(str(output)).create_view('bars')
    counts = db.execute('''select count(*),count(distinct market_id),count(distinct event_id)
        from bars where ts>=? and ts<?''', [epoch(START), epoch(END)]).fetchall()[0]
    metadata.update(cohortStart=START, cohortEndExclusive=END,
                    surroundingContext=['2026-01-31', '2026-03-01'],
                    cohortRows=counts[0], cohortContracts=counts[1], cohortEvents=counts[2])
    downloads=[]
    for i in range(4):
        dest=ROOT/'dist/downloads'/f'replication-polymarket-{i}.parquet'
        subset=db.sql(f'select * from bars where market_id::bigint%4={i} order by market_id,ts')
        subset.write_parquet(str(dest), compression='zstd')
        assert dest.stat().st_size<15_000_000, dest
        count=db.sql(f'select count(*) from bars where market_id::bigint%4={i}').fetchall()[0][0]
        downloads.append(dict(path='downloads/'+dest.name,bytes=dest.stat().st_size,
                              rows=count,sha256=digest(dest)))
    assert sum(d['rows'] for d in downloads)==metadata['rows']
    metadata.update(normalizedDownloads=downloads,
        normalizedSharding='Numeric market_id modulo four; union all four shards. Each contract is wholly in one shard.',
        sourceAsOf='The pinned metadata contains outcomes known by late March 2026; unresolved contracts are excluded consistently with the March study.')
    (cache/'replication-source.json').write_text(json.dumps(metadata,separators=(',',':')))
    db.close()
    return output,metadata


def summary(payload, minimum, allowed_events=None):
    markets, offsets=payload['markets'],payload['meta']['offsetMinutes']
    candidates=[r for r in payload['rows'] if allowed_events is None or markets[r[0]]['event'] in allowed_events]
    chosen=selected(candidates,minimum=minimum,multiplier=4,lead=0,volume=0)
    indices=[offsets.index(m) for m in OFFSETS]
    complete=[r for r in chosen if all(r[13][i] is not None for i in indices)]
    frame=pd.DataFrame({'event_id':[markets[r[0]]['event'] for r in complete],
        'market_id':[markets[r[0]]['id'] for r in complete],
        'before':[r[2] for r in complete], 'initial':[r[3] for r in complete],
        'outcome':[r[4] for r in complete]})
    result=dict(minimumMove=minimum,selected=len(chosen),n=len(complete),
        contracts=len({markets[r[0]]['id'] for r in complete}),
        events=len({markets[r[0]]['event'] for r in complete}),
        retention=len(complete)/len(chosen) if chosen else None,
        categoryMix=dict(sorted(Counter(markets[r[0]]['broad'] for r in complete).items())),
        path={}, firstResponseMinutesAfterAssumedNews=6)
    if not complete:
        return result
    result['firstDay']=datetime.fromtimestamp(min(r[1] for r in complete),timezone.utc).date().isoformat()
    result['lastDay']=datetime.fromtimestamp(max(r[1] for r in complete),timezone.utc).date().isoformat()
    result['medianLeadHours']=float(np.median([r[6] for r in complete]))
    result['meanInitialJump']=float((frame.initial-frame.before).mean())
    for minute,i in zip(OFFSETS,indices):
        prices=np.array([r[13][i] for r in complete])
        metrics=pd.DataFrame({'event_id':frame.event_id,'expected':prices,'observed':frame.outcome,
            'gap':prices-frame.outcome,'brier':(prices-frame.outcome)**2,
            'drift':prices-frame.initial,
            'brierGain':(frame.initial-frame.outcome)**2-(prices-frame.outcome)**2})
        result['path'][str(minute)]=estimate(metrics,['expected','observed','gap','brier','drift','brierGain'])
    result['retainedMeanMovement']=float((np.array([r[13][indices[-1]] for r in complete])-frame.before).mean()/(frame.initial-frame.before).mean())
    return result


def run(specification, cache, march_specification, metadata=None):
    cache.mkdir(parents=True,exist_ok=True)
    # Frozen parameters are passed to the shared detector. March defaults of
    # the existing dashboard remain unchanged.
    payload=analyze('polymarket',specification,cache/'shock-payload',
                    cohort_start=START,cohort_end=END)
    march_paths=[str(Path(p)) for p in sorted(glob.glob(march_specification))]
    if not march_paths:
        raise ValueError('March normalized bars are required for event exclusion')
    db=duckdb.connect(config={'threads':2,'memory_limit':'900MB'})
    db.read_parquet(march_paths).create_view('march')
    march_events={str(r[0]) for r in db.execute('select distinct event_id from march where ts>=? and ts<?',
                                               [MARCH_START,MARCH_END]).fetchall()}
    feb_events={m['event'] for m in payload['markets']}
    independent=feb_events-march_events
    march_payload=json.loads(gzip.decompress((ROOT/'dist/data/intraday/polymarket-shocks.json.gz').read_bytes()))
    cohort_defs=[('march_reference','March 1–28 reference',march_payload,None),
                 ('february_all','February 1–28: all eligible events',payload,None),
                 ('february_disjoint','February: events absent from March',payload,independent)]
    cohorts=[]
    for key,label,data,allowed in cohort_defs:
        cohorts.append(dict(id=key,label=label,analyses={
            '5':summary(data,.05,allowed),'20':summary(data,.20,allowed)}))
    destination=ROOT/'dist/data/intraday/shock-replication.json'
    if metadata is None and (cache/'replication-source.json').exists():
        metadata=json.loads((cache/'replication-source.json').read_text())
    if metadata is None and destination.exists():
        metadata=json.loads(destination.read_text()).get('sourceManifest')
    output=dict(meta=dict(
        study='Fixed-rule earlier-month replication',
        generatedAt=datetime.now(timezone.utc).isoformat(),
        venue='polymarket',replicationStart=START,replicationEndExclusive=END,
        frozenRules=RULES,sourceRevision=collector.REVISION,
        attribution='Akey, Grégoire, Harvie and Martineau (2026), Polymarket Users Dataset. CC BY 4.0.',
        source=collector.SOURCE,
        inputFiles=payload['meta']['inputFiles'],
        marchInputFiles=[dict(file=Path(p).name,sha256=digest(p)) for p in march_paths],
        marchCoreParentEvents=len(march_events),
        februaryCandidateParentEvents=len(feb_events),
        overlappingCandidateParentEvents=len(feb_events&march_events),
        independentCandidateParentEvents=len(independent),
        interval='Approximate 95% Student-t intervals clustered by parent event; suppressed below twenty event groups or at zero variance. Pointwise, not simultaneous.',
        interpretation='The February period was not used to select the published March shock rules. This is an earlier-period replication with frozen rules, not a prospective future holdout. The event-disjoint row excludes every parent event appearing anywhere in the March core normalized archive. Calendar/category differences remain and both periods share the same source and trading-price limitations.'),
        sourceManifest=metadata,cohorts=cohorts)
    destination.write_text(json.dumps(output,separators=(',',':'),allow_nan=False))
    print(json.dumps({'output':str(destination),'cohorts':cohorts},separators=(',',':')),flush=True)
    db.close()
    return output


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--collect',action='store_true')
    parser.add_argument('--cache',type=Path,default=Path('/tmp/atlas-replication'))
    parser.add_argument('--metadata-cache',type=Path,default=Path('/tmp/atlas-intraday-poly'))
    parser.add_argument('--bars',default=str(ROOT/'dist/downloads/replication-polymarket-*.parquet'))
    parser.add_argument('--march-bars',default=str(ROOT/'dist/downloads/intraday-polymarket-*.parquet'))
    args=parser.parse_args()
    if args.collect:
        bars,manifest=collect(args.cache,args.metadata_cache)
    else:
        bars,manifest=args.bars,None
    run(str(bars),args.cache,args.march_bars,manifest)
