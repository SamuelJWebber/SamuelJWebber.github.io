"""Build intraday horizon checks and rapid-price-move inputs from real bars.

Usage: python scripts/intraday_analysis.py --venue polymarket --bars PATH
       [--manifest PATH] [--output dist/data/intraday]

Requires duckdb, numpy, pandas, scipy. No network requests. Run the source
collector first. Bar end is the observation timestamp: the final actual trade
inside a bar can precede it by up to five minutes (Polymarket) or one (Kalshi).
Event times remain the source's recorded close/expiry proxies, not verified
occurrence times. The two different source cohorts must not be pooled.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
from functools import lru_cache
import glob
import gzip
import hashlib
import json
import math
from pathlib import Path

import duckdb
import numpy as np
import pandas as pd
from scipy.stats import t

ROOT = Path(__file__).resolve().parents[1]
HOURS = list(range(1, 73))
PAIRS = [(6, 1), (12, 1), (24, 1), (48, 1), (72, 1), (24, 6)]
WINDOWS = [15, 30, 60]
METRICS = ['expected', 'observed', 'bias', 'brier']
MOVE_COLUMNS = ['market', 'window', 'ts', 'before', 'after', 'won',
                'leadHours', 'forward1h', 'forward6h', 'forward24h',
                'windowVolume', 'spreadBefore', 'spreadAfter']


def finite_number(value, digits=8):
    return None if value is None or not np.isfinite(value) else round(float(value), digits)


@lru_cache(maxsize=None)
def critical(groups):
    return float(t.ppf(.975, groups - 1))


def estimate(frame, names=METRICS):
    """Contract/move-weighted means; sandwich variance clustered by event."""
    if not len(frame):
        return dict(n=0, events=0, **{k: None for k in names},
                    ci={k: None for k in names})
    gframe = frame.groupby('event_id', sort=False)[names].agg(['sum', 'count'])
    counts = gframe[(names[0], 'count')].to_numpy(float)
    sums = np.column_stack([gframe[(k, 'sum')].to_numpy(float) for k in names])
    n, groups = len(frame), len(counts)
    means = sums.sum(axis=0) / n
    variance = ((groups / (groups - 1)) * np.sum(
        (sums - counts[:, None] * means) ** 2, axis=0) / n ** 2
        if groups > 1 else np.full(len(names), np.nan))
    result = dict(n=n, events=groups, ci={})
    for name, mean, var in zip(names, means, variance):
        result[name] = finite_number(mean)
        if groups < 20 or not np.isfinite(var) or var <= 1e-20:
            result['ci'][name] = None
        else:
            radius = critical(groups) * math.sqrt(var)
            low, high = mean - radius, mean + radius
            if name in METRICS and name != 'bias':
                low, high = max(0, low), min(1, high)
            result['ci'][name] = [finite_number(low), finite_number(high)]
    return result


def emit(path, value, compressed=False):
    raw = json.dumps(value, separators=(',', ':'), ensure_ascii=False,
                     allow_nan=False).encode()
    if compressed:
        raw = gzip.compress(raw, compresslevel=6, mtime=0)
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_bytes(raw)
    temporary.replace(path)
    return len(raw)


def epoch(iso):
    return int(datetime.fromisoformat(iso.replace('Z', '+00:00')).timestamp())


def register_source(db, specification):
    """Accept one normalized Parquet, a quoted shard glob, or Kalshi JSON.gz.

    Public normalized downloads are sufficient for an entirely offline rebuild.
    Metadata/source checksums remain separate from the normalized input hash.
    """
    paths = [Path(p) for p in sorted(glob.glob(str(specification)))]
    if not paths:
        raise ValueError(f'No normalized source files match {specification}')
    hashes = [{'file':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
              for p in paths]
    if len(paths) == 1 and paths[0].name.endswith('.json.gz'):
        with gzip.open(paths[0], 'rt') as f:
            data = json.load(f)
        assert data['meta']['venue'] == 'kalshi'
        assert data['meta']['columns'] == ['ts','price','bid','ask','volume']
        records = []
        for m in data['markets']:
            for ts,price,bid,ask,volume in m['rows']:
                records.append((m['id'],m['event'],m['broad'],m['topic'],
                    ts,price,m['outcome'],m['anchor'],volume,bid,ask))
        frame = pd.DataFrame(records,columns=['market_id','event_id','broad','topic',
            'ts','price','outcome','anchor','volume','bid','ask'])
        db.register('normalized_download',frame)
        # Materialize the registered frame before it leaves this function.
        db.execute('create temp table source as select * from normalized_download')
    else:
        assert all(p.suffix == '.parquet' for p in paths)
        db.read_parquet([str(p) for p in paths]).create_view('source')
    combined = (hashes[0]['sha256'] if len(hashes) == 1 else
                hashlib.sha256(json.dumps(hashes,sort_keys=True).encode()).hexdigest())
    return combined, hashes


def scope_frames(frame):
    yield 'all', 'All topics', 'all', frame
    for kind, column in [('broad', 'broad'), ('detail', 'topic')]:
        for name in sorted(frame[column].dropna().unique()):
            yield kind + ':' + name, name, kind, frame[frame[column] == name]


def hourly_scopes(frame, candidates):
    result = {}
    for key, name, kind, group in scope_frames(frame):
        item = {'name': name, 'kind': kind, 'hours': {}, 'pairs': {}}
        for hour, h in group.groupby('hour', sort=True):
            metrics = estimate(h)
            ages = h.age_minutes.to_numpy(float)
            metrics['ageMinutes'] = dict(median=finite_number(np.median(ages)),
                p95=finite_number(np.quantile(ages, .95)), max=finite_number(ages.max()))
            item['hours'][str(hour)] = metrics
        for far, near in PAIRS:
            a = group[group.hour == far]
            b = group[group.hour == near]
            paired = a.merge(b, on='market_id', suffixes=('_far', '_near'),
                             validate='one_to_one')
            if not len(paired):
                continue
            assert (paired.event_id_far == paired.event_id_near).all()
            gain = pd.DataFrame({'event_id': paired.event_id_far,
                'brierGain': paired.brier_far - paired.brier_near})
            delta = estimate(gain, ['brierGain'])
            sample = dict(n=delta['n'], events=delta['events'],
                          brierGain=delta['brierGain'], ci=delta['ci']['brierGain'])
            for suffix in ['far', 'near']:
                sub = pd.DataFrame({'event_id': paired['event_id_' + suffix],
                    **{m: paired[m + '_' + suffix] for m in METRICS}})
                sample[suffix] = estimate(sub)
            item['pairs'][f'{far}/{near}'] = sample
        result[key] = item
    return result


def cooldown(rows, threshold=.30, window=30, lead_hours=24):
    """Match the browser: filter first, then earliest move per six-hour spell."""
    accepted, latest = [], {}
    for row in sorted(rows, key=lambda r: (r[0], r[2])):
        market, w, ts, before, after, won, lead = row[:7]
        if w != window or lead + 1e-9 < lead_hours or after - before + 1e-10 < threshold:
            continue
        if ts < latest.get(market, -math.inf) + 21600:
            continue
        accepted.append(row)
        latest[market] = ts
    return accepted


def analyze(venue, bars, output, manifest=None):
    output.mkdir(parents=True, exist_ok=True)
    is_poly = venue == 'polymarket'
    bar_minutes = 5 if is_poly else 1
    start = epoch('2026-03-01T00:00:00Z') if is_poly else 0
    end = epoch('2026-03-29T00:00:00Z') if is_poly else 2 ** 53 - 1
    source = ('https://www.vincentgregoire.com/polymarket-users-data/datasets/ohlcv/'
              if is_poly else 'https://docs.kalshi.com/api-reference/historical/get-historical-market-candlesticks')
    db = duckdb.connect(config={'threads': 3, 'memory_limit': '1800MB'})
    db.execute("set preserve_insertion_order=false")
    raw_checksum,input_files = register_source(db,bars)
    columns = {r[0] for r in db.execute('describe source').fetchall()}
    assert {'market_id', 'event_id', 'broad', 'topic', 'ts', 'price',
            'outcome', 'anchor', 'volume'} <= columns
    count, unique, bad, start_ts, end_ts = db.execute('''
        select count(*),count(distinct(market_id,ts)),
          count(*) filter(where market_id is null or event_id is null or broad is null
            or topic is null or outcome not in(0,1) or outcome is null
            or ts is null or anchor is null or (price is not null and
            (not isfinite(price) or price not between 0 and 1))),min(ts),max(ts)
        from source''').fetchone()
    assert count == unique and bad == 0, (count, unique, bad)
    inconsistent = db.execute('''select count(*) from (select market_id from source
        group by market_id having count(distinct event_id)>1 or count(distinct broad)>1
        or count(distinct topic)>1 or count(distinct anchor)>1 or count(distinct outcome)>1)''').fetchone()[0]
    assert not inconsistent
    spread_sql = '(ask-bid)' if {'bid', 'ask'} <= columns else 'null::double'
    spread_condition = '0<bid and bid<=ask and ask<1' if {'bid', 'ask'} <= columns else 'false'
    db.execute(f'''create temp table active as
        select market_id::varchar market_id,event_id::varchar event_id,broad,topic,
               ts::bigint ts,anchor::bigint anchor,outcome::int outcome,
               price::double price,volume::double volume,
               case when {spread_condition} then {spread_sql} else null end spread,
               sum(volume::double) over (partition by market_id order by ts
                   rows unbounded preceding) cumulative_volume
        from source where price is not null and isfinite(volume) and volume>0 and ts<=anchor''')
    active_count = db.execute('select count(*) from active').fetchone()[0]
    db.execute('''create temp table markets as select market_id::varchar market_id,
        any_value(event_id::varchar) event_id,any_value(broad) broad,
        any_value(topic) topic,any_value(outcome)::int outcome,
        any_value(anchor)::bigint anchor from source group by market_id''')
    db.execute(f'''create temp table cutoffs as
        select m.*,h.hour,anchor-h.hour*3600 cutoff from markets m
        cross join range(1,73) h(hour)
        where anchor-h.hour*3600>={start} and anchor-h.hour*3600<{end}''')
    db.execute('''create temp table observations as
        select c.*,b.price,b.ts bar_ts,(c.cutoff-b.ts)/60.0 age_minutes
        from cutoffs c asof left join active b
        on c.market_id=b.market_id and c.cutoff>=b.ts''')
    available = {str(h): {'candidateContracts': n, 'withFreshPrices': fresh,
                         'eligibleFavorites': favorites}
        for h,n,fresh,favorites in db.execute('''select hour,count(*),
            count(*) filter(where price is not null and age_minutes between 0 and 30),
            count(*) filter(where price is not null and age_minutes between 0 and 30
                and round(greatest(price,1-price)*100,12)>=51)
            from observations group by hour order by hour''').fetchall()}
    hourly = db.execute('''select market_id,event_id,broad,topic,anchor,hour,bar_ts,
        greatest(price,1-price) expected,
        case when price>=.5 then outcome else 1-outcome end observed,
        observed-expected bias,(observed-expected)^2 brier,age_minutes
        from observations where price is not null and age_minutes between 0 and 30
            and round(greatest(price,1-price)*100,12)>=51''').df()
    assert not hourly.duplicated(['market_id','hour']).any()
    assert ((hourly.anchor-hourly.hour*3600-hourly.bar_ts)>=0).all()
    assert (hourly.age_minutes<=30).all()
    scopes = hourly_scopes(hourly, available)
    print(venue, 'hourly', len(hourly), 'observations', len(scopes), 'scopes', flush=True)
    db.execute(f'''create temp table endpoints as
        select r.market_id,r.event_id,r.broad,r.topic,r.anchor,r.outcome,r.ts,
          w.minutes as window_minutes,l.price p0,r.price p1,
          l.spread spread0,r.spread spread1,
          greatest(0,r.cumulative_volume-l.cumulative_volume) window_volume
        from active r cross join (values (15),(30),(60)) w(minutes)
        join active l on l.market_id=r.market_id and l.ts=r.ts-w.minutes*60
        where r.ts>={start} and r.ts<{end}''')
    pair_counts = {str(w): {'activeEndpointPairs': n, 'candidateMoves': moves}
        for w,n,moves in db.execute('''select window_minutes,count(*),
        count(*) filter(where abs(p1-p0)>=.05-1e-10)
        from endpoints group by window_minutes order by window_minutes''').fetchall()}
    db.execute('''create temp table candidates as select * from endpoints
        where abs(p1-p0)>=.05-1e-10''')
    # The exact endpoint bars are already observed at detection. Forward closes
    # never enter detection, eligibility, or the cooldown selection.
    previous = 'candidates'
    for hours in [1, 6, 24]:
        target = f'forward_{hours}'
        db.execute(f'''create temp table {target} as
            select c.*,case when c.ts+{hours}*3600<=c.anchor
                and f.ts>=c.ts+{hours}*3600-300
                then f.price else null end f{hours},
                case when c.ts+{hours}*3600<=c.anchor
                and f.ts>=c.ts+{hours}*3600-300
                then f.ts else null end ft{hours}
            from {previous} c asof left join active f
            on c.market_id=f.market_id and c.ts+{hours}*3600>=f.ts''')
        previous = target
    move_markets = db.execute(f'''select distinct market_id,event_id,broad,topic,anchor
        from {previous} order by market_id''').fetchall()
    markets = [dict(id=m,event=e,broad=b,topic=t,anchor=a) for m,e,b,t,a in move_markets]
    index = {m['id']:i for i,m in enumerate(markets)}
    records = db.execute(f'''select market_id,window_minutes,ts,p0,p1,outcome,
        (anchor-ts)/3600.0 lead,f1,f6,f24,window_volume,spread0,spread1,
        ft1,ft6,ft24,anchor from {previous} order by market_id,ts,window_minutes''').fetchall()
    rows = []
    for market,w,ts,p0,p1,y,lead,f1,f6,f24,volume,s0,s1,ft1,ft6,ft24,anchor in records:
        rising = p1 > p0
        orient = lambda p: None if p is None else finite_number(p if rising else 1-p,12)
        before, after = orient(p0), orient(p1)
        assert after-before >= .05-1e-10 and lead>=0
        for h,ft in zip([1,6,24],[ft1,ft6,ft24]):
            if ft is not None:
                assert ts+h*3600-300<=ft<=ts+h*3600<=anchor
        rows.append([index[market],w,ts,before,after,int(y if rising else 1-y),
            finite_number(lead,10),orient(f1),orient(f6),orient(f24),
            finite_number(volume,6),finite_number(s0,8),finite_number(s1,8)])
    metadata = {
        'venue':venue,'barMinutes':bar_minutes,'source':source,
        'volumeUnit':'shares (tracked token)' if is_poly else 'contracts',
        'generatedDate':datetime.now(timezone.utc).date().isoformat(),
        'cohortStart':'2026-03-01T00:00:00Z' if is_poly else None,
        'cohortEnd':'2026-03-29T00:00:00Z (exclusive)' if is_poly else None,
        'observedBarRange':[start_ts,end_ts], 'inputSha256':raw_checksum,
        'inputFiles':input_files,
        'method':('Polymarket five-minute bars ending during March 1–28, 2026, for resolved binary markets. Adjacent archive days supply context only. '
                  if is_poly else 'A deterministic sample of resolved Kalshi contracts from the existing archive, with one-minute candles in the last 72 hours before reported close. ')+
                 'Each hourly horizon uses the latest completed positive-volume trade bar at or before the cutoff, with bar-end age at most 30 minutes. Favorites must be priced at least 51%. Missing bars are never interpolated or carried beyond that age limit. Each contract contributes once per horizon.',
        'clockNote':'The anchor is the source-reported close/expiry proxy, not independently verified event occurrence. A close can follow the public result. Price changes compare completed bar closes; actual trade timestamps within a bar may differ by up to the bar length. A 30-minute bar-age limit permits an actual last trade up to '+str(30+bar_minutes)+' minutes old.',
        'intervalNote':'Approximate 95% Student-t intervals cluster contracts within archive-defined parent events. Suppressed below 20 events or at zero estimated variance. They exclude source error, event-clock error, dependence between different event IDs, and multiple-comparison adjustments.',
        'counts':{'sourceBars':count,'activeBars':active_count,'sourceContracts':db.execute('select count(*) from markets').fetchone()[0],
                  'hourlyObservations':len(hourly),'moveCandidates':len(rows),'moveContracts':len(markets)},
        'hourlyAvailability':available,'moveAvailability':pair_counts,
        'candidateMinimumMovePoints':5,'cooldownHours':6,
        'spreadAvailable':not is_poly,
        'moveMethod':'Endpoints must both be positive-volume trade bars with completion times exactly 15, 30 or 60 minutes apart. A candidate moves by at least 5 percentage points. Prices and the result are oriented toward the outcome whose price rose; that outcome need not be the favorite. Filter by the requested move size and minimum hours before close, then retain the earliest qualifying move and require at least six hours before another move in that contract. Forward prices do not affect selection.',
        'forwardMethod':'For each one-, six- or 24-hour follow-up, use the last completed positive-volume trade bar at or before the follow-up, no more than five minutes old, only when the follow-up is at or before the source anchor. Missing follow-ups stay null. Reversal rates must use only their own available follow-up denominators.',
        'volumeMethod':'Window volume sums active bar quantity strictly after the start endpoint through the end endpoint. Polymarket counts only shares of the tracked outcome token, not all trading in both tokens; Kalshi counts contracts. Neither is dollar turnover. Endpoint spreads, when present, are same-minute YES ask minus bid, with both quotes strictly inside zero and one; trade and quote closes need not be simultaneous.',
        'cohortWarning':'These are different, selected archives. Do not pool the two source cohorts or compare their headline scores as if they forecast the same events.'
    }
    if manifest and manifest.exists():
        metadata['sourceManifest'] = json.loads(manifest.read_text())
    default = cooldown(rows)
    df = pd.DataFrame([{'event_id':markets[r[0]]['event'],'expected':r[4],
        'observed':r[5],'bias':r[5]-r[4],'brier':(r[5]-r[4])**2,
        'beforeBrier':(r[5]-r[3])**2,'brierGain':(r[5]-r[3])**2-(r[5]-r[4])**2}
        for r in default])
    metadata['defaultMoveCheck'] = dict(thresholdPoints=30,windowMinutes=30,minLeadHours=24,
        stats=estimate(df, METRICS+['beforeBrier','brierGain']))
    metadata['movesFiles'] = {str(w):f'data/intraday/{venue}-moves-{w}.json.gz'
                              for w in WINDOWS}
    n1 = emit(output/f'{venue}-analysis.json',{'meta':metadata,'scopes':scopes})
    sizes = {}
    for window in WINDOWS:
        selected = [r for r in rows if r[1] == window]
        ids = sorted({r[0] for r in selected})
        local_index = {old:new for new,old in enumerate(ids)}
        payload = {'meta':metadata,'windowMinutes':window,'columns':MOVE_COLUMNS,
                   'markets':[markets[i] for i in ids],
                   'rows':[[local_index[r[0]],*r[1:]] for r in selected]}
        sizes[str(window)] = emit(output/f'{venue}-moves-{window}.json.gz',payload,True)
    # The window-specific shards replace the first experimental combined file.
    (output/f'{venue}-moves.json.gz').unlink(missing_ok=True)
    print(venue,'written analysis',n1,'moves.gz',sizes,'candidates',len(rows),
          'default30pp/30min/24h',len(default),metadata['defaultMoveCheck']['stats'],flush=True)
    db.close()


if __name__ == '__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--venue',required=True,choices=['polymarket','kalshi'])
    parser.add_argument('--bars',required=True,
                        help='Normalized Parquet path, quoted shard glob, or Kalshi normalized JSON.gz download.')
    parser.add_argument('--manifest',type=Path)
    parser.add_argument('--output',type=Path,default=ROOT/'dist/data/intraday')
    args=parser.parse_args()
    analyze(args.venue,args.bars,args.output,args.manifest)
