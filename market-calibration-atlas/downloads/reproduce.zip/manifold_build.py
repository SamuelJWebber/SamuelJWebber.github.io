import duckdb as d,os,time,pathlib
p=pathlib.Path('/tmp/manidata');os.chdir(p)
while not (p/'bets.json').exists() or os.stat(p/'bets.json').st_size<6766040782:time.sleep(1)
c=d.connect(str(p/'db.db'));c.execute("set timezone='UTC'");c.execute("set threads=2");c.execute("set memory_limit='1000MB'")
c.execute("create or replace table m as select market_id,start_ms,anchor_ms,outcome from read_csv_auto('meta.csv') where not regexp_matches(tags,'(^|[|])non[-]?predictive([|]|$)')")
print('validate input',c.sql('select count(*) from m').fetchall(),flush=True)
c.execute("""create or replace table h as with b as (
select b.contractId as id,b.id as bet,b.probAfter as price,b.createdTime as t,m.anchor_ms,((m.anchor_ms-b.createdTime)//86400000)::integer as d
from read_json('bets.json',format='array',columns={'contractId':'VARCHAR','id':'VARCHAR','probAfter':'DOUBLE','createdTime':'BIGINT','outcome':'VARCHAR','amount':'DOUBLE','shares':'DOUBLE','isAnte':'BOOLEAN','isRedemption':'BOOLEAN','isLiquidityProvision':'BOOLEAN'}) b
join m on m.market_id=b.contractId where b.createdTime>=m.start_ms and b.createdTime<=m.anchor_ms-86400000 and b.outcome in ('YES','NO') and b.amount<>0 and b.shares<>0
and not coalesce(b.isAnte,false) and not coalesce(b.isRedemption,false) and not coalesce(b.isLiquidityProvision,false) and b.probAfter between 0 and 1)
select id as market_id,d as days,arg_max(price,struct_pack(t:=t,id:=bet)) as price,max(t) as completed_ms from b group by 1,2""")
print('horizon',c.sql('select count(*),count(distinct market_id),max(days) from h').fetchall(),flush=True)
while not (p/'topics.csv').exists():time.sleep(1)
c.execute("""copy (select h.market_id,h.market_id as event_id,t.topic,t.broad,h.days,h.price,m.outcome,epoch_ms(m.anchor_ms)::timestamptz as anchor,epoch_ms(h.completed_ms)::timestamptz as completed_at from h join m using(market_id) join 'topics.csv' t using(market_id) order by days) to '/tmp/market_dash/manifold.partial' (format parquet,compression zstd)""")
pathlib.Path('/tmp/market_dash/manifold.partial').rename('/tmp/market_dash/manifold.parquet')
print(c.sql("select count(*),count(distinct market_id),count(distinct topic),min(anchor),max(anchor),min(completed_at),max(completed_at),min(days),max(days),count(*) filter(where days<=90) from '/tmp/market_dash/manifold.parquet'").fetchall(),flush=True)
print(c.sql("select days,count(*),count(distinct market_id) from h where days in(1,7,30,90,180,365,500,730) group by all order by 1").fetchall(),flush=True)
