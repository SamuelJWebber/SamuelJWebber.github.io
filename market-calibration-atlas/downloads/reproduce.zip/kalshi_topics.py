import json,csv,collections,re,pathlib
p=pathlib.Path('/tmp/kaldata')
ref={r['ticker']:r for r in json.load(open(p/'series.json'))['series']}
def choose(k,cat,t,g):
 # Source-defined series taxonomy, with transparent overrides for recognizable subjects.
 def m(s):return bool(re.search(s,t+' '+g+' '+k,re.I))
 def tag(s):return s.lower() in tags
 tags={v.lower() for v in g.split('|')}
 def froms(rules,other):
  return next((topic for pattern,topic in rules if m(pattern)),other)
 if cat=='Mentions' or m(r'^$NEVER') or k in ['MENTION','KXMENTION']: return 'Politics','Mentions and speeches'
 if cat in ('Climate and Weather',) or (cat=='World' and m(r'(?:high |low |highest |lowest )temp|rain|hurricane|earthquake')):
  topic=froms([(r'daily temp|highest temp|lowest temp|high temp in|low temp in','Daily city temperatures'),(r'snow|rain|precipitation','Rain and snow'),(r'hurricane|tornado|wildfire|typhoon|tropical storm','Storms and wildfires'),(r'earthquake|tsunami','Earthquakes and tsunamis'),(r'global.*temp|warmest|temperature record|hottest','Longer-term temperature and records'),(r'temperature','Other temperature questions')],'Other weather')
  return 'Weather',topic
 if cat=='Crypto':
  topic=froms([(r'bitcoin|(?:kx)?btc','Bitcoin'),(r'ethereum|(?:kx)?eth','Ethereum'),(r'solana','Solana'),(r'\bxrp\b|ripple','XRP'),(r'dogecoin|\bdoge\b','Dogecoin'),(r'shiba','Shiba Inu')],'Other crypto')
  return 'Crypto',topic
 if cat=='Sports' or (cat in ('World','Unclassified') and m(r'football|basketball|\bbaseball\b|mlbwins')):
  topic=froms([(r'\bwnba|(?:kx)?wnba',"Basketball: WNBA"),(r'ncaam[wb]b|ncaamb|ncaawb|college basketball|march madness',"Basketball: NCAA"),(r'(?:kx)?nba|pro basketball|\bnba\b',"Basketball: NBA"),(r'basketball',"Basketball: other professional"),(r'ncaaf|college football',"American football: NCAA"),(r'(?:kx)?nfl|pro football|super bowl',"American football: NFL"),(r'league of legends|kx(lol)',"Esports: League of Legends"),(r'counter.strike|kxcs2',"Esports: Counter-Strike"),(r'dota',"Esports: Dota 2"),(r'valorant',"Esports: Valorant"),(r'esports|e-sports',"Esports: other games"),(r"women.s tennis|kxwta|\bwta\b","Tennis: WTA"),(r"men.s tennis|kxatp|\batp\b","Tennis: ATP"),(r"tennis","Tennis: other tournaments"),(r'premier league|kxepl',"Soccer: English Premier League"),(r'champions league|kxucl',"Soccer: UEFA Champions League"),(r'soccer|fifa|la liga|serie a|world cup|bundesliga|ligue 1',"Soccer: other competitions"),(r'baseball|kx(mlb|kbo)|world series',"Baseball"),(r'nhl|ice hockey|stanley cup|\bhockey\b',"Ice hockey"),(r'formula|nascar|motorsport|racing|kx(f1|indycar)',"Motorsport"),(r'ufc|boxing|\bmma\b|mixed martial',"Combat sports"),(r'golf|pga|ryder cup',"Golf"),(r'cricket',"Cricket"),(r'pickleball|table tennis',"Table tennis and pickleball"),(r'rugby',"Rugby"),(r'chess',"Chess"),(r'the olympics|olympic',"Olympics (other sports)")],'Other sports')
  return 'Sports',topic
 if cat=='Elections': return 'Politics','Elections and primaries'
 if cat in ('Politics','World') and not m(r'airport|tsa check|flight (delay|cancell)'):
  topic=froms([(r'ceasefire|peace deal','Ceasefires and peace deals'),(r'attack|military|troops|war in|war with|invad|missile|airstrike','Military action and conflict'),(r'approv(al|e)|approval rating','Political approval polls'),(r'court|scotus|pardon|indict|prosecut|convict|prison|sentence|trial','Courts, pardons and prosecution'),(r'shutdown|government funding','Government funding and shutdowns'),(r'nominat|appointment|resign|step down|cabinet|depart','Appointments and departures'),(r'legislat|executive order|bill pass|pass.*bill|veto|sign into law|reconciliation','Legislation and executive policy'),(r'visit|meeting|diploma|summit','Diplomacy and official visits'),(r'primary|primaries|election|presidential winner|electoral college','Elections and primaries'),(r'tariff|trade deal','Trade policy'),(r'tweet|truth social|post on x','Social media posting')],'Other politics and world events')
  return 'Politics',topic
 if cat in ('Science and Technology','Health') or m('spacex|space launch') or cat=='Companies' and tag('AI'):
  topic=froms([(r'spaceflight|\bspace\b|spacex|rocket|moon|nasa','Spaceflight'),(r'\bAI\b|model release|lmsys|large language|\bLLM\b|chatgpt|openai','AI models and releases'),(r'covid|bird flu|measles|influenza|pandemic|infectious|pox|public health','Infectious disease'),(r'medicine|drug|fda|ozempic|weight.loss|prescriptions','Health and drug approvals'),(r'tech.*outage|internet outage','Technology outages')],'Other technology and science')
  return 'Tech',topic
 if cat in ('Culture','Social','Entertainment'):
  topic=froms([(r'grammy|music award|vma award','Music awards'),(r'oscar|emmy|golden globe|critics.choice|academy award|sag award','Film and TV awards'),(r'rotten tomatoes|metacritic|critics. score','Film and TV review scores'),(r'spotify|billboard|music chart|album|single release','Music releases and charts'),(r'box office|theater gross|opening weekend','Box office'),(r'netflix|streaming rank','Streaming rankings'),(r'reality tv|bachelor|survivor|big brother|love island|dancing with the stars','Reality television'),(r'super bowl.*(show|concert)|live music|concert|perform at|halftime show','Live performances and Super Bowl entertainment'),(r'youtube|subscriber|video views','Online video views and subscribers'),(r'tweet|social media|truth social','Social media posting')],'Other culture and entertainment')
  return 'Culture',topic
 if cat in ('Transportation','World') and m('tsa|flight|airport|air travel|airline'):return 'Finance','Air travel volume and disruptions'
 if cat in ('Transportation','Economics','Financials','Business','Companies','Commodities','Unclassified'):
  topic=froms([(r'tsa|flight delay|airport','Air travel volume and disruptions'),(r'indices|s&p|nasdaq|dow jones|russell 2000|(?:kx)?inx','Equity indexes'),(r'crude oil|\bwti|brent|kxwti','Crude oil prices'),(r'gasoline|natural gas|gas price|gas weekly','Gasoline and natural gas prices'),(r'gold price|silver price|metals|copper price|lithium','Metals prices'),(r'treasury|t-note|t-bill','Treasury yields'),(r'central bank|fomc|fed funds|federal reserve|\bfed\b','Central bank decisions'),(r'inflation|consumer price index|\bcpi\b|\bpce\b','Inflation'),(r'employment|unemployment|payroll|jobless|job opening|nonfarm','Labor market'),(r'recession|\bgdp\b|gross domestic','GDP and recession'),(r'foreign exchange|exchange rate|usd.jpy|euro.usd','Foreign exchange'),(r'tariff|trade deal','Trade policy'),(r'\bipo\b|public offering','IPOs'),(r'mortgage|housing|\brent\b|rentnyc','Housing and mortgages'),(r'stock price|share price|earnings|tesla deliveries|tesla production','Individual companies and stocks')],'Other economy and finance' if cat!='Unclassified' else 'Unclassified Kalshi series')
  return ('Finance' if topic!='Unclassified Kalshi series' else 'Other'),topic
 return 'Other','Unclassified Kalshi series'
with open(p/'series_topics.tmp','w') as f:
 out=csv.writer(f);out.writerow(['series','broad','topic'])
 for a in csv.DictReader(open(p/'series_active.csv')):
  k=a['series'];s=ref.get(k) or ref.get('KX'+k) or ref.get(k.removeprefix('KX')) or {}
  b,t=choose(k,s.get('category','Unclassified'),s.get('title') or a['title'], '|'.join(s.get('tags') or []))
  out.writerow([k,b,t])
(p/'series_topics.tmp').rename(p/'series_topics.csv')
