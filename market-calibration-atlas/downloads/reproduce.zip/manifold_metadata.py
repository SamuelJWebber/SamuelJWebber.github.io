import collections, csv,json,pathlib,datetime
p=pathlib.Path('/tmp/manidata')
# Stream one exported JSON array without retaining unneeded question descriptions or user records.
def rows(path):
 dec=json.JSONDecoder(); buf='';i=0
 with open(path) as f:
  while True:
   if len(buf)-i<200000: 
    s=f.read(2000000);buf=buf[i:]+s;i=0
   while i<len(buf) and buf[i] in ',[\r\n\t ':i+=1
   if i>=len(buf) or buf[i]==']': return
   try: row,end=dec.raw_decode(buf,i)
   except json.JSONDecodeError:
    add=f.read(2000000)
    if not add:raise
    buf=buf[i:]+add;i=0; continue
   yield row;i=end
end=1720137600000 # 2024-07-05 00:00 UTC
counts=collections.Counter(); out=[]
for r in rows(p/'markets.json'):
 if not(r.get('visibility')=='public' and not r.get('deleted') and r.get('outcomeType')=='BINARY' and r.get('isResolved') and r.get('resolution') in ('YES','NO') and 0<(r.get('resolutionTime') or 0)<=end and not r.get('nonPredictive') and r.get('token') in (None,'MANA')):continue
 finish=min(r['resolutionTime'],r.get('closeTime') or r['resolutionTime'])
 if finish - r['createdTime']<=86400000:continue
 g=r.get('groupSlugs') or [x['slug'] for x in r.get('groupLinks',[]) if x.get('slug')];counts.update(set(g))
 out.append([r['id'],r['question'],'|'.join(g),r['createdTime'],finish,r['resolutionTime'],int(r['resolution']=='YES')])
with open(p/'meta.csv','w') as f:
 w=csv.writer(f);w.writerow(['market_id','question','tags','start_ms','anchor_ms','resolved_ms','outcome']);w.writerows(out)
print(len(out),counts.most_common(100),flush=True)
