Market Calibration Atlas — reproduction guide

Population
The dashboard evaluates favorites with a quoted probability of at least 51%. Each contract can appear once at a given number of days before cutoff if its source has an eligible price. Flip both the quoted probability and the binary outcome when the other side was favored. The raw downloadable panels retain original listed odds and outcomes.

Prices and metrics
A whole percent requires a trade at that value. The fractional view distinguishes probabilities to 12 decimal places on the percentage scale to normalize floating-point representations. The optional centered window includes both endpoints and is clipped at 51% and 100%. Signed bias is the observed favorite win rate minus the mean favorite price. The Brier score uses each eligible price individually. For the exact probability lookup, event-clustered approximate 95% intervals are suppressed when the sample lacks 20 parent events, both wins and losses, or between-event variation.

Building the views
1. Restore the six original forecast panels and the matching venue archives using the enclosed venue-specific documentation. Use Python 3 with DuckDB. Some older reproduction scripts use the source and output directories given in their original notes.
2. Run scripts/aggregate.py with the six panel Parquet paths to generate topic IDs, snapshots and numerical summaries. Keep the same directory structure for subsequent commands. Run scripts/windows.py on those panels to produce the anonymized, day-specific inputs for exact and custom ranges. Run scripts/matched.py on the six panels and scripts/make_compare_summaries.py for the comparison matrix.
3. Follow the trade and election volume notes supplied in scripts/ to produce trailing turnover and cumulative recorded turnover up to each forecast in the volume sidecar directory. Cumulative files are stored in its cumulative/ subdirectory. Run scripts/history_volume.py with the six panel paths and --volumes pointing to that directory.
4. Run scripts/pool_markets.py with the directory containing the six normalized venue Parquet panels, then run scripts/pool_history.py after the six venue history shards have been generated. The aggregate uses venue-qualified contract and event IDs. Volume splits use the median within venue, topic and horizon. Pooled exact lookup windows read and combine the six venue inputs.
5. The calendar results keep days-to-cutoff fixed while grouping forecasts by the year or quarter of the price observation. The retrospective volume median is recalculated for each venue, event type, horizon and volume measure. Ties remain in the lower group. All volume measures omit turnover after the forecast.

Historical bid and ask samples
Run scripts/quote_predictit.py --output predictit.json to rebuild the selected 2022 PredictIt Senate and governor sample from fixed, checksum-verified hourly snapshots. Run scripts/quote_kalshi.py kalshi.parquet kalshi.json --cache <cache-directory> to rebuild the deterministic Kalshi sample from the downloaded trade panel and the exchange candle API. The coverage page also provides the full quote samples directly. Each JSON defines its own columns, source, timing and inclusion rules.

The quote view holds the midpoint favorite fixed (at least 51%) for every price comparison. Let b and a denote the YES bid and ask. The YES and NO midpoints are (a+b)/2 and 1−(a+b)/2. The YES and NO asks are a and 1−b. Proportional no-vig divides the favorite ask by the sum of both asks. Average buyer net cents per $1 contract equals 100 × mean(favorite won − favorite ask) minus the user-entered fee in cents. Fee is an assumption.


November 2026 additions

Reliability checks: place the downloadable polymarket.parquet and kalshi.parquet in dist/downloads/ beneath the reproduction folder, and the corresponding dashboard metadata in dist/data/<venue>/meta.json (included). With Python 3 and duckdb, numpy, pandas and scipy installed, run python scripts/validation.py. It verifies the existing summaries and rebuilds dist/data/validation.json. Event weights, clustered intervals, the single chronological split, and the fixed 2024/2025 venue/category mix are documented in the script and JSON metadata. Actual occurrence and settlement publication timestamps are unavailable. Held-out intervals condition on the fitted correction; they are not a trading-return backtest.

The Kalshi quote sample now selects up to 250 contracts per horizon in the original fixed hash order. Run python scripts/quote_kalshi.py dist/downloads/kalshi.parquet dist/data/quotes/kalshi.json --cache candle-cache --sample-size 250 --workers 8. --prior-sample permits reuse of validated original quote observations. The published sample retains all 776 prior observations and contains 1,198 usable rows across 1,068 contracts. API responses may change; the exact published rows are included. The refresh did not extend the underlying trade archive dates.

Independent October benchmark: PredictDesks Research, October 2026, CC BY 4.0 (https://creativecommons.org/licenses/by/4.0/). Source https://www.predictdesks.com/blog/research/prediction-market-accuracy and CSV https://www.predictdesks.com/research/prediction-market-accuracy-2026.csv. Download the original compressed CSV from the dashboard and decompress it to a chosen cache folder as prediction-market-accuracy-2026.csv. Run python scripts/refresh_audit.py --cache <that-folder> --output dist/data/research-audit.json. Its checksum, 11 exact duplicates, one invalid probability, and exclusions are recorded in the JSON. This separate high-volume sample has different price definitions and no individual event IDs or quote timestamps; never pool it into the main archive or claim event-cluster intervals for it.


INTRADAY ADDITION — NOVEMBER 2026
See scripts/intraday_notes.txt for offline rebuild commands, raw-data downloads, source credits, cohort selection, and interpretation limits. The analysis supports hourly forecasts and 15/30/60-minute moves. The large raw data downloads are linked from the Intraday & moves view rather than duplicated in this ZIP.


NEWS-REACTION ADDITION — NOVEMBER 2026
See scripts/shock_notes.txt for the onset-aligned shock study, the assumed news clock, exact-bar matching, and offline rebuild commands. Shock candidates and paths are downloadable from the News reaction section in Intraday & moves.


Stronger price-shock evidence checks
Read scripts/shock_evidence_notes.txt for frozen February replication, quiet-window controls, paired quote checks, clustered and multiple-test inference, missing-price bounds, and independently timed official announcements. Compact audit inputs and summaries are included. Download the larger March and February normalized Parquet bars separately from the dashboard. The findings do not establish universal overreaction or a general news-processing speed.


Additional forecasting-value studies
See scripts/expansion_README.md for the six new studies, exact commands, bundled and separate input paths, source provenance, and limitations. Weather cached inputs, sports derived tables, and crypto episode summaries are included; large venue panels, raw crypto inputs, and the quote-watch archive remain separate.
