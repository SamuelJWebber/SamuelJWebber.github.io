# Cross-platform labels from native group slugs. Rules run from specific to broad.
import csv,re,pathlib
p=pathlib.Path('/tmp/manidata')
groups=[
('Sports',[
('American football: NFL',r'nfl|super-bowl|kansas-city-chiefs|miami-dolphins|buffalo-bills'),
('American football: NCAA',r'college-football|ncaa-football'),('Basketball: NCAA',r'college-basketball|march-madness'),('Basketball: WNBA',r'wnba'),('Basketball: NBA',r'nba'),('Basketball: other professional',r'basketball'),
('Soccer: English Premier League',r'premiere?-league'),('Soccer: UEFA Champions League',r'uefa-champions-league'),('Soccer: other competitions',r'soccer|la-liga|fifa|bundesliga|barcalona|brasileiro|copa-libertadores|uefa'),
('Motorsport',r'formula-1|motorsport|auto-racing|nascar'),('Baseball',r'baseball|^mlb$'),('Ice hockey',r'hockey|^nhl$'),('Rugby',r'rugby'),('Cricket',r'cricket'),('Golf',r'^golf$|^pga$'),
('Chess',r'^chess$'),('Combat sports',r'^mma|combat-sports|^ufc$|mixed-martial|boxing'),('Tennis: other tournaments',r'tennis'),('Esports: League of Legends',r'league-of-legends'),('Esports: other games',r'esports'),('Cycling',r'road-bicycle|tour-de-france|^cycling$')]),
('Weather',[('Earthquakes and tsunamis',r'earthquake|tsunami'),('Storms and wildfires',r'hurricane|storm|wildfire|tornado'),('Rain and snow',r'rainfall|snowfall'),('Other weather',r'^weather$|extreme-weather|^climate$')]),
('Crypto',[('Bitcoin',r'bitcoin'),('Ethereum',r'ethereum'),('Solana',r'solana'),('Other crypto',r'crypto-prices|crypto-news|crypto-speculation|cryptocurrenc|^crypto$|^ftx$')]),
('Politics',[('Elections and primaries',r'elections?|primaries|us-2022-midterms'),('Courts, pardons and prosecution',r'trump-indictments|supreme-court|^scotus$|court-cases|sbf-trial|trial-of-the-century'),('Political approval polls',r'approval-rating'),('Military action and conflict',r'israelhamas-conflict|ukrainerussia-war|arabisraeli-conflict|^wars$|^nuclear-risk$|terrorism'),('Legislation and executive policy',r'^118th-congress$|legislation|executive-order')]),
('Finance',[('Individual companies and stocks',r'tech-stocks|^tesla$|^nvidia$'),('Equity indexes',r'ftse|nasdaq|sp-500|sp500|stock-marketweekly'),('Central bank decisions',r'federal-reserve|interest-rates|central-bank'),('Inflation',r'^inflation$'),('Foreign exchange',r'forex|foreign-exchange'),('Air travel volume and disruptions',r'flight-delays'),('Labor market',r'unemployment|payroll'),('GDP and recession',r'^gdp$|recession')]),
('Tech',[('AI models and releases',r'gpt|llms|technical-ai-timelines'),('AI safety and governance',r'ai-safety|ai-regulation|ai-risk|ai-alignment|ai-impacts'),('AI and machine learning',r'^ai$|^openai$|artificial-intelligence|machine-learning'),('Technology outages',r'githubdown|technology-outages'),('Spaceflight',r'^space$|spacex|rockets'),('Infectious disease',r'covid|monkeypox|bird-flu'),('Health and drug approvals',r'^medicine$|^health$|longevity'),('Mathematics and proofs',r'mathematics|competition-math|proofniks')]),
('Culture',[('Box office',r'^box-?office$'),('Film and TV awards',r'oscars-|emmy-awards|golden-globe'),('Film and TV review scores',r'rotten-tomatoes'),('Music releases and charts',r'billboard|spotify'),('Streaming rankings',r'streaming-ranking|netflix-ranking'),('Online video views and subscribers',r'subscriber-milestones|mr-beast'),('Esports and video games culture',r'video-games|^gaming$|nintendo|the-legend-of-zelda'),('Sports and media personalities',r'^destinygg$|^vaush$'),('Social media posting',r'^twitter$|^tweeter$'),('Television and films',r'television-film|^movies$|^tv$|^hollywood$')]),
('Other',[('Personal goals and forecasts',r'new-years-resolution|personal-goals|^personal$|commitment-devices|health-and-fitness'),('Manifold and forecasting communities',r'^manifold|manibadges|metamarkets|metaforecasting|predictions-on-predictions|^metaculus$')]),
('Sports',[('Other sports',r'^sports-default$|^football$|sports-betting|olympics')]),('Politics',[('Other politics and world events',r'politics|geopolitics|world-default|ukraine|^israel$|^russia$|donald-trump|life-of-biden|^china$|^nato$|^iran$|^taiwan$')]),('Finance',[('Other economy and finance',r'economics-default|^finance$|global-macro|^business$|^stocks$|wall-street-bets')]),('Tech',[('Other technology and science',r'technology-default|science-default|superconductivity|lk99|^programming$|^github$')]),('Culture',[('Other culture and entertainment',r'culture-default|entertainment|music-|^celebrities$|^youtube$|^manga$|^anime$|taylor-swift')])]
rules=[(re.compile(pat),b,t)for b,items in groups for t,pat in items]
with open(p/'topics.tmp','w') as f:
 out=csv.writer(f);out.writerow(['market_id','broad','topic'])
 for r in csv.DictReader(open(p/'meta.csv')):
  tags=r['tags'].split('|')
  if any(re.search('non-?predictive|^selfresolving$|^free-money$',t) for t in tags):continue
  b,t=next(((b,t) for rx,b,t in rules if any(rx.search(s) for s in tags)),('Other','Other or untagged Manifold questions'))
  out.writerow([r['market_id'],b,t])
(p/'topics.tmp').rename(p/'topics.csv')
