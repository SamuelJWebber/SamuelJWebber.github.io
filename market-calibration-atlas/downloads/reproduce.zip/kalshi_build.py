import os,time,pathlib,duckdb,csv,json
p=pathlib.Path('/tmp/kaldata');os.chdir(p); (p/'partials').mkdir(exist_ok=True)
c=duckdb.connect(str(p/'build.db'));c.execute("set timezone='UTC'");c.execute("set threads=3");c.execute("set memory_limit='1500MB'");c.execute("set preserve_insertion_order=false")
def waitp(glob,n):
 while len(list((p/'raw').glob(glob)))<n:time.sleep(1)
waitp('markets*.parquet',4)
print('prepare market universe',flush=True)
c.execute("""create or replace table meta as
 select ticker,event_ticker as event_id, split_part(event_ticker,'-',1) as series, title,open_time,close_time as anchor, case result when 'yes' then 1 else 0 end::tinyint as outcome
 from 'raw/markets*.parquet'
 where market_type='binary' and status='finalized' and result in('yes','no') and open_time<close_time-interval '1 day'
 and close_time <= TIMESTAMPTZ '2026-01-26 00:00:00+00' and not starts_with(regexp_replace(event_ticker,'^KX',''),'MVE') and event_ticker is not null
""")
c.execute("copy (select series,any_value(title) as title,count(*) as markets from meta group by 1 order by count(*) desc) to '/tmp/kaldata/series_active.csv' (header)")
print('eligible',c.sql('select count(*),count(distinct ticker),min(open_time),max(anchor) from meta').fetchall(),flush=True)
for i in range(16):
 name=f'trades-{i:04d}.parquet';waitp(name,1)
 part=p/'partials'/name
 if part.exists():continue
 print('processing',i,flush=True)
 c.execute(f"""copy (with x as (select t.ticker,t.yes_price as cents, t.created_time as ts, t.trade_id, floor(epoch(m.anchor-t.created_time)/86400)::integer as days
 from read_parquet('raw/{name}') t join meta m using(ticker)
 where t.created_time>=m.open_time and t.created_time<=m.anchor-interval '1 day' and t.yes_price between 0 and 100 and t.count>0)
 select ticker,days,arg_max(cents,struct_pack(t:=ts, id:=trade_id))::tinyint as cents,max(ts) as completed_at
 from x group by ticker,days) to '{part}.tmp' (format parquet,compression zstd)""")
 pathlib.Path(str(part)+'.tmp').rename(part)
print('trade aggregate done',flush=True)
c.execute("""create or replace table horizon as select ticker,days,arg_max(cents,completed_at)::tinyint as cents,max(completed_at) as completed_at from 'partials/*.parquet' group by all""")
while not (p/'series_topics.csv').is_file():time.sleep(1)
c.execute("""copy (select h.ticker as market_id,m.event_id,coalesce(s.topic,'Unclassified Kalshi series') as topic,coalesce(s.broad,'Other') as broad,h.days,h.cents::double/100.0 as price,m.outcome,m.anchor,h.completed_at
 from horizon h join meta m using(ticker) left join 'series_topics.csv' s using(series) order by h.days)
 to '/tmp/market_dash/kalshi.partial' (format parquet,compression zstd)""")
pathlib.Path('/tmp/market_dash/kalshi.partial').rename('/tmp/market_dash/kalshi.parquet')
c.execute("copy (select ticker, event_id,series,title,open_time,anchor,outcome from meta semi join horizon using(ticker)) to '/tmp/kaldata/metadata.parquet' (format parquet,compression zstd)")
for sql in ["select count(*),count(distinct market_id),count(distinct event_id),count(distinct topic),min(days),max(days),min(anchor),max(anchor),min(completed_at),max(completed_at),count(*) filter(where days<=90),max(epoch(anchor - days*interval '1 day'-completed_at))/3600, min(epoch(anchor - days*interval '1 day'-completed_at)) from '/tmp/market_dash/kalshi.parquet'", "select days,count(*) as n,count(distinct event_id) as events from '/tmp/market_dash/kalshi.parquet' where days in(1,7,30,90,120,180,365,500,730,1000,1150) group by 1 order by 1", "select broad,count(*) as n,count(distinct market_id), max(days) from '/tmp/market_dash/kalshi.parquet' group by 1 order by n desc"]:
 print(c.sql(sql).fetchall(),flush=True)
print('COMPLETE',flush=True)
