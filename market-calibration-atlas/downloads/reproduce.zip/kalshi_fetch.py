import pathlib,json,subprocess,concurrent.futures as f,time
root=pathlib.Path('/tmp/kaldata')
def get(row):
 path=row['path']; dest=root/'raw'/path; tmp=dest.with_suffix('.part')
 url='https://huggingface.co/datasets/TrevorJS/kalshi-trades/resolve/main/'+path
 for i in range(4):
  if tmp.exists() and tmp.stat().st_size>row['size']:tmp.unlink()
  if not dest.exists():
   r=subprocess.run(['curl','-fLsS','--retry','1','--connect-timeout','25','--max-time','240','-C','-','-o',str(tmp),url],capture_output=True)
   if tmp.exists() and tmp.stat().st_size==row['size'] and tmp.open('rb').read(4)==b'PAR1':tmp.rename(dest)
  if dest.exists():print('done',path,row['size'],flush=True);return
 print('FAILED',path,r.stderr[-180:],flush=True)
rows=[r for r in json.loads((root/'trev.json').read_text()) if r['path'].endswith('parquet')]
rows.sort(key=lambda x:(int(x['path'].split('-')[1][:4]),x['path']))
with f.ThreadPoolExecutor(max_workers=8) as e:list(e.map(get,rows))
