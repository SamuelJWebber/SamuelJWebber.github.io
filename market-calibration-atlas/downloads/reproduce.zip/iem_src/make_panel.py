"""Build a positive-volume daily close panel from University of Iowa monthly WTA price histories."""
from pathlib import Path
import datetime as dt,csv,sys
import duckdb,pandas as pd
dest=Path(__file__).parent
races={29:('2000-11-07','Dem'),78:('2004-11-02','Rep'),149:('2008-11-04','Dem'),351:('2012-11-06','Dem'),362:('2016-11-08','Dem'),384:('2020-11-03','Dem'),421:('2024-11-05','Rep')}
obs=[]
for mid,(ymd,winner) in races.items():
    date=dt.date.fromisoformat(ymd)
    for f in dest.glob(f'raw_{mid}_*.csv'):
        for row in csv.reader(f.open()):
            trade,code,n,value,lo,hi,last=row
            day=dt.date.fromisoformat(trade)
            if n=='0' or day>=date:continue
            p=float(last)
            assert 0<=p<=1
            assert code.upper().startswith(('REP','DEM','REFORM')),code
            eligible=code.upper().startswith(winner.upper())
            if mid==78 and code.endswith(('L52','G52')):
                # Bush won with just over 51% of the Democratic/Republican popular vote.
                eligible=eligible and code.endswith('L52')
            obs.append((f'IEM-{mid}-{code}',f'IEM-PRES-{date.year}','US presidential popular vote margin' if mid==78 and code.endswith(('L52','G52')) else 'US presidential national popular vote','Politics',(date-day).days,p,int(eligible),pd.Timestamp(date)))
panel=pd.DataFrame(obs, columns=['market_id','event_id','topic','broad','days','price','outcome','anchor'])
assert not panel.duplicated(['market_id','days']).any()
assert panel.groupby('market_id').outcome.nunique().max()==1
print(len(panel),panel.market_id.nunique(),panel.event_id.nunique(),panel.days.max(),len(panel[panel.days>365]),flush=True)
print(panel.groupby('event_id').agg({'market_id':'nunique','days':'max'}),flush=True)
if len(sys.argv)==1:
 assert len(list(dest.glob('raw_*.csv')))==161
 assert panel.event_id.nunique()==7
 duckdb.sql("copy (select * from panel) to '"+str(dest.parent/'iem.parquet')+"' (format parquet,compression zstd)")
