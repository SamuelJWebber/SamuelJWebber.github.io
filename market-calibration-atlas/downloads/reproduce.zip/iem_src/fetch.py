from pathlib import Path
from urllib.request import Request,urlopen
from concurrent.futures import ThreadPoolExecutor,as_completed
import sys,html,calendar,datetime as dt,re,time
from collections import Counter
root=Path(__file__).parent
years={29:[2000],78:[2004],149:[2006,2007,2008],351:[2011,2012],362:[2014,2015,2016],384:[2019,2020],421:[2023,2024]}
def fetch(t):
 mid,y,m=t
 url=f'https://iemweb.biz.uiowa.edu/iem_pricehistory/pricehistory/?Market_ID={mid}&Month={calendar.month_name[m]}&Year={y}'
 file=root/f'raw_{mid}_{y}_{m:02}.csv'
 if file.exists(): return
 for i in range(3):
  try:
   h=urlopen(Request(url,headers={'User-Agent':'Mozilla/5.0 (research analysis)'}),timeout=22).read().decode()
   rows=[]
   for rs in re.findall(r'<tr\b[^>]*>(.*?)</tr>',h,re.I|re.S):
    v=[html.unescape(re.sub('<[^>]+>','',t)).strip() for t in re.findall(r'<td\b[^>]*>([^<]*)',rs,re.I|re.S)]
    if len(v)!=7 or not re.fullmatch(r'\d{1,2}/\d{1,2}/\d{2}',v[0]):continue
    dd=dt.datetime.strptime(v[0],'%m/%d/%y').date()
    assert (dd.year,dd.month)==(y,m),str((dd,y,m))
    rows.append(','.join([dd.isoformat(),v[1],v[2].replace(',',''),v[3].replace(',',''),v[4],v[5],v[6]]))
   if not rows and 'Price History for' not in h:raise ValueError('Unexpected page')
   file.write_text('\n'.join(rows));return
  except Exception as e:
   if i==2:print('FAIL',t,str(e),flush=True)
   time.sleep(0.3)
if __name__=='__main__':
 if len(sys.argv)>1: years={int(part.split(':')[0]):list(map(int,part.split(':')[1].split(','))) for part in sys.argv[1:]}
 ts=[(mid,y,m) for mid,ys in years.items() for y in ys for m in range(1,13) if y!=max(ys) or m<12]
 with ThreadPoolExecutor(max_workers=6) as pool:
  for i,fn in enumerate(as_completed(pool.submit(fetch,t) for t in ts)): 
   fn.result()
   if i%30==0:print('finished',i+1,'of',len(ts),flush=True)
